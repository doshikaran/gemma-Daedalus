entry_points={
    'console_scripts': ['l0p4map = main:main'],
}
