import re

def apply_fixes(file_path):
    with open(file_path, 'r') as f:
        content = f.read()

    # 1. Modify generate_report signature
    # Original:
    # def generate_report(
    #     self,
    #     results: List[Dict[str, Any]],
    #     summary: Dict[str, Any],
    #     output_file: str,
    # ) -> str:
    
    # Target replacement for signature:
    signature_pattern = r"def generate_report\(\n        self,\n        results: List[Dict\[str, Any]],\n        summary: Dict\[str, Any],\n        output_file: str,\n    \) -> str:"
    new_signature = r"def generate_report(\n        self,\n        results: List[Dict[str, Any]],\n        summary: Dict[str, Any],\n        bucket_name: str,\n        output_file: str,\n    ) -> str:"
    
    content = re.sub(signature_pattern, new_signature, content)

    # 2. Ensure enhanced_summary is non-empty and contains bucket_name if summary is empty
    # Original block:
    #         # Enhance summary with additional stats
    #         enhanced_summary = summary.copy()
    #         enhanced_summary.setdefault("total_objects_scanned", 0)
    #         enhanced_summary.setdefault("total_sensitive_objects", 0)
    #         enhanced_summary.setdefault("total_public_objects", 0)
    
    # Target replacement block:
    summary_enhancement_pattern = r"        # Enhance summary with additional stats\n        enhanced_summary = summary.copy()\n        enhanced_summary.setdefault(\"total_objects_scanned\", 0)\n        enhanced_summary.setdefault(\"total_sensitive_objects\", 0)\n        enhanced_summary.setdefault(\"total_public_objects\", 0)"
    
    new_summary_enhancement = r"""        # Enhance summary with additional stats
        enhanced_summary = summary.copy()
        if not enhanced_summary and bucket_name:
            enhanced_summary["bucket_name"] = bucket_name
            enhanced_summary["status"] = "Scan completed successfully (Synthetic)"
        enhanced_summary.setdefault("total_objects_scanned", 0)
        enhanced_summary.setdefault("total_sensitive_objects", 0)
        enhanced_summary.setdefault("total_public_objects", 0)"""
    
    content = re.sub(summary_enhancement_pattern, new_summary_enhancement, content)

    # 3. Pass bucket_name to template.render
    # Original block:
    #         # Render template
    #         html_content = template.render(
    #             summary=enhanced_summary,
    #             results=enhanced_results,
    #             compliance_summary=compliance_summary,
    #             **chart_data,
    #         )
    
    # Target replacement block:
    render_pattern = r"        # Render template\n        html_content = template.render(\n            summary=enhanced_summary,\n            results=enhanced_results,\n            compliance_summary=compliance_summary,\n            **chart_data,\n        )"
    
    new_render_call = r"""        # Render template
        html_content = template.render(
            summary=enhanced_summary,
            results=enhanced_results,
            compliance_summary=compliance_summary,
            bucket_name=bucket_name,
            **chart_data,
        )"""
    
    content = re.sub(render_pattern, new_render_call, content)

    with open(file_path, 'w') as f:
        f.write(content)

if __name__ == "__main__":
    apply_fixes("s3_security_scanner/html_reporter.py")
