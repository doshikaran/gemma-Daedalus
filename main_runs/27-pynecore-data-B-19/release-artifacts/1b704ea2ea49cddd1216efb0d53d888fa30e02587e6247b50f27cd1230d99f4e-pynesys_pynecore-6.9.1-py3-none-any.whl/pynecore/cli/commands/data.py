import sys
from typing import TYPE_CHECKING, TypeAlias
from pathlib import Path
from enum import Enum
from datetime import datetime, timedelta, UTC

from typer import Typer, Option, Argument, Exit, Context, secho, colors, confirm, BadParameter

from rich import print as rprint
from rich.progress import (Progress, SpinnerColumn, TextColumn, BarColumn,
                           TimeElapsedColumn, TimeRemainingColumn, TaskID)

from ..app import app, app_state
from ..pluggable import PluggableCommand
from ...core.plugin import discover_plugins, load_plugin, PluginNotFoundError
from ...core.plugin import ProviderPlugin, ProviderError
from ...core.provider_string import is_provider_string, parse_provider_string
from ...lib.timeframe import in_seconds
from ...core.data_converter import DataConverter, SupportedFormats as InputFormats
from ...core.download_runner import (download_to_file, ConflictAction, DownloadConflict,
                                     DownloadPlan, DownloadProgress, DownloadError)
from ...core.ohlcv import OHLCVReader
from ...core.aggregator import validate_aggregation, aggregate_ohlcv
from ...core.syminfo import SymInfo

from ...utils.rich.date_column import DateColumn

__all__ = ['parse_date_or_days', 'validate_timeframe']

app_data = Typer(help="OHLCV related commands")
app.add_typer(app_data, name="data")

# Trick to avoid type checking errors
if TYPE_CHECKING:
    DateOrDays: TypeAlias = datetime
else:
    # DateOrDays is either a datetime or a number of days
    DateOrDays = str


def _list_provider_names() -> list[str]:
    """Return the sorted names of all installed data-provider plugins."""
    names = []
    for name, ep in discover_plugins().items():
        try:
            cls = ep.load()
            if isinstance(cls, type) and issubclass(cls, ProviderPlugin):
                names.append(name)
        except Exception:  # noqa
            pass
    return sorted(names)


def _choose_provider() -> str | None:
    """Open the installed-provider picker and return its selected entry point."""
    from ..utils.provider_picker import ProviderChoice, ProviderPicker

    providers: list[ProviderChoice] = []
    for name, ep in discover_plugins().items():
        try:
            cls = ep.load()
            if isinstance(cls, type) and issubclass(cls, ProviderPlugin):
                display_name = getattr(cls, 'plugin_name', '')
                providers.append(ProviderChoice(name, display_name))
        except Exception:  # noqa
            pass
    providers.sort(key=lambda item: item.id)
    return ProviderPicker(providers).run()


def _resolve_provider_class(provider_name: str) -> type[ProviderPlugin]:
    """
    Load a data-provider plugin by name.

    :param provider_name: Provider entry-point name (e.g. ``"ccxt"``).
    :return: The provider plugin class.
    :raises ValueError: If the name is unknown or refers to a non-provider
        plugin. The caller's ``except (ImportError, ValueError)`` prints it.
    """
    try:
        cls = load_plugin(provider_name)
    except PluginNotFoundError:
        names = ', '.join(_list_provider_names()) or '(none)'
        raise ValueError(f"Unknown provider '{provider_name}'. Available providers: {names}")
    if not (isinstance(cls, type) and issubclass(cls, ProviderPlugin)):
        raise ValueError(f"Plugin '{provider_name}' is not a data provider.")
    return cls


# Available output formats
class OutputFormat(Enum):
    CSV = 'csv'
    JSON = 'json'


def _typer_validate_timeframe(value: str) -> str:
    """Typer callback wrapper: convert ValueError into a clean BadParameter."""
    try:
        return validate_timeframe(value)
    except ValueError as e:
        raise BadParameter(str(e))


def _typer_parse_date_or_days(value: str) -> "datetime | str":
    """Typer callback wrapper: convert ValueError into a clean BadParameter."""
    try:
        return parse_date_or_days(value)
    except ValueError as e:
        raise BadParameter(str(e))


# TV-compatible timeframe validation function
def validate_timeframe(value: str) -> str:
    """
    Validate TV-compatible timeframe string.

    :param value: Timeframe string to validate
    :return: Validated timeframe string
    :raises ValueError: If timeframe is invalid
    """
    value = value.upper()
    try:
        # Test if it's a valid TV timeframe by trying to convert to seconds
        in_seconds(value)
    except (ValueError, AssertionError):
        raise ValueError(
            f"Invalid timeframe: {value}. Must be a valid timeframe in TradingView format "
            f"(e.g. '1', '5', '60', '1D', '1W', '1M')."
        )
    return value


def parse_date_or_days(value: str) -> datetime | str:
    """
    Parse a date, a number of days, ``"continue"``, or ``"now"``.

    :param value: User-supplied string.
    :return: A ``datetime`` (UTC, seconds/microseconds zeroed) or the ``"continue"`` sentinel.
    :raises ValueError: If the value matches none of the accepted forms. Typer
        converts this into a clean CLI error; in-process callers (e.g. the
        symbol-browser wizard) can catch it directly.
    """
    if value == 'continue':
        return value
    if not value:
        return datetime.now(UTC).replace(second=0, microsecond=0)
    if value.strip().lower() == 'now':
        return datetime.now(UTC).replace(second=0, microsecond=0)
    try:
        return datetime.fromisoformat(str(value))
    except ValueError:
        pass
    try:
        days = int(value)
    except ValueError:
        raise ValueError(f"Invalid date format or days number: {value}")
    if days < 0:
        raise ValueError("Days cannot be negative")
    return (datetime.now(UTC) - timedelta(days=days)).replace(second=0, microsecond=0)


def _format_date_default(value, fallback: str) -> str:
    """Convert a parsed ``--from`` / ``--to`` value back into a user-friendly
    string for the symbol-browser wizard's default fields.

    ``parse_date_or_days`` accepts the result as input, so the round-trip is
    semantically loss-free.
    """
    if isinstance(value, str):
        return value
    if isinstance(value, datetime):
        ref = value if value.tzinfo else value.replace(tzinfo=UTC)
        if abs((datetime.now(UTC) - ref).total_seconds()) < 60:
            return "now"
        return value.strftime("%Y-%m-%d %H:%M:%S")
    return fallback


@app_data.command(cls=PluggableCommand)
def download(
        ctx: Context,
        provider: str | None = Argument(None, show_default=False,
                                        help="Provider name (e.g. 'ccxt'), a full provider string "
                                             "(e.g. 'ccxt:BYBIT:BTC/USDT:USDT@1D'), or the path of an "
                                             "already downloaded .ohlcv/.toml file to re-download it "
                                             "with its saved provider string (typically with -f continue). "
                                             "Omit it in a terminal to choose interactively"),
        symbol: str | None = Option(None, '--symbol', '-s', show_default=False,
                                    help="Symbol (e.g. BYBIT:BTC/USDT:USDT). Ignored when the "
                                         "provider string already contains a symbol"),
        list_symbols: bool = Option(False, '--list-symbols', '-ls',
                                    help="List available symbols of the provider"),
        list_brokers: bool = Option(False, '--list-brokers', '-lb',
                                    help="List available brokers/exchanges of a multi-broker provider"),
        timeframe: str = Option('1D', '--timeframe', '-tf', callback=_typer_validate_timeframe,
                                help="Timeframe in TradingView format (e.g., '1', '5S', '1D', '1W'). "
                                     "Ignored when the provider string contains an @timeframe"),
        time_from: DateOrDays = Option("continue", '--from', '-f',
                                       callback=_typer_parse_date_or_days, formats=[],
                                       metavar="[%Y-%m-%d|%Y-%m-%d %H:%M:%S|NUMBER]|continue",
                                       help="Start date or days back from now, or 'continue' to resume last download,"
                                            " or one year if no data"),
        time_to: DateOrDays = Option(datetime.now(UTC).replace(second=0, microsecond=0), '--to', '-t',
                                     callback=_typer_parse_date_or_days, formats=[],
                                     metavar="[%Y-%m-%d|%Y-%m-%d %H:%M:%S|NUMBER]",
                                     help="End date or days from start date"),
        show_info: bool = Option(False, '--symbol-info', '-si', help="Show symbol info"),
        force_save_info: bool = Option(False, '--force-save-info', '-fi',
                                       help="Force save symbol info"),
        truncate: bool = Option(False, '--truncate', '-tr',
                                help="Truncate file before downloading, all data will be lost"),
        chunk_size: int | None = Option(None, '--chunk-size', '-cs',
                                        help="Number of bars to download per API request. "
                                             "Overrides automatic detection based on exchange limits. "
                                             "Useful for exchanges with timeframe-specific limits (e.g., Bitget 1w: 12). "
                                             "Lower values = slower but safer, higher values = faster but may hit API limits."),
        extra_data: bool = Option(False, '--extra-data/--no-extra-data', '-ed',
                                  help="Also download provider extra fields (ask/bid/spread) into a "
                                       ".extra.csv sidecar. Off by default: extra fields cost extra "
                                       "requests and slow every later backtest that loads them. "
                                       "Ignored by providers that have no extra fields."),
):
    """
    Download historical OHLCV data

    The provider can be given either as a bare name plus ``-s``/``-tf`` flags
    (``pyne data download ccxt -s BYBIT:BTC/USDT:USDT -tf 1D``) or as a single
    provider string in the same syntax as ``pyne run``
    (``pyne data download ccxt:BYBIT:BTC/USDT:USDT@1D``). Both forms are equivalent.
    """
    try:
        from ...core.config import ensure_config
        from ...core.download_info import read_download_provider

        if provider is None:
            if not sys.stdin.isatty():
                secho("Error: Provider is required in non-interactive mode.",
                      err=True, fg=colors.RED)
                raise Exit(2)
            provider = _choose_provider()
            if provider is None:
                return

        # A .ohlcv/.toml path re-downloads with the provider string persisted
        # in the [download] section of its syminfo TOML.
        if provider.endswith(('.ohlcv', '.toml')):
            given = Path(provider)
            path = next((p for p in (given, app_state.data_dir / given.name) if p.exists()), None)
            if path is None:
                secho(f"Error: File not found: {provider}", err=True, fg=colors.RED)
                raise Exit(1)
            saved = read_download_provider(path.with_suffix('.toml'))
            if saved is None:
                secho(f"Error: {path.with_suffix('.toml').name} has no [download] provider "
                      f"section. Download it once with a provider string to record it.",
                      err=True, fg=colors.RED)
                raise Exit(1)
            provider = saved

        # Resolve the provider plugin from either the bare name or the leading
        # segment of a provider string.
        string_mode = is_provider_string(provider)
        provider_name = (provider.split(':', 1)[0] if string_mode else provider).lower()
        provider_class = _resolve_provider_class(provider_name)

        # --list-brokers needs only the provider plugin
        if list_brokers:
            try:
                brokers = provider_class.get_list_of_brokers()
            except NotImplementedError:
                secho(f"Provider '{provider_name}' does not support listing brokers.",
                      err=True, fg=colors.RED)
                raise Exit(1)
            except ProviderError as e:
                secho(f"Error: {e}", err=True, fg=colors.RED)
                raise Exit(1)
            ordered = sorted(brokers)
            id_width = max((len(b.id) for b in ordered), default=0)
            for b in ordered:
                print(f"{b.id:<{id_width}}  {b.name}".rstrip() if b.name else b.id)
            return

        # In string mode, derive broker/symbol/timeframe from the provider
        # string; the broker is re-folded into the symbol so multi-broker
        # providers (which split it off internally) receive what they expect.
        if string_mode:
            ps = parse_provider_string(provider, multi_broker=provider_class.multi_broker)
            if ps.symbol and symbol:
                raise ValueError("Symbol given both in the provider string and via "
                                 "-s/--symbol; use only one.")
            resolved_symbol = ps.symbol or symbol
            if ps.timeframe is not None:
                timeframe = validate_timeframe(ps.timeframe)
            if ps.broker:
                symbol = f"{ps.broker}:{resolved_symbol}" if resolved_symbol else ps.broker
            else:
                symbol = resolved_symbol

        config = None
        config_cls: type | None = getattr(provider_class, 'Config', None)
        if config_cls is not None:
            config = ensure_config(config_cls,
                                   app_state.config_dir / 'plugins' / f'{provider_name}.toml')

        def _fetch_symbols(sym: str | None) -> "tuple[ProviderPlugin, list[str], Path | None]":
            """Construct the provider for ``sym`` and, when it is a selector-only
            value (the provider leaves ``self.symbol`` as ``None``), fetch its
            symbol list for the TUI. Shown behind a spinner.

            :return: ``(provider_instance, symbol_list, tui_ohlcv_dir)``.
            """
            slist: list[str] = []
            tdir: Path | None = None
            with Progress(SpinnerColumn(), TextColumn("{task.description}"),
                          transient=True) as fetch_progress:
                fetch_progress.add_task(description="Fetching market data...", total=None)
                if sym is None:
                    inst: ProviderPlugin = provider_class(symbol=None, timeframe=timeframe,
                                                          config=config)
                    tdir = app_state.data_dir
                else:
                    inst = provider_class(symbol=sym, timeframe=timeframe,
                                          ohlcv_dir=app_state.data_dir, config=config)
                if inst.symbol is None and sys.stdin.isatty():
                    slist = inst.get_list_of_symbols()
                    tdir = app_state.data_dir
            return inst, slist, tdir

        def _browse_symbols(inst: "ProviderPlugin", slist: list[str], tdir: Path,
                            *, selector: str | None, can_go_back: bool) -> bool:
            """Launch the symbol browser TUI for ``inst``.

            :param selector: Broker/exchange selector the provider was opened
                with (the browsed symbols carry no such prefix), or None for
                single-broker providers. Used to build the canonical provider
                string persisted next to the download.
            :param can_go_back: When True, ESC returns to the broker picker
                instead of quitting the command.
            :return: True if the user asked to go back to the broker list.
            """
            from ..utils.symbol_browser import SymbolBrowser
            prefix = f"{provider_name}:{selector}" if selector else provider_name
            browser = SymbolBrowser(
                inst,
                slist,
                ohlcv_dir=tdir,
                provider_string_prefix=prefix,
                default_timeframe=timeframe,
                default_from=_format_date_default(time_from, "continue"),
                default_to=_format_date_default(time_to, "now"),
                default_chunk_size=chunk_size,
                default_extra_data=extra_data,
                can_go_back=can_go_back,
            )
            browser.run()
            return browser.go_back

        # Multi-broker providers (CCXT, cTrader) need a broker chosen before a
        # symbol can be browsed. When none was given and we're interactive, drop
        # into a broker picker first, then the symbol browser. The two form a
        # loop: ESC in the symbol browser returns to the broker list rather than
        # exiting, and a failure opening the chosen broker (e.g. an exchange that
        # needs API credentials) returns to the picker with the error shown so
        # another broker can be tried. Only the picker itself exits the command.
        if (provider_class.multi_broker and symbol is None
                and not list_symbols and sys.stdin.isatty()):
            try:
                with Progress(SpinnerColumn(), TextColumn("{task.description}"),
                              transient=True) as progress:
                    progress.add_task(description="Fetching available brokers...", total=None)
                    brokers = provider_class.get_list_of_brokers()
            except (NotImplementedError, ProviderError) as e:
                secho(f"Error: {e}", err=True, fg=colors.RED)
                raise Exit(1)
            from ..utils.broker_picker import BrokerPicker
            display_name = getattr(provider_class, 'plugin_name', provider_name)
            picker = BrokerPicker(sorted(brokers), provider_name=display_name)
            while True:
                chosen = picker.run()
                if chosen is None:
                    return
                try:
                    provider_instance, symbols_list, tui_ohlcv_dir = _fetch_symbols(chosen)
                except (NotImplementedError, ProviderError) as e:
                    picker.error = str(e)
                    continue
                picker.error = None
                assert tui_ohlcv_dir is not None
                if _browse_symbols(provider_instance, symbols_list, tui_ohlcv_dir,
                                   selector=chosen, can_go_back=True):
                    continue
                return

        # If list_symbols is True, we show the available symbols then exit
        if list_symbols:
            try:
                with Progress(SpinnerColumn(), TextColumn("{task.description}"),
                              transient=True) as progress:
                    progress.add_task(description="Fetching market data...", total=None)
                    provider_instance = provider_class(symbol=symbol, config=config)
                    symbols = provider_instance.get_list_of_symbols()
            except (NotImplementedError, ProviderError) as e:
                secho(f"Error: {e}", err=True, fg=colors.RED)
                raise Exit(1)
            for s in symbols:
                print(s)
            return

        # Some providers (e.g. CCXT) accept a selector-only ``--symbol`` (just
        # the exchange name): the constructor recognises it and leaves
        # ``self.symbol`` as ``None``. That signals "we know which backend but
        # not which instrument yet" — drop into the TUI to let the user pick.
        # Otherwise proceed to the download path.
        try:
            provider_instance, symbols_list, tui_ohlcv_dir = _fetch_symbols(symbol)
        except NotImplementedError as e:
            secho(f"Error: {e}", err=True, fg=colors.RED)
            secho("Pass a symbol explicitly with -s/--symbol.",
                  err=True, fg=colors.YELLOW)
            raise Exit(1)
        except ProviderError as e:
            secho(f"Error: {e}", err=True, fg=colors.RED)
            raise Exit(1)

        if provider_instance.symbol is None:
            if not sys.stdin.isatty():
                secho("Error: Symbol is required "
                      "(or use --list-symbols for non-interactive listing).",
                      err=True, fg=colors.RED)
                raise Exit(1)
            assert tui_ohlcv_dir is not None
            _browse_symbols(provider_instance, symbols_list, tui_ohlcv_dir,
                            selector=symbol, can_go_back=False)
            return

        # Download symbol info if not exists
        if force_save_info or not provider_instance.is_symbol_info_exists():
            with Progress(SpinnerColumn(finished_text="[green]✓"), TextColumn("{task.description}")) as progress:
                # Get symbol info task
                task = progress.add_task(description="Fetching symbol info...", total=1)
                sym_info = provider_instance.get_symbol_info(force_update=force_save_info)

                # Complete task
                progress.update(task, completed=1)

                # Print symbol info
                if show_info:
                    rprint(sym_info)
        else:  # We have symbol info, just show it
            sym_info = provider_instance.get_symbol_info()
            if show_info:
                rprint(sym_info)

        # Hand any plugin-injected CLI flags to the provider; it reads only its
        # own keys (see CLIPlugin.cli_params / PluggableCommand).
        provider_instance.plugin_params = getattr(ctx, "plugin_params", {})

        # Progress display is created only once the download range is resolved
        # (the bar's date column and total both need it).
        dl_progress: Progress | None = None
        dl_task: TaskID | None = None

        def on_start(plan: DownloadPlan) -> None:
            """ Open the progress display matching the resolved range """
            nonlocal dl_progress, dl_task
            if plan.fetch_all:
                # fetch_all provider: use spinner-only progress (no time-based progress bar)
                display = Progress(
                    SpinnerColumn(finished_text="[green]✓"),
                    TextColumn("{task.description}"),
                    TimeElapsedColumn(),
                )
                display.start()
                dl_task = display.add_task(
                    description="Downloading all available OHLCV data...",
                    total=None,
                )
            else:
                display = Progress(
                    SpinnerColumn(finished_text="[green]✓"),
                    TextColumn("{task.description}"),
                    DateColumn(plan.time_from),
                    BarColumn(),
                    TimeElapsedColumn(),
                    "/",
                    TimeRemainingColumn(),
                )
                display.start()
                dl_task = display.add_task(
                    description="Downloading OHLCV data...",
                    total=plan.total_seconds,
                )
            dl_progress = display

        def on_progress(progress_info: DownloadProgress) -> None:
            """ Callback to update progress """
            assert dl_progress is not None and dl_task is not None
            dl_progress.update(dl_task, completed=progress_info.elapsed_seconds)

        def on_conflict(conflict: DownloadConflict) -> ConflictAction:
            """ Ask the user before an existing file gets truncated """
            secho(f"The start date (from: {conflict.time_from}) is before the start of the "
                  f"existing file ({conflict.existing_start}).\n"
                  f"If you continue, the file will be truncated.",
                  fg=colors.YELLOW)
            confirm("Do you want to continue?", abort=True)
            return 'truncate'

        try:
            assert provider_instance is not None
            download_to_file(
                provider_instance,
                time_from=time_from, time_to=time_to,
                truncate=truncate, chunk_size=chunk_size, extra_data=extra_data,
                syminfo=sym_info,
                on_start=on_start, on_progress=on_progress, on_conflict=on_conflict,
                provider_string=f"{provider_name}:{symbol}@{timeframe}",
            )
        except DownloadError as e:
            secho(f"Error: {e}", err=True, fg=colors.RED)
            raise Exit(1)
        finally:
            if dl_progress is not None:
                dl_progress.stop()

    except ProviderError as e:
        secho(f"Error: {e}", err=True, fg=colors.RED)
        raise Exit(1)
    except (ImportError, ValueError) as e:
        secho(str(e), err=True, fg=colors.RED)
        raise Exit(2)


@app_data.command()
def convert_to(
        ohlcv_path: Path = Argument(..., dir_okay=False, file_okay=True,
                                    help="Data file to convert (*.ohlcv)"),
        fmt: OutputFormat = Option(
            'csv', '--format', '-f',
            case_sensitive=False,
            help="Output format"),
        as_datetime: bool = Option(False, '--as-datetime', '-dt',
                                   help="Save timestamp as datetime instead of UNIX timestamp"),
):
    """
    Convert downloaded data from pyne's OHLCV format to another format
    """
    # Check file format and extension
    if ohlcv_path.suffix == "":
        # No extension, add .ohlcv
        ohlcv_path = ohlcv_path.with_suffix(".ohlcv")

    # Expand data path
    if len(ohlcv_path.parts) == 1:
        ohlcv_path = app_state.data_dir / ohlcv_path
    # Check if data exists
    if not ohlcv_path.exists():
        secho(f"Data file '{ohlcv_path}' not found!", fg="red", err=True)
        raise Exit(1)

    out_path = None
    with Progress(SpinnerColumn(finished_text="[green]✓"), TextColumn("{task.description}")) as progress:
        # Convert
        with OHLCVReader(str(ohlcv_path)) as ohlcv_reader:
            if fmt.value == OutputFormat.CSV.value:
                task = progress.add_task(description="Converting to CSV...", total=1)
                out_path = str(ohlcv_path.with_suffix('.csv'))
                ohlcv_reader.save_to_csv(out_path, as_datetime=as_datetime)

            elif fmt.value == OutputFormat.JSON.value:
                task = progress.add_task(description="Converting to JSON...", total=1)
                out_path = str(ohlcv_path.with_suffix('.json'))
                ohlcv_reader.save_to_json(out_path, as_datetime=as_datetime)

            else:
                raise ValueError(f"Unsupported format: {fmt}")

            # Complete task
            progress.update(task, completed=1)

    if out_path:
        secho(f'Data file converted successfully to "{out_path}"!')


@app_data.command()
def convert_from(
        file_path: Path = Argument(..., help="Path to CSV/JSON/TXT file to convert"),
        provider: str = Option(None, '--provider', '-p',
                               help="Data provider, can be any name"),
        symbol: str | None = Option(None, '--symbol', '-s', show_default=False,
                                    help="Symbol (default: from file name)"),
        tz: str = Option('UTC', '--timezone', '-tz', help="Timezone"),
):
    """
    Convert data from other sources to pyne's OHLCV format
    """
    # Expand file path if only filename is provided (look in workdir/data)
    if len(file_path.parts) == 1:
        file_path = app_state.data_dir / file_path

    # Check if file exists
    if not file_path.exists():
        secho(f'File "{file_path}" not found!', fg=colors.RED, err=True)
        raise Exit(1)

    # Auto-detect symbol and provider from filename if not provided
    detected_symbol, detected_provider = DataConverter.guess_symbol_from_filename(file_path)

    if symbol is None:
        symbol = detected_symbol

    if provider is None and detected_provider is not None:
        provider = detected_provider

    # Fallback: peek into CSV content (Databento exports carry the symbol as a column)
    if (symbol is None or provider is None) and file_path.suffix.lower() == '.csv':
        content_symbol, content_provider = DataConverter.guess_symbol_from_csv_content(file_path)
        if symbol is None and content_symbol:
            symbol = content_symbol
        if provider is None and content_provider:
            provider = content_provider

    # Ensure we have required parameters
    if symbol is None:
        secho(f"Error: Could not detect symbol from filename '{file_path.name}'!", fg=colors.RED, err=True)
        secho("Please provide a symbol using --symbol option.", fg=colors.YELLOW, err=True)
        raise Exit(1)

    # Auto-detect file format
    fmt = file_path.suffix[1:].lower()
    if fmt not in InputFormats:
        raise ValueError(f"Unsupported file format: {file_path}")

    # Use the enhanced DataConverter for automatic conversion
    converter = DataConverter()

    try:
        with Progress(SpinnerColumn(finished_text="[green]✓"), TextColumn("{task.description}")) as progress:
            task = progress.add_task(description=f"Converting {fmt.upper()} to OHLCV format...", total=1)

            # Perform conversion with automatic TOML generation
            converter.convert_to_ohlcv(
                file_path=Path(file_path),
                provider=provider,
                symbol=symbol,
                timezone=tz,
                force=True
            )

            progress.update(task, completed=1)

    except Exception as e:
        secho(f"Error: {e}", err=True, fg=colors.RED)
        raise Exit(1)

    secho(f'Data file converted successfully to "{file_path}".')
    secho(f'A configuration file was automatically generated for you at "{file_path.with_suffix(".toml")}". '
          f'Please check it and adjust it to match your needs.')


@app_data.command()
def aggregate(
        source: Path = Argument(..., help="Source .ohlcv file (searches in workdir/data/ if only name given)"),
        timeframe: str = Option(..., '--timeframe', '-tf', callback=_typer_validate_timeframe,
                                help="Target timeframe in TradingView format (e.g., '60', '1D', '1W')"),
        output: Path | None = Option(None, '--output', '-o',
                                     help="Custom output path (auto-generated if not specified)"),
):
    """
    Aggregate OHLCV data from a lower timeframe to a higher one.

    Combines multiple smaller candles into larger timeframe candles.
    For example: daily candles → weekly candles, or 5-minute → 1-hour.

    The source timeframe is read from the .toml metadata file.
    Only upscaling is supported (small → large timeframe).
    """
    # Resolve source path
    if len(source.parts) == 1:
        source = app_state.data_dir / source
    if source.suffix == "":
        source = source.with_suffix(".ohlcv")

    if not source.exists():
        secho(f"Error: Source file not found: {source}", err=True, fg=colors.RED)
        raise Exit(1)

    if source.suffix != '.ohlcv':
        secho(f"Error: Source must be .ohlcv format, got: {source.suffix}", err=True, fg=colors.RED)
        raise Exit(1)

    # Read source timeframe from TOML
    toml_path = source.with_suffix('.toml')
    if not toml_path.exists():
        secho(f"Error: Metadata file not found: {toml_path}", err=True, fg=colors.RED)
        raise Exit(1)

    try:
        syminfo = SymInfo.load_toml(toml_path)
    except Exception as e:
        secho(f"Error reading metadata: {e}", err=True, fg=colors.RED)
        raise Exit(1)

    source_tf = syminfo.period

    # Validate timeframe compatibility
    try:
        validate_aggregation(source_tf, timeframe)
    except ValueError as e:
        secho(f"Error: {e}", err=True, fg=colors.RED)
        raise Exit(1)

    # Generate output path if not specified
    if output is None:
        # Replace the timeframe suffix in the filename: symbol_1D.ohlcv → symbol_1W.ohlcv
        stem = source.stem
        # If the stem ends with the source timeframe, replace it
        if stem.endswith(f"_{source_tf}"):
            new_stem = stem[:-len(source_tf)] + timeframe
        else:
            new_stem = f"{stem}_{timeframe}"
        out_path: Path = source.parent / f"{new_stem}.ohlcv"
    else:
        out_path = output

    if len(out_path.parts) == 1:
        out_path = app_state.data_dir / out_path

    if out_path.suffix == "":
        out_path = out_path.with_suffix(".ohlcv")

    # Confirm before overwriting existing file
    if out_path.exists():
        secho(f"Target file already exists: {out_path.name}", fg=colors.YELLOW)
        confirm("Overwrite?", abort=True)

    # Perform aggregation
    with Progress(
            SpinnerColumn(finished_text="[green]✓"),
            TextColumn("{task.description}"),
    ) as progress:
        progress.add_task(
            description=f"Aggregating {source_tf} → {timeframe}...",
            total=None,
        )

        try:
            # Use data timezone from TOML for correct day/week/month boundaries,
            # and the session opens so intraday bars anchor to the session the
            # way TradingView does (no-op for on-hour / 24-7 markets). The
            # symbol type and opening hours drive the multi-period (nD/nW/nM)
            # scheduled grid (see the resampler module docs).
            from zoneinfo import ZoneInfo
            data_tz = ZoneInfo(syminfo.timezone) if syminfo.timezone else None
            source_count, target_count = aggregate_ohlcv(
                source, out_path, timeframe, tz=data_tz,
                session_starts=syminfo.session_starts,
                opening_hours=syminfo.opening_hours,
                sym_type=syminfo.type, source_tf=source_tf)
        except Exception as e:
            secho(f"Error during aggregation: {e}", err=True, fg=colors.RED)
            raise Exit(1)

    # Copy and update TOML for the target file
    target_toml = out_path.with_suffix('.toml')
    try:
        syminfo.period = timeframe
        syminfo.save_toml(target_toml)
    except Exception as e:
        secho(f"Warning: Could not write metadata: {e}", fg=colors.YELLOW)

    secho(f"Aggregated {source_count:,} → {target_count:,} candles ({source_tf} → {timeframe})")
    secho(f'Output: "{out_path}"')


_SYMBOL_MAP_HEADER = """\
# Global symbol map: TradingView-style script symbols -> provider-qualified
# native symbols. The value format matches the [download] provider string
# ("provider:BROKER:SYMBOL"). An optional ":TF" suffix on the KEY overrides a
# single timeframe. One entry serves both backtest (the .ohlcv file is derived
# via the provider's naming convention) and live (a native PluginSymbol).
#
# Example:
#   [symbol_map]
#   "BINANCE:BTCUSDT" = "ccxt:BYBIT:BTC/USDT:USDT"
#   "NASDAQ:AAPL" = "capitalcom:AAPL"
#   "NASDAQ:AAPL:60" = "capitalcom:AAPL"
"""


@app_data.command(name="map")
def map_symbol(
        tv_symbol: str = Argument(...,
                                  help="TradingView-style symbol key, e.g. 'NASDAQ:AAPL' "
                                       "or 'NASDAQ:AAPL:60' for a per-timeframe override"),
        provider_symbol: str = Argument(...,
                                        help="Provider-qualified native symbol, e.g. "
                                             "'capitalcom:AAPL' or 'ccxt:BYBIT:BTC/USDT:USDT'"),
):
    """
    Add or update a global symbol_map.toml entry.

    Writes <workdir>/config/symbol_map.toml, creating it with a documented
    header when absent and preserving existing entries and comments otherwise.
    """
    from ...core.symbol_map import MappedSymbol, SYMBOL_MAP_FILENAME

    mapped = MappedSymbol.parse(provider_symbol)
    if mapped is None:
        secho(
            f"Invalid provider symbol {provider_symbol!r}: expected "
            f"'provider:native_symbol' (e.g. 'capitalcom:AAPL').",
            err=True, fg=colors.RED)
        raise Exit(1)

    path = app_state.config_dir / SYMBOL_MAP_FILENAME
    key_line = f'"{tv_symbol}" = "{provider_symbol}"'

    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(f"{_SYMBOL_MAP_HEADER}\n[symbol_map]\n{key_line}\n",
                        encoding="utf-8")
        secho(f'Created {path} with {tv_symbol} -> {provider_symbol}')
        return

    lines = path.read_text(encoding="utf-8").splitlines()
    key_prefix = f'"{tv_symbol}"'
    replaced = False
    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped.startswith(key_prefix):
            after = stripped[len(key_prefix):].lstrip()
            if after.startswith("="):
                lines[i] = key_line
                replaced = True
                break

    if not replaced:
        # Insert right after the [symbol_map] header, or append the whole
        # table when the file has no [symbol_map] section yet.
        header_idx = next(
            (i for i, ln in enumerate(lines) if ln.strip() == "[symbol_map]"), None)
        if header_idx is None:
            if lines and lines[-1].strip():
                lines.append("")
            lines.append("[symbol_map]")
            lines.append(key_line)
        else:
            lines.insert(header_idx + 1, key_line)

    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    verb = "Updated" if replaced else "Added"
    secho(f'{verb} {tv_symbol} -> {provider_symbol} in {path}')
