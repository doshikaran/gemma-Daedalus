"""
Currency rate provider for request.currency_rate().

Sources of exchange-rate data, in priority order:

* a security context already attached to the run — backtest or live —
  whose ``(basecurrency, currency)`` syminfo matches the requested pair.
  The provider reads the security's latest ``close`` from its
  :class:`ResultBlock` (the same channel ``__sec_read__`` uses).
* legacy file path: a sibling ``.toml`` describing a static
  ``.ohlcv`` file. Only relevant when older callers still pass plain
  paths; live runs never carry these.
* the chart symbol itself, as a last resort — when the chart is a currency
  pair (e.g. EURUSD chart), ``lib.close`` is an up-to-the-second stand-in.

MEASURED — the chart's own close is NOT what TradingView answers with, even
when the chart IS the requested pair: on BINANCE:BTCUSDT (base BTC, quote USDT)
``request.currency_rate("USDT", "BTC")`` is POLONIEX:USDTBTC's daily close of
day D-1 on 3298/3298 bars, and on FX:EURUSD ``request.currency_rate("USD",
"EUR")`` holds a value the chart never prints. TradingView keeps a separate
rate feed per pair, so a dedicated source always outranks the chart, which
stays only as the answer for a run that carries no rate feed at all.
"""
from __future__ import annotations

import bisect
from math import isnan
from pathlib import Path
from typing import TYPE_CHECKING, Any

from .ohlcv import OHLCVReader, record_count
from .security_shm import ResultReader

if TYPE_CHECKING:
    from .syminfo import SymInfo
    from .security_shm import SyncBlock

# Bound on first use, never at module level: pulling ``pynecore.lib`` in while a
# core module is still importing would load the runtime surface ahead of the
# import hook. Caching leaves that ordering untouched and only stops the lookup
# from running again on every later bar.
_lib: Any = None


class CurrencyRateProvider:
    """
    Provides currency exchange rates from running security contexts.

    Walks two input sources at construction time:
    * ``sec_syminfos`` — per-sec_id :class:`SymInfo` for active security
      contexts (the chart-side prefetch in live mode, the backtest
      ``.toml`` cache otherwise).
    * ``security_data`` — legacy file paths kept for backward compatibility
      with callers that have not been migrated yet.

    The chart's own OHLCV is also recognized — when the chart symbol is
    itself a currency pair (e.g. EURUSD) and nothing else serves the pair,
    the provider returns ``lib.close``.
    """

    __slots__ = (
        '_pair_map', '_chart_pair',
        '_sync_block', '_result_readers',
        '_file_rate_cache',
    )

    def __init__(
            self,
            security_data: 'dict[str, str | Path] | None' = None,
            chart_syminfo: 'SymInfo | None' = None,
            sec_syminfos: 'dict[str, SymInfo] | None' = None,
            sync_block: 'SyncBlock | None' = None,
    ):
        """
        :param security_data: Legacy mapping of user keys to OHLCV file paths.
                              Used only when no matching ``sec_syminfo`` is
                              available (backtest fallback for callers that
                              have not provided pre-loaded syminfos).
        :param chart_syminfo: Chart's SymInfo — if it carries basecurrency,
                              the chart itself becomes a rate source.
        :param sec_syminfos: Per-sec_id :class:`SymInfo` for security
                             contexts active in this run. The provider
                             builds its ``(basecurrency, currency) →
                             sec_id`` lookup primarily from these.
        :param sync_block: The shared :class:`SyncBlock` used by the
                           security infrastructure. Required when any rate
                           source is a sec_id (so :class:`ResultReader`
                           can fetch the latest pickled close from the
                           security's :class:`ResultBlock`).
        """
        # Tagged source: ``('sec', sec_id)`` for in-process security
        # contexts, ``('file', path)`` for legacy file-backed sources.
        self._pair_map: dict[tuple[str, str], tuple[str, str]] = {}
        self._chart_pair: tuple[str, str] | None = None
        self._sync_block: 'SyncBlock | None' = sync_block
        self._result_readers: dict[str, ResultReader] = {}
        # Bar open times, closes and the series' own bar length in milliseconds.
        self._file_rate_cache: dict[str, tuple[list[int], list[float], int]] = {}

        self._build_pair_map(
            security_data or {},
            chart_syminfo,
            sec_syminfos or {},
        )

    def _build_pair_map(
            self,
            security_data: 'dict[str, str | Path]',
            chart_syminfo: 'SymInfo | None',
            sec_syminfos: 'dict[str, SymInfo]',
    ) -> None:
        """
        Index every available rate source by ``(basecurrency, currency)``.

        Priority: running security context > static file > chart pair.
        On collisions within a priority class the first entry wins; this
        keeps the mapping deterministic across runs.
        """
        if chart_syminfo and chart_syminfo.basecurrency:
            self._chart_pair = (chart_syminfo.basecurrency, chart_syminfo.currency)

        for sec_id, syminfo in sec_syminfos.items():
            if not syminfo or not syminfo.basecurrency:
                continue
            pair = (syminfo.basecurrency, syminfo.currency)
            self._pair_map.setdefault(pair, ('sec', sec_id))

        from .syminfo import SymInfo
        for _key, path in security_data.items():
            ohlcv_path = self._resolve_ohlcv_path(path)
            if ohlcv_path is None:
                continue
            toml_path = Path(ohlcv_path).with_suffix('.toml')
            if not toml_path.exists():
                continue
            try:
                syminfo = SymInfo.load_toml(toml_path)
            except (ValueError, KeyError):
                continue
            if not syminfo.basecurrency:
                continue
            pair = (syminfo.basecurrency, syminfo.currency)
            existing = self._pair_map.get(pair)
            if existing is not None:
                # Sec-backed entries (live or in-process backtest contexts)
                # outrank static files; among files, the larger one wins to
                # match historical behaviour.
                if existing[0] == 'sec':
                    continue
                if self._get_ohlcv_bar_count(ohlcv_path) <= \
                        self._get_ohlcv_bar_count(existing[1]):
                    continue
            self._pair_map[pair] = ('file', ohlcv_path)

    def get_rate(self, from_cur: str, to_cur: str, timestamp: int) -> float:
        """
        Get exchange rate for a currency pair at a given timestamp.

        :param from_cur: Source currency code (e.g. "EUR")
        :param to_cur: Target currency code (e.g. "USD")
        :param timestamp: UNIX timestamp (seconds)
        :return: Exchange rate, or NaN if unavailable
        """
        if from_cur == "NONE" or to_cur == "NONE":
            return float('nan')
        if from_cur == to_cur:
            return 1.0

        if (from_cur, to_cur) in self._pair_map:
            return self._lookup(self._pair_map[(from_cur, to_cur)], timestamp)

        if (to_cur, from_cur) in self._pair_map:
            rate = self._lookup(self._pair_map[(to_cur, from_cur)], timestamp)
            return 1.0 / rate if rate and not isnan(rate) and rate != 0.0 else float('nan')

        global _lib
        if self._chart_pair == (from_cur, to_cur):
            if (lib := _lib) is None:
                from .. import lib
                _lib = lib
            return float(lib.close)
        if self._chart_pair == (to_cur, from_cur):
            if (lib := _lib) is None:
                from .. import lib
                _lib = lib
            close = float(lib.close)
            return 1.0 / close if close and not isnan(close) and close != 0.0 else float('nan')

        return float('nan')

    def _lookup(self, source: tuple[str, str], timestamp: int) -> float:
        """Dispatch on the tagged source type."""
        kind, value = source
        if kind == 'sec':
            return self._lookup_sec(value)
        return self._lookup_file(value, timestamp)

    def _lookup_sec(self, sec_id: str) -> float:
        """Read the latest pickled close from the security's result block."""
        if self._sync_block is None:
            return float('nan')
        reader = self._result_readers.get(sec_id)
        if reader is None:
            reader = ResultReader(sec_id)
            self._result_readers[sec_id] = reader
        try:
            value = reader.read(self._sync_block, default=None)
        except (FileNotFoundError, OSError):
            # Result block not attached yet — subprocess hasn't written
            # its first bar. Caller treats NaN as "not ready" and emits
            # NA for this bar.
            return float('nan')
        if value is None:
            return float('nan')
        if isinstance(value, (int, float)):
            return float(value)
        if isinstance(value, tuple) and value and isinstance(value[0], (int, float)):
            return float(value[0])
        return float('nan')

    def _lookup_file(self, ohlcv_path: str, timestamp: int) -> float:
        """
        Static-file path (backtest only).

        :param ohlcv_path: OHLCV file backing this pair.
        :param timestamp: Bar time in UNIX seconds, as :func:`get_rate` receives it.
        :return: Close of the last rate bar that had already closed, or NaN.
        """
        if ohlcv_path not in self._file_rate_cache:
            self._load_ohlcv(ohlcv_path)
        timestamps, closes, period_ms = self._file_rate_cache[ohlcv_path]
        if not timestamps:
            return float('nan')
        # Only an already-CLOSED rate bar may be read. The bar covering the chart bar has
        # not finished there, so its close is not knowable yet; reading it would be
        # lookahead. It is also what TradingView does: measured on BINANCE:BTCUSDT, the
        # account rate on chart day D is COINBASE:USDTUSD's daily close of day D-1, on
        # 1919/1919 daily bars. A bar stamped ``t`` closes at ``t + period``, so it counts
        # from chart time ``c`` when ``t <= c - period``.
        # The cache holds OHLCV timestamps, which are milliseconds.
        idx = bisect.bisect_right(timestamps, timestamp * 1000 - period_ms) - 1
        if idx < 0:
            return float('nan')
        return closes[idx]

    @staticmethod
    def _period_ms(declared: str | None, timestamps: list[int]) -> int:
        """
        Bar length of a rate series, in milliseconds.

        The declared period wins; the median gap between bars is the fallback for legacy
        v1 files, which declare none. The median is used rather than the smallest gap so
        the weekend of a five-day fiat feed and a DST-shifted day cannot shrink it.

        :param declared: Canonical period from the file header, or ``None``.
        :param timestamps: Bar open times in milliseconds, ascending.
        :return: The bar length, or 0 when neither source can tell.
        """
        if declared:
            from ..lib.timeframe import _in_seconds
            try:
                return _in_seconds(declared) * 1000
            except (ValueError, AssertionError):
                pass
        if len(timestamps) < 2:
            return 0
        deltas = sorted(b - a for a, b in zip(timestamps, timestamps[1:]) if b > a)
        if not deltas:
            return 0
        return deltas[len(deltas) // 2]

    def _load_ohlcv(self, ohlcv_path: str) -> None:
        """
        Cache millisecond timestamps and close prices of an OHLCV file.

        An unreadable or damaged file caches an empty series, which
        :meth:`_lookup_file` reports as NaN — the same answer as a missing pair.

        :param ohlcv_path: OHLCV file to load.
        """
        timestamps: list[int] = []
        closes: list[float] = []
        declared: str | None = None
        if Path(ohlcv_path).exists():
            try:
                with OHLCVReader(ohlcv_path) as reader:
                    declared = reader.period
                    for candle in reader:
                        timestamps.append(candle.timestamp)
                        closes.append(candle.close)
            except (OSError, ValueError):
                timestamps.clear()
                closes.clear()
        self._file_rate_cache[ohlcv_path] = (timestamps, closes,
                                             self._period_ms(declared, timestamps))

    def close(self) -> None:
        """Close every attached :class:`ResultReader`."""
        for r in self._result_readers.values():
            r.close()
        self._result_readers.clear()

    @staticmethod
    def _get_ohlcv_bar_count(path: str) -> int:
        """Get the number of bars in an OHLCV file without opening a reader."""
        return record_count(path)

    @staticmethod
    def _resolve_ohlcv_path(path: str | Path) -> str | None:
        """Resolve OHLCV file path, adding the ``.ohlcv`` extension if needed.

        A dot inside the name belongs to the symbol (e.g. a perpetual
        ``BTCUSDT.P``), so append by name rather than ``with_suffix`` which
        would clobber the symbol's own dotted tail.
        """
        p = Path(path)
        if p.name.endswith('.ohlcv'):
            return str(p) if p.exists() else None
        ohlcv_p = p.with_name(p.name + '.ohlcv')
        if ohlcv_p.exists():
            return str(ohlcv_p)
        return str(p) if p.exists() else None
