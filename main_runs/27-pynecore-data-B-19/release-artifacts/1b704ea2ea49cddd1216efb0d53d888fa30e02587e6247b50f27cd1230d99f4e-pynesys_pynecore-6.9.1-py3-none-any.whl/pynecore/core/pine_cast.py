from ..types.na import NA, na_float
from ..types.color import Color
from ..types.label import Label
from ..types.table import Table
from ..types.box import Box
from ..types.line import Line
from ..types.linefill import LineFill

# The one definition of Pine's comparison tolerance, which also decides the
# float-to-bool conversion (see ``transformers.pine_truthiness``).
from .pine_compare import EPSILON


def cast_color(x: Color | NA) -> Color:
    """
    Casts `na` to Color
    :param x: The value to convert
    :return: The casted value
    """
    return NA(Color) if isinstance(x, NA) else x


def cast_label(x: Label | NA) -> Label:
    """
    Casts `na` to Label

    :param x: The value to convert
    :return: The casted value
    """
    return NA(Label) if isinstance(x, NA) else x


def cast_table(x: Table | NA) -> Table:
    """
    Casts `na` to Table

    :param x: The value to convert
    :return: The casted value
    """
    return NA(Table) if isinstance(x, NA) else x


def cast_bool(x: bool | int | float | NA) -> bool:
    """
    Converts the x value to a bool value

    :param x: The value to convert
    :return: The casted value
    """
    if not (x == x):  # NA object or native nan
        return False
    if x.__class__ is float:
        # Pine converts a float to bool by the same tolerant rule its comparison
        # operators use, in the explicit cast too, not only in the implicit
        # contexts the truthiness rewrite covers (measured on TradingView,
        # BINANCE:BTCUSDT 30m: ``bool(1e-10)`` is false and ``bool(1.000001e-10)``
        # is true at both signs, on every one of 28149 bars)
        return x < -EPSILON or x > EPSILON
    return not not x


def cast_box(x: Box | NA) -> Box:
    """
    Casts `na` to Box

    :param x: The value to convert
    :return: The casted value
    """
    return NA(Box) if isinstance(x, NA) else x


def cast_int(x: int | float | NA) -> float:
    """
    Casts na or truncates float value to int

    :param x: The value to convert
    :return: The casted value
    """
    if not (x == x):  # NA object or native nan
        return na_float
    # A Pine int is a double at runtime: the truncated value travels as a float
    return float(int(x))


def cast_line(x: Line | NA) -> Line:
    """
    Casts `na` to Line

    :param x: The value to convert
    :return: The casted value
    """
    return NA(Line) if isinstance(x, NA) else x


def cast_float(x: float | int | NA) -> float:
    """
    Casts `na` to float

    :param x: The value to convert
    :return: The casted value
    """
    if not (x == x):  # NA object or native nan
        return na_float
    return float(x)


def cast_string(x: str | NA) -> str:
    """
    Casts `na` to string

    :param x: The value to convert
    :return: The casted value
    """
    return NA(str) if isinstance(x, NA) else x


def cast_linefill(x: LineFill | NA) -> LineFill:
    """
    Casts `na` to LineFill

    :param x: The value to convert
    :return: The casted value
    """
    return NA(LineFill) if isinstance(x, NA) else x
