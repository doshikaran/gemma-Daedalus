"""One-way position emulation engine over a hedging-mode broker account.

A hedging account holds several open positions ("legs") per symbol; a Pine
strategy sees a single *one-way* position. The pure helpers in
:mod:`~pynecore.core.broker.emulator` decide *what* to do (net the legs, pick a
FIFO close plan, snap per-leg volumes); this engine *drives* it: it fans a
:class:`~pynecore.core.broker.models.CloseIntent` out across the legs through a
thin :class:`~pynecore.core.plugin.broker.PositionPort`, and owns the
persist-first ledger that lets an interrupted fan-out resume on restart without
re-closing a leg that already settled.

It is the close/reversal counterpart of
:class:`~pynecore.core.broker.software_entry_stop_engine.SoftwareEntryStopEngine`
and :class:`~pynecore.core.broker.software_partial_bracket_engine.SoftwarePartialBracketEngine`:
one instance per :class:`~pynecore.core.broker.sync_engine.OrderSyncEngine`, the
persisted close-leg rows in :mod:`store_helpers` are the durable representation
(PERSIST-FIRST), and :meth:`restart_replay` re-derives an unfinished fan-out
from them. The legs' close FILLs themselves flow through the engine's ordinary
natural-close path (mapped to ``LegType.CLOSE`` by the plugin), so this engine
never touches the fill router — only the dispatch + its crash/replay.

The engine carries no broker, clock, or exchange-model state. Each broker action
goes through the :class:`PositionPort`; aggregation / selection / quantization
are the pure functions in :mod:`emulator`. That keeps it deterministic and
unit-testable in isolation, with ``store_ctx=None`` for the no-persistence path.
"""
from dataclasses import dataclass
from typing import TYPE_CHECKING

from pynecore.core.broker.emulator import (
    LegClose,
    aggregate_positions,
    net_survivor_legs,
    plan_leg_close_volumes,
    plan_reversal,
    select_legs_for_close,
)
from pynecore.core.broker.exceptions import (
    BracketAttachAfterFillRejectedError,
    ExchangeConnectionError,
    ExchangeOrderRejectedError,
    OrderDispositionUnknownError,
    OrderSkippedByPlugin,
)
from pynecore.core.broker.idempotency import (
    CLIENT_ORDER_ID_MAX_LEN,
    KIND_CANCEL,
    KIND_CLOSE,
    KIND_ENTRY,
    KIND_ENTRY_STOP,
    KIND_EXIT_SL,
    parse_client_order_id,
    parse_wire_client_order_id,
)
from pynecore.core.broker.models import (
    CancelIntent,
    CloseIntent,
    DispatchEnvelope,
    EntryIntent,
    ExitIntent,
    OrderType,
    PositionLeg,
)
from pynecore.lib.log import broker_warning as _blog_warning
from pynecore.core.broker.store_helpers import (
    BRACKET_OWN_STATE_CLEARING,
    BRACKET_OWN_STATE_RELEASED,
    CLOSE_LEG_STATE_DISPATCHED,
    ENTRY_KIND_POSITION,
    EXTRAS_KEY_BRACKET_OWN_ATTACH_COID,
    EXTRAS_KEY_BRACKET_OWN_CLEAR_COID,
    EXTRAS_KEY_BRACKET_OWN_LEG_ID,
    EXTRAS_KEY_BRACKET_OWN_SL,
    EXTRAS_KEY_BRACKET_OWN_STATE,
    EXTRAS_KEY_BRACKET_OWN_TP,
    EXTRAS_KEY_BRACKET_OWN_TRAIL_OFFSET,
    EXTRAS_KEY_CLOSE_LEG_ID,
    EXTRAS_KEY_CLOSE_LEG_VOLUME,
    EXTRAS_KEY_RESIDUAL_OPEN_BAR_TS_MS,
    EXTRAS_KEY_RESIDUAL_OPEN_ENTRY_COID,
    EXTRAS_KEY_RESIDUAL_OPEN_RETRY_SEQ,
    EXTRAS_KEY_RESIDUAL_OPEN_RUN_TAG,
    clear_residual_open_row,
    create_bracket_ownership_row,
    create_close_leg_row,
    create_residual_open_row,
    iter_active_bracket_ownerships,
    iter_active_close_legs,
    iter_active_residual_opens,
    update_bracket_ownership_state,
    update_close_leg_state,
)

if TYPE_CHECKING:
    from collections.abc import Callable

    from pynecore.core.broker.storage import RunContext
    from pynecore.core.plugin.broker import PositionPort


__all__ = [
    'CloseFanResult',
    'ReversalFanResult',
    'BracketFanResult',
    'ClearFanResult',
    'OneWayEmulator',
]


@dataclass(frozen=True)
class CloseFanResult:
    """Outcome of one fanned-out close, for the caller's return shaping / audit.

    :ivar legs: ``(leg_id, broker-grid volume)`` pairs actually dispatched, in
        FIFO order. Empty when nothing was open or the close was skipped. The
        volumes are BROKER-grid integers (cTrader centi-units, Capital.com
        lot-step counts, ...) — never comparable with a Pine-unit fill
        quantity; use ``dispatched_qty`` for that.
    :ivar dispatched_qty: Pine-unit quantity the dispatched legs cover — the
        summed FIFO plan slices, in the SAME unit as
        :attr:`~pynecore.core.broker.models.OrderEvent.fill_qty`, so the
        caller can compare it with the fills that come back. ``0.0`` when
        nothing was dispatched.
    :ivar shortfall: Pine-unit quantity the open legs could not cover (the
        broker holds less than Pine believes). ``0.0`` in the normal case; a
        positive value is the caller's signal to log, not halt.
    :ivar skipped: ``True`` when the whole close quantized below the broker's
        volume grid, so no order was sent (a non-halting skip — the engine
        re-evaluates next bar). Distinct from an empty ``legs`` with
        ``skipped=False``, which means the symbol was already flat.
    """
    legs: tuple[tuple[str, int], ...]
    dispatched_qty: float
    shortfall: float
    skipped: bool


@dataclass(frozen=True)
class ReversalFanResult:
    """Outcome of one decomposed reversal / add, for the caller's return shaping.

    :ivar closes: ``(leg_id, broker-grid volume)`` pairs FIFO-closed to retire
        the opposing exposure. Empty for a pure add (no opposing legs).
    :ivar open_qty: Pine-unit size opened in the order's own direction after the
        closes. ``0.0`` for an exact flatten (close all, open nothing).
    :ivar opened_orders: The ``ExchangeOrder``(s) the residual open produced.
        Empty when ``open_qty`` was zero.
    """
    closes: tuple[tuple[str, int], ...]
    open_qty: float
    opened_orders: tuple


@dataclass(frozen=True)
class BracketFanResult:
    """Outcome of one exit-bracket replication across a position's legs.

    :ivar legs: Broker leg ids the bracket was replicated onto, in FIFO order.
    :ivar skipped: ``True`` when nothing was amended — the symbol was flat (no
        position-side legs to protect) or the position book is incomplete (a
        protected-side entry's fill is not yet journaled) — a non-halting
        no-op; the caller re-evaluates next bar.
    :ivar skip_reason: Human-readable cause for an incomplete-book skip, for
        the caller's skip message; ``None`` for the flat / flipped-side skips.
    """
    legs: tuple[str, ...]
    skipped: bool
    skip_reason: str | None = None


@dataclass(frozen=True)
class ClearFanResult:
    """Outcome of one ownership-scoped exit-bracket clear.

    :ivar legs: Broker leg ids actually cleared — the subset the cancelled exit
        owns, never the whole position side. Empty when the exit owned nothing
        (already released, or no persisted ownership index).
    """
    legs: tuple[str, ...]


class OneWayEmulator:
    """Drives Pine one-way close/reversal over a hedging account's legs.

    One instance per :class:`~pynecore.core.broker.sync_engine.OrderSyncEngine`.
    The engine owns the persisted close-leg ledger and its restart replay; every
    broker-side action is performed through the :class:`PositionPort` the
    emulating plugin exposes.
    """

    def __init__(
            self,
            store_ctx: 'RunContext | None',
            *,
            mintick: float = 1.0,
            block_exposure_reopens: 'Callable[[], bool] | None' = None,
    ) -> None:
        self._store_ctx = store_ctx
        self._mintick = mintick
        #: Engine-supplied gate consulted before a residual-open re-dispatch
        #: (the reversal reopen leg). Wired to the engine's quarantine latch:
        #: under quarantine the owed FIFO closes still run (risk-reducing)
        #: but the reopen is withheld and its breadcrumb stays live, so the
        #: committed reversal finishes after the operator restart.
        self._block_exposure_reopens = block_exposure_reopens

    def _trail_price_distance(self, trail_offset: float | None) -> float | None:
        """Convert Pine trailing-offset ticks to the PositionPort price unit."""
        if trail_offset is None:
            return None
        return trail_offset * self._mintick

    # === Close fan-out ====================================================

    async def run_close(
            self, envelope: 'DispatchEnvelope', port: 'PositionPort',
    ) -> CloseFanResult:
        """Fan a :class:`CloseIntent` out as per-leg FIFO closes.

        Reads the live legs, nets them, selects the oldest legs on the position
        side to cover ``intent.qty``, snaps the plan to the broker grid, and
        dispatches one :meth:`PositionPort.close_leg` per leg — persisting each
        leg PERSIST-FIRST so a crash mid-fan resumes via :meth:`restart_replay`.

        Never raises for an undersized close: a whole-close-below-grid returns
        ``skipped=True`` and a broker-holds-less returns a positive
        ``shortfall`` — the bot keeps running and the caller decides how to
        surface it.
        """
        intent = envelope.intent
        assert isinstance(intent, CloseIntent)
        legs = await port.fetch_raw_positions(intent.symbol)
        pos = aggregate_positions(intent.symbol, legs)
        if pos is None or pos.side == 'flat':
            # Nothing open, or offsetting legs net to flat — benign no-op.
            return CloseFanResult(
                legs=(), dispatched_qty=0.0, shortfall=0.0, skipped=False,
            )
        # CloseIntent.side is the close direction ("sell" closes a long); the
        # legs to reduce sit on the opposite side of the book.
        leg_side = 'buy' if intent.side == 'sell' else 'sell'
        closes, shortfall = select_legs_for_close(intent.qty, legs, leg_side)
        if not closes:
            return CloseFanResult(
                legs=(), dispatched_qty=0.0, shortfall=shortfall,
                skipped=False,
            )
        await self._reject_unsupported_partial_closes(
            closes, legs, symbol=intent.symbol,
            intent_key=intent.intent_key, port=port,
        )
        parent_coid = envelope.client_order_id(KIND_CLOSE)
        dispatched = await self._fan_out_closes(
            closes, symbol=intent.symbol, side=intent.side,
            intent_key=intent.intent_key, pine_id=intent.pine_id,
            parent_coid=parent_coid, port=port,
        )
        if not dispatched:
            # Every slice rounded below the broker grid — skip, do not halt.
            return CloseFanResult(
                legs=(), dispatched_qty=0.0, shortfall=shortfall, skipped=True,
            )
        return CloseFanResult(
            legs=tuple(dispatched),
            # Pine units, NOT the broker-grid volumes above: the caller
            # compares this with the fill quantities the legs report back,
            # and those arrive in Pine units on every venue.
            dispatched_qty=round(sum(close.qty for close in closes), 12),
            shortfall=shortfall, skipped=False,
        )

    async def run_reversal(
            self, envelope: 'DispatchEnvelope', port: 'PositionPort',
    ) -> ReversalFanResult:
        """Decompose a Pine reversal/add entry over the hedging legs.

        Pine folds a reversal into one combined-size :class:`EntryIntent`
        assuming a netting auto-flip. On a hedging account that single order
        would open a separate opposing leg, so it is split: FIFO-close the
        opposing legs (up to the order size) and open only the residual in the
        order's own direction. Pure add (no opposing legs) opens the whole size;
        exact flatten (opposing exposure == order size) closes all and opens
        nothing.
        """
        intent = envelope.intent
        assert isinstance(intent, EntryIntent)
        if intent.order_type is not OrderType.MARKET:
            # A resting LIMIT / STOP entry is not Pine's combined-size market
            # auto-flip: it rests as a fresh working order and is decomposed
            # (if it is still a reversal when it triggers) only at FILL time.
            # Place it full-size now with NO opposing-leg close — retiring the
            # opposing exposure here would flatten the position before the entry
            # ever fires. (Fill-time decomposition of a resting reversal is a
            # follow-up.) ``place_leg`` runs the broker's own volume-bounds
            # pre-flight, so an out-of-range resting order still skips cleanly.
            opened = tuple(await port.place_leg(envelope, intent.qty))
            return ReversalFanResult(
                closes=(), open_qty=intent.qty, opened_orders=opened,
            )
        legs = await port.fetch_raw_positions(intent.symbol)
        plan = plan_reversal(intent.side, intent.qty, legs)
        # Pre-flight partial-leg capability BEFORE anything is persisted or
        # sent — same atomicity rationale as the volume-bounds check below.
        await self._reject_unsupported_partial_closes(
            plan.closes, legs, symbol=intent.symbol,
            intent_key=intent.intent_key, port=port,
        )
        # Pre-flight the broker volume bounds BEFORE any close lands: an
        # out-of-range order must raise the non-halting skip while it is still
        # true, otherwise the closes reduce the book yet the whole reversal is
        # reported skipped, desyncing the engine. A pure reduce (open_qty == 0)
        # validates the combined order size; a real reversal validates its
        # residual leg.
        preflight_qty = plan.open_qty if plan.open_qty > 0.0 else intent.qty
        await port.reject_out_of_range(envelope, preflight_qty)
        parent_coid = envelope.client_order_id(KIND_CLOSE)
        # Persist-first residual-open breadcrumb BEFORE the closes: a crash
        # after the closes land but before ``place_leg`` persists the residual
        # entry row would otherwise leave the book reduced with the residual
        # open lost — neither the close-leg replay nor the entry journal owns
        # it. ``restart_replay`` reconciles this against the residual entry row
        # and re-dispatches only if that row never landed. Only a genuine
        # reversal needs it: a pure add (no opposing legs, ``plan.closes``
        # empty) leaves the book intact, so re-opening it on restart would
        # bypass the next sync's Pine re-evaluation and resurrect an entry the
        # strategy may no longer want. The breadcrumb is gated on closes being
        # actually owed, never on a positive ``open_qty`` alone.
        residual_coid = f"{parent_coid}:residual"
        wrote_breadcrumb = bool(plan.closes) and plan.open_qty > 0.0
        if wrote_breadcrumb and self._store_ctx is not None:
            # The breadcrumb's entry coid must match the kind ``place_leg`` will
            # persist under: a stop-fired market entry dispatches as
            # ``KIND_ENTRY_STOP``, so anchoring on ``KIND_ENTRY`` there would
            # make the replay's row-existence check miss the landed entry row
            # and double-open the residual.
            entry_kind = KIND_ENTRY_STOP if intent.stop_fired_market else KIND_ENTRY
            create_residual_open_row(
                self._store_ctx,
                coid=residual_coid,
                symbol=intent.symbol,
                side=intent.side,
                qty=plan.open_qty,
                intent_key=intent.intent_key,
                pine_entry_id=intent.pine_id,
                entry_coid=envelope.client_order_id(entry_kind),
                run_tag=envelope.run_tag,
                bar_ts_ms=envelope.bar_ts_ms,
                retry_seq=envelope.retry_seq,
            )
        dispatched: list[tuple[str, int]] = []
        if plan.closes:
            try:
                dispatched = await self._fan_out_closes(
                    plan.closes, symbol=intent.symbol, side=intent.side,
                    intent_key=intent.intent_key, pine_id=intent.pine_id,
                    parent_coid=parent_coid, port=port,
                )
            except ExchangeOrderRejectedError:
                # A close leg was DEFINITIVELY refused — the fan-out raised
                # before the residual ``place_leg`` ran, so the residual never
                # opened. ``_dispatch_new`` turns this reject into a non-halting
                # skip for the entry (signal dropped, bot continues), so the
                # breadcrumb must be discharged here exactly as the residual
                # reject path below does: leaving it live would let a later
                # restart replay re-close + re-open a reversal the exchange
                # already rejected and Pine never re-signalled. An ambiguous
                # ``OrderDispositionUnknownError`` (caught by the broader
                # ``BrokerError`` contract, not here) leaves the close's fate —
                # and thus a possibly-owed residual — unknown, so its breadcrumb
                # must survive for restart reconciliation and is left intact.
                if wrote_breadcrumb and self._store_ctx is not None:
                    clear_residual_open_row(self._store_ctx, residual_coid)
                raise
        opened_orders: tuple = ()
        if plan.open_qty > 0.0:
            try:
                opened_orders = tuple(await port.place_leg(envelope, plan.open_qty))
            except ExchangeOrderRejectedError:
                # The exchange definitively refused the residual entry — nothing
                # opened. The dispatch path turns this into a non-halting skip
                # (signal dropped, bot continues), so the breadcrumb must be
                # discharged here: leaving it live would let a later restart
                # replay re-open a residual the exchange already rejected and Pine
                # never re-signalled. Only a DEFINITIVE reject clears it — an
                # ambiguous ``OrderDispositionUnknownError`` / connection error
                # leaves the open's fate unknown, so its breadcrumb must survive
                # for restart reconciliation and is left intact (re-raised).
                if wrote_breadcrumb and self._store_ctx is not None:
                    clear_residual_open_row(self._store_ctx, residual_coid)
                raise
            if wrote_breadcrumb and self._store_ctx is not None:
                # The residual entry row is now persisted (persist-first inside
                # ``place_leg``) and dispatched — the breadcrumb is discharged.
                clear_residual_open_row(self._store_ctx, residual_coid)
        return ReversalFanResult(
            closes=tuple(dispatched), open_qty=plan.open_qty,
            opened_orders=opened_orders,
        )

    @staticmethod
    async def _reject_unsupported_partial_closes(
            closes: tuple[LegClose, ...], legs: list[PositionLeg], *,
            symbol: str, intent_key: str, port: 'PositionPort',
    ) -> None:
        """Atomically skip a close plan containing a partial leg slice on a
        port that cannot express one.

        A venue without a per-leg partial reduce (Capital.com's
        ``DELETE /positions/{dealId}`` is full-row only) declares
        ``supports_partial_leg_close = False`` on its port; an absent
        attribute means supported. The check runs BEFORE any close-leg row
        is persisted or dispatched, so the skip leaves no half-reduced book
        and nothing for restart replay to resume — raising from inside the
        fan (the partial tail is dispatched last, FIFO) would desync the
        engine exactly like the volume-bounds case documented in
        :meth:`run_reversal`. Volumes are compared on the broker grid so
        float noise in the Pine-unit plan cannot fake a partial.
        """
        if getattr(port, 'supports_partial_leg_close', True):
            return
        if not closes:
            return
        quantize = await port.get_volume_quantizer(symbol)
        live_by_id = {leg.leg_id: leg for leg in legs}
        for close in closes:
            live = live_by_id.get(close.leg_id)
            if live is None:
                continue
            if quantize(close.qty) < quantize(live.qty):
                raise OrderSkippedByPlugin(
                    f"Skipping {symbol} close: leg {close.leg_id} would be "
                    f"reduced partially ({close.qty} of {live.qty}) but this "
                    f"broker only supports whole-leg closes on a hedging "
                    f"account. No order sent; partial closes need a one-way "
                    f"(netting) account.",
                    intent_key=intent_key,
                    reason="partial_leg_close_unsupported",
                    context={
                        'symbol': symbol,
                        'leg_id': close.leg_id,
                        'close_qty': close.qty,
                        'leg_qty': live.qty,
                    },
                )

    async def _fan_out_closes(
            self, closes: tuple[LegClose, ...], *,
            symbol: str, side: str, intent_key: str, pine_id: str,
            parent_coid: str, port: 'PositionPort',
    ) -> list[tuple[str, int]]:
        """Snap a FIFO close plan to the broker grid and dispatch it per leg.

        Shared by :meth:`run_close` and :meth:`run_reversal`. Each leg is
        PERSIST-FIRST: its row (coid ``f"{parent_coid}:{leg_id}"``, so a restart
        re-dispatch upserts the SAME row) is written ``pending`` BEFORE the wire
        call and finalised ``dispatched`` only after
        :meth:`PositionPort.close_leg` returns. Returns the
        ``(leg_id, broker-grid volume)`` pairs actually sent (empty when the
        whole plan rounded below the grid).
        """
        quantize = await port.get_volume_quantizer(symbol)
        dispatched = plan_leg_close_volumes(closes, quantize)
        for leg_id, volume in dispatched:
            leg_coid = f"{parent_coid}:{leg_id}"
            if self._store_ctx is not None:
                create_close_leg_row(
                    self._store_ctx,
                    coid=leg_coid,
                    symbol=symbol,
                    side=side,
                    qty=float(volume),
                    intent_key=intent_key,
                    pine_entry_id=pine_id,
                    parent_close_coid=parent_coid,
                    leg_id=leg_id,
                    leg_volume=volume,
                )
            await port.close_leg(symbol, leg_id, volume, leg_coid)
            if self._store_ctx is not None:
                update_close_leg_state(
                    self._store_ctx, coid=leg_coid,
                    new_state=CLOSE_LEG_STATE_DISPATCHED, close_row=True,
                )
        return dispatched

    # === Exit-bracket replication =========================================

    async def run_exit_bracket(
            self, envelope: 'DispatchEnvelope', port: 'PositionPort',
    ) -> BracketFanResult:
        """Replicate a Pine exit's bracket onto the net-survivor position legs.

        Hedging venues carry protective levels per position, so a one-way bracket
        over a multi-leg position is delivered by amending the SAME
        TP/SL/trailing onto each leg that makes up the net one-way position. On a
        mixed book (a manual hedge or a crash-interrupted reversal left opposing
        legs open) only the legs that survive virtual-FIFO netting are protected
        (:func:`net_survivor_legs`), never the gross majority side — amending the
        whole majority side would close more than the net position when the stop
        fires and flip it to the minority side. Each leg is recorded PERSIST-FIRST
        in the ownership index (keyed by the exit's ``intent_key``) BEFORE its
        amend, so :meth:`run_exit_bracket_clear` later clears ONLY the legs this
        exit owns and :meth:`restart_replay` can re-assert or release them. A flat
        symbol — or a book whose net side is the opposite of the one this exit
        protects — is a non-halting skip.

        Re-running it (a modify, or a re-attach after pyramiding) upserts the
        same per-leg rows idempotently: the row key is STABLE per (exit
        identity, leg) — derived from the exit's pine_id + from_entry + leg_id,
        NOT the bar-varying dispatch coid — so a modify on a later bar updates
        the same rows instead of accreting stale ones. Two exits sharing a
        pine_id but differing in from_entry get disjoint rows even on a shared
        leg (the dispatch coid alone would collide — it encodes pine_id but not
        from_entry). Legs that have since closed are released by the restart /
        reconcile pass, not here.

        The fan is also deferred (``skipped=True`` with a ``skip_reason``)
        while any protected-side position entry's fill is still pending in the
        journal — see :meth:`_pending_position_entry` — so it always runs over
        a complete book and covers a same-sync pyramid entry's own leg.
        """
        intent = envelope.intent
        assert isinstance(intent, ExitIntent)
        if intent.trail_price is not None and intent.trail_offset is not None:
            # The PositionPort amend surface carries no ``trail_price`` — the
            # deferred-activation trailing of the direct paths is not
            # expressible per-leg, so the trailing arms IMMEDIATELY at
            # ``trail_offset``. Trades can exit earlier/tighter than the Pine
            # simulation; surface it instead of diverging silently.
            _blog_warning(
                "one-way bracket replication: trail_price activation is not "
                "expressible per-leg — trailing on %s (exit %r) arms "
                "immediately at offset %s instead of after the activation "
                "level %s",
                intent.symbol, intent.pine_id, intent.trail_offset,
                intent.trail_price,
            )
        legs = await port.fetch_raw_positions(intent.symbol)
        side, on_side = net_survivor_legs(legs)
        # The net side must be the one this exit protects: ``intent.side`` is
        # the CLOSING direction, so a sell-side exit belongs to a long. When
        # the book has flipped since the exit was placed — the parent entry was
        # reversed away and the stale exit is re-dispatched against the new
        # opposite position — the levels are upside down for that side (a
        # long's take-profit sits ABOVE the price, a short's must sit below).
        # Venues reject that outright, which escalates into a defensive close
        # for a parent that no longer exists. The position this exit protects
        # is simply not there, so it is the same non-halting skip as a flat
        # book: no bracket, re-evaluated on the next bar.
        protected_side = 'buy' if intent.side == 'sell' else 'sell'
        if side == 'flat' or not on_side or side != protected_side:
            return BracketFanResult(legs=(), skipped=True)
        # Incomplete-book gate: a protected-side position entry whose FILL is
        # not yet journaled means the snapshot above cannot be tied to that
        # entry's venue leg yet (the leg id is only learned from the fill, and
        # on a same-sync pyramid the fill event has not been drained when this
        # fan runs). Fanning now would attach the bracket onto the OLDER legs
        # only, the intent would go active, and nothing ever re-fans — the
        # newest leg of a pyramid round would stay permanently unprotected. A
        # mixed book is worse: netting computed over the incomplete snapshot
        # can mis-drop a true survivor and the clear below would strip its live
        # bracket. Defer the WHOLE fan — the same non-halting skip as a flat
        # book — until every position-opening dispatch on this side has its
        # fill on the books; the re-run then covers all legs.
        if self._store_ctx is not None:
            pending_coid = self._pending_position_entry(
                intent.symbol, protected_side,
            )
            if pending_coid is not None:
                return BracketFanResult(
                    legs=(), skipped=True,
                    skip_reason=(
                        f"position book incomplete — entry dispatch "
                        f"{pending_coid!r} has not journaled its fill yet"
                    ),
                )
        survivors = {leg.leg_id for leg in on_side}
        # A re-attach can narrow the survivor set: a manual hedge or an
        # interrupted reversal opens an opposing leg that virtually FIFO-consumes
        # the oldest majority leg, so :func:`net_survivor_legs` now drops a leg
        # this exit owned on a prior attach. That leg is still PHYSICALLY open
        # (only virtually netted) and still carries the broker bracket from the
        # earlier attach; its ownership row would otherwise stay ``active`` and the
        # restart pass would re-assert the stale stop, which on a hit closes more
        # than the net exposure and flips the book. Clear + release those dropped
        # legs FIRST: a survivor amend below can raise
        # :class:`OrderDispositionUnknownError`, which the dispatch path parks
        # while promoting the NEW intent into ``_active_intents`` — the next diff
        # then sees Pine == active and never re-runs this fan, so a dropped-leg
        # clear left AFTER the survivor loop would never get retried. The dropped
        # set is disjoint from ``survivors`` (the clear skips survivor rows), so
        # ordering it before the amend loop is otherwise behaviour-neutral.
        await self._clear_dropped_survivor_legs(
            envelope, intent, survivors=survivors, port=port,
        )
        # Bar-varying dispatch coid (matches the plugin's per-leg amend anchor);
        # one per bracket attach, reused across its legs.
        attach_coid = envelope.client_order_id(KIND_EXIT_SL)
        replicated: list[str] = []
        for leg in on_side:
            own_coid = self._ownership_coid(intent.intent_key, leg.leg_id)
            if self._store_ctx is not None:
                create_bracket_ownership_row(
                    self._store_ctx,
                    coid=own_coid,
                    symbol=intent.symbol,
                    side=intent.side,
                    qty=intent.qty,
                    intent_key=intent.intent_key,
                    pine_entry_id=intent.pine_id,
                    from_entry=intent.from_entry,
                    leg_id=leg.leg_id,
                    attach_coid=attach_coid,
                    tp_price=intent.tp_price,
                    sl_price=intent.sl_price,
                    trail_price=intent.trail_price,
                    trail_offset=intent.trail_offset,
                    oca_name=intent.oca_name,
                    oca_type=intent.oca_type,
                )
            try:
                await port.amend_bracket(
                    intent.symbol, leg.leg_id, side=intent.side,
                    tp_price=intent.tp_price, sl_price=intent.sl_price,
                    trail_offset=self._trail_price_distance(intent.trail_offset),
                    coid=attach_coid,
                )
            except ExchangeOrderRejectedError as exc:
                # The amend was DEFINITIVELY rejected on a leg of an OPEN
                # position (we hold ``on_side`` legs), so the position is now
                # open and UNPROTECTED. PERSIST-FIRST wrote this leg's ownership
                # row before the call, but a reject means we are still alive (not
                # a crash), so release that one never-attached row synchronously
                # — leaving it active would make a later ownership-scoped clear
                # or restart replay believe this exit protects a leg it does not.
                # The legs already amended earlier in this fan keep their active
                # rows: those brackets DO exist, and the defensive close the
                # engine issues for the wrapped error flattens the whole
                # position. (A leg that vanished mid-fan surfaces NOT as a reject
                # but as the port's benign no-op, so it never reaches here; an
                # ambiguous timeout is intentionally not caught — the amend may
                # have landed, so its row stays active for replay / reconcile.)
                if self._store_ctx is not None:
                    update_bracket_ownership_state(
                        self._store_ctx, coid=own_coid,
                        new_state=BRACKET_OWN_STATE_RELEASED, close_row=True,
                    )
                raise BracketAttachAfterFillRejectedError(
                    f"one-way bracket attach rejected after fill "
                    f"(leg={leg.leg_id}, from_entry={intent.from_entry!r}): {exc}",
                    position_coid=f"__pyne_orphan__{intent.symbol}__{intent.from_entry}",
                    symbol=intent.symbol,
                    position_side=('buy' if intent.side == 'sell' else 'sell'),
                    qty=intent.qty,
                    position_deal_id=leg.leg_id,
                    from_entry=intent.from_entry,
                    exit_id=intent.pine_id,
                ) from exc
            replicated.append(leg.leg_id)
        return BracketFanResult(legs=tuple(replicated), skipped=False)

    def _pending_position_entry(self, symbol: str, protected_side: str) -> str | None:
        """Client-order-id of a protected-side position entry awaiting its fill.

        A live journal row with ``extras['kind'] == ENTRY_KIND_POSITION`` opens
        a venue leg immediately (MARKET dispatch or an adopted position), so
        while its cumulative ``filled_qty`` is short of ``qty`` the book
        snapshot is incomplete for ``protected_side``. Working (LIMIT / STOP)
        rows are excluded — they hold no leg until their fill promotes them to
        ``ENTRY_KIND_POSITION`` — and so are entries opening the opposite side.

        :param symbol: The exit's canonical broker symbol.
        :param protected_side: Position side the exit protects (``'buy'`` /
            ``'sell'``).
        :return: The first pending row's ``client_order_id``, or ``None`` when
            every protected-side position entry has its fill on the books.
        """
        assert self._store_ctx is not None
        for row in self._store_ctx.iter_live_orders(symbol=symbol):
            if (row.extras or {}).get('kind') != ENTRY_KIND_POSITION:
                continue
            if row.side != protected_side:
                continue
            if row.filled_qty < row.qty - 1e-9:
                return row.client_order_id
        return None

    async def _clear_dropped_survivor_legs(
            self, envelope: 'DispatchEnvelope', intent: ExitIntent, *,
            survivors: set[str], port: 'PositionPort',
    ) -> None:
        """Clear + release this exit's owned legs that fell out of the survivor set.

        On a re-attach the net survivor set can shrink (an opposing leg now
        virtually FIFO-consumes a leg this exit protected before). Each such leg is
        still physically open and still carries the prior broker bracket, so its
        active ownership row is cleared on the broker (amend-to-None) under a clear
        coid distinct from the attach coid, then released — mirroring
        :meth:`run_exit_bracket_clear` for the implicit drop. A ``*_NOT_FOUND``
        race on a vanished leg is the port's benign no-op; the restart pass would
        otherwise re-assert the stale stop.

        An ambiguous clear (:class:`OrderDispositionUnknownError`) on a dropped
        leg must NOT abort this call: :meth:`run_exit_bracket` runs the drop FIRST,
        before the survivor amend loop, so propagating here would skip the NEW
        protection on the surviving legs entirely — the dispatch path then parks
        the error while promoting the new intent into ``_active_intents``, so the
        next diff sees Pine == active, never re-runs the fan, and the survivors
        stay on STALE TP/SL indefinitely. The drop is persist-first ``clearing``,
        so leaving its row in that phase lets :meth:`drain_clearing_rows` (per
        sync) and :meth:`restart_replay` retry the idempotent re-clear; the
        survivor amend below proceeds with the new levels. This mirrors the
        unknown-disposition handling in :meth:`drain_clearing_rows`.
        """
        if self._store_ctx is None:
            return
        clear_coid = envelope.client_order_id(KIND_CANCEL)
        rows = list(iter_active_bracket_ownerships(
            self._store_ctx, symbol=intent.symbol, from_entry=intent.from_entry,
        ))
        for row in rows:
            if (row.intent_key or '') != intent.intent_key:
                continue
            leg_id: str | None = (row.extras or {}).get(EXTRAS_KEY_BRACKET_OWN_LEG_ID)
            if leg_id is None or leg_id in survivors:
                continue
            update_bracket_ownership_state(
                self._store_ctx, coid=row.client_order_id,
                new_state=BRACKET_OWN_STATE_CLEARING,
                extras_patch={EXTRAS_KEY_BRACKET_OWN_CLEAR_COID: clear_coid},
            )
            try:
                await port.amend_bracket(
                    intent.symbol, leg_id, side=row.side,
                    tp_price=None, sl_price=None, trail_offset=None,
                    coid=clear_coid,
                )
            except OrderDispositionUnknownError:
                # The clear did not confirm; leave the row ``clearing`` so
                # ``drain_clearing_rows`` / ``restart_replay`` retry the
                # idempotent re-clear, and DO NOT abort the survivor amend
                # below — those legs need their new protection now.
                continue
            update_bracket_ownership_state(
                self._store_ctx, coid=row.client_order_id,
                new_state=BRACKET_OWN_STATE_RELEASED, close_row=True,
            )

    async def drain_clearing_rows(self, symbol: str, port: 'PositionPort') -> set[str]:
        """Re-clear + release any ``clearing`` bracket-ownership rows in-session.

        :meth:`_clear_dropped_survivor_legs` (and :meth:`run_exit_bracket_clear`)
        mark a row ``clearing`` PERSIST-FIRST, then amend-to-None on the broker.
        An ambiguous :class:`OrderDispositionUnknownError` on that amend leaves the
        row stranded in ``clearing``: the dispatch path parks the exit and promotes
        it into ``_active_intents``, so the next diff sees Pine == active and never
        re-runs the owning fan, and the one-way orphan sweep skips active keys —
        the stale leg stays armed until the next restart's :meth:`restart_replay`.

        This drain closes that window. The engine calls it once per sync (after the
        orphan sweep): every live ``clearing`` row is re-cleared under its persisted
        clear coid and released, exactly like :meth:`_replay_bracket_one`'s clearing
        branch but per-sync rather than restart-only. A ``clearing`` row is by
        definition marked-for-removal, NEVER wanted protection, so re-clearing it is
        always safe even while the owning exit is still active (its survivor legs
        carry ``active`` rows, untouched here). A vanished leg's bracket is moot —
        release the row. Amending to None is idempotent (an already-cleared leg
        no-ops), so a re-clear that already landed is a broker no-op. A timeout on
        the re-clear leaves the row ``clearing`` for the next sync to retry rather
        than halting the bot.

        Returns the set of ``intent_key`` values whose LAST surviving ownership row
        the drain released this call. The engine drops the in-memory
        envelope/mapping for any such key whose owning exit Pine no longer emits —
        the orphan sweep's direct-clear timeout (``continue`` before
        ``_drop_envelope``) leaves that engine state behind, and the drain
        releasing the row here is the second half of the same retirement. Keys that
        still carry an ``active`` row (a live exit's survivor legs) are excluded, so
        a live bracket never loses its anchor.
        """
        if self._store_ctx is None:
            return set()
        rows = [
            row
            for row in iter_active_bracket_ownerships(self._store_ctx, symbol=symbol)
            if (row.extras or {}).get(EXTRAS_KEY_BRACKET_OWN_STATE)
            == BRACKET_OWN_STATE_CLEARING
        ]
        if not rows:
            return set()
        legs = await port.fetch_raw_positions(symbol)
        live_ids = {leg.leg_id for leg in legs}
        released: set[str] = set()
        for row in rows:
            extras = row.extras or {}
            leg_id: str | None = extras.get(EXTRAS_KEY_BRACKET_OWN_LEG_ID)
            if leg_id is not None and leg_id in live_ids:
                try:
                    await port.amend_bracket(
                        symbol, leg_id, side=row.side,
                        tp_price=None, sl_price=None, trail_offset=None,
                        coid=extras.get(EXTRAS_KEY_BRACKET_OWN_CLEAR_COID)
                        or row.client_order_id,
                    )
                except OrderDispositionUnknownError:
                    # Re-clear did not confirm; leave the row ``clearing`` so the
                    # next sync retries it (idempotent amend-to-None). Halting here
                    # would strand the bot on a recoverable broker round-trip.
                    continue
                except ExchangeConnectionError:
                    # The connection dropped mid-drain. Earlier rows in this loop
                    # may already be RELEASED (durably closed in the store) and
                    # their keys collected in ``released``; if we let the exception
                    # escape, that partial progress is lost — the caller logs +
                    # retries but never runs the envelope/mapping retirement, so a
                    # released row's stale anchor survives and a later re-emission
                    # rebuilds the same attach coid an idempotent plugin dedups,
                    # leaving the leg unprotected. Stop draining (the link is down)
                    # but RETURN what was already released so the engine retires it;
                    # this row stays ``clearing`` for the next sync to retry.
                    break
            update_bracket_ownership_state(
                self._store_ctx, coid=row.client_order_id,
                new_state=BRACKET_OWN_STATE_RELEASED, close_row=True,
            )
            if row.intent_key is not None:
                released.add(row.intent_key)
        # Only report a key whose every ownership row is now gone: a key still
        # carrying an ``active`` row (a live exit's survivor legs) must keep its
        # envelope, so the engine must not retire it.
        if not released:
            return released
        still_owned = {
            row.intent_key
            for row in iter_active_bracket_ownerships(self._store_ctx, symbol=symbol)
            if row.intent_key is not None
        }
        return released - still_owned

    async def drain_residual_opens(self, symbol: str, port: 'PositionPort') -> None:
        """Reconcile any live reversal residual-open breadcrumb per sync (in-session).

        The restart counterpart :meth:`_replay_residual_opens` reconciles these
        breadcrumbs once at startup, but the engine latches that replay after the
        first sync (``_one_way_replay_done``). Two paths leave a breadcrumb live
        mid-session: :meth:`run_reversal`'s residual ``place_leg`` raising
        :class:`OrderDispositionUnknownError` (the open's fate unknown, so the
        breadcrumb is intentionally NOT discharged), and :meth:`_replay_residual_one`
        hitting the same on its own re-dispatch. Without this drain such a breadcrumb
        would wait for the NEXT process restart before being reconciled.

        This closes that window. The engine calls it once per sync (alongside
        :meth:`drain_clearing_rows`), reconciling every live breadcrumb for
        ``symbol`` through the SAME :meth:`_replay_residual_one` path restart replay
        uses: if the residual's persist-first entry row already landed the breadcrumb
        is simply discharged (the entry / recovery path owns the open), otherwise the
        residual is re-opened under its deterministic entry coid (``KIND_ENTRY``, or
        ``KIND_ENTRY_STOP`` for a stop-fired reversal) — a duplicate is impossible
        at the exchange dedup, so a per-sync re-dispatch cannot double-open. A still-ambiguous re-dispatch leaves the row live for the
        next sync to retry rather than halting the bot, mirroring
        :meth:`drain_clearing_rows`. A successful in-session reversal discharges its
        own breadcrumb synchronously, so this only ever sees genuinely unresolved
        rows. Scoped to ``symbol`` (the engine owns one symbol); a breadcrumb for
        another symbol is that engine's drain to reconcile.
        """
        if self._store_ctx is None:
            return
        for row in list(iter_active_residual_opens(self._store_ctx, symbol=symbol)):
            await self._replay_residual_one(row, port)

    @staticmethod
    def _ownership_coid(intent_key: str, leg_id: str) -> str:
        """Stable per-(exit, leg) bracket-ownership row key.

        Keyed on the exit's ``intent_key`` (pine_id + from_entry) and the broker
        leg id, with no bar timestamp, so a modify re-attach upserts the SAME row
        and two exits sharing a pine_id but differing in from_entry never collide
        on a shared leg. Distinct from the bar-varying dispatch coid.
        """
        return f"bo:{intent_key}:{leg_id}"

    async def run_exit_bracket_clear(
            self, envelope: 'DispatchEnvelope', port: 'PositionPort',
    ) -> ClearFanResult:
        """Clear ONLY the legs the cancelled exit owns (the per-leg ownership fix).

        A broadcast clear amends every position-side leg, stripping a bracket a
        DIFFERENT exit set. This consults the persisted ownership index instead:
        it amends-to-clear only the legs whose row matches the cancel's
        ``intent_key`` (or, for a cancel-all-by-pine_id with ``from_entry`` None,
        every row whose exit shares that pine_id), then releases each cleared
        row. Without a persisted index (``store_ctx`` None) there is nothing to
        clear — a benign empty result.
        """
        intent = envelope.intent
        assert isinstance(intent, CancelIntent)
        if self._store_ctx is None:
            return ClearFanResult(legs=())
        cancel_coid = envelope.client_order_id(KIND_CANCEL)
        rows = list(iter_active_bracket_ownerships(
            self._store_ctx, symbol=intent.symbol, from_entry=intent.from_entry,
        ))
        cleared: list[str] = []
        for row in rows:
            if not self._owns(row, intent):
                continue
            leg_id: str | None = (row.extras or {}).get(EXTRAS_KEY_BRACKET_OWN_LEG_ID)
            if leg_id is None:
                continue
            # PERSIST-FIRST: mark the row ``clearing`` BEFORE the amend, so an
            # ambiguous (timed-out) clear leaves a row that :meth:`restart_replay`
            # re-CLEARS rather than re-asserting the original bracket — the
            # close-leg ``pending`` -> ``dispatched`` two-phase applied to the
            # clear. Without it a timed-out clear stays ``active`` and the next
            # restart resurrects the bracket the script asked to cancel. Record the
            # clear coid too, so the restart re-clears under the SAME clear coid —
            # NOT the attach coid, which a coid-idempotent plugin could dedup as a
            # repeat of the attach and swallow, leaving the bracket armed.
            update_bracket_ownership_state(
                self._store_ctx, coid=row.client_order_id,
                new_state=BRACKET_OWN_STATE_CLEARING,
                extras_patch={EXTRAS_KEY_BRACKET_OWN_CLEAR_COID: cancel_coid},
            )
            await port.amend_bracket(
                intent.symbol, leg_id, side=row.side,
                tp_price=None, sl_price=None, trail_offset=None,
                coid=cancel_coid,
            )
            update_bracket_ownership_state(
                self._store_ctx, coid=row.client_order_id,
                new_state=BRACKET_OWN_STATE_RELEASED, close_row=True,
            )
            cleared.append(leg_id)
        return ClearFanResult(legs=tuple(cleared))

    @staticmethod
    def _owns(row, intent: 'CancelIntent') -> bool:
        """Does ``row`` belong to the exit ``intent`` cancels?

        Exact ``intent_key`` match when the cancel targets one (pine_id,
        from_entry); an ``f"{pine_id}\\0"`` prefix match for a cancel-all
        (``from_entry`` None) that drops every exit sharing the pine_id.
        """
        row_key = row.intent_key or ''
        if intent.from_entry is not None:
            return row_key == intent.intent_key
        return row_key.startswith(f"{intent.pine_id}\0")

    # === Restart replay ===================================================

    async def restart_replay(self, port: 'PositionPort') -> None:
        """Resume any close-leg fan-out or bracket replication a crash interrupted.

        Called once at startup. Three ordered passes: pending close-leg rows
        are reconciled against the live legs and the residual re-dispatched (an
        already-settled leg is never re-closed); THEN reversal residual-open
        breadcrumbs are reconciled (the closes are now resolved, so a still-owed
        residual is safely re-opened) and the open re-dispatched only when its
        own entry row never landed; THEN active bracket-ownership rows are
        re-asserted on still-open legs (idempotent on the per-leg coid) and
        released when their leg has vanished.
        """
        if self._store_ctx is None:
            return
        await self._replay_close_legs(port)
        await self._replay_residual_opens(port)
        await self._replay_bracket_ownership(port)

    async def _replay_close_legs(self, port: 'PositionPort') -> None:
        """Reconcile + re-dispatch any pending close-leg rows (first replay pass).

        For every persisted ``pending`` close-leg row, reconcile against the live
        broker legs before re-sending: if the leg is gone, the close already
        landed — finalise the row without dispatching; if it is still open,
        re-dispatch only the residual (capped at the live leg size, re-snapped to
        the grid) so an already-partly-closed leg is never over-reduced. The
        natural-close fill dedup guards the fill side.
        """
        if self._store_ctx is None:
            return
        pending = list(iter_active_close_legs(self._store_ctx))
        if not pending:
            return
        by_symbol: dict[str, list] = {}
        for row in pending:
            by_symbol.setdefault(row.symbol, []).append(row)
        for symbol, rows in by_symbol.items():
            legs = await port.fetch_raw_positions(symbol)
            live_by_id = {leg.leg_id: leg for leg in legs}
            quantize = await port.get_volume_quantizer(symbol)
            for row in rows:
                await self._replay_one(row, symbol, live_by_id, quantize, port)

    async def _replay_one(
            self, row, symbol: str, live_by_id: dict[str, PositionLeg], quantize, port: 'PositionPort',
    ) -> None:
        """Reconcile + (if needed) re-dispatch one pending close-leg row."""
        if self._store_ctx is None:
            return
        extras = row.extras or {}
        leg_id: str | None = extras.get(EXTRAS_KEY_CLOSE_LEG_ID)
        live_leg = live_by_id.get(leg_id) if leg_id is not None else None
        if live_leg is None or leg_id is None:
            # Leg vanished — the close landed before the crash. Finalise only.
            update_close_leg_state(
                self._store_ctx, coid=row.client_order_id,
                new_state=CLOSE_LEG_STATE_DISPATCHED, close_row=True,
            )
            return
        persisted = extras.get(EXTRAS_KEY_CLOSE_LEG_VOLUME) or 0
        residual = min(int(persisted), quantize(live_leg.qty))
        if residual > 0:
            await port.close_leg(symbol, leg_id, residual, row.client_order_id)
        update_close_leg_state(
            self._store_ctx, coid=row.client_order_id,
            new_state=CLOSE_LEG_STATE_DISPATCHED, close_row=True,
        )

    async def _replay_residual_opens(self, port: 'PositionPort') -> None:
        """Re-dispatch any reversal residual-open a crash left un-persisted.

        Runs AFTER :meth:`_replay_close_legs`, so the reversal's FIFO closes are
        already reconciled and re-opening the residual cannot race them. For each
        live breadcrumb: if the residual's own entry row already exists, the
        ``place_leg`` persist-first write landed and the entry journal / startup
        recovery own it — just clear the breadcrumb; otherwise rebuild the
        dispatch envelope and re-open the residual under the SAME deterministic
        entry coid (``KIND_ENTRY``, or ``KIND_ENTRY_STOP`` for a stop-fired
        reversal; a duplicate is therefore impossible at the exchange dedup),
        then clear it.
        """
        if self._store_ctx is None:
            return
        for row in list(iter_active_residual_opens(self._store_ctx)):
            await self._replay_residual_one(row, port)

    async def _replay_residual_one(self, row, port: 'PositionPort') -> None:
        """Reconcile + (if needed) re-dispatch one residual-open breadcrumb."""
        if self._store_ctx is None:
            return
        extras = row.extras or {}
        entry_coid: str | None = extras.get(EXTRAS_KEY_RESIDUAL_OPEN_ENTRY_COID)
        if (entry_coid is not None
                and self._store_ctx.get_order(entry_coid) is not None):
            # ``place_leg`` reached its persist-first entry-row write before the
            # crash — the open is durable and owned by the entry path. Discharge.
            clear_residual_open_row(self._store_ctx, row.client_order_id)
            return
        # The residual open never persisted (persist-first guarantees the entry
        # row precedes any wire send, so its absence proves no dispatch happened —
        # re-opening cannot double-open). The breadcrumb is written BEFORE the
        # FIFO closes, so a crash in that window can also leave the opposing legs
        # un-closed AND their close-leg rows un-persisted — ``_replay_close_legs``
        # then has nothing to re-dispatch. Re-opening the residual on top of those
        # still-live opposing legs would over-expose the book. Reconcile against
        # the live legs first: a genuine reversal (positive residual) fully
        # consumes the opposing exposure, so every still-live opposing leg is an
        # owed close — FIFO-close them under the SAME deterministic parent coid
        # (idempotent at the exchange dedup) before the residual open.
        run_tag = extras.get(EXTRAS_KEY_RESIDUAL_OPEN_RUN_TAG)
        bar_ts_ms = extras.get(EXTRAS_KEY_RESIDUAL_OPEN_BAR_TS_MS)
        retry_seq = extras.get(EXTRAS_KEY_RESIDUAL_OPEN_RETRY_SEQ)
        assert isinstance(run_tag, str)
        assert isinstance(bar_ts_ms, int)
        assert isinstance(retry_seq, int)
        opposing_side = 'sell' if row.side == 'buy' else 'buy'
        live_legs = await port.fetch_raw_positions(row.symbol)
        owed_closes = tuple(
            LegClose(leg_id=leg.leg_id, qty=leg.qty)
            for leg in live_legs
            if leg.side == opposing_side and leg.qty > 0.0
        )
        if owed_closes:
            parent_coid = row.client_order_id.removesuffix(':residual')
            await self._fan_out_closes(
                owed_closes, symbol=row.symbol, side=row.side,
                intent_key=row.intent_key or row.pine_entry_id or '',
                pine_id=row.pine_entry_id or '', parent_coid=parent_coid, port=port,
            )
        # Quarantine gate: the reopen leg is a new-exposure dispatch. The
        # owed FIFO closes above still ran (risk-reducing), but the reopen
        # is withheld and the breadcrumb stays live — the committed
        # reversal finishes on the replay after the operator restart.
        if (self._block_exposure_reopens is not None
                and self._block_exposure_reopens()):
            _blog_warning(
                "one-way residual reopen %r withheld by quarantine; "
                "breadcrumb stays pending until the operator restart",
                row.client_order_id,
            )
            return
        # Rebuild the intent with the ORIGINAL dispatch's coid kind: a
        # stop-fired reversal's residual went out under ``KIND_ENTRY_STOP``
        # (the plugin picks the kind from ``stop_fired_market``), so the
        # replayed ``place_leg`` must persist and dedup under that same coid —
        # otherwise a second ambiguous round-trip would land an entry row the
        # breadcrumb's ``entry_coid`` check never finds, re-opening the
        # residual again. The flag is recovered from the persisted coid's kind
        # code rather than a separate extras field — both forms carry it raw:
        # canonical in ``{k}{r}``, wire in the raw prefix. A wire-form coid's
        # length IS the minting venue's budget, so replaying it at
        # ``len(entry_coid)`` re-mints the byte-identical id; a canonical coid
        # replays under the default (identity) budget.
        parsed_entry = parsed_wire = None
        coid_max_len = CLIENT_ORDER_ID_MAX_LEN
        if entry_coid is not None:
            parsed_entry = parse_client_order_id(entry_coid)
            if parsed_entry is None:
                parsed_wire = parse_wire_client_order_id(entry_coid)
                if parsed_wire is not None:
                    coid_max_len = len(entry_coid)
        entry_kind = (
            parsed_entry.kind if parsed_entry is not None
            else parsed_wire.kind if parsed_wire is not None
            else None
        )
        stop_fired = entry_kind == KIND_ENTRY_STOP
        envelope = DispatchEnvelope(
            intent=EntryIntent(
                pine_id=row.pine_entry_id, symbol=row.symbol, side=row.side,
                qty=row.qty, order_type=OrderType.MARKET,
                stop_fired_market=stop_fired,
            ),
            run_tag=run_tag, bar_ts_ms=bar_ts_ms, retry_seq=retry_seq,
            coid_max_len=coid_max_len,
        )
        try:
            await port.place_leg(envelope, row.qty)
        except ExchangeOrderRejectedError:
            # The exchange definitively refused the residual entry — nothing
            # opened. ``restart_replay`` runs inside the sync startup wrapper,
            # which only catches ``ExchangeConnectionError`` (sync_engine), so
            # propagating here would abort startup and the breadcrumb would
            # survive un-cleared, retrying the same rejected residual on every
            # later sync. Discharge the breadcrumb and stop: the residual the
            # exchange rejected and Pine never re-signalled must not re-open.
            clear_residual_open_row(self._store_ctx, row.client_order_id)
            return
        except OrderDispositionUnknownError:
            # The residual entry's fate is unknown (ambiguous round-trip). Leave
            # the breadcrumb live so the next sync's replay / drain reconciles it
            # against the then-known leg state, but do NOT propagate — that would
            # abort startup on a recoverable round-trip, mirroring the bracket
            # re-clear path above.
            return
        clear_residual_open_row(self._store_ctx, row.client_order_id)

    async def _replay_bracket_ownership(self, port: 'PositionPort') -> None:
        """Re-assert / finish live bracket-ownership rows (second replay pass).

        For every live ownership row: if its leg is still open, an ``active`` row
        is re-asserted idempotently on the same per-leg coid (the broker no-ops an
        unchanged amend) while a ``clearing`` row (a clear a crash interrupted) is
        finished by re-clearing then releasing it; if the leg has vanished, the
        bracket it carried is moot — release the orphan row so it leaves the live
        index.
        """
        if self._store_ctx is None:
            return
        rows = list(iter_active_bracket_ownerships(self._store_ctx))
        if not rows:
            return
        by_symbol: dict[str, list] = {}
        for row in rows:
            by_symbol.setdefault(row.symbol, []).append(row)
        for symbol, srows in by_symbol.items():
            legs = await port.fetch_raw_positions(symbol)
            live_ids = {leg.leg_id for leg in legs}
            for row in srows:
                await self._replay_bracket_one(row, symbol, live_ids, port)

    async def _replay_bracket_one(
            self, row, symbol: str, live_ids: set, port: 'PositionPort',
    ) -> None:
        """Re-assert / finish one bracket-ownership row, or release a vanished leg."""
        if self._store_ctx is None:
            return
        extras = row.extras or {}
        leg_id: str | None = extras.get(EXTRAS_KEY_BRACKET_OWN_LEG_ID)
        if leg_id is None or leg_id not in live_ids:
            update_bracket_ownership_state(
                self._store_ctx, coid=row.client_order_id,
                new_state=BRACKET_OWN_STATE_RELEASED, close_row=True,
            )
            return
        if extras.get(EXTRAS_KEY_BRACKET_OWN_STATE) == BRACKET_OWN_STATE_CLEARING:
            # A clear interrupted before it confirmed (crash or ambiguous
            # timeout): finish it. Amending to None is idempotent — an already
            # cleared leg no-ops — so re-clear then release, NEVER re-assert the
            # original levels (that would resurrect a cancelled bracket). Re-clear
            # under the persisted clear coid (NOT the attach coid): the contract
            # lets a plugin dedup a repeated coid, so reusing the attach coid here
            # could be swallowed as a duplicate attach, leaving the bracket armed.
            try:
                await port.amend_bracket(
                    symbol, leg_id, side=row.side,
                    tp_price=None, sl_price=None, trail_offset=None,
                    coid=extras.get(EXTRAS_KEY_BRACKET_OWN_CLEAR_COID)
                    or row.client_order_id,
                )
            except OrderDispositionUnknownError:
                # The re-clear did not confirm. ``restart_replay`` runs inside the
                # sync startup wrapper, which only catches ``ExchangeConnectionError``;
                # propagating this sibling error would abort startup on a recoverable
                # ambiguous round-trip. Leave the row ``clearing`` (NOT released) so
                # the next ``drain_clearing_rows`` / replay retries the idempotent
                # re-clear, mirroring ``drain_clearing_rows``.
                return
            update_bracket_ownership_state(
                self._store_ctx, coid=row.client_order_id,
                new_state=BRACKET_OWN_STATE_RELEASED, close_row=True,
            )
            return
        await port.amend_bracket(
            symbol, leg_id, side=row.side,
            tp_price=extras.get(EXTRAS_KEY_BRACKET_OWN_TP),
            sl_price=extras.get(EXTRAS_KEY_BRACKET_OWN_SL),
            trail_offset=self._trail_price_distance(
                extras.get(EXTRAS_KEY_BRACKET_OWN_TRAIL_OFFSET)
            ),
            coid=extras.get(EXTRAS_KEY_BRACKET_OWN_ATTACH_COID) or row.client_order_id,
        )
