from typing import Any
import os
import sys
import logging
from datetime import datetime, UTC
from pathlib import Path

#: Fallback virtual-console width (columns) for a redirected/durable log sink.
#: Rich falls back to 80 columns when stdout is not a real terminal, which
#: hard-wraps long broker and exchange order identifiers (UUIDs) across
#: physical lines so they can no longer be grepped or copied as one token.
#: A wide virtual console keeps identifier-bearing lines on a single line.
DURABLE_LOG_WIDTH = 200

from .string import format as _format
from .. import lib

# Try to import rich, but don't fail if not available
try:
    import rich
    import rich.logging
except ImportError:
    rich = None


__all__ = (
    'info', 'warning', 'error', 'logger', 'setup_security_file_log',
    'broker_debug', 'broker_info', 'broker_warning', 'broker_error', 'ohlcv_info',
    'sim_info',
)

_security_logger: logging.Logger | None = None

if os.environ.get("PYNE_NO_COLOR_LOG", "") == "1":
    rich = None


def _resolve_log_console_width(is_tty: bool, columns_env: str | None) -> int | None:
    """Pick the Rich console width for the log handler.

    On an interactive terminal (``is_tty``) return ``None`` so Rich keeps
    auto-detecting the real terminal width. When stdout is redirected to a
    durable sink (file, pipe, systemd journal, Docker log) Rich would fall
    back to 80 columns and fold long broker/order identifiers across lines;
    return an explicit wide width so they stay searchable. An explicit
    ``COLUMNS`` override always wins so a caller can widen or narrow the
    transcript deliberately.

    :param is_tty: Whether stdout is an interactive terminal.
    :param columns_env: The raw ``COLUMNS`` environment value, if any.
    :return: An explicit column count, or ``None`` to let Rich auto-detect.
    """
    if columns_env:
        try:
            width = int(columns_env)
        except ValueError:
            width = 0
        if width > 0:
            return width
    if is_tty:
        return None
    return DURABLE_LOG_WIDTH


# noinspection PyProtectedMember
def _resolve_log_time(record: logging.LogRecord) -> datetime:
    """Pick the timestamp + timezone for a log record.

    Single source of truth for all three formatters (Rich, plain, security
    file). Prefers Pine time (``lib._time``); falls back to the record's
    wall clock when Pine time is unset (startup phase before the first bar).
    Either way the result is timezone-aware: ``syminfo.timezone`` if set,
    otherwise UTC — so the ``%z`` column is never blank.
    """
    tz_raw = getattr(getattr(lib, 'syminfo', None), 'timezone', None)
    tz: str | None = tz_raw if isinstance(tz_raw, str) and tz_raw else None
    epoch = lib._time / 1000 if lib._time else record.created
    dt = datetime.fromtimestamp(epoch, UTC)
    if tz is not None:
        return dt.astimezone(lib._parse_timezone(tz))
    return dt

# Custom RichHandler that uses Pine Script time and timezone
if rich:
    class PineRichHandler(rich.logging.RichHandler):
        """Custom RichHandler that formats time using syminfo.timezone"""

        def render(self, *, record, traceback, message_renderable):
            """Override render to use Pine Script time and timezone"""
            from rich.text import Text
            from rich.table import Table

            log_time = _resolve_log_time(record)

            # Format the time
            path = Path(record.pathname).name
            level = self.get_level_text(record)
            time_format = None if self.formatter is None else self.formatter.datefmt

            # Create custom log output with colored bar_index
            if hasattr(lib, 'bar_index') and lib.bar_index is not None:
                # Format the base time
                time_str = log_time.strftime(time_format or "[%Y-%m-%d %H:%M:%S]")

                # Create table for log output
                output = Table.grid(padding=(0, 1))

                # Add columns - no style for first two columns to allow Text styling
                output.add_column()  # Time column
                output.add_column()  # Bar index column
                output.add_column(style="log.level", width=8)  # Level column
                output.add_column(style="log.message", overflow="fold")  # Message column

                # Build row with styled Text objects
                row = [
                    Text(time_str, style="log.time"),
                    Text(f"bar: {int(lib.bar_index):6}", style="cyan"),
                    level,
                    message_renderable,
                ]

                output.add_row(*row)
                return output
            else:
                # Standard rendering without bar_index
                log_renderable = self._log_render(
                    self.console,
                    [message_renderable] if not traceback else [message_renderable, traceback],
                    log_time=log_time,
                    time_format=time_format,
                    level=level,
                    path=path,
                    line_no=record.lineno,
                    link_path=record.pathname if self.enable_link_path else None,
                )
                return log_renderable


# noinspection PyProtectedMember
class PineLogFormatter(logging.Formatter):
    """Custom formatter that mimics Pine Script log format"""

    def formatTime(self, record: logging.LogRecord, datefmt: str | None = None) -> str:
        """Format the time using syminfo.timezone"""
        dt = _resolve_log_time(record)

        # Format the datetime
        if datefmt:
            time_str = dt.strftime(datefmt)
        else:
            time_str = dt.strftime("%Y-%m-%d %H:%M:%S,%f")[:-3]

        # Add bar_index to the time string
        if hasattr(lib, 'bar_index') and lib.bar_index is not None:
            time_str = f"{time_str} bar: {int(lib.bar_index):6}"

        return time_str

    def format(self, record: logging.LogRecord) -> Any:
        """Format log record in Pine style: [timestamp]: message"""
        if record.args:
            msg = _format(record.msg, *record.args)
        else:
            msg = str(record.msg)

        record.args = ()

        record.created = lib._time / 1000 if lib._time else record.created
        if rich:
            return msg

        record.msg = msg
        return super().format(record)


# Create logger
logger = logging.getLogger("pyne_core_logger")
# Remove existing handlers before adding new one
if logger.hasHandlers():
    logger.handlers.clear()

logger.setLevel(logging.INFO)
if rich:
    from rich.console import Console as _RichConsole

    _stdout_is_tty = bool(getattr(sys.stdout, "isatty", lambda: False)())
    _log_console_width = _resolve_log_console_width(
        _stdout_is_tty, os.environ.get("COLUMNS"),
    )
    _log_console = (
        None if _log_console_width is None
        else _RichConsole(width=_log_console_width)
    )
    handler = PineRichHandler(  # noqa
        console=_log_console,
        show_time=True,
        show_level=True,
        omit_repeated_times=False,
        markup=False,
        show_path=False,
    )
else:
    handler = logging.StreamHandler()
handler.setFormatter(PineLogFormatter(
    "%(asctime)s %(levelname)-7s %(message)s",
    datefmt="[%Y-%m-%d %H:%M:%S%z]")
)
logger.addHandler(handler)


def setup_security_file_log(log_path: str, context_label: str) -> None:
    """
    Set up file-based logging for a security process.

    Called from security_process_main when PYNE_SECURITY_LOG is set.
    The context_label (e.g. "AAPL 1D") is prepended to each log line.

    :param log_path: Path to the log file
    :param context_label: Security context identifier (symbol + timeframe)
    """
    global _security_logger
    sec_logger = logging.getLogger(f"pyne_security_{context_label}")
    sec_logger.setLevel(logging.DEBUG)
    sec_logger.propagate = False
    if sec_logger.hasHandlers():
        sec_logger.handlers.clear()
    fh = logging.FileHandler(log_path, mode='a', encoding='utf-8')
    fh.setFormatter(SecurityFileFormatter(context_label))
    sec_logger.addHandler(fh)
    _security_logger = sec_logger


# noinspection PyProtectedMember
class SecurityFileFormatter(logging.Formatter):
    """Formatter for security process file logs with context label and Pine time."""

    def __init__(self, context_label: str):
        super().__init__()
        self.context_label = context_label

    def format(self, record: logging.LogRecord) -> str:
        if record.args:
            msg = _format(record.msg, *record.args)
            record.args = ()
        else:
            msg = str(record.msg)

        dt = _resolve_log_time(record)
        time_str = dt.strftime("%Y-%m-%d %H:%M:%S%z")
        bar_str = f" bar: {int(lib.bar_index):6}" if hasattr(lib, 'bar_index') and lib.bar_index is not None else ""

        return f"[{self.context_label}] [{time_str}]{bar_str} {record.levelname:<7} {msg}"


# noinspection PyPep8Naming,PyUnusedLocal
def info(formatString: str, *args: Any, **kwargs: Any) -> None:
    """
    Print an info message to the console.

    :param formatString: Message format string
    :param args: Arguments to format the message
    :param kwargs: Additional arguments (unused)
    """
    # noinspection PyProtectedMember
    if lib._lib_semaphore:
        if _security_logger:
            _security_logger.info(formatString, *args)
        return
    logger.info(formatString, *args)


# noinspection PyPep8Naming,PyUnusedLocal
def warning(formatString: str, *args: Any, **kwargs: Any) -> None:
    """
    Print a warning message to the console.

    :param formatString: Message format string
    :param args: Arguments to format the message
    :param kwargs: Additional arguments (unused)
    """
    # noinspection PyProtectedMember
    if lib._lib_semaphore:
        if _security_logger:
            _security_logger.warning(formatString, *args)
        return
    logger.warning(formatString, *args)


# noinspection PyPep8Naming,PyUnusedLocal
def error(formatString: str, *args: Any, **kwargs: Any) -> None:
    """
    Print an error message to the console.

    :param formatString: Message format string
    :param args: Arguments to format the message
    :param kwargs: Additional arguments (unused)
    """
    # noinspection PyProtectedMember
    if lib._lib_semaphore:
        if _security_logger:
            _security_logger.error(formatString, *args)
        return
    logger.error(formatString, *args)


#
# Internal tagged helpers
#
# These route non-Pine-script events (broker dispatch, OHLCV market data,
# any future category) through the same logger handler as ``info/warning/
# error`` above — uniform Pine-time + ``bar: N`` columns, same Rich
# Console (which the live CLI spinner shares). They pre-format ``%``-style
# placeholders client-side so call sites use idiomatic Python logging
# rather than Pine's ``string.format`` ``{0}/{1}`` numbered placeholders.
# All internal tagging lives here so the codebase has one central log
# module, not one per subsystem.
#

def _emit_tagged(level: int, prefix: str, message: str, args: tuple) -> None:
    text = prefix + (message % args if args else message)
    logger.log(level, text)


def broker_debug(message: str, *args: Any) -> None:
    """Emit a DEBUG-level broker event (``[BROKER]`` tag).

    For high-frequency or by-design-expected events (e.g. dropping a
    redelivered duplicate fill) that must stay inspectable without flooding
    the operator's INFO log.
    """
    _emit_tagged(logging.DEBUG, "[BROKER] ", message, args)


def broker_info(message: str, *args: Any) -> None:
    """Emit an INFO-level broker event (``[BROKER]`` tag)."""
    _emit_tagged(logging.INFO, "[BROKER] ", message, args)


def broker_warning(message: str, *args: Any) -> None:
    """Emit a WARNING-level broker event (``[BROKER]`` tag)."""
    _emit_tagged(logging.WARNING, "[BROKER] ", message, args)


def broker_error(message: str, *args: Any) -> None:
    """Emit an ERROR-level broker event (``[BROKER]`` tag)."""
    _emit_tagged(logging.ERROR, "[BROKER] ", message, args)


def ohlcv_info(message: str, *args: Any) -> None:
    """Emit an INFO-level market-data line (``[OHLCV]`` tag)."""
    _emit_tagged(logging.INFO, "[OHLCV] ", message, args)


def sim_info(message: str, *args: Any) -> None:
    """Emit an INFO-level paper-trading event (``[SIM]`` tag).

    The simulator counterpart to ``broker_info``: in ``--live`` mode without
    ``--broker`` the :class:`SimPosition` fills orders locally, so there is no
    ``OrderSyncEngine`` to narrate entries and exits. This gives the operator
    the same per-fill visibility for paper trading.
    """
    _emit_tagged(logging.INFO, "[SIM] ", message, args)
