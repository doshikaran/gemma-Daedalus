from copy import copy as _copy
from typing import Any, overload

from ..core.module_property import module_property
from ..types.chart import ChartPoint
from ..types.base import next_vid
from ..types.line import LineEnum, Line
from ..types.na import NA, na_int, na_float
from ..types.pine_types import PyneFloat, PyneInt
from ..lib import xloc as _xloc, extend as _extend, color as _color
from ..lib import linefill as _linefill
from ._drawing import bar_coord as _bar_coord, price as _price
from .. import lib

_registry: dict[Line, None] = {}


def _remove(line_obj: Line) -> None:
    """Remove a line and every linefill referencing it (Pine deletes a linefill
    when either of its lines is deleted, including count-limit eviction)."""
    _registry.pop(line_obj, None)
    _linefill._registry[:] = [lf for lf in _linefill._registry
                              if lf.line1 is not line_obj and lf.line2 is not line_obj]

style_arrow_both = LineEnum('ab')
style_arrow_left = LineEnum('al')
style_arrow_right = LineEnum('ar')
style_dashed = LineEnum('dsh')
style_dotted = LineEnum('dot')
style_solid = LineEnum('sol')


@overload
def new(first_point: ChartPoint, second_point: ChartPoint, xloc: _xloc.XLoc = _xloc.bar_index,
        extend: _extend.Extend = _extend.none, color: _color.Color = _color.blue,
        style: LineEnum = style_solid, width: int = 1, force_overlay: bool = False) -> Line: ...


@overload
def new(x1: int | float, y1: float, x2: int | float, y2: float,
        xloc: _xloc.XLoc = _xloc.bar_index, extend: _extend.Extend = _extend.none,
        color: _color.Color = _color.blue, style: LineEnum = style_solid,
        width: int = 1, force_overlay: bool = False) -> Line: ...


# Positional parameter orders of the two Pine call shapes; ``new()`` maps ``*args``
# onto one of these depending on whether the first positional is a ``chart.point``.
_POINT_PARAMS = ('first_point', 'second_point', 'xloc', 'extend', 'color', 'style',
                 'width', 'force_overlay')
_COORD_PARAMS = ('x1', 'y1', 'x2', 'y2', 'xloc', 'extend', 'color', 'style',
                 'width', 'force_overlay')


# noinspection PyProtectedMember
def new(*args: Any, **kwargs: Any) -> Line:
    """
    Creates a new line object.

    Two call shapes are accepted:
    - ``line.new(first_point, second_point, ...)`` where both arguments are ``chart.point`` objects.
    - ``line.new(x1, y1, x2, y2, ...)`` where ``x1`` / ``x2`` are bar index
      (``xloc.bar_index``) or bar UNIX time in milliseconds (``xloc.bar_time``),
      and ``y1`` / ``y2`` are prices. Float ``x1`` / ``x2`` are truncated to int.

    :param x1: Bar index / bar time of the first point (coordinate form)
    :param y1: Price of the first point (coordinate form)
    :param x2: Bar index / bar time of the second point (coordinate form only)
    :param y2: Price of the second point (coordinate form only)
    :param xloc: Possible values: ``xloc.bar_index`` and ``xloc.bar_time``
    :param extend: If ``extend=extend.none``, draws segment from (x1, y1) to (x2, y2)
    :param color: Line color
    :param style: Line style. Possible values: ``line.style_solid``, ``line.style_dotted``,
                  ``line.style_dashed``, ``line.style_arrow_left``, ``line.style_arrow_right``,
                  ``line.style_arrow_both``
    :param width: Line width in pixels
    :param force_overlay: If true, the drawing will display on the main chart pane
    :param first_point: First ``chart.point`` (point form, keyword equivalent of the first positional)
    :param second_point: Second ``chart.point`` (point form, keyword equivalent of the second positional)
    :return: A line object
    """
    if args:
        names = _POINT_PARAMS if isinstance(args[0], ChartPoint) else _COORD_PARAMS
        if len(args) > len(names):
            raise TypeError(f"line.new() takes at most {len(names)} positional arguments")
        for name, value in zip(names, args):
            if name in kwargs:
                raise TypeError(f"line.new() got multiple values for argument '{name}'")
            kwargs[name] = value
    first_point = kwargs.get('first_point')
    second_point = kwargs.get('second_point')
    xloc = kwargs.get('xloc', _xloc.bar_index)
    extend = kwargs.get('extend', _extend.none)
    color = kwargs.get('color', _color.blue)
    style = kwargs.get('style', style_solid)
    width = kwargs.get('width', 1)
    force_overlay = kwargs.get('force_overlay', False)
    if isinstance(first_point, ChartPoint):
        second = second_point if isinstance(second_point, ChartPoint) else first_point
        if xloc == _xloc.bar_time:
            x1_val, y1_val = first_point.time, first_point.price
            x2_val, y2_val = second.time, second.price
        else:
            x1_val, y1_val = first_point.index, first_point.price
            x2_val, y2_val = second.index, second.price
    else:
        x1 = kwargs.get('x1')
        y1 = kwargs.get('y1')
        x2 = kwargs.get('x2')
        y2 = kwargs.get('y2')
        x1_val, y1_val = _bar_coord(x1), _price(y1)
        x2_val, y2_val = _bar_coord(x2), _price(y2)

    line_obj = Line(
        x1=x1_val,
        y1=y1_val,
        x2=x2_val,
        y2=y2_val,
        xloc=xloc,
        extend=extend,
        color=color,
        style=style or style_solid,
        width=width,
        force_overlay=force_overlay
    )
    line_obj.vid = next_vid()
    _registry[line_obj] = None
    # Enforce Pine's max_lines_count cap: drop the oldest line (FIFO) past the limit.
    # A security child never sets ``lib._script``; fall back to TV's hard maximum
    # (500) there, otherwise the registry grows without bound (the child re-runs
    # main() for every bar of its own series, accumulating every drawing ever made).
    if len(_registry) > (lib._script.max_lines_count if lib._script is not None else 500):
        _remove(next(iter(_registry)))
    return line_obj


# noinspection PyShadowingBuiltins
@module_property
def all() -> list[Line]:
    """Returns all line objects"""
    return list(_registry)


# noinspection PyShadowingBuiltins
def delete(id):
    """Delete line object"""
    if isinstance(id, NA):
        return
    _remove(id)


# noinspection PyShadowingBuiltins,PyProtectedMember
def copy(id):
    """Copy line object"""
    if isinstance(id, NA):
        return NA(Line)
    clone = _copy(id)
    clone.vid = next_vid()
    _registry[clone] = None
    if len(_registry) > (lib._script.max_lines_count if lib._script is not None else 500):
        _remove(next(iter(_registry)))
    return clone


# noinspection PyShadowingBuiltins
def get_x1(id: Line) -> PyneInt:
    """
    Returns UNIX time or bar index (depending on the last xloc value set) of the first point of the line.

    :param id: Line object
    :return: UNIX timestamp (in milliseconds) or bar index
    """
    if isinstance(id, NA):
        return na_int
    return id.x1


# noinspection PyShadowingBuiltins
def get_y1(id: Line) -> PyneFloat:
    """
    Returns price of the first point of the line.

    :param id: Line object
    :return: Price of the first point
    """
    if isinstance(id, NA):
        return na_float
    return id.y1


# noinspection PyShadowingBuiltins
def get_x2(id: Line) -> PyneInt:
    """
    Returns UNIX time or bar index (depending on the last xloc value set) of the second point of the line.

    :param id: Line object
    :return: UNIX timestamp (in milliseconds) or bar index
    """
    if isinstance(id, NA):
        return na_int
    return id.x2


# noinspection PyShadowingBuiltins
def get_y2(id: Line) -> PyneFloat:
    """
    Returns price of the second point of the line.

    :param id: Line object
    :return: Price of the second point
    """
    if isinstance(id, NA):
        return na_float
    return id.y2


# noinspection PyShadowingBuiltins
def set_color(id: Line, color: _color.Color) -> None:
    """
    Sets the line color

    :param id: Line object
    :param color: New line color
    """
    if isinstance(id, NA):
        return
    id.color = color


# noinspection PyShadowingBuiltins
def set_extend(id: Line, extend: _extend.Extend) -> None:
    """
    Sets extending type of this line object

    :param id: Line object
    :param extend: New extending type
    """
    if isinstance(id, NA):
        return
    id.extend = extend


# noinspection PyShadowingBuiltins
def set_first_point(id: Line, point: ChartPoint) -> None:
    """
    Sets the first point of the id line to point

    :param id: A line object
    :param point: A chart.point object
    """
    if isinstance(id, NA):
        return
    if id.xloc == _xloc.bar_time:
        id.x1, id.y1 = _bar_coord(point.time), _price(point.price)
    else:  # xloc.bar_index
        id.x1, id.y1 = _bar_coord(point.index), _price(point.price)


# noinspection PyShadowingBuiltins
def set_second_point(id: Line, point: ChartPoint) -> None:
    """
    Sets the second point of the id line to point

    :param id: A line object
    :param point: A chart.point object
    """
    if isinstance(id, NA):
        return
    if id.xloc == _xloc.bar_time:
        id.x2, id.y2 = _bar_coord(point.time), _price(point.price)
    else:  # xloc.bar_index
        id.x2, id.y2 = _bar_coord(point.index), _price(point.price)


# noinspection PyShadowingBuiltins
def set_style(id: Line, style: LineEnum) -> None:
    """
    Sets the line style

    :param id: Line object
    :param style: New line style
    """
    if isinstance(id, NA):
        return
    id.style = style


# noinspection PyShadowingBuiltins
def set_width(id: Line, width: int) -> None:
    """
    Sets the line width

    :param id: Line object
    :param width: New line width in pixels
    """
    if isinstance(id, NA):
        return
    id.width = width


# noinspection PyShadowingBuiltins
def set_x1(id: Line, x: int) -> None:
    """
    Sets bar index or bar time (depending on the xloc) of the first point

    :param id: Line object
    :param x: Bar index or bar time
    """
    if isinstance(id, NA):
        return
    id.x1 = _bar_coord(x)


# noinspection PyShadowingBuiltins
def set_x2(id: Line, x: int) -> None:
    """
    Sets bar index or bar time (depending on the xloc) of the second point

    :param id: Line object
    :param x: Bar index or bar time
    """
    if isinstance(id, NA):
        return
    id.x2 = _bar_coord(x)


# noinspection PyShadowingBuiltins
def set_xloc(id: Line, x1: int, x2: int, xloc: _xloc.XLoc) -> None:
    """
    Sets x-location and new bar index/time values

    :param id: Line object
    :param x1: Bar index or bar time of the first point
    :param x2: Bar index or bar time of the second point
    :param xloc: New x-location value
    """
    if isinstance(id, NA):
        return
    id.x1 = _bar_coord(x1)
    id.x2 = _bar_coord(x2)
    id.xloc = xloc


# noinspection PyShadowingBuiltins
def set_xy1(id: Line, x: int, y: float) -> None:
    """
    Sets bar index/time and price of the first point

    :param id: Line object
    :param x: Bar index or bar time
    :param y: Price
    """
    if isinstance(id, NA):
        return
    id.x1 = _bar_coord(x)
    id.y1 = _price(y)


# noinspection PyShadowingBuiltins
def set_xy2(id: Line, x: int, y: float) -> None:
    """
    Sets bar index/time and price of the second point

    :param id: Line object
    :param x: Bar index or bar time
    :param y: Price
    """
    if isinstance(id, NA):
        return
    id.x2 = _bar_coord(x)
    id.y2 = _price(y)


# noinspection PyShadowingBuiltins
def set_y1(id: Line, y: float) -> None:
    """
    Sets price of the first point

    :param id: Line object
    :param y: Price
    """
    if isinstance(id, NA):
        return
    id.y1 = _price(y)


# noinspection PyShadowingBuiltins
def set_y2(id: Line, y: float) -> None:
    """
    Sets price of the second point

    :param id: Line object
    :param y: Price
    """
    if isinstance(id, NA):
        return
    id.y2 = _price(y)


# noinspection PyShadowingBuiltins
def get_price(id: Line, x: int) -> PyneFloat:
    """
    Returns the price level of a line at a given bar index.

    :param id: Line object
    :param x: Bar index for which price is required
    :return: Price value of line 'id' at bar index 'x'
    :raises RuntimeError: If the line was created with xloc.bar_time instead of xloc.bar_index
    """
    if isinstance(id, NA):
        return na_float
    
    # Check if line was created with xloc.bar_index
    if id.xloc != _xloc.bar_index:
        raise RuntimeError("line.get_price() can only be called for lines created using 'xloc.bar_index'")
    
    # Line is considered to have been created using 'extend=extend.both'
    # Calculate the slope of the line
    x1, y1 = id.x1, id.y1
    x2, y2 = id.x2, id.y2
    
    # Handle vertical line case (x1 == x2)
    if x1 == x2:
        # For vertical lines, return y1 for any x
        return y1
    
    # Calculate price using linear interpolation/extrapolation
    # Formula: y = y1 + (y2 - y1) * (x - x1) / (x2 - x1)
    slope = (y2 - y1) / (x2 - x1)
    price = y1 + slope * (x - x1)
    
    return price
