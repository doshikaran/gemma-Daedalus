from __future__ import annotations

from math import nan
from typing import TYPE_CHECKING, Any, TypeVar, overload

from ..types.footprint import Footprint
from ..types.na import NA

if TYPE_CHECKING:
    from ..core.currency import CurrencyRateProvider

_currency_provider: CurrencyRateProvider | None = None

# Bound on first use, never at module level: importing ``pynecore.lib`` from here
# would load the runtime surface while this module is still being imported.
# Caching leaves that ordering untouched and only stops the lookup from running
# again on every later bar.
_lib: Any = None

T = TypeVar('T')


# noinspection PyUnusedLocal
def security(symbol, timeframe, expression: T, *args, **kwargs) -> T:
    """
    Request data from another symbol/timeframe.

    Pine v6 positional signature:
    ``security(symbol, timeframe, expression, gaps, lookahead,
    ignore_invalid_symbol, currency, ...)``.

    Supported ``lookahead`` modes:

    - ``barmerge.lookahead_off`` (default): closed-only — the security
      context shows the most recently CLOSED security bar in both
      historical and live mode. Repaint-free.
    - ``barmerge.lookahead_last_closed``: PyneSys-native synonym for
      "last closed" in any mode. Functionally identical to
      ``lookahead_off`` in PyneCore; prefer it when "last closed" is the
      explicit intent (no reliance on the TV ``close[1]`` idiom).
    - ``barmerge.lookahead_on``: same-symbol HTF — the security context
      steps into the containing HTF bar, which runs with
      ``barstate.isconfirmed=False`` over OHLCV aggregated from the chart
      timeframe. Historical and live mode behave identically. The
      daily-pivot idiom ``security(sym, "D", close[1], lookahead_on)`` reads
      the just-closed prior period, matching TradingView.

      A bare ``close`` reads the containing period AS BUILT SO FAR, which
      **differs from TradingView deliberately**: TV returns the period's
      final close on every chart bar of the period, i.e. future data
      everywhere but the period's last bar, and PyneCore does not reproduce
      lookahead. Cross-symbol HTF: the developing bar cannot be aggregated
      (wrong instrument), so a chart bar inside an open HTF period reads as
      ``na``; ``close[1]`` at the period boundary still delivers the
      just-closed cross-symbol HTF close, so the idiom continues to work.

    This function exists for IDE support only. In compiled scripts, the
    SecurityTransformer rewrites all calls into the signal/write/read
    protocol at AST level — this function is never called at runtime.
    """
    raise RuntimeError(
        "request.security() should not be called directly. "
        "It is rewritten by SecurityTransformer during compilation."
    )


# noinspection PyUnusedLocal
@overload
def security_lower_tf(
        symbol, timeframe, expression: tuple,
        ignore_invalid_symbol=False, currency=None,
        ignore_invalid_timeframe=False, calc_bars_count=None,
) -> tuple[list, ...]: ...


# noinspection PyUnusedLocal
@overload
def security_lower_tf(
        symbol, timeframe, expression: T,
        ignore_invalid_symbol=False, currency=None,
        ignore_invalid_timeframe=False, calc_bars_count=None,
) -> list[T]: ...


# noinspection PyUnusedLocal
def security_lower_tf(
        symbol, timeframe, expression,
        ignore_invalid_symbol=False, currency=None,
        ignore_invalid_timeframe=False, calc_bars_count=None,
) -> Any:
    """
    Request intrabar data from a lower timeframe.

    Returns an array of values, one per intrabar within each chart bar; a tuple
    expression yields a tuple of such arrays, one per tuple element.
    This function exists for IDE support only. In compiled scripts, the
    SecurityTransformer rewrites all calls into the LTF signal/write/read
    protocol at AST level — this function is never called at runtime.

    :param symbol: Symbol to request data from
    :param timeframe: Lower timeframe string (must be <= chart timeframe)
    :param expression: Expression to evaluate in the lower timeframe context
    :param ignore_invalid_symbol: If True, return empty array for invalid symbols
    :param currency: Currency for conversion (not yet supported)
    :param ignore_invalid_timeframe: If True, ignore invalid timeframe
    :param calc_bars_count: Number of bars to calculate (not yet supported)
    :return: array of expression values per intrabar
    """
    raise RuntimeError(
        "request.security_lower_tf() should not be called directly. "
        "It is rewritten by SecurityTransformer during compilation."
    )


def currency_rate(from_currency: str, to_currency: str) -> float:
    """
    Get the currency conversion rate between two currencies.

    Returns the exchange rate to convert from ``from_currency`` to ``to_currency``
    at the current bar's timestamp. The rate is looked up from OHLCV data files
    whose TOML metadata matches the requested currency pair.

    An empty currency code means "no conversion" and the identity rate needs no
    data at all, so both cases answer 1.0 before any provider is consulted.

    :param from_currency: Source currency code (e.g. ``"EUR"``, ``currency.EUR``)
    :param to_currency: Target currency code (e.g. ``"USD"``, ``currency.USD``)
    :return: Exchange rate as float, or ``na`` if no data is available
    """
    # Measured on TradingView (CAPITALCOM:EURUSD 60): ("USD", ""), ("", "USD"),
    # ("", "") and ("USD", "USD") all plot 1.0, while ("EUR", "USD") plots the
    # real rate. Pine's own "Default currency" inputs pass "" for exactly this.
    _from, _to = str(from_currency), str(to_currency)
    if not _from or not _to or _from == _to:
        return 1.0
    if _currency_provider is None:
        return nan
    global _lib
    if (lib := _lib) is None:
        from .. import lib
        _lib = lib
    # noinspection PyProtectedMember
    timestamp = int(lib._datetime.timestamp())
    return _currency_provider.get_rate(_from, _to, timestamp)


# noinspection PyUnusedLocal
def dividends(
        ticker=None, field=None, gaps=None, lookahead=None,
        ignore_invalid_symbol=False, currency=None,
) -> float:
    """
    Request dividend data for a symbol.

    :param ticker: Symbol ticker
    :param field: Dividend field (dividends.gross, dividends.net)
    :param gaps: Gap handling mode (barmerge.gaps_on/off)
    :param lookahead: Lookahead mode (barmerge.lookahead_on/off)
    :param ignore_invalid_symbol: If True, return na instead of raising
    :param currency: Currency the returned values are converted to
    :return: Dividend value or na
    :raises NotImplementedError: When ignore_invalid_symbol is False
    """
    if ignore_invalid_symbol:
        return nan
    raise NotImplementedError("request.dividends() is not yet implemented in PyneCore")


# noinspection PyUnusedLocal
def splits(
        ticker=None, field=None, gaps=None, lookahead=None,
        ignore_invalid_symbol=False,
) -> float:
    """
    Request stock split data for a symbol.

    :param ticker: Symbol ticker
    :param field: Split field (splits.numerator, splits.denominator)
    :param gaps: Gap handling mode (barmerge.gaps_on/off)
    :param lookahead: Lookahead mode (barmerge.lookahead_on/off)
    :param ignore_invalid_symbol: If True, return na instead of raising
    :return: Split value or na
    :raises NotImplementedError: When ignore_invalid_symbol is False
    """
    if ignore_invalid_symbol:
        return nan
    raise NotImplementedError("request.splits() is not yet implemented in PyneCore")


# noinspection PyUnusedLocal
def earnings(
        ticker=None, field=None, gaps=None, lookahead=None,
        ignore_invalid_symbol=False, currency=None,
) -> float:
    """
    Request earnings data for a symbol.

    :param ticker: Symbol ticker
    :param field: Earnings field (earnings.actual, earnings.estimate, earnings.standardized)
    :param gaps: Gap handling mode (barmerge.gaps_on/off)
    :param lookahead: Lookahead mode (barmerge.lookahead_on/off)
    :param ignore_invalid_symbol: If True, return na instead of raising
    :param currency: Currency the returned values are converted to
    :return: Earnings value or na
    :raises NotImplementedError: When ignore_invalid_symbol is False
    """
    if ignore_invalid_symbol:
        return nan
    raise NotImplementedError("request.earnings() is not yet implemented in PyneCore")


# noinspection PyUnusedLocal
def financial(
        symbol=None, financial_id=None, period=None, gaps=None,
        ignore_invalid_symbol=False, currency=None,
) -> float:
    """
    Request financial data from FactSet.

    :param symbol: Symbol ticker
    :param financial_id: Financial metric id (e.g. "MARKET_CAP_BASIC")
    :param period: Reporting period ("FQ", "FH", "FY", "TTM", "D")
    :param gaps: Gap handling mode (barmerge.gaps_on/off)
    :param ignore_invalid_symbol: If True, return na instead of raising
    :param currency: Currency for conversion
    :return: Financial value or na
    :raises NotImplementedError: When ignore_invalid_symbol is False
    """
    if ignore_invalid_symbol:
        return nan
    raise NotImplementedError("request.financial() is not yet implemented in PyneCore")


# noinspection PyUnusedLocal
def economic(*args, **kwargs) -> float:
    """
    Request economic data.

    :raises NotImplementedError: Not yet implemented in PyneCore
    """
    raise NotImplementedError("request.economic() is not yet implemented in PyneCore")


# noinspection PyUnusedLocal
def quandl(*args, **kwargs) -> float:
    """
    Request data from Quandl/Nasdaq.

    :raises NotImplementedError: Not yet implemented in PyneCore
    """
    raise NotImplementedError("request.quandl() is not yet implemented in PyneCore")


# noinspection PyUnusedLocal
def seed(source=None, symbol=None, expression=None,
         ignore_invalid_symbol=False, calc_bars_count=None):
    """
    Request data from user-maintained GitHub repositories.

    Seed data lives in TradingView-hosted community repositories that PyneCore
    has no access to — like :func:`footprint`, the data is fundamentally
    unavailable, so the call returns ``na`` instead of aborting the script;
    well-written scripts guard their seed series with ``na()`` checks.

    :param source: Seed repository name (e.g. "seed_crypto_santiment")
    :param symbol: Data series name within the repository
    :param expression: Expression to evaluate in the seed context
    :param ignore_invalid_symbol: If True, return na for invalid symbols
    :param calc_bars_count: Number of bars to calculate (unused)
    :return: na, or a tuple of na when ``expression`` is a tuple
    """
    # A tuple expression yields a tuple in Pine, so the na fallback has to keep the
    # arity -- otherwise the compiled ``a, b = request.seed(...)`` destructuring dies
    # with "na is not iterable" instead of handing the script two na values.
    # Only a tuple, never a list: PyneComp compiles a Pine tuple expression to a tuple
    # literal, while a Pine array arrives as a plain list. Measured on TradingView
    # (BINANCE:BTCUSDT 1D): an array expression is legal and returns a single na array
    # id -- array.size() on it halts with RE10052 -- so it must stay one na here too.
    if isinstance(expression, tuple):
        return tuple(NA(None) for _ in expression)
    return NA(None)


# noinspection PyUnusedLocal
def footprint(ticks_per_row: int, va_percent: int = 70,
              imbalance_percent: int = 300) -> Footprint | NA[Footprint]:
    """
    Request volume footprint data for the current bar.

    Footprint order flow (per-tick buy/sell aggressor split, POC, VAH, VAL) is
    sourced by TradingView from tick-level bid/ask data that PyneCore does not
    have — only OHLCV bars are available. Rather than aborting the whole script,
    the footprint is reported as ``na`` so that scripts guarding their footprint
    reads with ``na()`` (the required Pine pattern, since TV itself returns na
    when footprint data is unavailable) fall back to their price-action paths.

    :param ticks_per_row: Number of ticks per footprint row
    :param va_percent: Value Area percentage
    :param imbalance_percent: Buy/sell imbalance threshold percentage
    :return: ``na`` footprint (order-flow data unavailable in PyneCore)
    """
    return NA(Footprint)


def _reset_request_state() -> None:
    """Reset request module state between script runs."""
    global _currency_provider
    _currency_provider = None
