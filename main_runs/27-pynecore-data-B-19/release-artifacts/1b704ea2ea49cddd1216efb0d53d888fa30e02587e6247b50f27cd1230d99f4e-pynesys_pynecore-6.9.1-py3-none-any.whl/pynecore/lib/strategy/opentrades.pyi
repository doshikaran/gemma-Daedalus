from ...types import PyneFloat, PyneInt, PyneStr


# IDE-facing view of the function-and-namespace module: bare ``strategy.opentrades``
# is an int value, ``strategy.opentrades.commission(...)`` a namespaced function;
# the AST transformer resolves both at runtime. The ``int`` base keeps arithmetic
# on the bare name type-checking.
class OpenTradesModule(int):
    def __call__(self) -> PyneInt: ...

    #
    # Variables
    #

    capital_held: PyneFloat

    #
    # Functions
    #

    def commission(self, trade_num: int) -> PyneFloat: ...

    def entry_bar_index(self, trade_num: int) -> PyneInt: ...

    def entry_comment(self, trade_num: int) -> PyneStr: ...

    def entry_id(self, trade_num: int) -> PyneStr: ...

    def entry_price(self, trade_num: int) -> PyneFloat: ...

    def entry_time(self, trade_num: int) -> PyneInt: ...

    def max_drawdown(self, trade_num: int) -> PyneFloat: ...

    def max_drawdown_percent(self, trade_num: int) -> PyneFloat: ...

    def max_runup(self, trade_num: int) -> PyneFloat: ...

    def max_runup_percent(self, trade_num: int) -> PyneFloat: ...

    def profit(self, trade_num: int) -> PyneFloat: ...

    def profit_percent(self, trade_num: int) -> PyneFloat: ...

    def size(self, trade_num: int) -> PyneFloat: ...


opentrades: OpenTradesModule
