from __future__ import annotations
from typing import TypeVar, Generic

T = TypeVar('T')

class Series(Generic[T]):
    """
    Runtime placeholder for the Pine series type: it passes the value
    through unchanged, so the annotation costs nothing at runtime.

    def __call__(self, val: T) -> T:
        return val

    def __new__(cls, val: T) -> T:
        return val

PersistentSeries = Series
