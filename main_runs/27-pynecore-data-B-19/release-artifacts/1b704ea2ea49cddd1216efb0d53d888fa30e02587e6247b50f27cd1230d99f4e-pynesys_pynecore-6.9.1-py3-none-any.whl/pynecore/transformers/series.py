"""
Transform Series type annotations and accesses into state-vector slots.

A series variable's circular buffer (a
:class:`~pynecore.core.series.SeriesImpl`) lives in a compile-time-assigned
slot of its scope's state vector; ``_make_state`` creates a fresh buffer for
every instance from the layout's ``series`` entries. The emitted code
addresses the buffer with a literal index:

- ``s: Series[float] = value`` -> ``s = __state__[N].add(value)`` (the local
  name keeps tracking the current scalar value, plain reads stay untouched),
- ``s = value``                -> ``s = __state__[N].set(value)``,
- ``s += value``               -> ``s = __state__[N].set(s + value)``,
- ``s[idx]``                   -> ``__state__[N][idx]``,
- ``lib.max_bars_back(s, num)`` in statement position
                               -> ``__state__[N].max_bars_back = num``
  (other positions are left to the ``lib.max_bars_back`` runtime no-op), and the
  same for the other buffer setters in ``_BUFFER_SETTERS``,
- a ``Series``-annotated parameter loses the Series wrapper from its
  annotation and gets ``s = __state__[N].add(s)`` prepended to the body.

Subscript READS resolve through the scope chain: a nested definition reaches
a parent's series buffer through a closure reference on the parent's
scope-qualified state parameter. The library-series declarations that
:class:`~pynecore.transformers.lib_series.LibrarySeriesTransformer` anchors
in ``main`` rely on this. Writes stay same-scope only, like the legacy
transformer: a plain assignment in a nested scope declares a local that
shadows the parent's series.
"""
from typing import cast
import ast

from .dynamic_default import is_dynamic_default_guard
from .pine_type_rules import OBJECT, get_ty, set_ty, stamp_lowering
from .slot_layout import ModuleLayout, scope_for_function

__all__ = ['SeriesTransformer']

#: ``lib`` no-ops that address a series buffer itself instead of its value, mapped
#: to the :class:`~pynecore.core.series.SeriesImpl` attribute they set. Only a
#: statement-position call on a series NAME is converted; every other position is
#: left to the runtime no-op in :mod:`pynecore.lib`.
_BUFFER_SETTERS = {
    'max_bars_back': 'max_bars_back',
}


class SeriesTransformer(ast.NodeTransformer):
    """Rewrite Series declarations and accesses to state-vector slots."""

    def __init__(self, layout: ModuleLayout):
        self.layout = layout
        self.scope_stack: list[str] = []
        self.current_scope: str = ''
        # scope -> var name -> series slot
        self.series_slots: dict[str, dict[str, int]] = {}
        self.series_declarations: dict[str, set[str]] = {}
        self.local_vars: dict[str, set[str]] = {}
        # Inside a parameter-default guard, where an assignment to a series
        # parameter gives it its value instead of writing its history
        self._in_default_guard = False

    # --- helpers ---------------------------------------------------------

    def _lookup(self, var_name: str) -> tuple[str, int] | None:
        """Resolve a name to its declaring scope and series slot.

        A name locally assigned in the current scope (but not declared as a
        Series there) shadows any parent series of the same name.

        :param var_name: Source-level variable name.
        :return: (declaring scope, slot index) or None.
        """
        if (var_name in self.local_vars.get(self.current_scope, ())
                and var_name not in self.series_declarations.get(self.current_scope, ())):
            return None
        slots = self.series_slots.get(self.current_scope)
        if slots is not None and var_name in slots:
            return self.current_scope, slots[var_name]
        for i in range(len(self.scope_stack) - 1, 0, -1):
            scope = '·'.join(self.scope_stack[:i])
            slots = self.series_slots.get(scope)
            if slots is not None and var_name in slots:
                return scope, slots[var_name]
        return None

    def _state_ref(self, scope: str, slot: int) -> ast.Subscript:
        """Build a ``<state param>[slot]`` reference for a scope."""
        return ast.Subscript(
            value=ast.Name(id=self.layout.state_param(scope), ctx=ast.Load()),
            slice=ast.Constant(value=slot), ctx=ast.Load())

    def _buffer_call(self, scope: str, slot: int, method: str, args: list[ast.expr]) -> ast.Call:
        """Build a ``<state param>[slot].<method>(...)`` call.

        ``add`` and ``set`` both return the value they stored, so the call
        stands where that value stood and carries its Pine type.
        """
        return stamp_lowering(ast.Call(
            func=ast.Attribute(value=self._state_ref(scope, slot),
                               attr=method, ctx=ast.Load()),
            args=args, keywords=[]), get_ty(args[0]) if args else OBJECT)

    def _register(self, var_name: str, elem: str | None = None) -> int:
        """Allocate a series slot for a declaration in the current scope.

        :param var_name: Source-level variable name.
        :param elem: Statically known element type name from the ``Series[T]``
            annotation (``'float'`` and ``'int'`` select the native-nan na value,
            ``'int'`` also stores every value as a float), or None.
        :return: The allocated slot index.
        """
        slot = self.layout.scope(self.current_scope).add_series(
            var_name, ast.Constant(value=None), elem)
        self.series_slots.setdefault(self.current_scope, {})[var_name] = slot
        self.series_declarations[self.current_scope].add(var_name)
        self.local_vars[self.current_scope].add(var_name)
        return slot

    @staticmethod
    def _is_series_type(annotation: ast.expr) -> bool:
        """Check if a type annotation is Series."""
        if isinstance(annotation, ast.Subscript):
            return (isinstance(annotation.value, ast.Name)
                    and annotation.value.id == 'Series')
        return isinstance(annotation, ast.Name) and annotation.id == 'Series'

    @staticmethod
    def _series_elem(annotation: ast.expr) -> str | None:
        """Element type name of a ``Series[T]`` annotation, if statically known.

        Only the scalar names are meaningful downstream: the numeric ones
        select the native nan as the series' na value, and ``'int'``
        additionally makes the series store every value as a float (a Pine int
        is a double at runtime); ``'bool'`` selects the bool na the script runs
        with. Everything else — bare ``Series``, other element types, complex
        annotations — yields None.

        :param annotation: The (Series) type annotation.
        :return: ``'float'``, ``'int'`` or ``'bool'`` for those element types, otherwise None.
        """
        if (isinstance(annotation, ast.Subscript)
                and isinstance(annotation.slice, ast.Name)
                and annotation.slice.id in ('float', 'int', 'bool')):
            return annotation.slice.id
        return None

    # --- visitors --------------------------------------------------------

    def visit_Module(self, node: ast.Module) -> ast.Module:
        self.layout.assign_scope_ids(node)
        return cast(ast.Module, self.generic_visit(node))

    def visit_ImportFrom(self, node: ast.ImportFrom) -> ast.ImportFrom | None:
        """Strip the Series name from pynecore imports."""
        if node.module and node.module.startswith('pynecore'):
            new_names = [name for name in node.names if name.name != 'Series']
            if not new_names:
                return None
            node.names = new_names
        return node

    def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
        """Track scopes and convert Series-annotated parameters."""
        self.scope_stack.append(self.layout.scope_segment(node))
        self.current_scope = '·'.join(self.scope_stack)
        scope_for_function(self.layout, self.current_scope, node)
        self.local_vars.setdefault(self.current_scope, set())
        self.series_declarations.setdefault(self.current_scope, set())

        param_inits: list[ast.stmt] = []
        for arg in node.args.args:
            self.local_vars[self.current_scope].add(arg.arg)
            if arg.annotation is not None and self._is_series_type(arg.annotation):
                slot = self._register(arg.arg, self._series_elem(arg.annotation))
                arg.annotation = (arg.annotation.slice
                                  if isinstance(arg.annotation, ast.Subscript) else None)
                param_inits.append(ast.Assign(
                    targets=[ast.Name(id=arg.arg, ctx=ast.Store())],
                    value=self._buffer_call(self.current_scope, slot, 'add',
                                            [ast.Name(id=arg.arg, ctx=ast.Load())])))

        node = cast(ast.FunctionDef, self.generic_visit(node))

        if param_inits:
            insert_pos = 0
            first = node.body[0] if node.body else None
            if (isinstance(first, ast.Expr) and isinstance(first.value, ast.Constant)
                    and isinstance(first.value.value, str)):
                insert_pos = 1
            # A parameter whose default is dynamic arrives as the sentinel and
            # gets its value in DynamicDefaultTransformer's guard block;
            # recording it above that would put the sentinel into the series.
            # The block is contiguous but need not be first — an earlier pass
            # may have prepended a hoisted declaration of its own
            guard = next((i for i, stmt in enumerate(node.body)
                          if is_dynamic_default_guard(stmt)), None)
            if guard is not None:
                insert_pos = guard
                while insert_pos < len(node.body) \
                        and is_dynamic_default_guard(node.body[insert_pos]):
                    insert_pos += 1
            node.body[insert_pos:insert_pos] = param_inits

        self.scope_stack.pop()
        self.current_scope = '·'.join(self.scope_stack)
        return node

    def visit_AnnAssign(self, node: ast.AnnAssign) -> ast.AST | None:
        """Convert Series declarations into slot allocations with ``add()``."""
        if not (isinstance(node.target, ast.Name) and self._is_series_type(node.annotation)):
            if isinstance(node.target, ast.Name) and self.current_scope:
                # An annotated assignment declares a local — it shadows a
                # same-named parent series, like a plain assignment does.
                self.local_vars.setdefault(self.current_scope, set()).add(node.target.id)
            if node.value:
                node.value = cast(ast.expr, self.visit(node.value))
            return node

        if not self.current_scope:
            raise SyntaxError("Series variables must be declared inside a function")

        slot = self._register(node.target.id, self._series_elem(node.annotation))
        if node.value is None:
            return None
        return ast.Assign(
            targets=[ast.Name(id=node.target.id, ctx=ast.Store())],
            value=self._buffer_call(self.current_scope, slot, 'add',
                                    [cast(ast.expr, self.visit(node.value))]))

    def visit_If(self, node: ast.If) -> ast.AST:
        """Leave a parameter-default guard's own assignment alone.

        ``DynamicDefaultTransformer`` emits ``if p is <sentinel>: p = <default>``
        at the top of the body, which gives a PARAMETER its value; the series
        recording of that parameter happens right after the guard block. Writing
        the default through the buffer instead would write into a series that
        has not recorded this bar yet -- ``set()`` on an empty buffer answers na
        and stores nothing.
        """
        if is_dynamic_default_guard(node):
            outer, self._in_default_guard = self._in_default_guard, True
            try:
                node.body = [cast(ast.stmt, self.visit(stmt)) for stmt in node.body]
            finally:
                self._in_default_guard = outer
            return node
        return cast(ast.AST, self.generic_visit(node))

    def visit_Assign(self, node: ast.Assign) -> ast.AST | list[ast.stmt]:
        """Convert assignments to same-scope series variables into buffer writes."""
        if len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            var_name = cast(ast.Name, node.targets[0]).id
            slots = self.series_slots.get(self.current_scope)
            if self._in_default_guard and slots is not None and var_name in slots:
                # The guard resolves the parameter; the buffer write follows it
                node.value = cast(ast.expr, self.visit(node.value))
                return node
            if slots is not None and var_name in slots:
                return ast.Assign(
                    targets=[ast.Name(id=var_name, ctx=ast.Store())],
                    value=self._buffer_call(self.current_scope, slots[var_name], 'set',
                                            [cast(ast.expr, self.visit(node.value))]))
            if self.current_scope:
                self.local_vars.setdefault(self.current_scope, set()).add(var_name)

        # Tuple/list unpacking (``a, b = f()``): a series element is declared bare
        # (``a: Series`` with no initializer, so no per-bar ``add()``) and the
        # unpack only binds the local name — its buffer never advances. Emit an
        # ``add()`` per series element to record history so ``a[1]`` works.
        target = node.targets[0] if len(node.targets) == 1 else None
        if (isinstance(target, (ast.Tuple, ast.List))
                and self.current_scope
                and all(isinstance(e, ast.Name) for e in target.elts)):
            slots = self.series_slots.get(self.current_scope, {})
            node.value = cast(ast.expr, self.visit(node.value))
            stmts: list[ast.stmt] = [node]
            for elt in target.elts:
                name = cast(ast.Name, elt).id
                if name in slots:
                    stmts.append(ast.Assign(
                        targets=[ast.Name(id=name, ctx=ast.Store())],
                        value=self._buffer_call(self.current_scope, slots[name], 'add',
                                                [ast.Name(id=name, ctx=ast.Load())])))
                else:
                    self.local_vars.setdefault(self.current_scope, set()).add(name)
            return stmts if len(stmts) > 1 else node

        return cast(ast.AST, self.generic_visit(node))

    def visit_AugAssign(self, node: ast.AugAssign) -> ast.AST:
        """Convert augmented assignments to same-scope series into ``set()``."""
        if isinstance(node.target, ast.Name):
            slots = self.series_slots.get(self.current_scope)
            if slots is not None and node.target.id in slots:
                # The target's stamp is the type of the AUGMENTED value, which
                # is what both the read below and the whole expression carry
                augmented = get_ty(node.target)
                value = stamp_lowering(
                    ast.BinOp(left=set_ty(ast.Name(id=node.target.id, ctx=ast.Load()),
                                          augmented),
                              op=node.op,
                              right=cast(ast.expr, self.visit(node.value))), augmented)
                return ast.Assign(
                    targets=[ast.Name(id=node.target.id, ctx=ast.Store())],
                    value=self._buffer_call(self.current_scope, slots[node.target.id],
                                            'set', [value]))
        return cast(ast.AST, self.generic_visit(node))

    def visit_Subscript(self, node: ast.Subscript) -> ast.AST:
        """Rewrite series indexing to address the buffer in its slot."""
        if isinstance(node.value, ast.Name):
            found = self._lookup(node.value.id)
            if found:
                scope, slot = found
                node.value = self._state_ref(scope, slot)
                node.slice = cast(ast.expr, self.visit(node.slice))
                return node
        return cast(ast.AST, self.generic_visit(node))

    def visit_Expr(self, node: ast.Expr) -> ast.AST:
        """Convert a statement-position buffer setter call into an attribute
        assignment on the buffer (see :data:`_BUFFER_SETTERS`)."""
        call = node.value
        if (isinstance(call, ast.Call) and isinstance(call.func, ast.Attribute)
                and call.func.attr in _BUFFER_SETTERS
                and isinstance(call.func.value, ast.Name)
                and call.func.value.id == 'lib'
                and len(call.args) >= 2 and isinstance(call.args[0], ast.Name)):
            found = self._lookup(call.args[0].id)
            if found:
                scope, slot = found
                return ast.Assign(
                    targets=[ast.Attribute(value=self._state_ref(scope, slot),
                                           attr=_BUFFER_SETTERS[call.func.attr], ctx=ast.Store())],
                    value=cast(ast.expr, self.visit(call.args[1])))
        return cast(ast.AST, self.generic_visit(node))
