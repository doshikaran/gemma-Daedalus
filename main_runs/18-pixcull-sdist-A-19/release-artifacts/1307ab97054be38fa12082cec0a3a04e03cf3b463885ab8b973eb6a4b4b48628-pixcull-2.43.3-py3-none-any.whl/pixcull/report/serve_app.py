"""Web demo for PixCull: upload images → auto detect / sort / score.

This is the V1.2 user-facing demo. It complements ``scripts/serve_review.py``
(which compares pipeline output against a labeled golden set) by letting a
user drop in a *fresh* batch of images they've never labeled and see the
pipeline's keep / maybe / cull verdict in their browser.

Architecture (single-file, stdlib http.server only):

  GET    /                  upload page (HTML + drag-drop input)
  POST   /analyze           multipart upload of N images → returns {run_id}
                            (background thread starts the pipeline)
  POST   /scan_local        analyze a local folder *in place* (no copy)
                            body: {folder: "/path/to/photos"} → {run_id, n}
                            For users with GB-scale RAW collections: only
                            scores.csv / thumbs / XMP land in /tmp; the
                            originals stay where they live.
  POST   /browse            list a server-side directory (file picker UX)
                            body: {path?: str} → {entries, parent}
  GET    /status/<run_id>   JSON {state, done, total, message}
  GET    /results/<run_id>  rendered HTML grid of decisions for that run
  POST   /export/<run_id>   write XMP sidecars
                            body: {target?: "tmp"|"alongside"} (V1.2)
                            'alongside' (scan mode only) writes next to the
                            originals where Lightroom expects them
  GET    /xmp_zip/<run_id>  download all sidecars as a single .zip
  GET    /thumb/<run_id>/<filename>  thumbnail (lazy-built, cached on disk)
  GET    /full/<run_id>/<filename>   full-size preview
  GET    /runs              admin: list every run with size + age + decisions
  GET    /storage_info      admin: total disk usage + model cache breakdown
  DELETE /runs/<run_id>     admin: remove one run's input + output dir
                            (scan-mode runs ONLY touch /tmp output;
                             originals are never deleted)
  POST   /runs/cleanup      admin: bulk delete by policy
                            JSON body: {older_than_hours?: int, keep_last?: int}

Why a separate file from serve_review.py:

  - serve_review needs ground_truth.csv to exist; demo uploads have no GT
  - The demo flow has an extra "uploading → analyzing → done" lifecycle
    that doesn't apply to the static review viewer
  - Keeping the review viewer untouched preserves its label-collection role

Reuses from the project: pixcull.pipeline.orchestrator.run_pipeline (with
its progress_cb hook), pixcull.io.loader.load_image (for thumbnail decode),
pixcull.io.xmp.write_xmp + decision_to_xmp (for the LR/C1 export).

Defaults:
  --host 127.0.0.1   localhost only (safe; LAN exposure must be opt-in)
  --rescorer-mode off  works on machines without a trained rescorer.

LAN sharing: ``--host 0.0.0.0`` opens the port to your LAN. The CLI
prints both ``127.0.0.1`` and the machine's first non-loopback v4 IP
so you (or someone on your wifi) can hit it from a phone or laptop.
File uploads up to 200 MB; no auth — only run on networks you trust.
"""

from __future__ import annotations

import argparse
import cgi  # noqa: DEP002 — deprecated but present in 3.12; we control runtime
import io
import json
import shutil
import socket
import os
import sys
import threading
import time
import traceback
import uuid
import webbrowser
from collections import Counter
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import quote, unquote, urlparse

# v2.31 — packaged-install support. Until now every asset path was
# `Path(__file__).parent.parent / …`, i.e. "this file lives in
# <repo>/scripts/", which is true for a git clone and FALSE for a
# pip-installed wheel (where serve_demo ships inside the pixcull package
# and there is no repo root). Two resolvers split the concerns:
#
#   _pkg_root()  — the installed `pixcull` package dir. Always correct;
#                  templates + locale ship inside the wheel, so anything
#                  REQUIRED at runtime resolves through here.
#   _repo_root() — the git checkout root, or None when pip-installed.
#                  Only for dev/optional assets (samples/, models/,
#                  docs/, training CSV dumps) that the wheel omits; call
#                  sites already degrade when they're missing.
def _pkg_root() -> Path:
    """Directory of the installed `pixcull` package (works both from a
    git checkout and from site-packages)."""
    import pixcull as _pixcull_pkg
    return Path(_pixcull_pkg.__file__).resolve().parent


def _repo_root() -> Path | None:
    """The git checkout root, or None when running from a wheel.
    Detected by the presence of pyproject.toml one level above this
    file's dir — a pip install has no such layout."""
    # This module ships INSIDE the package (pixcull/report/serve_app.py),
    # so the checkout root is three levels up — and only exists in a clone.
    cand = Path(__file__).resolve().parent.parent.parent
    return cand if (cand / "pyproject.toml").is_file() else None


# v2.5-P0-1 — pure serialization/coercion helpers extracted to an
# importable, unit-tested module (first slice of de-monolithing this file).
# Imported back into this namespace so every existing call site is unchanged.
from pixcull.report.serve_util import (  # noqa: E402,F401
    _clean_csv_string,
    _f,
    _html_escape,
    _opt_int,
    _parse_int_list,
    _safe_dumps,
    _scrub_nan,
)

# ---------------------------------------------------------------------------
# Module-level state. _RUNS is keyed by short hex IDs; each run tracks its
# own input/output dirs + progress so the upload page can poll status.
#
# Threading model: each upload spawns one background thread that runs the
# pipeline; the HTTP server is a ThreadingHTTPServer so polls don't block on
# the analyzer thread. We never share dataframes across threads — the
# results page reads scores.csv off disk after the run finishes.
# ---------------------------------------------------------------------------
_RUNS: dict[str, dict] = {}
_RUNS_LOCK = threading.Lock()

# v0.10-P0-2 — live mDNS service handles, keyed by event_id.  The
# event-issue handler populates this on advertise; the revoke
# handler pops + unadvertises.  Module-level so the daemon-thread
# server class can reach it across all request handlers.
_MDNS_ADVERTS: dict[str, dict] = {}

# V2.1 retrain state — one global slot since you only ever want one
# training job running at a time. Guarded by _RUNS_LOCK to keep the
# /retrain handler simple.
_RETRAIN_STATE: dict = {"state": "idle"}

# V14.6 — first-run model-download state. The launcher kicks off
# ``run_first_setup`` in a thread after starting the server; that
# thread updates this dict via ``first_run_set`` between targets.
# The browser polls /first_run_status every 1.5 s to drive a progress
# UI, so the user sees something happening during the 5-10 minute
# initial download instead of an eerily silent dock icon.
#
# Phases:
#   "idle"     — first run already completed, page should redirect
#   "warming"  — actively downloading; ``current`` / ``total`` /
#                ``step_label`` populated
#   "done"     — completed (with or without errors); page redirects
#                to / after a 1 s celebration
#   "skipped"  — first-run was cancelled by the user (no setup ran)
_FIRST_RUN_STATE: dict = {
    "phase":      "idle",
    "current":    0,
    "total":      0,
    "step_label": "",
    "errors":     [],
    "include_vlm": False,
    "started_at": 0.0,
}
_FIRST_RUN_LOCK = threading.Lock()


def first_run_set(**kwargs) -> None:
    """Thread-safe state update from the launcher's setup thread.

    Call from the launcher between warming steps to surface progress
    to any browser tab pointed at /first_run. Unknown keys are
    accepted so we can extend the schema without coordinating
    cross-module bumps.
    """
    with _FIRST_RUN_LOCK:
        _FIRST_RUN_STATE.update(kwargs)


def first_run_snapshot() -> dict:
    """Read-only copy for the /first_run_status endpoint."""
    with _FIRST_RUN_LOCK:
        out = dict(_FIRST_RUN_STATE)
        # ``errors`` is a list — return a copy so the caller can
        # mutate freely without racing the writer.
        out["errors"] = list(out.get("errors", []))
        return out


def first_run_append_error(label: str, msg: str) -> None:
    """Add a single warming-step failure to the error list."""
    with _FIRST_RUN_LOCK:
        _FIRST_RUN_STATE.setdefault("errors", []).append(
            {"label": label, "message": msg}
        )


# V17.7 — bulk-classify whitelist. The bulk-classify endpoint scans
# a user-supplied folder; subsequent /verticals/bulk_thumb requests
# need to validate the requested path against what we just saw so
# users can't probe arbitrary parts of the filesystem via the
# thumbnail server. Keyed by abs-path string; value is the (mtime,
# size) we measured at scan time so a swapped-out file is rejected.
_BULK_PATHS: dict[str, tuple[float, int]] = {}
_BULK_LOCK = threading.Lock()


def _bulk_register_paths(paths: list[Path]) -> None:
    with _BULK_LOCK:
        for p in paths:
            try:
                st = p.stat()
                _BULK_PATHS[str(p.resolve())] = (st.st_mtime, st.st_size)
            except OSError:
                continue


def _bulk_path_allowed(p: Path) -> bool:
    try:
        rp = str(p.resolve())
    except OSError:
        return False
    with _BULK_LOCK:
        return rp in _BULK_PATHS


# V14.7 — config helpers. The launcher's app_data_dir / config_path /
# load_config also handle this (more robustly with corruption backups),
# but we can't import from app/launcher.py here without creating a
# circular import. Lightweight duplicates good enough for the
# settings-toggle endpoints; first_read_config falls back to {} on
# any error rather than corrupting the file.
def _app_data_dir() -> Path:
    if sys.platform == "darwin":
        p = Path.home() / "Library" / "Application Support" / "PixCull"
    else:
        p = Path.home() / ".pixcull"
    try:
        p.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        _dbg("_app_data_dir", exc, str(p))
    return p


def _user_config_path() -> Path:
    return _app_data_dir() / "config.json"


def _load_user_config() -> dict:
    p = _user_config_path()
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text("utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        _dbg("_load_user_config", exc, str(p))
        return {}


def _save_user_config(cfg: dict) -> None:
    """Atomic write to config.json with 0600 perms.

    Atomic via temp-file + rename so a crash mid-write can't leave a
    half-truncated config that ``_load_user_config`` then has to
    salvage.
    """
    p = _user_config_path()
    tmp = p.with_suffix(".tmp")
    try:
        tmp.write_text(json.dumps(cfg, ensure_ascii=False, indent=2),
                       encoding="utf-8")
        try:
            os.chmod(tmp, 0o600)
        except OSError:
            pass
        tmp.replace(p)
    except OSError as exc:
        _dbg("_save_user_config", exc, str(p))


# V17.12 — global error capture. Two entry points:
#
#   _capture_exception(label, exc, extra)
#       Wrap server-side handler's broad except blocks. Submits the
#       redacted traceback + label to the V14.7 reporter on a daemon
#       thread (must never block / re-raise — error path must stay
#       errorless).
#
#   _capture_client_event(payload)
#       Receives the browser-side window.onerror payload, fires
#       through the same submit pipeline.
#
# Both respect the V14.7 opt-in: if ``error_reports_enabled`` is
# False in config.json, both no-op silently. Even on opt-in, an
# empty / missing endpoint means dry-run (the report is built +
# redacted but not sent over the network) — useful for debugging.
def _capture_exception(label: str, exc: BaseException,
                         extra: dict | None = None) -> None:
    """Server-side hook for unexpected handler failures.

    Designed to be called from inside a broad ``except`` block:

        try:
            ...
        except Exception as exc:
            _capture_exception("verticals.tune", exc, {"key": key})
            traceback.print_exc(file=sys.stderr)
            self._reject_upload(500, ...)

    Never raises. Fire-and-forget on a daemon thread so the user's
    HTTP response isn't blocked by a slow reporter endpoint.
    """
    try:
        from pixcull import error_reporting as er
        cfg = _load_user_config()
        if not er.is_enabled(cfg):
            return
        import traceback as _tb
        full_extra = {
            "label":          label,
            "exception_type": type(exc).__name__,
            "exception_msg":  er.redact(str(exc)),
            "traceback":      er.redact(_tb.format_exc()),
        }
        if extra:
            # Redact every string value in caller-supplied extra fields
            # so a careless extra={"path": "/Users/alice/photos"} can't
            # leak.
            for k, v in extra.items():
                if isinstance(v, str):
                    full_extra[k] = er.redact(v)
                else:
                    full_extra[k] = v

        def _submit_worker():
            try:
                er.submit_report(
                    cfg, app_version=str(cfg.get("app_version", "dev")),
                    log_dir=_app_data_dir() / "logs",
                    reason="auto_exception",
                    extra=full_extra,
                )
            except Exception:
                pass   # reporter MUST be silent on its own failures

        threading.Thread(target=_submit_worker, daemon=True,
                          name="pixcull-error-reporter").start()
    except Exception:
        # Capture path itself must never raise.
        pass


def _capture_client_event(payload: dict) -> None:
    """Receive a window.onerror / unhandledrejection event from the
    browser, route through the V14.7 reporter.

    Caller-supplied fields are bounded + redacted (filenames in
    stack traces, /Users/<name> in source URLs, etc).
    """
    try:
        from pixcull import error_reporting as er
        cfg = _load_user_config()
        if not er.is_enabled(cfg):
            return
        # Bound payload sizes — a runaway page could spam giant stacks.
        def _clip(s, n=2000):
            s = str(s or "")
            return s[:n] if len(s) > n else s
        full_extra = {
            "kind":     _clip(payload.get("kind"), 64),
            "message":  er.redact(_clip(payload.get("message"))),
            "source":   er.redact(_clip(payload.get("source"), 200)),
            "lineno":   payload.get("lineno"),
            "colno":    payload.get("colno"),
            "stack":    er.redact(_clip(payload.get("stack"), 4000)),
            "url":      er.redact(_clip(payload.get("url"), 200)),
            "ua":       _clip(payload.get("ua"), 200),
        }

        def _submit_worker():
            try:
                er.submit_report(
                    cfg, app_version=str(cfg.get("app_version", "dev")),
                    log_dir=_app_data_dir() / "logs",
                    reason="client_event",
                    extra=full_extra,
                )
            except Exception:
                pass

        threading.Thread(target=_submit_worker, daemon=True,
                          name="pixcull-client-error-reporter").start()
    except Exception:
        pass


# V11.2 auto-retrain trigger:
# Increments on every human annotation save; once it crosses
# AUTO_RETRAIN_THRESHOLD, the next /annotation save will spawn a
# background retrain (debounced — won't fire while one is already
# running) then reset the counter. Small enough to feel
# 'continuously learning', large enough that we don't burn CPU
# on every single click.
_AUTO_RETRAIN_THRESHOLD = 10
_annotations_since_retrain = 0

# P-UX-4 — reject-reason taxonomy. When a photographer marks a photo
# ``cull``, they can optionally tag *why* via a small overlay. Tokens
# are snake_case ASCII for stability across versions + CSV/training
# tools; the UI translates them to localized labels at render time
# (same convention as the genre/scene taxonomy). Adding a new token
# here is enough to surface it in the picker — the server validates
# against this list to silently drop typos.
_CULL_REASONS: tuple[str, ...] = (
    "focus_miss",       # 焦点不准  — the AF locked on the wrong plane
    "eyes_closed",      # 闭眼/表情 — subject blinked / awkward expression
    "motion_blur",      # 模糊抖动 — handshake or subject motion blur
    "framing",          # 构图差   — bad composition / crop / framing
    "duplicate",        # 与更佳重复 — kept a better near-duplicate
    "exposure",         # 曝光问题 — under/overexposed beyond recovery
    "other",            # 其他    — catch-all for everything else
)

_DEFAULT_PORT = 8770
_FALLBACK_PORTS = (8770, 8771, 8772, 9322, 7799)
_DEMO_ROOT = Path(  # base dir for upload + output trees
    os.environ.get("PIXCULL_DEMO_ROOT", "/tmp/pixcull_demo")
)  # env override lets tests serve a hermetic fixture run (v2.5)
# v0.13.10 — server boot time, surfaced by /healthz uptime_s field.
_SERVER_BOOT_TIME = time.time()
_THUMB_SIZE = 420
_FULL_SIZE = 1600


# V19.4.1 — hot-reloadable results page template.
#
# Pre-V19.4.1 the entire 2600-line ``_RESULTS_HTML`` template was a
# module-level ``r"""..."""`` constant baked into memory at import. Any
# fix to its HTML/JS — like the V19.4 TDZ on shadowed ``const esc`` —
# required killing + restarting the long-running server. That made
# the bug feel worse than it was (fix in code, still broken in users'
# browsers because the running process was holding stale bytes).
#
# Moving the template to ``pixcull/report/templates/results.html`` and
# loading it per-request with an mtime cache means: edit the .html,
# next hit picks it up. The mtime check is a couple of microseconds
# vs. the ~10 ms cost of re-parsing 2.5 MB of template, so the cache
# pays for itself on the typical reload-debug loop.
_RESULTS_HTML_PATH = (
    _pkg_root() / "report" / "templates" / "results.html"
)


# v0.6 (3/5) — shared design tokens.
# Single source of truth for the v0.4 P0 + v0.5 LR-grade palette
# that previously lived only inside pixcull/report/templates/
# results.html.  Interpolated into the inline <style> blocks of
# the upload page, admin page, face-audit page, and delivery-
# audit page so /, /admin, /admin/face_audit/<id>, and
# /admin/delivery/<id> all share the same visual language.
_DESIGN_TOKENS_CSS = r"""
  @font-face{font-family:"Geist Variable";font-style:normal;font-weight:100 900;font-display:swap;src:url("/docs/brand/geist-variable.woff2") format("woff2");unicode-range:U+0000-2E7F;}
  :root {
    /* surfaces — v2.21 Studio Neutral: achromatic ramp, aligned
       with results.css (the photo surround carries no hue) */
    --bg:           #161616;
    --bg-card:      #1d1d1d;
    --bg-card-hi:   #242424;
    --surface-2:    #242424;
    --surface-3:    #2e2e2e;
    --chrome:       #0f0f0f;
    /* text — neutral ramp (was a stray cool blue-gray set that never
       matched the main workspace) */
    --fg:           #e6e6e6;
    --fg-2:         #c6c6c6;
    --muted:        #9b9b9b;
    --muted-soft:   #707070;
    /* borders */
    --border:       #262626;
    --border-hi:    #363636;
    /* accent — v2.21 champagne gold */
    --accent:       #d5b584;
    --accent-hi:    #eaca98;
    --accent-soft:  rgba(213,181,132,0.15);
    --accent-glow:  rgba(213,181,132,0.42);
    --focus-ring:   rgba(234,202,152,0.55);
    /* semantic palette */
    --c-success:        #63bd7f;
    --c-success-tint:   rgba(99,189,127,0.14);
    --c-success-border: rgba(99,189,127,0.40);
    --c-warn:           #d6a443;
    --c-warn-tint:      rgba(214,164,67,0.14);
    --c-warn-border:    rgba(214,164,67,0.40);
    --c-danger:         #e0604e;
    --c-danger-tint:    rgba(224,96,78,0.14);
    --c-danger-border:  rgba(224,96,78,0.40);
    --c-info:           #6fa7bd;
    --c-info-tint:      rgba(111,167,189,0.14);
    --c-info-border:    rgba(111,167,189,0.40);
    --c-neutral:        #9b9b9b;
    --c-neutral-tint:   rgba(155,155,155,0.10);
    --c-neutral-border: rgba(155,155,155,0.30);
    /* legacy alias for V14 callers */
    --keep:  var(--c-success);
    --maybe: var(--c-warn);
    --cull:  var(--c-danger);
    --error: var(--c-danger);
    /* typography */
    --font-display: "Geist Variable", -apple-system,
                    BlinkMacSystemFont, "Segoe UI Variable", "Segoe UI",
                    "PingFang SC", "Microsoft Yahei UI", "Noto Sans SC", sans-serif;
    --font-body:    "Geist Variable", -apple-system, BlinkMacSystemFont,
                    "Segoe UI Variable", "Segoe UI", "PingFang SC",
                    "Microsoft Yahei UI", "Noto Sans SC", sans-serif;
    --font-mono:    ui-monospace, "SF Mono", "JetBrains Mono", Menlo,
                    monospace;
    /* v2.2 — editorial serif for hero numbers / titles (offline-first) */
    --font-serif:   "Charter", "Iowan Old Style", "PT Serif",
                    "Source Serif Pro", Georgia, "Songti SC", serif;
    /* v2.37 — the sans counterpart. The shared set defined --font-serif
       but not this, so every page hand-rolled the same stack; the share
       page's copy was the last one left. */
    --font-sans:    -apple-system, BlinkMacSystemFont, "Segoe UI",
                    "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei",
                    system-ui, sans-serif;
    --t-hero:    28px;  --t-h2:    18px;  --t-h3:    14px;
    --t-body:    13px;  --t-small: 11.5px; --t-tiny:  10.5px;
    --lh-tight:  1.25;  --lh-normal: 1.55; --lh-loose: 1.7;
    /* spacing */
    --space-1: 4px;  --space-2: 8px;  --space-3: 12px;
    --space-4: 16px; --space-5: 20px; --space-6: 24px;
    --space-7: 32px; --space-8: 48px;
    /* radius — v2.21 tightened pro register */
    --radius-sm: 5px;  --radius-md: 8px;  --radius-lg: 11px;
    --radius-xl: 14px; --radius-pill: 999px;
    /* glass — v2.29 shipped these into results.css's token module but not
       into THIS shared blob, so standalone pages (/library, /tether,
       /history, upload, admin) silently rendered chrome with no frost.
       Same values; one material across every surface. */
    --glass-blur:          16px;
    --glass-sat:           130%;
    --glass-filter:        blur(var(--glass-blur)) saturate(var(--glass-sat));
    --glass-scrim-filter:  blur(4px);
    --glass-edge:          inset 0 1px 0 rgba(255,255,255,0.08);
    /* shadows — v2.2 softer + wider "expensive" elevation */
    --shadow-sm: 0 1px 3px rgba(0,0,0,0.34);
    --shadow-md: 0 6px 22px rgba(0,0,0,0.36);
    --shadow-lg: 0 16px 40px rgba(0,0,0,0.46);
    --shadow-xl: 0 30px 64px rgba(0,0,0,0.52);
    /* motion */
    --duration-fast: 120ms; --duration-normal: 220ms; --duration-slow: 320ms;
    /* v0.9-P0-1 — signature soft-bounce: every transition gains
       ~6% overshoot at the destination, mirroring Linear / Stripe /
       Apple Photos.  Original flat curve preserved as --ease-out-flat
       for the rare case overshoot would mislead (data bar widths). */
    --ease-out:      cubic-bezier(0.34, 1.56, 0.64, 1);
    --ease-out-flat: cubic-bezier(0.16, 1, 0.3, 1);
    --ease-in-out:   cubic-bezier(0.4, 0, 0.2, 1);
    --ease-spring:   cubic-bezier(0.34, 1.56, 0.64, 1);
  }
  /* Light theme override — same shape as results.html */
  html[data-theme="light"] {
    /* v2.2 — warm paper-and-ink editorial, mirrors results.html light */
    --bg:           #f7f7f7;
    --bg-card:      #ffffff;
    --bg-card-hi:   #eeeeee;
    --surface-2:    #e9e9e9;
    --surface-3:    #dddddd;
    --chrome:       #ffffff;
    --fg:           #171717;
    --fg-2:         #3a3a3c;
    --muted:        #616165;
    --muted-soft:   #858589;
    --border:       #e2e2e2;
    --border-hi:    #c9c9c9;
    /* light glass: an 8% white highlight is invisible on a near-white
       film — light materials read via a stronger edge (as tokens.css). */
    --glass-edge:   inset 0 1px 0 rgba(255,255,255,0.65);
    --accent:       #6c501f;
    --accent-hi:    #866939;
    --accent-soft:  rgba(71,58,41,0.10);
    --accent-glow:  rgba(71,58,41,0.30);
    --focus-ring:   rgba(71,58,41,0.45);
    --shadow-sm: 0 1px 2px  rgba(0,0,0,0.07);
    --shadow-md: 0 4px 14px rgba(0,0,0,0.09);
    --shadow-lg: 0 14px 34px rgba(0,0,0,0.10);
    --shadow-xl: 0 28px 60px rgba(0,0,0,0.12);
  }
  @media (prefers-reduced-motion: reduce) {
    :root {
      --duration-fast: 1ms; --duration-normal: 1ms; --duration-slow: 1ms;
    }
  }
  /* v2.32 — same a11y contract as results.css: a user who asks for less
     transparency gets solid chrome, not frosted glass. */
  @media (prefers-reduced-transparency: reduce) {
    :root, [data-theme="light"] {
      --glass-filter: none; --glass-scrim-filter: none; --glass-edge: none;
    }
    header { background: var(--chrome) !important; }
  }
  /* v0.9-P0-3 — signature brand-wide gradient + CTA helper, available
     on every page that uses _DESIGN_TOKENS_CSS (upload / admin / share).
     Defined here so the token name + curve are project-wide single source. */
  :root {
    --brand-gradient:       linear-gradient(135deg, #d5b584 0%, #93743f 100%);
    --brand-gradient-soft:  linear-gradient(135deg,
                              rgba(213,181,132,0.18) 0%,
                              rgba(106,96,82,0.18) 100%);
  }
  /* Primary CTA: signature gradient backdrop, white text, soft glow.
     Hover lifts 1px + brightens; active settles. */
  button.btn-primary,
  .btn-brand-gradient {
    background: var(--brand-gradient) !important;
    color: #ffffff !important;
    border: 0 !important;
    box-shadow: 0 4px 14px rgba(213,181,132, 0.35);
    transition: filter 120ms var(--ease-out, ease-out),
                transform 120ms var(--ease-out, ease-out),
                box-shadow 220ms var(--ease-out, ease-out);
  }
  button.btn-primary:hover,
  .btn-brand-gradient:hover {
    filter: brightness(1.08);
    transform: translateY(-1px);
    box-shadow: 0 6px 20px rgba(213,181,132, 0.45);
  }
  button.btn-primary:active,
  .btn-brand-gradient:active {
    transform: translateY(0);
    filter: brightness(0.95);
  }
  button.btn-primary:disabled {
    filter: grayscale(0.4) brightness(0.6);
    cursor: not-allowed;
    transform: none;
    box-shadow: none;
  }
"""


# v2.35 — theme boot for the standalone pages.
#
# The bug this fixes: _DESIGN_TOKENS_CSS has carried a complete
# `html[data-theme="light"]` block since v2.2, but of the eleven pages
# that inject those tokens, ten never set `data-theme` at all — so light
# theme has NEVER applied on /library, /history, /tether, /upload,
# /admin, /verticals, /privacy, /disagreement, first-run or vertical-bulk.
# A user who picked 浅色 in the review workspace still got a dark
# /library.  The toggle lives in results.js module 29; these pages only
# need to *honour* the choice, so this mirrors its exact contract:
# localStorage["pixcull_theme"] of "dark" | "light" | "system" (anything
# else, or unreadable storage, means system), and system resolves via
# prefers-color-scheme.
#
# Runs inline in <head> so the attribute is set before first paint —
# injected as a script element rather than a page edit so a page added
# later cannot forget it.
_THEME_BOOT_HTML = """<script>
/* v2.35 — honour the theme the user picked in the review workspace.
   Same key + resolution order as results.js setupThemeToggle(). */
(function () {
  try {
    var p = null;
    try { p = localStorage.getItem("pixcull_theme"); } catch (e) {}
    if (p !== "dark" && p !== "light") {
      p = (window.matchMedia &&
           window.matchMedia("(prefers-color-scheme: light)").matches)
          ? "light" : "dark";
    }
    document.documentElement.setAttribute("data-theme", p);
  } catch (e) { /* never let theming break the page */ }
})();
</script>
"""


# v2.39 — the theme *control*, not just the theme.
#
# v2.35 made the standalone pages OBEY the preference; they still had no
# way to change it.  A photographer who opened /library directly (or
# followed a link into /history) had to go back to the review workspace
# to switch, which is where module 29's toolbar toggle lives.
#
# Injected as a fixed-position control rather than added to each page's
# header: the pages have wildly different layouts and three of them have
# no header at all, and per-page wiring is precisely how ten of eleven
# pages ended up without the boot script in the first place.
#
# The cycle and the storage contract are module 29's, exactly:
# dark → light → system → dark, persisted under localStorage
# "pixcull_theme"; "system" re-reads prefers-color-scheme and keeps
# following it live via a matchMedia listener.
_THEME_TOGGLE_HTML = """<style>
  .pc-theme-fab {
    position: fixed; right: 16px; bottom: 16px; z-index: 90;
    display: inline-flex; align-items: center; gap: 7px;
    padding: 7px 12px 7px 10px;
    font: 500 12px/1 -apple-system, BlinkMacSystemFont, "Segoe UI",
          "PingFang SC", system-ui, sans-serif;
    color: var(--fg-2, #c6c6c6);
    background: color-mix(in srgb, var(--chrome, #1d1d1d) 82%, transparent);
    backdrop-filter: var(--glass-filter, blur(16px) saturate(130%));
    -webkit-backdrop-filter: var(--glass-filter, blur(16px) saturate(130%));
    box-shadow: var(--glass-edge, none), var(--shadow-md, 0 4px 14px rgba(0,0,0,.2));
    border: 1px solid var(--border, #2a2a2a);
    border-radius: 999px; cursor: pointer;
    transition: color 140ms, border-color 140ms, transform 140ms;
  }
  .pc-theme-fab:hover { color: var(--fg, #e6e6e6);
                        border-color: var(--border-hi, #3a3a3a); }
  .pc-theme-fab:focus-visible { outline: 2px solid var(--focus-ring, #888);
                                outline-offset: 2px; }
  .pc-theme-fab svg { width: 14px; height: 14px; flex: none; }
  /* Printing a delivery page shouldn't print app chrome. */
  @media print { .pc-theme-fab { display: none; } }
  @media (prefers-reduced-motion: reduce) {
    .pc-theme-fab { transition: none; }
  }
</style>
<button class="pc-theme-fab" id="pcThemeFab" type="button"
        aria-live="polite" title="切换主题 / Switch theme">
  <svg id="pcThemeIcon" viewBox="0 0 24 24" fill="none" stroke="currentColor"
       stroke-width="1.8" stroke-linecap="round" aria-hidden="true"></svg>
  <span id="pcThemeLabel">主题</span>
</button>
<script>
(function () {
  var KEY = "pixcull_theme";
  var MOON = '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>';
  var SUN  = '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2' +
             'M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2' +
             'M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>';
  var AUTO = '<circle cx="12" cy="12" r="9"/><path d="M12 3v18" />' +
             '<path d="M12 3a9 9 0 0 1 0 18z" fill="currentColor" ' +
             'stroke="none"/>';
  var btn = document.getElementById("pcThemeFab");
  var icon = document.getElementById("pcThemeIcon");
  var label = document.getElementById("pcThemeLabel");
  if (!btn) return;
  var mq = window.matchMedia && window.matchMedia("(prefers-color-scheme: light)");
  function pref() {
    var p = null;
    try { p = localStorage.getItem(KEY); } catch (e) {}
    return (p === "dark" || p === "light" || p === "system") ? p : "system";
  }
  function effective(p) {
    if (p === "light" || p === "dark") return p;
    return (mq && mq.matches) ? "light" : "dark";
  }
  function render(p) {
    var eff = effective(p);
    document.documentElement.setAttribute("data-theme", eff);
    icon.innerHTML = p === "system" ? AUTO : (eff === "light" ? SUN : MOON);
    label.textContent = p === "system" ? "跟随系统"
                      : p === "light" ? "浅色" : "深色";
    btn.setAttribute("aria-label", "当前主题:" + label.textContent +
                                   ",点击切换");
  }
  btn.addEventListener("click", function () {
    var p = pref();
    p = p === "dark" ? "light" : p === "light" ? "system" : "dark";
    try { localStorage.setItem(KEY, p); } catch (e) {}
    render(p);
  });
  if (mq && mq.addEventListener) {
    mq.addEventListener("change", function () {
      if (pref() === "system") render("system");
    });
  }
  render(pref());
})();
</script>
"""


def _read_template(name: str) -> str:
    """v2.5-P0-1 — load a sibling HTML page template (video_review /
    timeline) from the same dir as results.html, so large embedded page
    blobs live as files instead of bloating this module.

    v2.35 — also splices in the shared design tokens and the theme-boot
    script.  Both were previously done per call site, and both got
    forgotten: /first_run, /privacy, /verticals and /vertical_bulk build
    their constants ABOVE where _DESIGN_TOKENS_CSS used to be defined, so
    their ``.replace`` would have raised NameError and simply wasn't
    written — leaving four pages on a hand-rolled pre-v2.21 palette with
    no light theme at all.  Injecting here, once, removes the whole class
    of bug; the constant now lives above this function so import-time
    callers can see it.  Call sites that still do their own ``.replace``
    are harmless no-ops (the marker is already consumed).
    """
    html = (_RESULTS_HTML_PATH.parent / name).read_text(encoding="utf-8")
    if "/*__DESIGN_TOKENS_CSS__*/" in html:
        html = html.replace("/*__DESIGN_TOKENS_CSS__*/", _DESIGN_TOKENS_CSS)
    if "</head>" in html and "pixcull_theme" not in html:
        html = html.replace("</head>", _THEME_BOOT_HTML + "</head>", 1)
        # v2.39 — and the control to change it.  Guarded by the same
        # "did we already inject" check, and placed at end-of-body so it
        # can't shift a page's layout.
        if "</body>" in html:
            html = html.replace("</body>", _THEME_TOGGLE_HTML + "</body>", 1)
    return html
_RESULTS_HTML_CACHE: tuple[int, str] | None = None


def _results_html_template() -> str:
    """Return the current ``results.html`` template body.

    Cached by mtime — repeat hits at the same revision skip the
    file read. On first request after a template edit the mtime
    differs and we re-load.

    Raises FileNotFoundError if the template is missing — that's a
    deployment bug (template not bundled), surface loudly.
    """
    global _RESULTS_HTML_CACHE
    p = _RESULTS_HTML_PATH
    mt = p.stat().st_mtime_ns  # FileNotFoundError propagates
    if _RESULTS_HTML_CACHE and _RESULTS_HTML_CACHE[0] == mt:
        return _RESULTS_HTML_CACHE[1]
    content = p.read_text(encoding="utf-8")
    _RESULTS_HTML_CACHE = (mt, content)
    return content

# Upload limits. The byte cap is a real safety boundary (multipart parsing
# spools to disk above ~1 KB per field anyway, but unbounded uploads still
# let an attacker fill /tmp). The file-count cap mostly protects the
# multipart parser from pathological tiny-file storms. Both can be
# overridden at startup via --max-upload-mb / --max-upload-files.
#
# 8 GB default is sized for typical pro photo workflows: a Canon R5 / R6
# burst is ~30-60 MB per CR3, so 8 GB ≈ 130-260 RAW shots in one upload.
# If you need bigger, raise --max-upload-mb. Pipeline throughput then
# becomes the user-visible bottleneck (1-10 s per image) — not this cap.
_MAX_UPLOAD_BYTES_DEFAULT = 8 * 1024 * 1024 * 1024  # 8 GB
_MAX_UPLOAD_FILES_DEFAULT = 500
# Refuse the upload if it would push /tmp below this much free space after
# landing on disk. Keeps the system usable even if the user hands us a
# batch that exactly fills the disk.
_MIN_FREE_SPACE_AFTER_BYTES = 1 * 1024 * 1024 * 1024  # 1 GB


# V14.0 — replace silent ``except: pass`` with traceable debug logs.
# We don't want noisy stderr in normal operation, but every "we tried, it
# failed, we kept going" path should leave a fingerprint for the rare bug
# report ("my run shows 0 images though there's a manifest"). One-line
# DEBUG-level breadcrumbs make those reproducible.
_DEBUG_LOG = "PIXCULL_DEBUG" in __import__("os").environ


def _dbg(where: str, exc: BaseException | None = None, extra: str = "") -> None:
    """One-line breadcrumb to stderr for a non-fatal failure path.

    Always writes when PIXCULL_DEBUG is set; otherwise stays quiet to keep
    happy-path output clean. The point isn't user-facing logs — it's that
    when a bug report comes in we can ask the user to re-run with
    PIXCULL_DEBUG=1 and immediately see *which* fallback fired.
    """
    if not _DEBUG_LOG:
        return
    msg = f"[pixcull.dbg] {where}"
    if exc is not None:
        msg += f" :: {type(exc).__name__}: {exc}"
    if extra:
        msg += f" :: {extra}"
    sys.stderr.write(msg + "\n")


# V14.0 — JSON encoder that turns NaN/Infinity into null instead of writing
# literal "NaN" / "Infinity" tokens (which are not valid JSON and crash
# strict parsers like the JS frontend's JSON.parse). Use anywhere a
# pandas-derived value might be NaN.
class _SafeJSONEncoder(json.JSONEncoder):
    def __init__(self, *a, **kw):
        # allow_nan=False would raise — we want a quiet substitution instead
        kw.setdefault("ensure_ascii", False)
        super().__init__(*a, **kw)

    def iterencode(self, o, _one_shot=False):
        # JSONEncoder.iterencode emits "NaN"/"Infinity" by default. We
        # walk the object first and substitute, which is cheap relative
        # to the network cost of sending the response.
        return super().iterencode(_scrub_nan(o), _one_shot=_one_shot)


# _scrub_nan / _safe_dumps → pixcull.report.serve_util (v2.5-P0-1),
# imported at the top of this file.


# V14.1 — JSONL cache. rubric.jsonl + annotations.jsonl get re-parsed
# from disk on every result render, every annotation modal open, every
# rubric API hit. For a 1000-image batch where the user clicks through
# 200 thumbnails this is 200 full re-parses of a multi-MB file.
#
# This is a tiny mtime-keyed LRU. Files are invalidated whenever their
# mtime moves forward (annotation save bumps mtime, so the cache stays
# fresh without explicit invalidation calls). Bounded to 16 entries to
# survive aggressive admin tools without memory growth.
class _MtimeLRUCache:
    """Tiny thread-safe LRU keyed by (path, mtime).

    Why not functools.lru_cache: we need to invalidate when the file
    changes on disk, and lru_cache has no eviction by anything other
    than its arg tuple. Keying on mtime makes a write naturally bust
    the entry without needing to touch the cache from the writer.
    """

    def __init__(self, maxsize: int = 16):
        self._max = maxsize
        self._d: "dict[tuple, object]" = {}
        self._lock = threading.Lock()

    def get_or_load(self, path: Path, loader):
        try:
            mtime = path.stat().st_mtime_ns
        except OSError:
            return loader()  # path gone; let loader handle
        key = (str(path), mtime)
        with self._lock:
            if key in self._d:
                # Touch by re-inserting to keep MRU at the end (Py 3.7+
                # dicts preserve insertion order)
                v = self._d.pop(key)
                self._d[key] = v
                return v
        v = loader()
        with self._lock:
            self._d[key] = v
            # Evict any older entries for this same path AND drop oldest
            # entries past the bound.
            for k in list(self._d.keys()):
                if k[0] == str(path) and k != key:
                    self._d.pop(k, None)
            while len(self._d) > self._max:
                self._d.pop(next(iter(self._d)))
        return v


_JSONL_CACHE = _MtimeLRUCache(maxsize=16)


def _read_jsonl_cached(path: Path) -> list[dict]:
    """Return a parsed list of records from a JSONL file, cached by
    (path, mtime). Lines that fail to parse are skipped (matches the
    historic behavior — bad lines never aborted the read)."""
    def _load() -> list[dict]:
        out: list[dict] = []
        try:
            with open(path, encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        out.append(json.loads(line))
                    except json.JSONDecodeError as exc:
                        _dbg("_read_jsonl_cached/parse", exc, str(path))
        except OSError as exc:
            _dbg("_read_jsonl_cached/open", exc, str(path))
        return out
    return _JSONL_CACHE.get_or_load(path, _load)


def _read_human_by_fn_cached(ann_path: Path) -> dict[str, dict]:
    """Latest-wins index of human annotations keyed by filename. Built
    on top of ``_read_jsonl_cached`` so it benefits from the same mtime
    cache (with negligible extra memory — same dicts, different shape).
    """
    if not ann_path.exists():
        return {}
    out: dict[str, dict] = {}
    for rec in _read_jsonl_cached(ann_path):
        fn = rec.get("filename")
        if fn:
            out[fn] = rec  # later wins
    return out


# _html_escape → pixcull.report.serve_util (v2.5-P0-1).


def _pick_port(preferred: int, host: str) -> int:
    """Return the preferred port if free on ``host``, else first free fallback."""
    candidates = (preferred, *_FALLBACK_PORTS)
    for p in candidates:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind((host, p))
                return p
            except OSError:
                continue
    raise RuntimeError(
        f"All preferred ports busy: {candidates}. Pass --port to choose."
    )


def _local_ipv4() -> str | None:
    """Best-effort guess at the LAN-visible IPv4. Returns None if offline.

    Tries the "connect-to-public-IP-then-read-our-source-IP" trick that
    works on every macOS/Linux without parsing ifconfig output. We never
    actually send any packets — UDP socket connect just sets the kernel's
    routing table, no traffic leaves the machine.
    """
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.settimeout(0.2)
            # Cloudflare 1.1.1.1 — any reachable v4 address works
            s.connect(("1.1.1.1", 80))
            return s.getsockname()[0]
    except OSError:
        return None


def _new_run_id() -> str:
    return uuid.uuid4().hex[:10]


def _run_dir(run_id: str) -> Path:
    return _DEMO_ROOT / run_id


# v2.0-P0-4 — video-run helpers.
import re as _re_video  # noqa: E402


def _safe_run_id(run_id: str) -> str | None:
    """Validate a run_id used in a filesystem path.  Returns the id or
    None if it contains path-traversal / separator characters."""
    run_id = (run_id or "").strip().strip("/")
    if not run_id or not _re_video.fullmatch(r"[A-Za-z0-9_.\-]+", run_id):
        return None
    if run_id in (".", ".."):
        return None
    return run_id


def _video_frames_dir(run_dir: Path) -> Path | None:
    """Return the single ``video_frames/<video_id>/`` subdir of a run,
    or None when the run isn't a video run (or is ambiguous)."""
    root = run_dir / "video_frames"
    if not root.is_dir():
        return None
    subs = [p for p in root.iterdir()
            if p.is_dir() and (p / "manifest.json").exists()]
    return subs[0] if len(subs) == 1 else None


def is_video_run(run_id: str) -> bool:
    """True when the run has the v2.0 video artifacts on disk."""
    rid = _safe_run_id(run_id)
    if rid is None:
        return False
    run_dir = _run_dir(rid)
    return (run_dir / "temporal.json").exists() \
        and _video_frames_dir(run_dir) is not None


def _rebuild_reel_profile() -> int:
    """v2.20-P3 — walk every run's reel_decisions.jsonl (last line wins per
    rank), join each decided rank to its candidate's v2.17 sub-signals, and
    relearn the shooter's reel taste profile (written to
    ``~/.pixcull/reel_profile.json``; the ranking gate needs ≥20 decisions).
    Returns the record count that fed the profile (0 = nothing learnable)."""
    from pixcull.scoring.reel import REEL_PROFILE_PATH, learn_reel_profile
    records: list[dict] = []
    try:
        run_dirs = [d for d in _DEMO_ROOT.iterdir() if d.is_dir()]
    except OSError:
        return 0
    for rd in run_dirs:
        dec_path = rd / "reel_decisions.jsonl"
        cand_path = rd / "reel_candidates.json"
        if not (dec_path.exists() and cand_path.exists()):
            continue
        try:
            cands = {int(c.get("rank")): c
                     for c in json.loads(cand_path.read_text("utf-8"))
                     if c.get("rank") is not None}
            latest: dict[int, str] = {}
            for line in dec_path.read_text("utf-8").splitlines():
                try:
                    r = json.loads(line)
                    latest[int(r["rank"])] = str(r.get("decision") or "")
                except (ValueError, KeyError, TypeError):
                    continue
        except (OSError, ValueError):
            continue
        for rank, dec in latest.items():
            if dec not in ("keep", "cull"):
                continue                      # cleared decision — skip
            sig = (cands.get(rank) or {}).get("signals")
            if sig:
                records.append({"decision": dec, "signals": sig})
    prof = learn_reel_profile(records)
    if prof is None:
        return 0
    try:
        REEL_PROFILE_PATH.parent.mkdir(parents=True, exist_ok=True)
        REEL_PROFILE_PATH.write_text(
            json.dumps(prof, ensure_ascii=False, indent=2), encoding="utf-8")
    except OSError:
        return 0
    return int(prof.get("n") or 0)


def _build_video_payload(run_id: str) -> dict | None:
    """v2.2-P0-2 — per-frame temporal scores + reel candidates keyed by
    *filename*, so the results.html lightbox can render a video-mode
    scrubber (frames serve via the same /full/ path as the grid).
    Returns None for photo runs."""
    rid = _safe_run_id(run_id)
    if rid is None or not is_video_run(rid):
        return None
    run_dir = _run_dir(rid)
    frames_dir = _video_frames_dir(run_dir)
    try:
        manifest = json.loads((frames_dir / "manifest.json").read_text("utf-8"))
        temporal = json.loads((run_dir / "temporal.json").read_text("utf-8"))
    except (OSError, ValueError):
        return None
    id2fn = {f.get("frame_id"): f.get("filename")
             for f in manifest.get("frames", [])}
    frames = []
    for f in temporal.get("frames", []):
        fn = id2fn.get(f.get("frame_id"))
        if fn:
            frames.append({
                "filename": fn,
                "t": f.get("timestamp_s", 0.0),
                "score_temporal": f.get("score_temporal", 0.0),
                "burst_event": f.get("burst_event", 0.0),
                "score_final": f.get("score_final"),
            })
    if not frames:
        return None
    # v2.19-P2 — audio events for the lightbox scrubber's bottom lane.
    audio_events = []
    try:
        ap = run_dir / "audio_events.json"
        if ap.exists():
            _aud = json.loads(ap.read_text("utf-8"))
            audio_events = [
                {"kind": e.get("kind"), "start_s": e.get("start_s"),
                 "end_s": e.get("end_s"), "confidence": e.get("confidence")}
                for e in (_aud.get("events") or [])
            ]
    except (OSError, ValueError):
        audio_events = []
    reel = []
    reel_path = run_dir / "reel_candidates.json"
    if reel_path.exists():
        try:
            for c in json.loads(reel_path.read_text("utf-8")):
                reel.append({
                    "rank": c.get("rank"), "start_s": c.get("start_s"),
                    "end_s": c.get("end_s"), "score": c.get("score"),
                    "why": c.get("why_semantic") or c.get("why"),
                    # v2.7 — bilingual caption; the frontend picks zh/en by
                    # the active locale. en falls back to zh→why so the field
                    # is always present for older runs without why_semantic_en.
                    "why_en": (c.get("why_semantic_en")
                               or c.get("why_semantic") or c.get("why")),
                    "best_filename": id2fn.get(c.get("best_frame_id")),
                })
        except (OSError, ValueError):
            pass
    return {"frames": frames, "reel": reel, "audio": audio_events}


def _render_video_review_html(rid: str) -> str:
    """v2.0-P0-4 — self-contained video-native lightbox + timeline scrubber.

    Reads its data from ``/video/data/<rid>`` and frames from
    ``/video/frame/<rid>/<frame_id>``.  Timeline shows the per-frame
    ``score_temporal`` peaks + reel-candidate bands; dragging the
    playhead switches frames in real time; J/K/L shuttle like DaVinci.
    ``rid`` is pre-validated to ``[A-Za-z0-9_.-]+`` so it is safe to
    embed in a JS string literal.
    """
    return _read_template("video_review.html").replace("__RUN_ID__", rid)


# _VIDEO_REVIEW_HTML extracted to templates/video_review.html (v2.5-P0-1 slice 2);
# loaded lazily via _read_template() in its render function.



# ==========================================================================
# v2.0-P1-2 — photo + video joint timeline.
# ==========================================================================

def _parse_capture_dt(s: str) -> float | None:
    """Parse an EXIF / ISO datetime string to an epoch float, or None."""
    if not s:
        return None
    s = str(s).strip()
    if not s or s.lower() == "nan":
        return None
    from datetime import datetime as _dt
    for fmt in ("%Y:%m:%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S",
                "%Y:%m:%d %H:%M:%S.%f", "%Y-%m-%dT%H:%M:%S.%f"):
        try:
            return _dt.strptime(s[:len(fmt) + 6], fmt).timestamp()
        except (ValueError, TypeError):
            continue
    try:
        return _dt.fromisoformat(s).timestamp()
    except (ValueError, TypeError):
        return None


def build_joint_timeline(photos: list[dict], videos: list[dict]) -> list[dict]:
    """Merge photo + video items onto one capture-time-sorted timeline.

    Items without a parseable time sort to the end (stable).  Pure —
    unit-tested without IO.
    """
    items = list(photos) + list(videos)
    with_t = [it for it in items if it.get("t") is not None]
    without_t = [it for it in items if it.get("t") is None]
    with_t.sort(key=lambda it: it["t"])
    return with_t + without_t


def _photo_timeline_items(run_id: str, *, limit: int = 800) -> list[dict]:
    """Photo rows for a run from scores.csv → timeline items."""
    import csv as _csv
    run_dir = _run_dir(run_id)
    scores = run_dir / "scores.csv"
    if not scores.exists():
        return []
    out: list[dict] = []
    try:
        with open(scores, newline="") as fh:
            for row in _csv.DictReader(fh):
                fn = row.get("filename", "")
                # Skip the synthetic video frames of a video run.
                t = _parse_capture_dt(row.get("datetime", ""))
                sf = row.get("score_final")
                try:
                    score = float(sf) if sf not in (None, "", "nan") else None
                except ValueError:
                    score = None
                out.append({
                    "kind": "photo", "run_id": run_id, "filename": fn,
                    "t": t, "iso": (row.get("datetime") or "").strip(),
                    "decision": row.get("decision", ""), "score": score,
                    "thumb": f"/thumb/{quote(run_id)}/{quote(fn)}?w=200",
                })
                if len(out) >= limit:
                    break
    except OSError:
        return []
    return out


def _video_timeline_items() -> list[dict]:
    """All video runs under _DEMO_ROOT → timeline items (by source mtime)."""
    out: list[dict] = []
    if not _DEMO_ROOT.exists():
        return out
    for child in sorted(_DEMO_ROOT.iterdir()):
        if not child.is_dir():
            continue
        rid = child.name
        if not is_video_run(rid):
            continue
        frames_dir = _video_frames_dir(child)
        manifest = {}
        if frames_dir is not None:
            try:
                manifest = json.loads(
                    (frames_dir / "manifest.json").read_text("utf-8"))
            except (OSError, ValueError):
                manifest = {}
        # Capture time: source mtime, else run-dir mtime.
        t = None
        src = manifest.get("source_path")
        try:
            if src and Path(src).exists():
                t = Path(src).stat().st_mtime
            else:
                t = child.stat().st_mtime
        except OSError:
            t = None
        cand_count = 0
        best_why = ""
        reel_path = child / "reel_candidates.json"
        if reel_path.exists():
            try:
                cands = json.loads(reel_path.read_text("utf-8"))
                cand_count = len(cands)
                if cands:
                    best_why = cands[0].get("why", "")
            except (OSError, ValueError):
                pass
        from datetime import datetime as _dt
        out.append({
            "kind": "video", "run_id": rid,
            "source_name": manifest.get("source_name", rid),
            "t": t,
            "iso": (_dt.fromtimestamp(t).isoformat(timespec="seconds")
                    if t else ""),
            "duration_s": manifest.get("duration_s"),
            "frame_count": manifest.get("frame_count"),
            "candidate_count": cand_count, "best_why": best_why,
        })
    return out


def _render_timeline_html(rid: str) -> str:
    """v2.0-P1-2 — joint photo+video timeline page (data via fetch)."""
    return _read_template("timeline.html").replace("__RUN_ID__", rid)


# _TIMELINE_HTML extracted to templates/timeline.html (v2.5-P0-1 slice 2);
# loaded lazily via _read_template() in its render function.



def _set_run(run_id: str, **fields: object) -> None:
    """Thread-safe partial update of a run's state dict."""
    with _RUNS_LOCK:
        run = _RUNS.setdefault(run_id, {})
        run.update(fields)


def _get_run(run_id: str) -> dict | None:
    with _RUNS_LOCK:
        run = _RUNS.get(run_id)
        return dict(run) if run is not None else None


def _analyze_in_background(
    run_id: str,
    rescorer_mode: str,
    rescorer_path: str | None,
    vlm_mode: str = "off",
    meta_mode: str = "off",
) -> None:
    """Worker thread: run the pipeline on the run's source dir.

    Two modes, both go through the same ``run_pipeline()``:
      * mode="upload"  source = run_dir/input/    (we copied bytes in)
      * mode="scan"    source = an arbitrary local path (originals untouched)

    The orchestrator doesn't care which — it just walks the path. The
    difference shows up later in thumbnail serving (manifest lookup) and
    cleanup (scan mode never deletes originals).

    Never raises out of the thread — fills run["state"]="error" and
    run["message"] with the exception summary instead.
    """
    # Imported here, not at module scope, so a missing-deps environment can
    # still serve the upload page and return a friendly error rather than
    # crashing on startup.
    from pixcull.pipeline.orchestrator import run_pipeline

    run = _get_run(run_id)
    if run is None:
        return
    source_dir = Path(run.get("source_dir") or run["input_dir"])
    output_dir = Path(run["output_dir"])

    def progress_cb(done: int, total: int, message: str) -> None:
        _set_run(run_id, done=done, total=total, message=message)

    _set_run(run_id, state="running", started_at=time.time(),
             vlm_mode=vlm_mode, meta_mode=meta_mode)
    try:
        # V17.2 — pass the run's vertical (set by /scan_local) into
        # the pipeline so decide() can apply per-vertical thresholds
        # + tolerated flags. None / unknown vertical = unchanged behavior.
        run_pipeline(
            source_dir,
            output_dir,
            rescorer_mode=rescorer_mode,
            rescorer_path=rescorer_path,
            progress_cb=progress_cb,
            vlm_mode=vlm_mode,
            meta_mode=meta_mode,
            vertical=run.get("vertical"),
        )
        _set_run(
            run_id,
            state="done",
            finished_at=time.time(),
            message="完成",
        )
    except Exception as exc:  # noqa: BLE001
        # Surface any pipeline failure to the browser instead of a silent
        # spinner. Full traceback goes to the server stderr for debugging.
        traceback.print_exc(file=sys.stderr)
        _set_run(
            run_id,
            state="error",
            finished_at=time.time(),
            message=f"分析失败: {type(exc).__name__}: {exc}",
        )


# ---------------------------------------------------------------------------
# Result rendering: read scores.csv off disk, build the rows the HTML grid
# expects. Mirrors serve_review's row schema (subset) so the same CSS works.
# ---------------------------------------------------------------------------

# P-UX-10 — inconsistency thresholds. The 4 scoring sources
# (auto / model / vlm / meta) ought to broadly agree on a frame's
# rubric stars; large disagreement usually means the frame sits in
# a corner the rubric isn't calibrated for ("ambiguous moment",
# "unusual composition") and is worth a human glance.
#
# Numbers below picked empirically from the V25 batch:
#   stddev > 0.7 stars per axis  → call it noisy on that axis
#   sum of per-axis stddevs > 2.0 → call the whole row noisy
# A row with no human label yet AND a noisy total → "review me".
_INCONSISTENCY_AXIS_THRESH = 0.7
_INCONSISTENCY_TOTAL_THRESH = 2.0


def _compute_inconsistency(auto_stars: dict, model_stars: dict,
                            vlm_stars: dict, meta_stars: dict,
                            axis_names: list[str],
                            has_human: bool) -> dict:
    """Compute per-axis + total stddev across the available scoring
    sources for one row. Returns a dict with three keys ready to
    splat into the row payload.

    ``inconsistency_total``     float, sum of per-axis stddevs
    ``inconsistency_per_axis``  {axis: stddev | None}
    ``needs_review``            bool — True iff total > threshold
                                AND no human annotation exists yet
    """
    import math
    per_axis: dict[str, float | None] = {}
    total = 0.0
    n_with_signal = 0
    for axis in axis_names:
        vals = []
        for src in (auto_stars, model_stars, vlm_stars, meta_stars):
            v = src.get(axis) if isinstance(src, dict) else None
            if v is not None:
                try:
                    vals.append(float(v))
                except (TypeError, ValueError):
                    pass
        if len(vals) < 2:
            per_axis[axis] = None
            continue
        mean = sum(vals) / len(vals)
        var = sum((x - mean) ** 2 for x in vals) / len(vals)
        std = math.sqrt(var)
        per_axis[axis] = round(std, 3)
        total += std
        n_with_signal += 1
    total = round(total, 3)
    return {
        "inconsistency_total":    total,
        "inconsistency_per_axis": per_axis,
        # Only flag for review when the noise is real *and* the user
        # hasn't already decided. We trust their judgment over the
        # rubric's stddev.
        "needs_review": (
            n_with_signal >= 1
            and total >= _INCONSISTENCY_TOTAL_THRESH
            and not has_human
        ),
    }


# P-UX-14 — within-burst exposure-consistency thresholds.
#   mean_luma deviation ≥ 18 (on 0..255 scale ≈ ~⅓ stop)
#   OR  highlight_clip_pct delta ≥ 4%  (visible blown highlights)
# Cluster needs ≥ 3 members for the median to be meaningful;
# singleton "clusters" (cluster_id None) skip the check entirely.
_EXPOSURE_LUMA_DELTA   = 18.0
_EXPOSURE_HIGHLIGHT_DELTA = 4.0
_EXPOSURE_MIN_CLUSTER = 3


def _exposure_consistency_pass(rows: list[dict]) -> None:
    """Mutates rows in place: adds ``exposure_outlier`` (bool) and
    ``exposure_deviation`` (dict) to each row that's part of a
    real burst cluster (size ≥ 3) AND deviates from the cluster
    median by ≥ the thresholds above.

    The cluster_id comes from V9.0's near-duplicate / burst grouping,
    so "cluster" here means "photos the photographer took within
    seconds of each other of essentially the same scene" — the
    only place where exposure consistency is meaningful (totally
    different scenes will have different luma by design).
    """
    from collections import defaultdict
    import statistics

    by_cluster: dict[int, list[dict]] = defaultdict(list)
    for r in rows:
        cid = r.get("cluster_id")
        if cid is None:
            continue
        by_cluster[cid].append(r)

    for cid, members in by_cluster.items():
        if len(members) < _EXPOSURE_MIN_CLUSTER:
            continue
        lumas = [m["mean_luma"] for m in members if m.get("mean_luma") is not None]
        highs = [m["highlight_clip_pct"] for m in members if m.get("highlight_clip_pct") is not None]
        if len(lumas) < _EXPOSURE_MIN_CLUSTER:
            continue
        med_luma = statistics.median(lumas)
        med_high = statistics.median(highs) if len(highs) >= _EXPOSURE_MIN_CLUSTER else None
        for m in members:
            ml = m.get("mean_luma")
            mh = m.get("highlight_clip_pct")
            if ml is None:
                continue
            luma_delta = ml - med_luma
            high_delta = (mh - med_high) if (mh is not None and med_high is not None) else 0.0
            is_outlier = (
                abs(luma_delta) >= _EXPOSURE_LUMA_DELTA
                or abs(high_delta) >= _EXPOSURE_HIGHLIGHT_DELTA
            )
            if is_outlier:
                m["exposure_outlier"] = True
                m["exposure_deviation"] = {
                    "luma_delta":      round(luma_delta, 1),
                    "highlight_delta": round(high_delta, 2),
                    "cluster_median_luma":  round(med_luma, 1),
                    "cluster_size":    len(members),
                }


def _row_has_develop_settings(r) -> bool:
    """P-PRO-1 — check whether a row's source image has Lr develop
    edits (crs:*) in its XMP sidecar.

    Lazy + best-effort: returns False whenever the source path is
    unknown or the sidecar can't be parsed. The actual develop
    application happens in load_image_for_display via
    pixcull.io.xmp.read_develop_settings — we just expose a "yes/no"
    flag on the row so the lightbox can show a "已应用 Lr 调色" badge.
    """
    src = r.get("path")
    if not src:
        return False
    try:
        from pixcull.io.xmp import read_develop_settings
        dev = read_develop_settings(Path(str(src)))
        return bool(dev)
    except Exception:
        return False


# v2.33 — results were rebuilt from scratch on EVERY request.  Measured
# on a 20,000-row run: 6.2s to render the page and another 6.3s for each
# /results_rows hydration chunk, because pandas re-parses the whole CSV,
# re-merges annotations and re-derives the rubric axes per call — and one
# page load calls this 5+ times.  Caching it took the page to 0.055s and
# each chunk to 0.045s (~140x).
#
# Keyed on the mtimes of the ONLY two files the build reads (scores.csv
# and annotations.jsonl), so a re-score or a saved annotation busts it
# naturally — the same invalidation discipline _JSONL_CACHE already uses,
# no new mechanism to keep in sync.  The output_dir is in the key too: a
# run_id is only unique *within* a demo root, and the tests remap
# _DEMO_ROOT while reusing run ids, so path-blind keys could collide.
#
# NB: the cached tuple is handed back by reference, so callers must treat
# rows/summary as READ-ONLY — an in-place edit would poison every later
# request.  All 18 call sites plus every helper they forward rows into
# (_build_face_clusters_info, _build_locations_info, build_gallery_zip,
# generate_for_run, apply_style_guide) were AST-audited as read-only when
# this landed; keep it that way, or copy before mutating.
_RESULTS_CACHE: dict[tuple, tuple] = {}
_RESULTS_CACHE_LOCK = threading.Lock()
_RESULTS_CACHE_MAX = 4          # runs are multi-MB; a few is plenty


def _build_results(run_id: str) -> tuple[list[dict], dict] | None:
    """Cached wrapper around :func:`_build_results_uncached`.

    Falls through to an uncached build whenever the inputs can't be
    stat'ed — better a slow correct answer than a wrong cached one.
    """
    run = _get_run(run_id) or _reload_run_from_disk(run_id)
    if run is None:
        return None
    output_dir = Path(run["output_dir"])
    scores_path = output_dir / "scores.csv"
    ann_path = output_dir / "annotations.jsonl"
    try:
        # annotations.jsonl is optional: 0 means "not present", which is
        # the same observable state as before it was ever written.
        ann_mtime = ann_path.stat().st_mtime_ns if ann_path.exists() else 0
        cache_key = (run_id, str(output_dir),
                     scores_path.stat().st_mtime_ns, ann_mtime)
    except OSError:
        return _build_results_uncached(run_id)

    with _RESULTS_CACHE_LOCK:
        hit = _RESULTS_CACHE.get(cache_key)
    if hit is not None:
        return hit

    # Built OUTSIDE the lock: this is the multi-second path, and holding
    # the lock across it would serialise every concurrent request.  Two
    # racing builds duplicate work but agree on the result.
    built = _build_results_uncached(run_id)
    if built is not None:
        with _RESULTS_CACHE_LOCK:
            # Drop superseded generations of THIS run first: a re-scored
            # run would otherwise keep up to _MAX copies of its own
            # multi-MB row list alive until plain eviction got to them
            # (_MtimeLRUCache does the same for its single path).
            for k in [k for k in _RESULTS_CACHE
                      if k[:2] == cache_key[:2] and k != cache_key]:
                _RESULTS_CACHE.pop(k, None)
            if len(_RESULTS_CACHE) >= _RESULTS_CACHE_MAX:
                _RESULTS_CACHE.pop(next(iter(_RESULTS_CACHE)))   # oldest out
            _RESULTS_CACHE[cache_key] = built
    return built


# v2.35 — near-duplicate grouping cache.  Same mtime-keyed discipline as
# _RESULTS_CACHE above: the writer (a re-score rebuilding embeddings.npz)
# never has to know this exists.  Keyed on threshold too, because that's
# a request parameter the UI lets the user sweep.
_NEARDUP_CACHE: dict[tuple, list] = {}
_NEARDUP_CACHE_LOCK = threading.Lock()
_NEARDUP_CACHE_MAX = 8          # a few thresholds across a couple of runs


def _cached_near_dup_groups(cache_path: Path, cache: dict,
                            threshold: float) -> list:
    """Group near-duplicates, reusing the last result when nothing moved.

    Falls through to an uncached grouping if the vector file can't be
    stat'ed — a slow correct answer beats a wrongly-cached one.
    """
    from pixcull.scoring.near_dup import group_near_dups

    names = [str(f) for f in cache["filenames"]]
    try:
        key = (str(cache_path), cache_path.stat().st_mtime_ns,
               round(float(threshold), 6), len(names))
    except OSError:
        return group_near_dups(names, cache["vectors"], threshold=threshold)

    with _NEARDUP_CACHE_LOCK:
        hit = _NEARDUP_CACHE.get(key)
    if hit is not None:
        return hit

    # Computed outside the lock: this is the multi-second path.
    groups = group_near_dups(names, cache["vectors"], threshold=threshold)
    with _NEARDUP_CACHE_LOCK:
        # Drop superseded entries for this same vector file first, so a
        # re-scored run can't pin several generations of its groups.
        for k in [k for k in _NEARDUP_CACHE
                  if k[0] == key[0] and k[1] != key[1]]:
            _NEARDUP_CACHE.pop(k, None)
        if len(_NEARDUP_CACHE) >= _NEARDUP_CACHE_MAX:
            _NEARDUP_CACHE.pop(next(iter(_NEARDUP_CACHE)))
        _NEARDUP_CACHE[key] = groups
    return groups


def _build_results_uncached(run_id: str) -> tuple[list[dict], dict] | None:
    # V8.5: fall back to disk-reload if the run isn't in memory
    # (e.g. server restarted, or the .app and dev server share runs
    # via a symlink). Without this fallback /results/<run_id> is
    # 404 even when scores.csv exists on disk.
    run = _get_run(run_id) or _reload_run_from_disk(run_id)
    if run is None:
        return None
    output_dir = Path(run["output_dir"])
    scores_path = output_dir / "scores.csv"
    if not scores_path.exists():
        return None

    import pandas as pd  # local import to keep startup light

    df = pd.read_csv(scores_path)

    # V2.0: pull human annotations off disk (latest line wins per fn).
    # V14.1: cached via _MtimeLRUCache so repeat renders / API hits in
    # the same session don't re-parse the same multi-MB file.
    output_dir = Path(run["output_dir"])
    ann_path = output_dir / "annotations.jsonl"
    human_by_fn: dict[str, dict] = _read_human_by_fn_cached(ann_path)

    from pixcull.scoring.rubric import RUBRIC_AXES
    from pixcull.scoring.photo_advice import build_advice
    rubric_axis_names = [a.name for a in RUBRIC_AXES]

    # V17.3 — read the run's vertical override (set by /scan_local from
    # the dropdown) once up front. Passed into build_advice for every
    # row so wedding/bird/kids/etc tagged batches get business-flavored
    # phrasing instead of generic.
    run_vertical = run.get("vertical") or None

    rows: list[dict] = []
    # V14.3 — enumerate so build_advice can pick phrases by batch index
    # rather than filename hash. Renaming a JPG no longer rotates its
    # review text (which the user found confusing).
    # v2.37 — plain dicts, not df.iterrows().
    #
    # The loop body touches ~58 cells per row (44 r.get() + 12 r[...] + 2
    # r.to_dict()).  Against a pandas Series every one of those is an
    # Index.get_loc hash lookup into an Arrow array; profiled on a
    # 20,000-row run that was 1.22M Series.get() calls costing 7.1s of a
    # 16.3s build — 43% of the time spent looking cells up rather than
    # doing anything with them.  to_dict("records") pays the conversion
    # once and makes every access a plain dict lookup.
    #
    # NB this also removes iterrows()'s dtype upcast: a Series must have
    # one dtype, so iterrows() silently turned int columns into floats,
    # while to_dict("records") preserves each column's own dtype.  That
    # is a real behaviour difference, so the acceptance bar for this
    # change was a field-by-field diff of all 20,000 built rows against
    # the previous implementation, not just a stopwatch.
    for _idx, r in enumerate(df.to_dict("records")):
        fn = str(r["filename"])
        # Auto rubric stars from CSV columns ('rubric_<axis>_stars')
        auto_stars = {
            name: _f(r.get(f"rubric_{name}_stars"))
            for name in rubric_axis_names
        }
        # V2.1 model predictions ('model_<axis>_stars') if rescorer
        # was loaded at run time. Absent for pre-V2.1 runs.
        model_stars = {
            name: _f(r.get(f"model_{name}_stars"))
            for name in rubric_axis_names
        }
        # V3.0 VLM predictions ('vlm_<axis>_stars') if VLM was on.
        vlm_stars = {
            name: _f(r.get(f"vlm_{name}_stars"))
            for name in rubric_axis_names
        }
        # V3.1 Meta-judge predictions ('meta_<axis>_stars') if meta on.
        meta_stars = {
            name: _f(r.get(f"meta_{name}_stars"))
            for name in rubric_axis_names
        }
        # Human override if present — last save per filename wins.
        human_rec = human_by_fn.get(fn)
        human_stars: dict[str, float | None] = {}
        if human_rec:
            for name in rubric_axis_names:
                axis_data = (human_rec.get("axes") or {}).get(name) or {}
                human_stars[name] = axis_data.get("stars")
        # Final stars per axis: human → meta → vlm → model → auto.
        # Trustworthiness order: humans always win, meta-judge calibrated
        # against multi-source > raw VLM > V2.1 regressor > heuristic.
        def _pick(name: str) -> float | None:
            for src in (human_stars, meta_stars, vlm_stars, model_stars, auto_stars):
                v = src.get(name) if isinstance(src, dict) else None
                if v is not None:
                    return v
            return None
        final_stars = {name: _pick(name) for name in rubric_axis_names}
        # V5.2: build photographer-friendly advice from final stars +
        # raw row metrics + meta inconsistencies. V14.3: idx is the
        # row's position in the batch — used as the deterministic
        # phrase-rotation anchor (rename-stable, unlike old filename
        # hash) and fed into _synthesize_maybe_rationale for the
        # 'why is this maybe?' summary line.
        advice = build_advice(
            row=r,                    # already a plain dict (v2.37)
            final_stars=final_stars,
            decision=str(r.get("decision", "") or ""),
            meta_inconsistencies=str(r.get("meta_inconsistencies", "") or ""),
            idx=_idx,
            vertical=run_vertical,        # V17.3 — business-flavored phrases
        )
        # V9.0: detected style modes for the UI tag chip
        from pixcull.scoring.style_modes import detect_style_modes
        sp = detect_style_modes(r)    # plain dict since v2.37
        # cluster_id from duplicate detector — used by V9.0 grouping
        cluster_id = r.get("cluster_id")
        try:
            cluster_id = int(cluster_id) if cluster_id is not None else None
        except (TypeError, ValueError):
            cluster_id = None
        # take time of capture for date sorting
        dt_str = str(r.get("datetime", "") or "")
        rows.append({
            "filename": fn,
            # V21.2 — surface the absolute source path so the LR plugin
            # write-back (GET /decisions/<run_id>) can match photos by
            # path rather than basename (different shoots reuse the same
            # IMG_NNNN.jpg filename — basename matching is ambiguous).
            "src_path": str(r.get("path", "") or ""),
            "scene": str(r.get("scene", "") or ""),
            "decision": str(r.get("decision", "") or ""),
            # v2.15-P0 — has a HUMAN confirmed this photo's keep/maybe/cull?
            # (annotations.jsonl overall_label; rubric-stars-only annotations
            # don't count — the culling pass is about the decision.)  Drives
            # the workspace-bar "待审 N" progress + the session-done moment.
            "human_decided": bool(
                human_rec
                and str(human_rec.get("overall_label", "")).strip().lower()
                in ("keep", "maybe", "cull")
            ),
            "score_final": _f(r.get("score_final")),
            "score_sharpness": _f(r.get("score_sharpness")),
            "score_exposure": _f(r.get("score_exposure")),
            "score_aesthetic": _f(r.get("score_aesthetic")),
            "score_composition": _f(r.get("score_composition")),
            # V20 — flags was emitting the literal string "nan" whenever
            # the underlying CSV cell was empty / pandas-NaN. The lightbox
            # template renders the "检测器旗标" section as ${r.flags ?
            # … : ''}, so "nan" (truthy non-empty string) showed up as
            # a useless "nan" line on tens of thousands of clean photos.
            # Coerce to empty so the section is hidden when there's
            # nothing to report.
            "flags": _clean_csv_string(r.get("flags")),
            "reason": str(r.get("reason", "") or ""),
            "advice": advice,
            # V22.0 — per-face cluster IDs (list[int], one per
            # meaningful face). -1 = noise / unique-ish face. Empty
            # list = no faces in this photo. The CSV stores this as
            # a string repr; parse it back if non-empty.
            "face_clusters": _parse_int_list(r.get("face_clusters")),
            # V23 — GPS coords + location cluster id. None when EXIF
            # had no GPS / failed lock; the UI groups those under
            # "未知位置". gps_lat/lon are surfaced so the UI can show
            # a map pin in the lightbox info pane (V23.1+).
            "gps_lat":        _f(r.get("gps_lat")),
            "gps_lon":        _f(r.get("gps_lon")),
            "gps_cluster_id": _opt_int(r.get("gps_cluster_id")),
            # P-UX-14 — raw luma + clip-pct surfaced so we can detect
            # within-burst exposure outliers after all rows are built.
            # These are the same metrics the per-photo scorer already
            # computed; we just plumb them through so a downstream
            # pass can flag inconsistencies.
            "mean_luma":          _f(r.get("mean_luma")),
            "highlight_clip_pct": _f(r.get("highlight_clip_pct")),
            "shadow_clip_pct":    _f(r.get("shadow_clip_pct")),
            # V27 — per-burst peak rank. peak_rank=0 means "THE peak"
            # in this row's burst cluster; is_burst_peak is the same
            # signal as a bool for cheaper JS access. Singleton
            # clusters (no real burst) all get rank=0 + is_peak=True
            # but the UI ignores them by checking cluster size.
            "peak_rank":      _opt_int(r.get("peak_rank")),
            "is_burst_peak":  bool(r.get("is_burst_peak"))
                              if r.get("is_burst_peak") not in
                                 (None, "", float("nan"))
                              else False,
            # P-AI-5.1 — per-component reason string for the cluster's
            # winner ("眼睛睁开 95%" / "簇内最锐 100%" / "动作差异
            # 最大 85%"). None on non-peak rows + on singletons;
            # surfaced as a tooltip on the 🏆 badge in the lightbox.
            "burst_peak_reason": (str(r["burst_peak_reason"])
                                  if r.get("burst_peak_reason") not in
                                     (None, "", float("nan"))
                                  else None),
            # P-PRO-4.1 — wedding moment (only set on rows where
            # scene == wedding).  "unknown" means the classifier
            # abstained on a tight-margin top-2.  None on non-wedding.
            "wedding_moment": (str(r["wedding_moment"])
                               if r.get("wedding_moment") not in
                                  (None, "", float("nan"))
                               else None),
            "wedding_moment_confidence": _f(r.get("wedding_moment_confidence")),
            # v2.20(#2) — raw signals the per-axis why-low prose reads
            "face_max_smile": _f(r.get("face_max_smile")),
            "clipiqa": _f(r.get("clipiqa")),
            "laion_aes": _f(r.get("laion_aes")),
            # V9.0 sort/filter/group fields
            "cluster_id": cluster_id,
            "datetime": dt_str,
            "style_modes": sorted(sp.modes),
            "rescorer_pred": (
                str(r.get("rescorer_pred"))
                if "rescorer_pred" in df.columns
                and r.get("rescorer_pred") not in (None, "", float("nan"))
                and str(r.get("rescorer_pred")) != "nan"
                else None
            ),
            "rescorer_prob_keep": _f(r.get("rescorer_prob_keep"))
            if "rescorer_prob_keep" in df.columns else None,
            # Rubric: per-axis stars (the visible 1-5) plus the human
            # override marker so the UI can show a 'human-graded' badge.
            "rubric_stars": final_stars,
            # V2.1: keep auto/model/human as separate dicts so the modal
            # can render a 3-way comparison ("auto says 4, model says 3,
            # human says 5 — interesting!"). Tooltips on the result
            # cards use these to surface disagreements at a glance.
            "rubric_auto_stars": auto_stars,
            "rubric_model_stars": model_stars,
            "rubric_vlm_stars": vlm_stars,
            "rubric_meta_stars": meta_stars,
            "rubric_human_stars": {k: human_stars.get(k) for k in rubric_axis_names},
            "rubric_human_labeled": human_rec is not None,
            # P-UX-10 — disagreement among the available scoring
            # sources. For each axis, take the stddev across
            # (auto / model / vlm / meta) wherever a value is present
            # (skip None). Max across axes is the "noisy axis"; sum
            # is the row's overall inconsistency. Surfaced as a card
            # chip + a "review me" hint when ≥ 1.0 stars and no
            # human annotation has settled the matter yet.
            **_compute_inconsistency(
                auto_stars, model_stars, vlm_stars, meta_stars,
                rubric_axis_names,
                has_human=(human_rec is not None),
            ),
            "rubric_overall_rationale": (
                human_rec.get("overall_rationale") if human_rec else ""
            ),
            # P-UX-4 — optional reject reason (one of _CULL_REASONS or "").
            # Only surfaced when the LATEST human annotation actually
            # culled the photo — otherwise a stale "focus_miss" from a
            # since-revised verdict would mislead the UI chip + filter.
            "cull_reason": (
                str(human_rec.get("cull_reason") or "")
                if (human_rec and
                    str(human_rec.get("overall_label", "")).strip().lower() == "cull")
                else ""
            ),
            # P-PRO-1 — has the user edited develop settings in Lr?
            # If yes, the lightbox shows a "已应用 Lr 调色" badge so
            # the user knows the displayed preview reflects their
            # edit (load_image_for_display picks up crs:* settings
            # automatically; scoring still uses the RAW for now).
            "has_develop_settings": _row_has_develop_settings(r),
            # V3.x rationales for the modal's 4-way comparison
            "vlm_overall_rationale": str(r.get("vlm_overall_rationale", "") or ""),
            "vlm_overall_label": str(r.get("vlm_overall_label", "") or ""),
            "meta_overall_rationale": str(r.get("meta_overall_rationale", "") or ""),
            "meta_overall_label": str(r.get("meta_overall_label", "") or ""),
            "meta_confidence": _f(r.get("meta_confidence")),
            "meta_inconsistencies": str(r.get("meta_inconsistencies", "") or ""),
        })

    # P-UX-14 — within-burst exposure-consistency check. For each
    # cluster of ≥ 3 photos, take the median mean_luma + median
    # highlight_clip_pct, then flag rows whose deviation exceeds
    # the (light-relative) threshold. Catches the situation where
    # a wedding/event series has one frame at +1 stop because the
    # photographer's finger drifted off the dial — uniquely worth
    # flagging because the user often hasn't NOTICED themselves.
    _exposure_consistency_pass(rows)

    # Sort: keep first, then maybe, then cull, by score within group.
    order = {"keep": 0, "maybe": 1, "cull": 2, "": 3}
    rows.sort(key=lambda x: (order.get(x["decision"], 4),
                              -(x["score_final"] or 0)))

    counts = Counter(r["decision"] for r in rows)
    # V1.2 rescorer summary: "the model agrees with the rule on N out of M
    # non-cull rows; disagrees on D." Shown in the header so the user sees
    # immediately whether the learned head is contributing signal.
    rescored = [r for r in rows if r["rescorer_pred"] is not None]
    disagrees = [r for r in rescored if r["rescorer_pred"] != r["decision"]]
    # V2.0 rubric summary: how many images have any human label, mean
    # stars per axis (auto+human pooled). Surfaces "did the human
    # contribute signal yet" at a glance.
    n_human_labeled = sum(1 for r in rows if r["rubric_human_labeled"])
    # V17.8 — count of human annotations with overall_label in
    # (keep, cull) — these are the candidates the "📥 灌入 sample
    # bank" button promotes. We surface only when the run also
    # carries a vertical tag (set by /scan_local from the dropdown).
    n_promotable = 0
    if run.get("vertical"):
        for r in rows:
            rec = human_by_fn.get(r["filename"]) or {}
            lbl = (rec.get("overall_label") or "").strip().lower()
            if lbl in ("keep", "cull"):
                n_promotable += 1
    axis_means: dict[str, float | None] = {}
    for name in rubric_axis_names:
        vals = [r["rubric_stars"][name] for r in rows
                if r["rubric_stars"].get(name) is not None]
        axis_means[name] = round(sum(vals) / len(vals), 2) if vals else None
    # V17.2 — surface the vertical override + policy notes so the
    # results page can render a small badge ("应用了垂类: kids ·
    # keep -5pp / cull -5pp"). Falls back to None for runs that
    # didn't pick a vertical (most existing runs).
    vertical_key = run.get("vertical")
    vertical_info: dict | None = None
    if vertical_key:
        try:
            from pixcull.verticals import get_vertical
            v = get_vertical(vertical_key)
            if v is not None:
                vertical_info = {
                    "key":   v.key,
                    "zh":    v.zh,
                    "icon":  v.icon,
                    "policy_notes": v.policy.notes,
                    "keep_min_delta": v.policy.keep_min_delta,
                    "cull_max_delta": v.policy.cull_max_delta,
                    "tolerated_flags": sorted(v.policy.tolerated_flags),
                }
        except Exception:
            vertical_info = None

    summary = {
        "n_total": len(rows),
        "n_keep": counts.get("keep", 0),
        "n_maybe": counts.get("maybe", 0),
        "n_cull": counts.get("cull", 0),
        "rescorer_active": len(rescored) > 0,
        "rescorer_n_scored": len(rescored),
        "rescorer_n_disagrees": len(disagrees),
        "n_human_labeled": n_human_labeled,
        # v2.15-P0 — how many photos have a human-confirmed decision.
        # n_total − n_human_decided = the "待审" (unreviewed) count that
        # gives the culling pass a visible finish line.
        "n_human_decided": sum(1 for r in rows if r["human_decided"]),
        "n_promotable": n_promotable,    # V17.8 — promote-to-bank count
        "rubric_axis_means": axis_means,
        "mode": run.get("mode", "upload"),
        "origin_folder": run.get("origin_folder"),
        "started_at": run.get("started_at"),
        "finished_at": run.get("finished_at"),
        "elapsed_s": (
            round(run["finished_at"] - run["started_at"], 1)
            if run.get("finished_at") and run.get("started_at") else None
        ),
        "vertical": vertical_info,
    }
    return rows, summary


# _f / _clean_csv_string / _opt_int / _parse_int_list →
# pixcull.report.serve_util (v2.5-P0-1), imported at the top of this file.


# ---------------------------------------------------------------------------
# V22.1 — face cluster summary + per-run label persistence.
# Labels are user-edited names for cluster IDs ("Bride", "Groom",
# "Child A"). Stored per-run at ``<output_dir>/face_labels.json``;
# cross-run inheritance (so "Bride" label sticks across multiple
# weddings) is V22.2+.
# ---------------------------------------------------------------------------

def _face_labels_path(run_id: str) -> Path | None:
    """Resolve the on-disk label file for a run, or None if the run
    has no output dir on disk."""
    run = _get_run(run_id) or _reload_run_from_disk(run_id)
    if run is None:
        return None
    od = run.get("output_dir")
    if not od:
        return None
    return Path(od) / "face_labels.json"


def _load_face_labels(run_id: str) -> dict[int, str]:
    """Read the run's label file. Returns {cluster_id: label}.
    Empty dict when no file or parse error — never raises."""
    p = _face_labels_path(run_id)
    if p is None or not p.exists():
        return {}
    try:
        data = json.loads(p.read_text("utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    labels = data.get("labels") or {}
    out: dict[int, str] = {}
    for k, v in labels.items():
        try:
            out[int(k)] = str(v)
        except (TypeError, ValueError):
            continue
    return out


def _save_face_labels(run_id: str, labels: dict[int, str]) -> bool:
    """Persist labels for a run. Returns True on success."""
    p = _face_labels_path(run_id)
    if p is None:
        return False
    p.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "schema":      "pixcull.face_labels.v1",
        "run_id":      run_id,
        "updated_at":  time.time(),
        "labels":      {str(k): v for k, v in labels.items()},
    }
    try:
        p.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        return True
    except OSError:
        return False


def _build_face_clusters_info(run_id: str, rows: list[dict]) -> dict:
    """Build the {clusters: [...], labels: {...}} block for the
    results-page payload.

    Each cluster entry has:
        id           run-scoped int (>= 0 for real clusters, -1 = noise)
        n_photos     distinct photos that contain at least one face
                     with this cluster id
        n_faces      total face count across the batch with this id
        sample_filenames  up to 5 filenames for thumbnail samples
        label        user-supplied label (may be "")
        suggested_label   V22.2 — auto-inherited from prior runs when
                          this cluster's centroid matches a labeled
                          library entry. Shape: {label, similarity}
                          or None.
    """
    labels = _load_face_labels(run_id)
    # Build distinct-photo + total-face counts per cluster.
    cluster_counts: dict[int, dict] = {}
    for r in rows:
        cs = r.get("face_clusters") or []
        if not cs:
            continue
        # First record total face count
        for cid in cs:
            d = cluster_counts.setdefault(cid, {
                "id":               cid,
                "n_photos":         0,
                "n_faces":          0,
                "sample_filenames": [],
            })
            d["n_faces"] += 1
        # Then distinct-photo counting (use a set per row to dedupe
        # photos that contain the same person twice — siblings, mirror
        # shots — from inflating n_photos)
        fn = r.get("filename", "")
        for cid in set(cs):
            d = cluster_counts.setdefault(cid, {
                "id":               cid,
                "n_photos":         0,
                "n_faces":          0,
                "sample_filenames": [],
            })
            d["n_photos"] += 1
            if fn and len(d["sample_filenames"]) < 5:
                d["sample_filenames"].append(fn)

    # V22.2 — attempt cross-run label inheritance via centroid match.
    # Loads this run's per-cluster centroids (saved by face_clustering
    # post-pass), compares against the active user's face library,
    # and emits a suggested_label when sim >= SUGGEST_THRESHOLD.
    suggestions: dict[int, dict] = {}
    try:
        from pixcull.pipeline.face_library import (
            load_run_centroids, suggest_labels,
        )
        from pixcull.users import get_active_user, user_root
        run = _get_run(run_id) or _reload_run_from_disk(run_id)
        if run and run.get("output_dir"):
            run_centroids = load_run_centroids(Path(run["output_dir"]))
            if run_centroids is not None:
                cluster_ids_arr, centroids = run_centroids
                ulib = user_root(get_active_user())
                suggs = suggest_labels(centroids, ulib)
                for cid_int, sugg in zip(cluster_ids_arr.tolist(), suggs):
                    if sugg is not None:
                        suggestions[int(cid_int)] = {
                            "label":      sugg[0],
                            "similarity": float(round(sugg[1], 3)),
                        }
    except Exception as exc:  # noqa: BLE001
        # Non-essential. Surface but don't fail the request.
        print(f"[face_clusters_info] V22.2 suggest skipped: "
              f"{type(exc).__name__}: {exc}", file=sys.stderr)

    # Attach labels + sort by n_photos desc (noise/-1 always last).
    out: list[dict] = []
    for cid, d in cluster_counts.items():
        d["label"] = labels.get(cid, "")
        # V22.2 — suggested_label from cross-run centroid match.
        # Only shown when there's no user-set label for this cluster
        # (user override always wins).
        if cid >= 0 and not d["label"] and cid in suggestions:
            d["suggested_label"] = suggestions[cid]
        out.append(d)
    out.sort(key=lambda d: (d["id"] < 0, -d["n_photos"]))
    return {
        "clusters": out,
        "n_noise":  cluster_counts.get(-1, {}).get("n_photos", 0),
    }


# ---------------------------------------------------------------------------
# V23 — location cluster summary for the travel-persona UI.
# Reads gps_cluster_id from already-loaded rows, computes centroid +
# n_photos + per-cluster "best" filename. No persistence layer yet
# (location labels — "Notre Dame" / "我家" — are V23.1 work; reverse
# geocoding goes beyond V23 scope).
# ---------------------------------------------------------------------------

# V23.1 — per-run location labels. Same shape as face labels (V22.1):
# {cluster_id: "Notre Dame" / "我家" / ...}, stored at
# <output_dir>/location_labels.json. Pattern mirrors face labels
# exactly so the UI code can reuse the same inline-edit flow.

def _location_labels_path(run_id: str) -> Path | None:
    run = _get_run(run_id) or _reload_run_from_disk(run_id)
    if run is None:
        return None
    od = run.get("output_dir")
    if not od:
        return None
    return Path(od) / "location_labels.json"


def _load_location_labels(run_id: str) -> dict[int, str]:
    p = _location_labels_path(run_id)
    if p is None or not p.exists():
        return {}
    try:
        data = json.loads(p.read_text("utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    labels = data.get("labels") or {}
    out: dict[int, str] = {}
    for k, v in labels.items():
        try:
            out[int(k)] = str(v)
        except (TypeError, ValueError):
            continue
    return out


def _save_location_labels(run_id: str, labels: dict[int, str]) -> bool:
    p = _location_labels_path(run_id)
    if p is None:
        return False
    p.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "schema":     "pixcull.location_labels.v1",
        "run_id":     run_id,
        "updated_at": time.time(),
        "labels":     {str(k): v for k, v in labels.items()},
    }
    try:
        p.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        return True
    except OSError:
        return False


def _build_locations_info(rows: list[dict],
                              run_id: str | None = None) -> dict:
    """Build the {clusters: [...], n_no_gps} block for the results
    payload + the /locations endpoint.

    Each cluster entry:
        id              run-scoped int
        n_photos        photos in this cluster
        center_lat,
        center_lon      unweighted mean of member coords
        best_filename   highest score_final photo in the cluster
        best_score      that photo's final score
        sample_filenames first up-to-5 filenames (for thumbnails)
        label           V23.1 — user-supplied location name (may be "")
    """
    cluster_acc: dict[int, dict] = {}
    n_no_gps = 0
    for r in rows:
        cid = r.get("gps_cluster_id")
        if cid is None:
            n_no_gps += 1
            continue
        try:
            cid_int = int(cid)
        except (TypeError, ValueError):
            n_no_gps += 1
            continue
        d = cluster_acc.setdefault(cid_int, {
            "id":               cid_int,
            "n_photos":         0,
            "lats":             [],
            "lons":             [],
            "sample_filenames": [],
            "best_score":       -1.0,
            "best_filename":    "",
        })
        d["n_photos"] += 1
        lat = r.get("gps_lat")
        lon = r.get("gps_lon")
        if lat is not None and lon is not None:
            d["lats"].append(float(lat))
            d["lons"].append(float(lon))
        fn = r.get("filename", "")
        if fn and len(d["sample_filenames"]) < 5:
            d["sample_filenames"].append(fn)
        sf = r.get("score_final")
        if sf is not None:
            try:
                sf_f = float(sf)
            except (TypeError, ValueError):
                sf_f = -1.0
            if sf_f > d["best_score"]:
                d["best_score"] = sf_f
                d["best_filename"] = fn

    # V23.1 — attach user-supplied location labels.
    labels = _load_location_labels(run_id) if run_id else {}

    clusters: list[dict] = []
    for d in cluster_acc.values():
        if d["lats"]:
            d["center_lat"] = sum(d["lats"]) / len(d["lats"])
            d["center_lon"] = sum(d["lons"]) / len(d["lons"])
        else:
            d["center_lat"] = None
            d["center_lon"] = None
        d.pop("lats", None)
        d.pop("lons", None)
        d["label"] = labels.get(d["id"], "")
        clusters.append(d)
    clusters.sort(key=lambda d: -d["n_photos"])
    return {
        "clusters":  clusters,
        "n_no_gps":  n_no_gps,
        "n_total":   len(rows),
    }


# ---------------------------------------------------------------------------
# V2.1 retrain worker — invokes build_axis_training_set + train_axis_rescorers
# as Python imports (faster than shelling out, and we get exceptions back).
# Updates _RETRAIN_STATE so the admin UI can poll progress.
# ---------------------------------------------------------------------------
def _retrain_in_background(include_auto: bool, also_goldenset: bool) -> None:
    """Background worker for /retrain. Never raises."""
    global _RETRAIN_STATE
    try:
        with _RUNS_LOCK:
            _RETRAIN_STATE = {
                "state": "running",
                "phase": "collecting training data",
                "started_at": time.time(),
            }

        # Step 1: build training_axis.csv. Reuse the script's main-style
        # logic by calling its helpers directly.
        import sys as _sys
        _rr_scripts = _repo_root()
        scripts_dir = (_rr_scripts / "scripts") if _rr_scripts else Path(__file__).parent.resolve()
        if str(scripts_dir) not in _sys.path:
            _sys.path.insert(0, str(scripts_dir))
        # Defer imports until inside the worker so we don't block startup
        # on sklearn loading. ImportError here is reported via state.
        from build_axis_training_set import _gather_run, AXIS_NAMES  # type: ignore
        import pandas as pd

        all_rows: list[dict] = []
        n_with_human = 0
        for run_dir in sorted(_DEMO_ROOT.iterdir()):
            if not run_dir.is_dir():
                continue
            if not (len(run_dir.name) == 10 and
                    all(c in "0123456789abcdef" for c in run_dir.name)):
                continue
            rows = _gather_run(run_dir)
            if not rows:
                continue
            had_human = any(
                any(r.get(f"target_{ax}_source") == "human" for ax in AXIS_NAMES)
                for r in rows
            )
            if had_human:
                n_with_human += 1
            all_rows.extend(rows)

        # Optional goldenset warm-start
        gs_csv = Path.home() / "Pictures/pixcull-goldenset/_eval_output/scores.csv"
        gt_csv = Path.home() / "Pictures/pixcull-goldenset/ground_truth.csv"
        if also_goldenset and gs_csv.exists() and gt_csv.exists():
            with _RUNS_LOCK:
                _RETRAIN_STATE["phase"] = "loading goldenset warm-start"
            gs = pd.read_csv(gs_csv)
            gt = pd.read_csv(gt_csv, comment="#")
            gt = gt[gt["manual_label"].isin(["keep", "maybe", "cull"])]
            merged = gs.merge(gt[["filename", "manual_label"]],
                              on="filename", how="inner")
            from build_axis_training_set import (  # type: ignore
                FEATURE_COLS_NUMERIC, FEATURE_COLS_CATEGORICAL,
            )
            for _, r in merged.iterrows():
                row: dict = {
                    "filename": r["filename"],
                    "_run_id": "goldenset_warmstart",
                }
                for col in FEATURE_COLS_NUMERIC + FEATURE_COLS_CATEGORICAL:
                    row[col] = r.get(col)
                # Prefer per-axis stars from V2.0 columns; fall back to
                # the coarse keep/maybe/cull → 5/3/1 mapping.
                label_to_stars = {"keep": 5.0, "maybe": 3.0, "cull": 1.0}
                fallback = label_to_stars.get(r["manual_label"], 3.0)
                for axis in AXIS_NAMES:
                    auto_v = r.get(f"rubric_{axis}_stars")
                    row[f"target_{axis}"] = (
                        float(auto_v) if pd.notna(auto_v) else fallback
                    )
                    row[f"target_{axis}_source"] = (
                        "goldenset_v2" if pd.notna(auto_v) else "goldenset"
                    )
                all_rows.append(row)

        if not all_rows:
            with _RUNS_LOCK:
                _RETRAIN_STATE = {
                    "state": "error",
                    "message": "没有训练数据 — 先标几张或开 also_goldenset",
                    "finished_at": time.time(),
                }
            return

        df = pd.DataFrame(all_rows)
        if not include_auto:
            human_mask = pd.Series(False, index=df.index)
            for axis in AXIS_NAMES:
                human_mask |= (df[f"target_{axis}_source"] == "human")
            df = df[human_mask]
        if df.empty:
            with _RUNS_LOCK:
                _RETRAIN_STATE = {
                    "state": "error",
                    "message": "过滤后无训练数据,试试 include_auto=true",
                    "finished_at": time.time(),
                }
            return

        # Persist + train
        with _RUNS_LOCK:
            _RETRAIN_STATE.update({
                "phase": f"training on {len(df)} rows",
                "n_rows": len(df),
            })

        # Use a stable on-disk path so the user can inspect what was
        # trained — keeps the audit story straight.
        repo_root = _repo_root() or (Path.home() / ".pixcull")
        training_csv = repo_root / "training_axis.csv"
        df.to_csv(training_csv, index=False)

        # Now train. Import the trainer's helpers and invoke per axis.
        from train_axis_rescorers import train_one_axis  # type: ignore
        out_dir = repo_root / "models"
        results = []
        for axis in AXIS_NAMES:
            with _RUNS_LOCK:
                _RETRAIN_STATE["phase"] = f"training axis: {axis}"
            r = train_one_axis(df, axis, out_dir, cv=5, seed=42, min_rows=20)
            if r is not None:
                results.append(r)

        # Save meta JSON (matches train_axis_rescorers.py)
        from pixcull.scoring.axis_rescorer import axis_meta_path
        meta = {
            "created_at": pd.Timestamp.now("UTC").isoformat(),
            "training_csv": str(training_csv.resolve()),
            "n_rows_in_csv": len(df),
            "axes": results,
            "seed": 42,
            "cv": 5,
            "n_runs_with_human": n_with_human,
        }
        axis_meta_path(out_dir).write_text(
            json.dumps(meta, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

        with _RUNS_LOCK:
            _RETRAIN_STATE = {
                "state": "done",
                "started_at": _RETRAIN_STATE.get("started_at"),
                "finished_at": time.time(),
                "axes": results,
                "n_rows": len(df),
                "message": f"训练完成 {len(results)}/{len(AXIS_NAMES)} 轴",
            }

    except Exception as exc:  # noqa: BLE001
        traceback.print_exc(file=sys.stderr)
        with _RUNS_LOCK:
            _RETRAIN_STATE = {
                "state": "error",
                "message": f"训练失败: {type(exc).__name__}: {exc}",
                "finished_at": time.time(),
            }


# ---------------------------------------------------------------------------
# Storage admin: enumerate runs on disk, compute sizes, delete safely.
#
# We always derive the run list from the filesystem (not _RUNS) so that
# runs from a previous server session — which never made it into the
# in-memory dict — are still listed and prunable. The dict's metadata
# (started/finished_at, decisions) is layered in when present.
# ---------------------------------------------------------------------------
def _dir_size_bytes(p: Path) -> int:
    total = 0
    try:
        for f in p.rglob("*"):
            try:
                if f.is_file() and not f.is_symlink():
                    total += f.stat().st_size
            except OSError as exc:
                _dbg("_dir_size_bytes/stat", exc, str(f))
                continue
    except OSError as exc:
        _dbg("_dir_size_bytes/rglob", exc, str(p))
    return total


def _enumerate_runs() -> list[dict]:
    """List every directory under ``_DEMO_ROOT`` that looks like a run.

    A "run" is any first-level subdir whose name is a 10-char hex string
    (matches our ``_new_run_id()`` format). Anything else under
    ``_DEMO_ROOT`` is left alone — we never delete what we didn't create.
    """
    out: list[dict] = []
    if not _DEMO_ROOT.exists():
        return out
    for child in sorted(_DEMO_ROOT.iterdir(), key=lambda x: x.name):
        if not child.is_dir():
            continue
        # Heuristic: 10-char hex matches our run_id pattern.
        if not (len(child.name) == 10 and all(c in "0123456789abcdef" for c in child.name)):
            continue

        run_id = child.name
        input_dir = child / "input"
        output_dir = child / "output"
        scores_csv = output_dir / "scores.csv"

        n_input = 0
        if input_dir.exists():
            n_input = sum(1 for f in input_dir.iterdir() if f.is_file())

        # Pull decision counts from scores.csv (cheap CSV parse, no pandas)
        decisions = {"keep": 0, "maybe": 0, "cull": 0}
        if scores_csv.exists():
            try:
                import csv
                with open(scores_csv, encoding="utf-8") as f:
                    reader = csv.DictReader(f)
                    for row in reader:
                        d = row.get("decision", "")
                        if d in decisions:
                            decisions[d] += 1
            except (OSError, csv.Error) as exc:
                _dbg("_enumerate_runs/scores.csv", exc, str(scores_csv))

        # Modification time of the run dir = "last touched"; useful for
        # the older-than-N-hours policy.
        try:
            mtime = child.stat().st_mtime
        except OSError:
            mtime = 0

        # Pick up live state from the in-memory dict if this run is from
        # the current server session.
        live = _get_run(run_id) or {}

        # Detect mode from manifest.json — scan-mode runs leave one
        # behind, upload-mode runs don't. Lets the admin UI distinguish
        # "delete this also wipes uploaded copies" from "delete only
        # touches our /tmp output, originals stay put".
        manifest_path = output_dir / "manifest.json"
        mode = live.get("mode")
        if mode is None:
            mode = "scan" if manifest_path.exists() else "upload"

        # In scan mode n_input doesn't exist on disk (we don't copy);
        # pull the count from the manifest instead so the admin table
        # still has something useful to show.
        if mode == "scan" and manifest_path.exists():
            try:
                manifest = json.loads(manifest_path.read_text("utf-8"))
                n_input = len(manifest)
            except (OSError, json.JSONDecodeError) as exc:
                _dbg("_enumerate_runs/manifest", exc, str(manifest_path))

        out.append({
            "run_id": run_id,
            "mode": mode,
            "size_bytes": _dir_size_bytes(child),
            "n_input": n_input,
            "decisions": decisions,
            "state": live.get("state", "stale" if not scores_csv.exists() else "done"),
            "mtime": mtime,
            "age_seconds": max(0, int(time.time() - mtime)) if mtime else None,
            "started_at": live.get("started_at"),
            "finished_at": live.get("finished_at"),
        })
    # Newest first — that's what the user will scan visually.
    out.sort(key=lambda r: -(r["mtime"] or 0))
    return out


def _reload_run_from_disk(run_id: str) -> dict | None:
    """Reconstruct minimal run metadata when a thumbnail is requested
    after a server restart. Reads ``output/manifest.json`` if present
    (scan mode) and the basic dir layout otherwise.
    """
    if not run_id or not run_id.replace("_", "").replace("-", "").isalnum():
        return None
    run_root = _DEMO_ROOT / run_id
    if not run_root.is_dir():
        return None
    output_dir = run_root / "output"
    input_dir = run_root / "input"
    manifest_path = output_dir / "manifest.json"
    info: dict = {
        "output_dir": str(output_dir),
    }
    # v2.35.2 — a run laid out by `pixcull video` puts scores.csv directly
    # in its --output dir, with no nested output/. Accept either shape, or
    # the run is invisible to the registry.
    if not (output_dir / "scores.csv").is_file() and \
            (run_root / "scores.csv").is_file():
        output_dir = run_root
        manifest_path = output_dir / "manifest.json"
        info["output_dir"] = str(output_dir)

    if manifest_path.exists():
        info["mode"] = "scan"
        info["input_dir"] = ""  # n/a in scan mode
        try:
            info["files_manifest"] = json.loads(manifest_path.read_text("utf-8"))
        except (OSError, json.JSONDecodeError):
            info["files_manifest"] = {}
    elif input_dir.is_dir():
        info["mode"] = "upload"
        info["input_dir"] = str(input_dir)
    elif (output_dir / "scores.csv").is_file():
        # v2.35.2 — a VIDEO run has neither: `pixcull video` writes no
        # manifest.json and has no input/ dir, its frames live in
        # video_frames/<clip>_<hash>/. Before this, such a run failed to
        # reload at all, so /api/v1/runs reported it missing, every
        # /thumb 404'd, and the photo+video timeline rendered as N broken
        # images. scores.csv is the real marker of "this is a run";
        # _resolve_image_source falls back to its `path` column.
        info["mode"] = "csv"
        info["input_dir"] = ""
    else:
        return None
    return info


def _resolve_image_source(run: dict, filename: str) -> Path | None:
    """Find the absolute on-disk path of ``filename`` within a run.

    In upload mode the file lives under ``input_dir/<filename>``. In scan
    mode we consult the manifest (preferred — exact original location)
    or fall back to scanning ``source_dir`` for a basename match.
    """
    mode = run.get("mode")
    if mode == "scan":
        # Try the in-memory dict first (set when run started this session)
        manifest = run.get("files_manifest")
        if not manifest:
            # Fall through to disk
            mp = Path(run["output_dir"]) / "manifest.json"
            if mp.exists():
                try:
                    manifest = json.loads(mp.read_text("utf-8"))
                except (OSError, json.JSONDecodeError):
                    manifest = {}
        if manifest:
            p = manifest.get(filename)
            if p:
                return Path(p)
        # Last resort: walk source_dir looking for the filename. Guard the
        # empty case explicitly: ``Path("")`` equals ``Path(".")``, whose
        # ``.is_dir()`` is True, so an empty source would ``rglob`` the
        # entire server CWD (the whole repo) on EVERY missing thumbnail —
        # ~2s each, serialized under the lock, enough to saturate the
        # browser's 6-connection-per-host pool and freeze the grid (a run
        # whose originals were moved/deleted hit exactly this). A run with
        # no recorded source simply has no resolvable originals.
        src_raw = run.get("source_dir") or run.get("origin_folder")
        if src_raw:
            src_dir = Path(src_raw)
            if src_dir.is_dir():
                for f in src_dir.rglob(filename):
                    return f
        return None
    # upload mode (default)
    input_dir = run.get("input_dir") or ""
    if input_dir:
        candidate = Path(input_dir) / filename
        if candidate.exists():
            return candidate
    # v2.35.2 — last resort: scores.csv's own ``path`` column.
    #
    # A VIDEO run is exactly this case. Its frames live in
    # ``video_frames/<clip>_<hash>/``, it has no manifest.json and no
    # input_dir, so neither branch above could resolve anything: every
    # /thumb request 404'd and the whole photo+video timeline rendered as
    # 50 broken images. The CSV records the absolute path of each frame,
    # which is authoritative — the same column v2.34 found the library
    # indexer was ignoring for the same reason.
    return _scores_path_map(Path(run["output_dir"])).get(filename)


def _scores_path_map(output_dir: Path) -> dict[str, Path]:
    """``filename -> path`` from scores.csv, for runs with no manifest.

    Cached on the CSV's mtime because _resolve_image_source is called
    once PER THUMBNAIL — parsing the CSV inline would be one full parse
    per image (50 parses to draw one video timeline, thousands on a real
    shoot). Only paths that exist are returned.
    """
    def _load() -> dict[str, Path]:
        import csv as _csv
        out: dict[str, Path] = {}
        scores = output_dir / "scores.csv"
        if not scores.is_file():
            return out
        try:
            with scores.open("r", encoding="utf-8", newline="") as fh:
                for row in _csv.DictReader(fh):
                    fn, raw = row.get("filename"), row.get("path")
                    if fn and raw:
                        p = Path(raw)
                        if p.is_file():
                            out[fn] = p
        except (OSError, ValueError):
            return {}
        return out

    return _SCORES_PATH_CACHE.get_or_load(output_dir / "scores.csv", _load)


_SCORES_PATH_CACHE = _MtimeLRUCache(maxsize=8)


# ── v2.9-P0-1 — face Close-ups (Narrative Select) ────────────────────────────
# Lazily detect faces on the full image at serve time and cache the bboxes
# (normalized, resolution-independent) so the lightbox close-ups rail can show a
# zoomed crop of every face without re-detecting per crop. Reuses the pipeline's
# MediaPipe FaceDetector; degrades to "no faces" when the optional weights /
# mediapipe are absent — the rail simply doesn't render.
_FACE_DETECTOR = None
_FACE_DETECTOR_FAILED = False
_FACE_BBOX_CACHE: dict[tuple, list] = {}   # (src, mtime) → [(nx1,ny1,nx2,ny2,conf), ...]


def _get_face_detector():
    global _FACE_DETECTOR, _FACE_DETECTOR_FAILED
    if _FACE_DETECTOR is not None:
        return _FACE_DETECTOR
    if _FACE_DETECTOR_FAILED:
        return None
    try:
        from pixcull.detectors.face import FaceDetector
        _FACE_DETECTOR = FaceDetector()
    except Exception:
        _FACE_DETECTOR_FAILED = True
        _FACE_DETECTOR = None
    return _FACE_DETECTOR


def _detect_faces_for_src(src: Path) -> list:
    """Return meaningful face boxes for ``src`` as normalized tuples
    ``(nx1, ny1, nx2, ny2, conf)`` (fractions of width/height, so they map onto
    any display size), largest-first. Cached by (path, mtime); empty list when
    no faces / no detector."""
    try:
        mtime = src.stat().st_mtime
    except OSError:
        return []
    key = (str(src), mtime)
    cached = _FACE_BBOX_CACHE.get(key)
    if cached is not None:
        return cached
    det = _get_face_detector()
    if det is None:
        _FACE_BBOX_CACHE[key] = []
        return []
    boxes: list = []
    try:
        from pixcull.io.loader import load_image
        img = load_image(src, max_side=1600)
        if img is not None:
            res = det.analyze(img)
            W, H = img.size
            for b in (res.extras.get("face_bboxes") or []):
                x1, y1, x2, y2 = b[0], b[1], b[2], b[3]
                conf = float(b[4]) if len(b) > 4 else 0.0
                if W > 0 and H > 0:
                    boxes.append((x1 / W, y1 / H, x2 / W, y2 / H, conf))
    except Exception:
        boxes = []
    # Largest face first so the rail leads with the dominant subject.
    boxes.sort(key=lambda b: (b[2] - b[0]) * (b[3] - b[1]), reverse=True)
    _FACE_BBOX_CACHE[key] = boxes
    return boxes


def _delete_run(run_id: str) -> tuple[bool, str]:
    """Best-effort delete of a single run dir. Returns (ok, message).

    Refuses to touch anything outside ``_DEMO_ROOT`` — defense in depth
    against a maliciously crafted run_id like ``../etc``. Also drops the
    in-memory state so a subsequent ``/status/<id>`` reports 404.
    """
    if not run_id or not run_id.replace("_", "").replace("-", "").isalnum():
        return False, "invalid run_id"
    target = (_DEMO_ROOT / run_id).resolve()
    try:
        # Refuse if resolution escaped _DEMO_ROOT (symlink trickery, etc.)
        target.relative_to(_DEMO_ROOT.resolve())
    except ValueError:
        return False, "run_id resolves outside demo root"
    if not target.exists():
        return False, "no such run"

    try:
        shutil.rmtree(target)
    except OSError as exc:
        return False, f"rmtree failed: {exc}"

    with _RUNS_LOCK:
        _RUNS.pop(run_id, None)
    return True, "deleted"


# Global model cache directories the user might want to know about — these
# are *machine-wide* and not deleted by run cleanup, but listing them on
# the storage page makes the "where's my disk going" question answerable.
_GLOBAL_CACHES = [
    ("torch hub", Path.home() / ".cache" / "torch"),
    ("HuggingFace", Path.home() / ".cache" / "huggingface"),
]


def _storage_info() -> dict:
    runs = _enumerate_runs()
    runs_total = sum(r["size_bytes"] for r in runs)
    caches = []
    for label, path in _GLOBAL_CACHES:
        if path.exists():
            caches.append({
                "label": label,
                "path": str(path),
                "size_bytes": _dir_size_bytes(path),
            })
    return {
        "demo_root": str(_DEMO_ROOT),
        "runs_total_bytes": runs_total,
        "n_runs": len(runs),
        "runs": runs,
        "global_caches": caches,
    }


# ---------------------------------------------------------------------------
# HTTP handler.
# ---------------------------------------------------------------------------
class _Handler(BaseHTTPRequestHandler):
    server_version = "PixCullDemo/1.2"

    def send_error(self, code: int, message: str | None = None,
                    explain: str | None = None) -> None:
        """Override stdlib send_error to handle non-ASCII messages.

        BaseHTTPRequestHandler.send_response_only() encodes the HTTP
        status line as latin-1; any em-dash / Chinese / etc. character
        crashes the request thread mid-response with UnicodeEncodeError,
        which has cascaded into '查看结果按钮整个崩溃' before this fix.
        We strip the message to ASCII for the status line and stash the
        original (Unicode-safe) text in the JSON body that's already
        ASCII-only HTTP-headers + utf-8 payload.
        """
        if message is None:
            message = "error"
        # ASCII-safe status reason phrase (per RFC 7230 §3.1.2)
        ascii_msg = message.encode("ascii", "ignore").decode("ascii") or "error"
        # Body carries the original message in UTF-8 JSON
        try:
            body = json.dumps(
                {"code": code, "error": message, "explain": explain or ""},
                ensure_ascii=False,
            ).encode("utf-8")
        except Exception:
            body = json.dumps({"code": code, "error": ascii_msg}).encode("utf-8")
        try:
            self.send_response(code, ascii_msg)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            if self.command != "HEAD":
                self.wfile.write(body)
        except Exception:
            # Last-resort: don't let secondary failures crash the worker
            pass

    def log_message(self, fmt: str, *args: object) -> None:
        sys.stderr.write("%s - %s\n" % (self.address_string(), fmt % args))

    # --- V25 /api/v1/ dispatch ---------------------------------------------
    # Routes under /api/v1/ are designed for programmatic consumption:
    # mobile apps, third-party tools, the Lightroom plugin's future
    # cross-machine support. All return clean JSON (no HTML) and carry
    # CORS headers from end_headers() above.
    #
    # Most routes are thin aliases over the existing handlers; the
    # unique additions are the discovery endpoint and the mobile-friendly
    # summary endpoints (``/runs/<id>`` returns a single JSON doc
    # describing the run + linking to its specific assets).
    def _dispatch_api_v1_get(self, path: str) -> bool:
        """Returns True if the request was handled. Caller falls through
        to legacy routes (or 404) when this returns False."""
        sub = path[len("/api/v1"):]
        if sub in ("", "/"):
            return self._serve_api_v1_index()
        if sub == "/runs":
            return self._serve_runs_list_json_api()
        if sub == "/verticals":
            self._serve_verticals_json(); return True
        if sub == "/storage_info":
            self._serve_storage_info(); return True
        if sub == "/rubric_meta":
            self._serve_rubric_meta(); return True
        # P-UX-4 — stable enum advertisement so clients (iOS,
        # third-party) populate the reject-reason picker without
        # hardcoding the token list. Currently exposes cull_reasons
        # + their default zh-CN labels; will grow as more taxonomies
        # appear (style_modes, scenes, etc.).
        if sub == "/taxonomy":
            return self._serve_api_v1_taxonomy()
        # v0.8-P0-1 — i18n locale fetcher.
        # GET /api/v1/locale?lang=en_US → {lang, strings: {...}}
        if sub == "/locale":
            return self._serve_api_v1_locale()
        # v0.8-P0-2 — LAN sync change-list polling.
        # GET /api/v1/sync/event/<token>/changes?since=<ms>
        #   → {schema, run_id, server_ts, annotations: [...]}
        if sub.startswith("/sync/event/") and sub.endswith("/changes"):
            token = sub[len("/sync/event/"):-len("/changes")]
            return self._serve_sync_event_changes(token)
        # v0.9-P1-2 — multiplayer presence list.
        # GET /api/v1/sync/event/<token>/presence
        #   → {schema, server_ts, peers: [...]}
        if sub.startswith("/sync/event/") and sub.endswith("/presence"):
            token = sub[len("/sync/event/"):-len("/presence")]
            return self._serve_sync_event_presence(token)
        # v0.10-P0-2 — mDNS discovery (LAN auto-detect of sessions).
        # GET /api/v1/sync/discover?timeout=2
        #   → {schema, available, sessions: [...]}
        if sub == "/sync/discover":
            return self._serve_sync_discover()
        # v0.11-P0-3 — WebRTC signaling inbox.
        # GET /api/v1/sync/webrtc/inbox?peer=<id>&since=<ms>
        #   → {ok, messages: [{kind, from, payload, ts_ms}]}
        if sub == "/sync/webrtc/inbox":
            return self._serve_sync_webrtc_inbox()
        # P-UX-9 — accumulated cull-reason counts so the picker can
        # sort by user frequency + admin can show "your cull habits".
        if sub == "/cull_reasons/stats":
            return self._serve_api_v1_cull_reason_stats()
        # P-UX-12 — per-user taste profile (scene preferences, axis
        # weights inferred from history, cull-reason distribution).
        if sub == "/users/preferences":
            return self._serve_api_v1_user_preferences()
        # P-AI-1 — personalized keep/maybe threshold profile.
        # Reads /users/preferences then derives a small shift to the
        # global thresholds based on the user's historical keep-rate
        # vs the baseline 0.65.
        if sub == "/users/profile":
            return self._serve_api_v1_user_profile()
        # INFRA-4 — daily LLM spend ledger
        if sub == "/llm_budget":
            return self._serve_llm_budget()
        # INFRA-2 — multi-machine sync status
        if sub == "/sync_status":
            return self._serve_sync_status()
        # P2.2 — list active tether sessions
        if sub == "/tether":
            return self._serve_tether_list()
        # V28 — user / team profile endpoints
        if sub == "/users":
            return self._serve_users_list()
        if sub == "/users/active":
            return self._serve_users_active()
        # v0.10-P1-1 — team taste aggregate (multi-user discrepancy
        # report for /admin/team_taste).
        if sub == "/team_taste":
            return self._serve_team_taste()
        # /runs/<id> and its sub-resources
        if sub.startswith("/runs/"):
            tail = sub[len("/runs/"):]
            # /runs/<id> (no further path) → run summary
            if "/" not in tail:
                return self._serve_api_v1_run_summary(tail)
            run_id, rest = tail.split("/", 1)
            if rest == "decisions":
                self._serve_decisions(run_id); return True
            if rest == "face_clusters":
                self._serve_face_clusters(run_id); return True
            if rest == "locations":
                self._serve_locations(run_id); return True
            if rest == "status":
                self._serve_status(run_id); return True
            if rest == "scores.csv":
                self._serve_scores_csv(run_id); return True
            if rest == "gallery.zip" or rest.startswith("gallery.zip?"):
                # Strip /api/v1/runs/<id>/gallery.zip → ``run_id`` +
                # optional ``?include=keep,maybe``. Re-attach the query
                # string the way ``_serve_gallery_zip`` expects.
                qs = ""
                if "?" in rest:
                    _, qs = rest.split("?", 1)
                self._serve_gallery_zip(f"{run_id}?{qs}" if qs else run_id)
                return True
            if rest == "xmp.zip":
                self._serve_xmp_zip(run_id); return True
            # P2.1 V0.2 — paginated rows for the mobile photo grid.
            # ``?limit=N&offset=K`` (defaults 200 / 0). Slim row shape
            # — only the fields the iOS grid + lightbox render —
            # so a 1500-photo wedding doesn't ship 5MB of advice text
            # the mobile UI doesn't use.
            if rest == "rows":
                qs = urlparse(self.path).query
                return self._serve_api_v1_rows(run_id, qs)
            # V0.3 — single rich row for the iOS lightbox info panel.
            # Strips nothing, so callers see advice + rubric_stars +
            # gps_lat/lon + face_clusters etc. URL-encoded filename
            # because mobile-shot photos often have spaces / non-ASCII.
            if rest.startswith("row/"):
                fn = rest[len("row/"):]
                return self._serve_api_v1_row(run_id, fn)
            # P-AI-2 — text→image CLIP semantic search
            if rest == "semantic_search":
                qs = urlparse(self.path).query
                return self._serve_api_v1_semantic_search(run_id, qs)
            # v2.6-P1 — CLIP near-duplicate groups for the grid fold.
            if rest == "near_dups":
                qs = urlparse(self.path).query
                return self._serve_api_v1_near_dups(run_id, qs)
            # v2.9-P1-1 — chronological Scenes (capture-time segmentation).
            if rest == "scenes":
                qs = urlparse(self.path).query
                return self._serve_api_v1_scenes(run_id, qs)
            # P-UX-5 — composite-similarity nearest-neighbor lookup
            # ("show me photos like this one") for the lightbox's
            # similar-photos row. Returns up to k=5 by default.
            if rest.startswith("similar/"):
                fn = rest[len("similar/"):]
                qs = urlparse(self.path).query
                return self._serve_api_v1_similar(run_id, fn, qs)
            # v2.9-P0-1 — detected faces for the lightbox close-ups rail.
            if rest.startswith("faces/"):
                fn = rest[len("faces/"):]
                return self._serve_api_v1_faces(run_id, fn)
            # P2.4 — active-learning queue (batch). Accepts ?n=N.
            # urlparse already stripped the query string from ``path``
            # in the caller; read it back off ``self.path`` so we
            # forward it to _serve_next_to_label.
            if rest == "next_to_label":
                qs = urlparse(self.path).query
                rel = f"{run_id}?{qs}" if qs else run_id
                self._serve_next_to_label(rel); return True
            # v0.10-P0-4 — iOS Companion portfolio JSON.  Same data
            # the web /share/<run>/<token> page builds, but as JSON
            # without requiring a share token (iOS hits this through
            # its existing API-key channel).
            if rest == "portfolio":
                return self._serve_run_portfolio_json(run_id)
            # v0.10-P1-4 — audio-photo sync POST handler dispatch is
            # in the POST table; here we only register the GET so
            # clients can ping the endpoint for its enabled-state.
            if rest == "audio_sync":
                return self._serve_audio_sync_status()
        return False

    def _dispatch_api_v1_post(self, path: str) -> bool:
        sub = path[len("/api/v1"):]
        if sub == "/scan_local":
            self._handle_scan_local(); return True
        if sub == "/analyze":
            self._handle_analyze_post(); return True
        # V28 — user management
        if sub == "/users":
            return self._handle_users_create()
        # INFRA-2 — explicit "configure sync now" trigger
        if sub == "/sync_configure":
            return self._handle_sync_configure()
        # INFRA-3 — multi-shooter event merge
        if sub == "/events/merge":
            return self._handle_event_merge()
        # P2.2 — tether session start / stop
        if sub == "/tether/start":
            return self._handle_tether_start()
        if sub.startswith("/tether/") and sub.endswith("/stop"):
            sid = sub[len("/tether/"):-len("/stop")]
            return self._handle_tether_stop(sid)
        # V28.2 — switch active user via cookie (no restart needed)
        if sub == "/users/active":
            return self._handle_users_active_post()
        if sub.startswith("/users/") and sub.endswith("/team_subscribe"):
            uid = sub[len("/users/"):-len("/team_subscribe")]
            return self._handle_team_subscribe(uid)
        if sub.startswith("/runs/"):
            tail = sub[len("/runs/"):]
            if "/" in tail:
                run_id, rest = tail.split("/", 1)
                if rest == "face_clusters/label":
                    self._handle_face_label_post(run_id); return True
                if rest == "locations/label":
                    self._handle_location_label_post(run_id); return True
                if rest == "export":
                    self._handle_export(run_id); return True
                if rest == "auto_caption":
                    self._handle_auto_caption(run_id); return True
                # P-UX-15 — pull edits from Lr/C1 XMP sidecars back
                # into PixCull annotations (round-trip).
                if rest == "lr_sync":
                    return self._handle_lr_sync(run_id)
                # P2.1 V0.2 — annotation alias for the iOS swipe-to-
                # label flow. Forwards to the existing
                # ``_handle_save_annotation`` which takes "run/filename".
                if rest.startswith("annotate/"):
                    fn = rest[len("annotate/"):]
                    self._handle_save_annotation(f"{run_id}/{fn}")
                    return True
        return False

    def _serve_api_v1_index(self) -> bool:
        """V25 discovery endpoint. Returns the route map + version info
        so mobile / third-party clients can introspect without scraping
        the source.
        """
        body = _safe_dumps({
            "schema":   "pixcull.api.v1.index",
            "version":  "v1",
            "server":   "PixCull",
            "auth": {
                "model":            "localhost-free + optional API key",
                "api_key_header":   "X-PixCull-API-Key",
                "api_key_env":      "PIXCULL_API_KEY",
                "is_localhost":     self.client_address[0] in
                                     ("127.0.0.1", "::1", "localhost"),
            },
            "cors": {
                "origins_env": "PIXCULL_API_CORS_ORIGINS",
                "current":     (os.environ.get("PIXCULL_API_CORS_ORIGINS")
                                or "*"),
            },
            "endpoints": [
                {"method": "GET",  "path": "/api/v1/",
                 "doc":    "this discovery index"},
                {"method": "GET",  "path": "/api/v1/runs",
                 "doc":    "list runs with summary"},
                {"method": "GET",  "path": "/api/v1/runs/<run_id>",
                 "doc":    "summary of one run + asset URLs"},
                {"method": "GET",  "path": "/api/v1/runs/<run_id>/rows",
                 "params": {"limit": "200 (default)", "offset": "0 (default)"},
                 "doc":    "paginated slim row list for mobile photo grid"},
                {"method": "GET",  "path": "/api/v1/runs/<run_id>/row/<filename>",
                 "doc":    "single rich row (V20 advice + rubric stars + "
                          "GPS + face clusters) for the iOS lightbox"},
                # P-AI-2 — CLIP-backed text→image semantic search
                {"method": "GET",  "path": "/api/v1/runs/<run_id>/semantic_search",
                 "params": {"q":  "free-text query (e.g. 'flying bird' / 'long-exposure waterfall' / 飞鸟展翅)",
                            "k":  "10 (default), max 50"},
                 "doc":    "rank photos by CLIP cosine similarity to "
                          "the query. Lazy-builds embeddings.npz "
                          "on first hit (slow first call, fast after)."},
                # P-UX-5 — composite-similarity nearest-neighbor
                {"method": "GET",  "path": "/api/v1/runs/<run_id>/similar/<filename>",
                 "params": {"k": "5 (default), max 20"},
                 "doc":    "top-k visually-similar photos for the "
                          "lightbox 'similar' row. Composite score "
                          "over burst+scene+face+GPS+rubric."},
                # INFRA-3 — multi-shooter event merge (MVP)
                {"method": "POST", "path": "/api/v1/events/merge",
                 "body":   "{source_runs: [run_id, ...], name?: str}",
                 "doc":    "concatenate ≥ 2 source runs into a merged "
                          "event run; reuses /results UI"},
                # P-UX-15 — read Lr/C1 XMP edits back into annotations
                {"method": "POST", "path": "/api/v1/runs/<run_id>/lr_sync",
                 "doc":    "scan each photo's XMP sidecar; treat "
                          "xmp:Rating as authoritative human verdict "
                          "(5/4→keep, 3→maybe, 2/1→cull, 0→skip); "
                          "append per-row annotations for changes"},
                {"method": "POST", "path": "/api/v1/runs/<run_id>/annotate/<filename>",
                 "body":   "{overall_label: keep|maybe|cull, "
                          "axes?: {}, overall_rationale?: str, "
                          "cull_reason?: <token from /api/v1/taxonomy>}",
                 "doc":    "save a human annotation for a single photo "
                          "(append-only; latest wins on read)"},
                # P-UX-4 — taxonomy advertisement so iOS / future clients
                # can populate the cull-reason picker without hardcoding
                # the token list. ASCII tokens are stable; localized
                # labels live in the UI layer.
                {"method": "GET",  "path": "/api/v1/taxonomy",
                 "doc":    "stable enums: cull_reasons (+future labels)"},
                # P-UX-9 — usage stats over the user's annotations history
                {"method": "GET",  "path": "/api/v1/cull_reasons/stats",
                 "doc":    "accumulated cull-reason counts across all runs"},
                # P-UX-12 — per-user taste profile
                {"method": "GET",  "path": "/api/v1/users/preferences",
                 "doc":    "scene + axis + cull-reason profile derived "
                          "from your annotation history (admin page card)"},
                {"method": "GET",  "path": "/api/v1/runs/<run_id>/decisions",
                 "doc":    "{filename: keep|maybe|cull} + src_paths"},
                {"method": "GET",  "path": "/api/v1/runs/<run_id>/face_clusters",
                 "doc":    "face cluster summary + labels"},
                {"method": "POST", "path": "/api/v1/runs/<run_id>/face_clusters/label",
                 "body":   "{cluster_id: int, label: str}",
                 "doc":    "rename a face cluster"},
                {"method": "GET",  "path": "/api/v1/runs/<run_id>/locations",
                 "doc":    "GPS location cluster summary"},
                {"method": "POST", "path": "/api/v1/runs/<run_id>/locations/label",
                 "body":   "{cluster_id: int, label: str}",
                 "doc":    "rename a GPS location cluster (V23.1)"},
                {"method": "GET",  "path": "/api/v1/runs/<run_id>/status",
                 "doc":    "pipeline progress JSON"},
                {"method": "GET",  "path": "/api/v1/runs/<run_id>/scores.csv",
                 "doc":    "scores.csv download"},
                {"method": "GET",  "path": "/api/v1/runs/<run_id>/gallery.zip",
                 "params": {"include": "keep | keep,maybe | keep,maybe,cull"},
                 "doc":    "standalone HTML gallery zip"},
                {"method": "GET",  "path": "/api/v1/runs/<run_id>/xmp.zip",
                 "doc":    "XMP sidecar zip (run /export first)"},
                {"method": "POST", "path": "/api/v1/runs/<run_id>/export",
                 "doc":    "render XMP sidecars to disk"},
                {"method": "POST", "path": "/api/v1/runs/<run_id>/auto_caption",
                 "body":   "{polish?: bool, decisions?: [keep,...]}",
                 "doc":    "P2.5 — generate IPTC captions per photo. "
                          "compose (free) or polish (DeepSeek, "
                          "INFRA-4-budgeted). Persisted to "
                          "auto_captions.json; next /export uses them."},
                {"method": "POST", "path": "/api/v1/scan_local",
                 "body":   "{folder: abs_path, vertical?: str}",
                 "doc":    "kick off a scan of a local folder"},
                {"method": "POST", "path": "/api/v1/analyze",
                 "doc":    "upload + analyze a multipart batch"},
                {"method": "GET",  "path": "/api/v1/verticals",
                 "doc":    "vertical registry + sample bank progress"},
                {"method": "GET",  "path": "/api/v1/storage_info",
                 "doc":    "disk usage + run count summary"},
                {"method": "GET",  "path": "/api/v1/rubric_meta",
                 "doc":    "rubric axes definition (for annotation UI)"},
                # INFRA-4 — LLM cost ledger
                {"method": "GET",  "path": "/api/v1/llm_budget",
                 "doc":    "daily LLM spend (yuan) + cap from "
                          "PIXCULL_LLM_BUDGET_YUAN env (default 10)"},
                # INFRA-2 — multi-machine sync
                {"method": "GET",  "path": "/api/v1/sync_status",
                 "doc":    "sync target + per-subtree state for "
                          "the active user"},
                {"method": "POST", "path": "/api/v1/sync_configure",
                 "body":   "{user_id?: str, team_id?: str}",
                 "doc":    "wire sync subtrees (symlinks) for a user "
                          "or team to the PIXCULL_SYNC_DIR target"},
                # P2.2 — Lr/C1 tether live-cull
                {"method": "GET",  "path": "/api/v1/tether",
                 "doc":    "list active tether sessions"},
                {"method": "POST", "path": "/api/v1/tether/start",
                 "body":   "{folder: abs_path, vertical?: str}",
                 "doc":    "start a watcher that auto-analyzes new "
                          "files in the tether folder (Lr/C1 tether dest)"},
                {"method": "POST", "path": "/api/v1/tether/<session>/stop",
                 "doc":    "stop a tether session"},
                # P2.4 — active-learning queue
                {"method": "GET",  "path": "/api/v1/runs/<run_id>/next_to_label",
                 "params": {"n": "1 (default) | N for batch queue"},
                 "doc":    "active-learning queue: highest-info-gain "
                          "photos to label next, ranked by rescorer "
                          "disagreement + uncertainty"},
                # V28 multi-user
                {"method": "GET",  "path": "/api/v1/users",
                 "doc":    "list user profiles + active user"},
                {"method": "GET",  "path": "/api/v1/users/active",
                 "doc":    "just the active user id"},
                {"method": "POST", "path": "/api/v1/users",
                 "body":   "{user_id: str}",
                 "doc":    "create user profile (idempotent)"},
                {"method": "POST", "path": "/api/v1/users/<uid>/team_subscribe",
                 "body":   "{vertical: str, team_id: str|''}",
                 "doc":    "redirect a user's vertical bank to a team's; "
                          "empty team_id unsubscribes"},
            ],
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "public, max-age=60")
        self.end_headers()
        self.wfile.write(body)
        return True

    def _serve_runs_list_json_api(self) -> bool:
        """V25 — clean JSON run list (no HTML). The pre-existing
        ``/runs`` endpoint already returns JSON (via _enumerate_runs);
        this is the versioned alias with the standard envelope shape.
        """
        runs = _enumerate_runs()
        body = _safe_dumps({
            "schema":  "pixcull.api.v1.runs.list",
            "n_runs":  len(runs),
            "runs":    runs,
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)
        return True

    def _serve_api_v1_rows(self, run_id: str, qs: str) -> bool:
        """P2.1 V0.2 — paginated rows for the iOS photo grid.

        URL: GET /api/v1/runs/<run_id>/rows[?limit=N&offset=K]
        Default ``limit=200``, ``offset=0``. Hard-capped at 1000 so
        a typo can't ship a 50MB blob.

        Slim row shape — strip the heavy ``advice`` blob (~2 KB/row),
        ``rubric_stars``, ``scene_probs``, etc. The iOS V0.2 grid + swipe
        annotator only needs filename, decision, score_final, scene,
        cluster_id, is_burst_peak. When the user opens the lightbox
        we re-fetch a single row via /results JSON (already implemented).
        """
        result = _build_results(run_id)
        if result is None:
            run = _get_run(run_id) or _reload_run_from_disk(run_id)
            if run is None:
                self.send_error(404, "no such run"); return True
            self.send_error(425, "results not ready"); return True
        rows, _summary = result

        from urllib.parse import parse_qs
        qparams = parse_qs(qs) if qs else {}
        try:
            limit = int(qparams.get("limit", ["200"])[0])
            offset = int(qparams.get("offset", ["0"])[0])
        except (ValueError, TypeError):
            limit, offset = 200, 0
        limit = max(1, min(1000, limit))
        offset = max(0, offset)

        # Slim each row to the iOS-grid essentials. ``filename`` is
        # the primary key the grid renders; the rest is decoration.
        page = []
        for r in rows[offset:offset + limit]:
            page.append({
                "filename":      r.get("filename"),
                "decision":      r.get("decision"),
                "score_final":   r.get("score_final"),
                "scene":         r.get("scene"),
                "cluster_id":    r.get("cluster_id"),
                "is_burst_peak": bool(r.get("is_burst_peak")),
                "rubric_human_labeled": bool(r.get("rubric_human_labeled")),
                # P-UX-4 — empty unless the row carries an annotated
                # reject reason. iOS V0.4+ can show this as a small
                # chip on the swipe card without re-fetching the row.
                "cull_reason":   str(r.get("cull_reason") or ""),
            })

        body = _safe_dumps({
            "schema":  "pixcull.api.v1.rows.v1",
            "run_id":  run_id,
            "n_total": len(rows),
            "offset":  offset,
            "limit":   limit,
            "rows":    page,
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)
        return True

    def _serve_api_v1_semantic_search(self, run_id: str, qs: str) -> bool:
        """P-AI-2 — CLIP text→image semantic search.

        URL: GET /api/v1/runs/<run_id>/semantic_search?q=<text>&k=10

        On first call for a given run, walks every photo, CLIP-encodes
        it, and persists ``output/embeddings.npz`` (~512 floats/photo
        ≈ 2 KB/photo). Subsequent calls reuse the cache and complete
        in single-digit ms.

        Returns ranked list of (filename, similarity) plus a build_ms
        + cached flags so the UI can show "first search builds the
        cache — ~X seconds" feedback.
        """
        from urllib.parse import parse_qs

        result = _build_results(run_id)
        if result is None:
            self.send_error(404, "no such run"); return True
        rows, _ = result

        qparams = parse_qs(qs) if qs else {}
        query = (qparams.get("q", [""])[0] or "").strip()
        if not query:
            self._reject_upload(400, "q (query) is required"); return True
        try:
            k = int(qparams.get("k", ["10"])[0])
        except (ValueError, TypeError):
            k = 10
        k = max(1, min(50, k))

        run = _get_run(run_id) or _reload_run_from_disk(run_id)
        if run is None:
            self.send_error(404, "no such run"); return True
        cache_path = Path(run["output_dir"]) / "embeddings.npz"

        from pixcull.scoring.semantic_search import (
            load_embeddings_cache, build_embeddings_cache, search as _semsearch,
        )
        cache = load_embeddings_cache(cache_path)
        was_cached = cache is not None
        build_ms = 0.0
        if cache is None:
            # Resolve absolute image paths from each row's manifest /
            # src_path. We only encode photos whose path is reachable;
            # missing files just get skipped.
            paths: list[Path] = []
            for r in rows:
                fn = r.get("filename")
                src = r.get("src_path")
                if src and Path(src).is_file():
                    paths.append(Path(src))
                else:
                    p = _resolve_image_source(run, fn) if fn else None
                    if p and p.is_file():
                        paths.append(p)
            if not paths:
                self._reject_upload(425,
                    "no reachable photos to build embeddings cache"); return True
            t0 = time.time()
            cache = build_embeddings_cache(paths, cache_path)
            build_ms = (time.time() - t0) * 1000.0

        try:
            ranked = _semsearch(query, cache=cache, k=k)
        except Exception as e:
            self._reject_upload(500, f"search failed: {e}"); return True

        # Enrich with each match's decision + score_final so the UI
        # can show context next to the result rows.
        by_fn = {r.get("filename"): r for r in rows}
        results = []
        for fn, sim in ranked:
            r = by_fn.get(fn) or {}
            results.append({
                "filename":     fn,
                "similarity":   round(sim, 4),
                "decision":     r.get("decision"),
                "score_final":  r.get("score_final"),
                "scene":        r.get("scene"),
            })

        body = _safe_dumps({
            "schema":      "pixcull.api.v1.semantic_search.v1",
            "run_id":      run_id,
            "query":       query,
            "k":           k,
            "cached":      was_cached,
            "build_ms":    round(build_ms, 1),
            "n_photos":    int(cache["vectors"].shape[0]),
            "results":     results,
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)
        return True

    def _serve_api_v1_near_dups(self, run_id: str, qs: str) -> bool:
        """v2.6-P1 — CLIP near-duplicate groups for the grid fold.

        URL: GET /api/v1/runs/<run_id>/near_dups?threshold=0.92

        The deferred half of v2.4-P1-1: burst collapse folds
        time-bucketed clusters; this folds *visual* near-dups regardless
        of capture time (the re-shot composition minutes later).  Reuses
        the semantic-search ``embeddings.npz`` cache — lazily built on
        first call, same contract as ``/semantic_search`` — then groups
        connected components of cosine ≥ threshold and picks the
        highest-``score_final`` member as each group's hero.
        """
        from urllib.parse import parse_qs

        result = _build_results(run_id)
        if result is None:
            self.send_error(404, "no such run"); return True
        rows, _ = result
        qp = parse_qs(qs) if qs else {}
        try:
            thr = float(qp.get("threshold", ["0.92"])[0])
        except (TypeError, ValueError):
            thr = 0.92
        thr = max(0.5, min(0.999, thr))

        run = _get_run(run_id) or _reload_run_from_disk(run_id)
        if run is None:
            self.send_error(404, "no such run"); return True
        cache_path = Path(run["output_dir"]) / "embeddings.npz"
        from pixcull.scoring.near_dup import group_near_dups, pick_heroes
        from pixcull.scoring.semantic_search import (
            build_embeddings_cache, load_embeddings_cache)
        cache = load_embeddings_cache(cache_path)
        was_cached = cache is not None
        if cache is None:
            paths: list[Path] = []
            for r in rows:
                fn = r.get("filename")
                src = r.get("src_path")
                if src and Path(src).is_file():
                    paths.append(Path(src))
                else:
                    p = _resolve_image_source(run, fn) if fn else None
                    if p and p.is_file():
                        paths.append(p)
            if not paths:
                self._reject_upload(425,
                    "no reachable photos to build embeddings cache"); return True
            cache = build_embeddings_cache(paths, cache_path)

        # v2.35 — grouping is O(N**2) and this is a per-request handler
        # with a user-adjustable threshold, so every nudge of the slider
        # re-paid 1.5s at 20k photos and 7.7s at 50k. The grouping is a
        # pure function of (vectors, threshold), so cache it on the
        # vector file's mtime plus the threshold; pick_heroes below still
        # runs fresh because it depends on the (separately cached) rows.
        groups = _cached_near_dup_groups(cache_path, cache, thr)
        scores = {r.get("filename"): r.get("score_final") for r in rows
                  if isinstance(r.get("score_final"), (int, float))}
        body = _safe_dumps({
            "schema":    "pixcull.api.v1.near_dups.v1",
            "run_id":    run_id,
            "threshold": thr,
            "cached":    was_cached,
            "n_photos":  int(cache["vectors"].shape[0]),
            "groups":    pick_heroes(groups, scores),
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)
        return True

    def _serve_api_v1_scenes(self, run_id: str, qs: str) -> bool:
        """v2.9-P1-1 — chronological Scenes for the narrative view.

        URL: GET /api/v1/runs/<run_id>/scenes[?k=3&min_gap=120]

        Segments the run into capture-time scenes (``scoring/scenes.py``) and
        returns each with its frame list, time range, and keep count so the
        Scenes view can render time-grouped sections instead of a flat grid.
        """
        from urllib.parse import parse_qs
        from datetime import datetime as _dt
        result = _build_results(run_id)
        if result is None:
            self.send_error(404, "no such run"); return True
        rows, _ = result
        qp = parse_qs(qs) if qs else {}
        try:
            k = float(qp.get("k", ["3.0"])[0])
        except (TypeError, ValueError):
            k = 3.0
        try:
            min_gap = float(qp.get("min_gap", ["120"])[0])
        except (TypeError, ValueError):
            min_gap = 120.0
        from pixcull.scoring.scenes import segment_scenes
        items = [{"filename": r.get("filename"), "timestamp": r.get("datetime")}
                 for r in rows if r.get("filename")]
        scenes = segment_scenes(items, k=max(0.0, k), min_gap_s=max(1.0, min_gap))
        keep_by_fn = {
            r.get("filename"): (str(r.get("decision") or "").lower() == "keep")
            for r in rows
        }

        def _iso(ts):
            return _dt.fromtimestamp(ts).isoformat(timespec="seconds") if ts else None

        out = [{
            "index":     s.index,
            "n":         s.n,
            "n_keep":    sum(1 for fn in s.filenames if keep_by_fn.get(fn)),
            "start":     _iso(s.start_ts),
            "end":       _iso(s.end_ts),
            "filenames": s.filenames,
        } for s in scenes]
        body = _safe_dumps({
            "schema":    "pixcull.api.v1.scenes.v1",
            "run_id":    run_id,
            "n_scenes":  len(out),
            "k":         k,
            "min_gap_s": min_gap,
            "scenes":    out,
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)
        return True

    def _serve_api_v1_faces(self, run_id: str, filename: str) -> bool:
        """v2.9-P0-1 — detected faces for the lightbox close-ups rail.

        URL: GET /api/v1/runs/<run_id>/faces/<filename>

        Lazily runs MediaPipe face detection on the full image (cached by
        path+mtime) and returns each meaningful face as a normalized bbox plus
        a crop URL.  ``faces: []`` when none / no detector — the rail then
        simply doesn't render (content-first; no empty chrome).
        """
        filename = unquote(filename)
        run = _get_run(run_id) or _reload_run_from_disk(run_id)
        if run is None:
            self.send_error(404, "no such run"); return True
        src = _resolve_image_source(run, Path(filename).name)
        if src is None or not src.exists():
            self.send_error(404, f"not found: {filename}"); return True
        boxes = _detect_faces_for_src(src)
        fn = Path(filename).name
        faces = [{
            "i": i,
            "bbox": [round(b[0], 5), round(b[1], 5), round(b[2], 5), round(b[3], 5)],
            "conf": round(float(b[4]), 3),
            "crop": f"/face_crop/{quote(run_id)}/{quote(fn)}/{i}?w=256",
        } for i, b in enumerate(boxes)]
        body = _safe_dumps({
            "schema":   "pixcull.api.v1.faces.v1",
            "run_id":   run_id,
            "filename": fn,
            "n_faces":  len(faces),
            "faces":    faces,
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)
        return True

    def _serve_face_crop(self, rel: str) -> None:
        """v2.9-P0-1 — square close-up crop of one detected face.

        Format: /face_crop/<run_id>/<filename>/<index>[?w=N].  Crops a square
        around the i-th face bbox (60% context margin), resizes to ``w`` (96–512,
        default 256), caches on disk under ``<output>/face_crops/``.
        """
        from urllib.parse import parse_qs, urlsplit
        rel = unquote(rel)
        sp = urlsplit("/" + rel)
        parts = sp.path.lstrip("/").split("/")
        if len(parts) < 3:
            self.send_error(400, "expected run_id/filename/index"); return
        run_id, idx_s = parts[0], parts[-1]
        fn = "/".join(parts[1:-1])
        try:
            idx = int(idx_s)
        except ValueError:
            self.send_error(400, "bad face index"); return
        qs = parse_qs(sp.query) if sp.query else {}
        try:
            req_w = int(qs.get("w", ["256"])[0])
        except (TypeError, ValueError):
            req_w = 256
        req_w = max(96, min(512, req_w))
        run = _get_run(run_id) or _reload_run_from_disk(run_id)
        if run is None:
            self.send_error(404, "no such run"); return
        src = _resolve_image_source(run, Path(fn).name)
        if src is None or not src.exists():
            self.send_error(404, f"not found: {fn}"); return
        boxes = _detect_faces_for_src(src)
        if idx < 0 or idx >= len(boxes):
            self.send_error(404, "no such face"); return
        cache_dir = Path(run["output_dir"]) / "face_crops"
        cache_dir.mkdir(parents=True, exist_ok=True)
        cache_path = cache_dir / f"{src.name}.f{idx}.{req_w}.v1.jpg"
        if not cache_path.exists():
            from pixcull.io.loader import load_image
            img = load_image(src, max_side=1600)
            if img is None:
                self.send_error(500, "image decode failed"); return
            W, H = img.size
            nx1, ny1, nx2, ny2 = boxes[idx][:4]
            x1, y1, x2, y2 = nx1 * W, ny1 * H, nx2 * W, ny2 * H
            cx, cy = (x1 + x2) / 2, (y1 + y2) / 2
            half = max(x2 - x1, y2 - y1) * 0.8   # 60% margin → some context
            left, top = max(0, int(cx - half)), max(0, int(cy - half))
            right, bot = min(W, int(cx + half)), min(H, int(cy + half))
            if right - left < 16 or bot - top < 16:
                self.send_error(404, "face too small"); return
            crop = img.crop((left, top, right, bot)).convert("RGB")
            if crop.width != req_w:
                ratio = req_w / crop.width
                crop = crop.resize((req_w, max(1, int(crop.height * ratio))))
            crop.save(cache_path, "JPEG", quality=82)
        data = cache_path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", "image/jpeg")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "public, max-age=86400")
        self.end_headers()
        self.wfile.write(data)

    def _serve_api_v1_similar(self, run_id: str, filename: str, qs: str) -> bool:
        """P-UX-5 — "show me photos like this one" for the lightbox.

        We don't keep raw CLIP embeddings on disk (would be GB-scale
        across runs), but the rubric / scene / cluster / face / GPS
        columns already carry a rich perceptual signature per photo.
        This composes them into a single 0..1 similarity score with
        named reasons so the lightbox can show "why" each match
        surfaced ("same burst", "same person + same scene", etc).

        URL: GET /api/v1/runs/<run_id>/similar/<filename>?k=5

        Response:
          {
            "schema": "pixcull.api.v1.similar.v1",
            "target": "<filename>",
            "k": 5,
            "similar": [
              {"filename": ..., "similarity": 0.87,
               "reasons": ["burst", "same_scene"],
               "decision": "keep", "score_final": 0.72},
              ...
            ]
          }
        """
        result = _build_results(run_id)
        if result is None:
            run = _get_run(run_id) or _reload_run_from_disk(run_id)
            if run is None:
                self.send_error(404, "no such run"); return True
            self.send_error(425, "results not ready"); return True
        rows, _ = result
        fn = unquote(filename)
        target = next((r for r in rows if r.get("filename") == fn), None)
        if target is None:
            self.send_error(404, f"no such filename: {fn}"); return True

        from urllib.parse import parse_qs
        qparams = parse_qs(qs) if qs else {}
        try:
            k = int(qparams.get("k", ["5"])[0])
        except (ValueError, TypeError):
            k = 5
        k = max(1, min(20, k))

        # Build the perceptual signature for the target then score every
        # OTHER row by composite similarity. Weights chosen so a burst
        # neighbor dominates (it's almost certainly a near-dupe), then
        # face+scene match, then rubric proximity (the long tail).
        t_cluster = target.get("cluster_id")
        t_scene   = (target.get("scene") or "").strip()
        t_faces   = set(target.get("face_clusters") or [])
        t_gps_cid = target.get("gps_cluster_id")
        t_rubric  = target.get("rubric_stars") or {}
        t_aest    = target.get("score_aesthetic")

        def _rubric_proximity(other_rubric: dict) -> float:
            """L1 distance over present axes, mapped to 0..1 similarity."""
            if not other_rubric or not t_rubric:
                return 0.0
            axes = [a for a in t_rubric.keys()
                    if t_rubric.get(a) is not None
                    and other_rubric.get(a) is not None]
            if not axes:
                return 0.0
            dist = sum(
                abs(float(t_rubric[a]) - float(other_rubric[a]))
                for a in axes
            ) / (len(axes) * 4.0)  # max single-axis diff is 5-1 = 4
            return max(0.0, 1.0 - dist)

        candidates: list[tuple[float, list[str], dict]] = []
        for r in rows:
            if r.get("filename") == fn:
                continue
            sim = 0.0
            reasons: list[str] = []
            # Burst neighbor — strongest signal. cluster_id is the
            # already-validated photo-level dedup grouping.
            if (t_cluster is not None
                    and r.get("cluster_id") == t_cluster):
                sim += 0.55
                reasons.append("burst")
            # Same scene token — caps at 0.25 alone, stacks with face/GPS
            o_scene = (r.get("scene") or "").strip()
            if t_scene and o_scene == t_scene:
                sim += 0.18
                reasons.append("same_scene")
            # Face overlap (Jaccard) — same subject across non-burst frames
            o_faces = set(r.get("face_clusters") or [])
            if t_faces and o_faces:
                jacc = len(t_faces & o_faces) / max(1, len(t_faces | o_faces))
                if jacc > 0:
                    sim += 0.22 * jacc
                    reasons.append("same_person")
            # GPS location cluster — same physical spot at this batch
            if (t_gps_cid is not None
                    and r.get("gps_cluster_id") == t_gps_cid):
                sim += 0.10
                reasons.append("same_location")
            # Rubric proximity — the perceptual long tail (composition,
            # light, moment, etc. similar feel).
            r_prox = _rubric_proximity(r.get("rubric_stars") or {})
            if r_prox > 0.5:
                sim += 0.10 * r_prox
                if r_prox > 0.75:
                    reasons.append("similar_rubric")
            # Aesthetic-score proximity — finer-grained tie-breaker.
            o_aest = r.get("score_aesthetic")
            if t_aest is not None and o_aest is not None:
                delta = abs(float(t_aest) - float(o_aest))
                sim += 0.05 * max(0.0, 1.0 - delta)
            if sim > 0.10:  # noise floor — don't surface random matches
                candidates.append((sim, reasons, r))

        candidates.sort(key=lambda c: c[0], reverse=True)
        top = candidates[:k]
        similar = [
            {
                "filename":    r.get("filename"),
                "similarity":  round(sim, 3),
                "reasons":     reasons,
                "decision":    r.get("decision"),
                "score_final": r.get("score_final"),
            }
            for (sim, reasons, r) in top
        ]
        body = _safe_dumps({
            "schema":  "pixcull.api.v1.similar.v1",
            "run_id":  run_id,
            "target":  fn,
            "k":       k,
            "similar": similar,
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)
        return True

    def _serve_api_v1_locale(self) -> bool:
        """v0.8-P0-1 — return the requested locale's {key: string} map.

        The client (results.html JS shim) calls this when the user
        toggles language; the response is then merged into the
        in-memory I18N map and every ``[data-i18n]`` element is
        re-painted. Cached 5 minutes — locales don't change often.

        Query string: ``?lang=en_US`` (or ``zh-CN`` etc; the i18n
        module normalises). Falls back to zh_CN if unknown.
        """
        from urllib.parse import parse_qs, urlparse as _up
        from pixcull.i18n import (
            DEFAULT_LOCALE,
            SUPPORTED_LOCALES,
            load_locale,
        )

        qs = parse_qs(_up(self.path).query)
        lang_arg = (qs.get("lang") or [DEFAULT_LOCALE])[0]
        strings = load_locale(lang_arg)
        body = _safe_dumps({
            "schema":     "pixcull.api.v1.locale/v1",
            "lang":       lang_arg,
            "supported":  list(SUPPORTED_LOCALES),
            "strings":    strings,
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "public, max-age=300")
        self.end_headers()
        self.wfile.write(body)
        return True

    def _serve_api_v1_taxonomy(self) -> bool:
        """P-UX-4 — stable enum advertisement.

        Returns the cull-reason taxonomy (snake_case tokens + zh-CN
        labels) so clients can render a picker without hardcoding
        the list. Adding a token to ``_CULL_REASONS`` and a label
        below is the full change needed for both the web UI and any
        future iOS/CLI client to pick it up.
        """
        labels_zh = {
            "focus_miss":   "焦点不准",
            "eyes_closed":  "闭眼/表情",
            "motion_blur":  "模糊抖动",
            "framing":      "构图差",
            "duplicate":    "与更佳重复",
            "exposure":     "曝光问题",
            "other":        "其他",
        }
        body = _safe_dumps({
            "schema":  "pixcull.api.v1.taxonomy.v1",
            "cull_reasons": [
                {"token": t, "label_zh": labels_zh.get(t, t)}
                for t in _CULL_REASONS
            ],
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "max-age=300")
        self.end_headers()
        self.wfile.write(body)
        return True

    def _handle_event_merge(self) -> bool:
        """INFRA-3 — combine two or more runs into a merged event.

        POST /api/v1/events/merge
          body: {source_runs: [run_id, ...], name?: str}
          → {ok, merged_run_id, source_runs, name}

        The merged run lives in /tmp/pixcull_demo/event_XXXX/ and
        reuses the existing /results/<run> infrastructure (it just
        IS a normal run, with an event_meta.json sidecar).
        """
        clen = int(self.headers.get("Content-Length", "0") or "0")
        if clen <= 0 or clen > 65536:
            self._reject_upload(400, "expected JSON body"); return True
        try:
            params = json.loads(self.rfile.read(clen).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            self._reject_upload(400, f"JSON parse failed: {exc}"); return True
        source_runs = params.get("source_runs") or []
        name = str(params.get("name") or "") or None
        if (not isinstance(source_runs, list) or len(source_runs) < 2 or
                not all(isinstance(s, str) and s for s in source_runs)):
            self._reject_upload(400, "source_runs must be a list of ≥ 2 run IDs")
            return True
        try:
            from pixcull.events import merge_runs
            merged_id = merge_runs(source_runs, name=name, demo_root=_DEMO_ROOT)
        except FileNotFoundError as exc:
            self._reject_upload(404, str(exc)); return True
        except (ValueError, OSError) as exc:
            self._reject_upload(400, str(exc)); return True

        body = _safe_dumps({
            "ok":             True,
            "merged_run_id":  merged_id,
            "source_runs":    source_runs,
            "name":           name,
            "url":            f"/results/{merged_id}",
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)
        return True

    def _handle_lr_sync(self, run_id: str) -> bool:
        """P-UX-15 — Lr / Capture One round-trip.

        Walks every photo in the run, looks for its XMP sidecar next
        to the source image, and treats the sidecar's xmp:Rating as
        an authoritative human verdict (Lr / C1 are the source of
        truth once the photographer edits there).

        Mapping (mirrors decision_to_xmp inverted):
          5★, 4★ → keep
          3★      → maybe
          2★, 1★ → cull
          0★      → no signal, skip

        Writes a human annotation per row whose sidecar rating
        differs from our current decision. Append-only, latest-wins,
        same shape as a manual /annotation POST.

        POST body: empty / ignored.
        Response: {ok, run_id, sidecars_seen, applied, skipped, unchanged}
        """
        # P-PRO-2 — read_sidecar_any tries .xmp first (Lr + C1 sync-xmp +
        # Bridge) then falls back to .cos (Capture One session-only).
        from pixcull.io.xmp import read_sidecar_any as read_xmp_sidecar  # type: ignore

        run = _get_run(run_id) or _reload_run_from_disk(run_id)
        if run is None:
            self._reject_upload(404, f"no such run: {run_id}")
            return True
        result = _build_results(run_id)
        if result is None:
            self._reject_upload(425, "results not ready"); return True
        rows, _summary = result

        rating_to_decision = {
            5: "keep", 4: "keep",
            3: "maybe",
            2: "cull", 1: "cull",
        }
        applied: list[dict] = []
        unchanged: list[str] = []
        skipped: list[str] = []
        sidecars_seen = 0

        ann_path = Path(run["output_dir"]) / "annotations.jsonl"
        ann_path.parent.mkdir(parents=True, exist_ok=True)
        ts = time.time()

        for r in rows:
            src = r.get("src_path") or ""
            if not src:
                # Upload-mode runs without a recoverable source path
                # can't have an Lr/C1 sidecar to read.
                skipped.append(r.get("filename") or "")
                continue
            try:
                xmp = read_xmp_sidecar(Path(src))
            except Exception:
                skipped.append(r.get("filename") or "")
                continue
            rating = xmp.get("rating", 0) or 0
            if rating == 0:
                skipped.append(r.get("filename") or "")
                continue
            sidecars_seen += 1
            new_decision = rating_to_decision.get(rating)
            if new_decision is None:
                skipped.append(r.get("filename") or "")
                continue
            # Skip if PixCull already agrees with Lr
            if r.get("decision") == new_decision:
                unchanged.append(r.get("filename") or "")
                continue
            label_hint = xmp.get("color_label") or ""
            sidecar_source = xmp.get("source") or "xmp"   # P-PRO-2
            tool_label = {
                "xmp":         "Lr/C1",
                "c1_session":  "Capture One",
            }.get(sidecar_source, "sidecar")
            rationale = f"{tool_label} round-trip: rating={rating}★ label={label_hint!r}"
            record = {
                "filename":          r.get("filename"),
                "axes":              {},
                "overall_label":     new_decision,
                "overall_rationale": rationale,
                "cull_reason":       "",
                "source":            "lr_round_trip",
                "lr_rating":         rating,
                "lr_color_label":    label_hint,
                "sidecar_format":    sidecar_source,        # P-PRO-2
                "timestamp":         ts,
            }
            with open(ann_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(record, ensure_ascii=False) + "\n")
            applied.append({
                "filename":        r.get("filename"),
                "from":            r.get("decision"),
                "to":              new_decision,
                "rating":          rating,
                "label":           label_hint,
                "sidecar_format":  sidecar_source,
            })

        body = _safe_dumps({
            "ok":              True,
            "run_id":          run_id,
            "sidecars_seen":   sidecars_seen,
            "applied":         len(applied),
            "applied_detail":  applied[:50],
            "unchanged":       len(unchanged),
            "skipped":         len(skipped),
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)
        return True

    def _serve_api_v1_user_profile(self) -> bool:
        """P-AI-1 — derived personalization profile.

        Same source data as /users/preferences but distilled to the
        runtime-relevant shape: keep_threshold_shift, axis priorities,
        is_active. Reuses _serve_api_v1_user_preferences's aggregation
        logic by calling profile_from_preferences() on the same
        in-memory dict.

        GET /api/v1/users/profile  → personalized.PersonalProfile json
        """
        from pixcull.scoring.personalized import (
            MIN_ANNS_FOR_PERSONALIZATION, profile_from_preferences)

        prefs = self._aggregate_user_preferences()
        profile = profile_from_preferences(prefs)
        payload = {
            "schema":  "pixcull.api.v1.user_profile.v1",
            "user_id": profile.user_id,
            "n_annotations":      profile.n_annotations,
            # v2.5 — activation threshold, so the UI can render the
            # cold-start progress ("距按你调校还差 N 张") instead of the
            # personalisation moat staying invisible until 50 corrections.
            "min_annotations":    MIN_ANNS_FOR_PERSONALIZATION,
            "is_active":          profile.is_active(),
            "keep_rate":          profile.keep_rate,
            "cull_rate":          profile.cull_rate,
            "keep_threshold_shift": profile.keep_threshold_shift,
            "axis_keep_means":    profile.axis_keep_means,
            "axis_cull_means":    profile.axis_cull_means,
            "most_cared_axis":    profile.most_cared_axis,
        }
        body = _safe_dumps(payload).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "max-age=30")
        self.end_headers()
        self.wfile.write(body)
        return True

    def _aggregate_user_preferences(self) -> dict:
        """Shared aggregation logic used by both /users/preferences
        and /users/profile so they don't fork."""
        from collections import Counter, defaultdict
        cull_reasons: Counter[str] = Counter()
        scene_decision: dict[str, Counter[str]] = defaultdict(Counter)
        per_dec_stars: dict[str, dict[str, list[float]]] = {
            "keep": defaultdict(list),
            "maybe": defaultdict(list),
            "cull": defaultdict(list),
        }
        n_human = 0
        for run_dir in sorted(_DEMO_ROOT.glob("*/")):
            ann_path = run_dir / "output" / "annotations.jsonl"
            csv_path = run_dir / "output" / "scores.csv"
            if not ann_path.is_file():
                continue
            scene_by_fn: dict[str, str] = {}
            if csv_path.is_file():
                try:
                    import csv as _csv
                    with open(csv_path, encoding="utf-8") as f:
                        rdr = _csv.DictReader(f)
                        for row in rdr:
                            fn = (row.get("filename") or "").strip()
                            if fn:
                                scene_by_fn[fn] = (row.get("scene") or "unknown").strip()
                except OSError:
                    pass
            latest: dict[str, dict] = {}
            try:
                with open(ann_path, encoding="utf-8") as f:
                    for line in f:
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            rec = json.loads(line)
                        except json.JSONDecodeError:
                            continue
                        fn = rec.get("filename")
                        if fn:
                            latest[fn] = rec
            except OSError:
                continue
            for fn, rec in latest.items():
                label = str(rec.get("overall_label", "")).strip().lower()
                if label not in ("keep", "maybe", "cull"):
                    continue
                n_human += 1
                scene = scene_by_fn.get(fn, "unknown")
                scene_decision[scene][label] += 1
                if label == "cull":
                    reason = str(rec.get("cull_reason") or "").strip().lower()
                    if reason and reason in _CULL_REASONS:
                        cull_reasons[reason] += 1
                axes = rec.get("axes") or {}
                for axis_name, ax in axes.items():
                    if isinstance(ax, dict):
                        stars = ax.get("stars")
                        if stars is not None:
                            try:
                                per_dec_stars[label][axis_name].append(float(stars))
                            except (TypeError, ValueError):
                                continue

        def _mean(xs):
            return round(sum(xs) / len(xs), 2) if xs else None

        return {
            "total_human_annotations": n_human,
            "cull_reasons": dict(cull_reasons),
            "scene_decision_counts": {
                s: dict(c) for s, c in scene_decision.items()
            },
            "avg_rubric_when": {
                label: {ax: _mean(vals) for ax, vals in d.items()}
                for label, d in per_dec_stars.items()
            },
        }

    def _serve_api_v1_user_preferences(self) -> bool:
        """P-UX-12 — per-user taste profile.

        Walks every ``annotations.jsonl`` across all runs and the
        matching ``scores.csv`` for scene context, then summarizes:

          - cull_reasons:        which reasons you tag most often
          - scene_decision_counts: keep/maybe/cull breakdown per scene
          - avg_rubric_when_keep:  for kept photos, the mean star per axis
          - avg_rubric_when_cull:  same, for culled photos
          - total_human_annotations

        These let the admin page show "your taste profile" — which
        kinds of frames you reward vs reject, and what axes you
        seem to care about most. Feeds an honest "the rescorer
        could adapt these weights for you" pitch (P-UX-12 v0.2).
        """
        from collections import Counter, defaultdict
        cull_reasons: Counter[str] = Counter()
        scene_decision: dict[str, Counter[str]] = defaultdict(Counter)
        # Per-axis stars accumulators, split by user verdict.
        # Structure: {"keep": {axis: [stars, ...]}, "cull": {...}}
        per_dec_stars: dict[str, dict[str, list[float]]] = {
            "keep": defaultdict(list),
            "maybe": defaultdict(list),
            "cull": defaultdict(list),
        }
        n_human = 0

        # Cache scene lookups so we don't re-parse a scores.csv per
        # annotation — read once per run into a {filename: scene} dict.
        for run_dir in sorted(_DEMO_ROOT.glob("*/")):
            ann_path = run_dir / "output" / "annotations.jsonl"
            csv_path = run_dir / "output" / "scores.csv"
            if not ann_path.is_file():
                continue
            scene_by_fn: dict[str, str] = {}
            if csv_path.is_file():
                try:
                    import csv as _csv
                    with open(csv_path, encoding="utf-8") as f:
                        rdr = _csv.DictReader(f)
                        for row in rdr:
                            fn = (row.get("filename") or "").strip()
                            if fn:
                                scene_by_fn[fn] = (row.get("scene") or "unknown").strip()
                except OSError:
                    pass

            # Latest-wins reducer over annotations
            latest: dict[str, dict] = {}
            try:
                with open(ann_path, encoding="utf-8") as f:
                    for line in f:
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            rec = json.loads(line)
                        except json.JSONDecodeError:
                            continue
                        fn = rec.get("filename")
                        if fn:
                            latest[fn] = rec
            except OSError:
                continue

            for fn, rec in latest.items():
                label = str(rec.get("overall_label", "")).strip().lower()
                if label not in ("keep", "maybe", "cull"):
                    continue
                n_human += 1
                scene = scene_by_fn.get(fn, "unknown")
                scene_decision[scene][label] += 1
                if label == "cull":
                    reason = str(rec.get("cull_reason") or "").strip().lower()
                    if reason and reason in _CULL_REASONS:
                        cull_reasons[reason] += 1
                # Per-axis stars from the human's rubric
                axes = rec.get("axes") or {}
                for axis_name, ax in axes.items():
                    if not isinstance(ax, dict):
                        continue
                    stars = ax.get("stars")
                    if stars is None:
                        continue
                    try:
                        per_dec_stars[label][axis_name].append(float(stars))
                    except (TypeError, ValueError):
                        continue

        def _mean(xs: list[float]) -> float | None:
            return round(sum(xs) / len(xs), 2) if xs else None

        avg_when = {
            label: {ax: _mean(vals) for ax, vals in d.items()}
            for label, d in per_dec_stars.items()
        }

        body = _safe_dumps({
            "schema":  "pixcull.api.v1.user_preferences.v1",
            "total_human_annotations": n_human,
            "cull_reasons": dict(cull_reasons),
            "scene_decision_counts": {
                scene: dict(counts) for scene, counts in scene_decision.items()
            },
            "avg_rubric_when": avg_when,
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "max-age=30")
        self.end_headers()
        self.wfile.write(body)
        return True

    def _serve_api_v1_cull_reason_stats(self) -> bool:
        """P-UX-9 — accumulated cull-reason counts across the user's
        runs. Drives two things on the client:

          1. Reorder the cull-reason picker so the tokens you reach
             for most are listed first (less mouse travel).
          2. Power a "your cull habits" card on /admin so the user
             can see their own bias over time.

        Read-only aggregate: walks every ``annotations.jsonl`` under
        ``/tmp/pixcull_demo/<run_id>/output/``, tallies the
        ``cull_reason`` field on rows whose latest annotation was
        ``cull``. Latest-wins per (run, filename) so a row that was
        first marked cull/focus_miss then later flipped to keep
        contributes zero.
        """
        from collections import Counter
        counts: Counter[str] = Counter()
        n_scanned = 0
        n_with_reason = 0
        for run_dir in sorted(_DEMO_ROOT.glob("*/")):
            ann_path = run_dir / "output" / "annotations.jsonl"
            if not ann_path.is_file():
                continue
            # Latest-wins reducer
            latest: dict[str, dict] = {}
            try:
                with open(ann_path, encoding="utf-8") as f:
                    for line in f:
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            rec = json.loads(line)
                        except json.JSONDecodeError:
                            continue
                        fn = rec.get("filename")
                        if not fn:
                            continue
                        latest[fn] = rec
                        n_scanned += 1
            except OSError:
                continue
            for rec in latest.values():
                if str(rec.get("overall_label", "")).strip().lower() != "cull":
                    continue
                reason = str(rec.get("cull_reason") or "").strip().lower()
                if reason and reason in _CULL_REASONS:
                    counts[reason] += 1
                    n_with_reason += 1

        # Stable order: same taxonomy order as /taxonomy; clients
        # combine this with the count to sort their picker.
        body = _safe_dumps({
            "schema":   "pixcull.api.v1.cull_reason_stats.v1",
            "counts":   {t: counts.get(t, 0) for t in _CULL_REASONS},
            "total_culls_with_reason": n_with_reason,
            "total_annotations_scanned": n_scanned,
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "max-age=30")
        self.end_headers()
        self.wfile.write(body)
        return True

    def _serve_audio_sync_status(self) -> bool:
        """v0.10-P1-4 — GET /api/v1/runs/<run_id>/audio_sync

        Returns the enabled state + the supported keyword
        vocabulary so the iOS / external client can decide
        whether to even start streaming transcripts.  Safe to
        call without PIXCULL_AUDIO_SYNC enabled; the response
        clearly signals "feature is off".
        """
        try:
            from pixcull.audio_sync import (
                CEREMONY_KEYWORDS, DEFAULT_WINDOW_S, is_enabled,
            )
        except Exception as exc:
            _dbg("audio_sync/import", exc, "status")
            self.send_error(500, "audio_sync import failed")
            return True
        body = _safe_dumps({
            "schema":          "pixcull.api.v1.audio_sync.status/v1",
            "enabled":         is_enabled(),
            "default_window_s": DEFAULT_WINDOW_S,
            "vocab_size":      len(CEREMONY_KEYWORDS),
            "moments":         sorted(set(CEREMONY_KEYWORDS.values())),
            "hint":            ("set PIXCULL_AUDIO_SYNC=1 in the server"
                                 " env to enable POST"),
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)
        return True

    def _handle_audio_sync_post(self, run_id: str) -> bool:
        """v0.10-P1-4 — POST /api/v1/runs/<run_id>/audio_sync

        Body:
          {
            "transcripts": [
              {"ts_ms": int, "text": str, "confidence": float},
              ...
            ],
            "window_s": optional float
          }
        Returns:
          {n_matched, suggestions: {filename: moment}, matches: [...]}
        """
        try:
            from pixcull.audio_sync import (
                DEFAULT_WINDOW_S, apply_audio_sync, is_enabled,
            )
        except Exception as exc:
            _dbg("audio_sync/import", exc, "post")
            self.send_error(500, "audio_sync import failed")
            return True
        if not is_enabled():
            self.send_error(
                403, "audio_sync not enabled (set PIXCULL_AUDIO_SYNC=1)")
            return True
        run = _get_run(run_id) or _reload_run_from_disk(run_id)
        if run is None:
            self.send_error(404, "no such run")
            return True
        body = self._read_json_body()
        transcripts = body.get("transcripts")
        if not isinstance(transcripts, list):
            self.send_error(400, "missing or non-list 'transcripts'")
            return True
        # Defensive cap.  500 transcripts ≈ 25 min of typical
        # ceremony speech at one phrase per 3s.
        if len(transcripts) > 500:
            self.send_error(413, "too many transcripts per call (max 500)")
            return True
        try:
            window_s = float(body.get("window_s") or DEFAULT_WINDOW_S)
        except (TypeError, ValueError):
            window_s = DEFAULT_WINDOW_S
        # Pull the run's scores.csv as the row set for correlation.
        out_dir = Path(run["output_dir"])
        scores_csv = out_dir / "scores.csv"
        rows: list[dict] = []
        if scores_csv.exists():
            try:
                import csv
                with scores_csv.open("r", encoding="utf-8", newline="") as f:
                    rows = list(csv.DictReader(f))
            except OSError as exc:
                _dbg("audio_sync/read_csv", exc, run_id)
                rows = []
        try:
            summary = apply_audio_sync(
                transcripts, rows, window_s=window_s,
            )
        except Exception as exc:
            _dbg("audio_sync/apply", exc, run_id)
            self.send_error(500, "audio_sync apply failed")
            return True
        self._json_ok(summary)
        return True

    def _serve_run_portfolio_json(self, run_id: str) -> bool:
        """v0.10-P0-4 — GET /api/v1/runs/<run_id>/portfolio

        JSON variant of the v0.9-P0-5 /share/<run>/<token>
        portfolio page.  iOS Companion's PortfolioView renders this
        — same chapter grouping + keynums + per-row metadata as
        the web, but in JSON not HTML.

        Doesn't require a share token (iOS uses the existing
        X-PixCull-API-Key channel for auth).  Skips the
        share-page-only fields (comments, photographer name from
        share-record) because those live in the share lifecycle,
        not the run.
        """
        run = _get_run(run_id) or _reload_run_from_disk(run_id)
        if run is None:
            self.send_error(404, "no such run")
            return True
        try:
            keeps, meta = self._share_collect_keeps(run)
        except Exception as exc:
            _dbg("api/v1/portfolio", exc, run_id)
            self.send_error(500, "portfolio collect failed")
            return True
        # Shape the response for iOS's PortfolioResponse decoder.
        payload = {
            "meta": {
                "photographer": None,   # iOS will pull from its own settings
                "client":       None,
                "event":        None,
                "event_date":   meta.get("date_last"),
                "contact":      None,
                "n_total":      meta.get("n_total"),
                "n_keeps":      meta.get("n_keeps"),
                "ratio":        meta.get("ratio"),
                "scenes":       list((meta.get("scenes") or {}).keys()),
            },
            "rows": keeps,
        }
        body = _safe_dumps(payload).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)
        return True

    def _serve_api_v1_row(self, run_id: str, filename: str) -> bool:
        """V0.3 — full single-row dict for the iOS lightbox.

        Includes ``advice`` (verdict + strengths + weaknesses +
        suggestions, all from V20), ``rubric_stars`` (per-axis 1-5★),
        ``gps_lat`` / ``gps_lon``, ``face_clusters`` (per-face cluster
        ids; iOS resolves to names via the face_clusters endpoint),
        and any meta-judge / VLM rationale present.

        Looks the row up by filename in the result rows. 404 if not
        found — typically because the filename was URL-encoded wrong,
        but the message says so the iOS UI can tell.
        """
        result = _build_results(run_id)
        if result is None:
            run = _get_run(run_id) or _reload_run_from_disk(run_id)
            if run is None:
                self.send_error(404, "no such run"); return True
            self.send_error(425, "results not ready"); return True
        rows, _ = result
        fn = unquote(filename)
        match = next((r for r in rows if r.get("filename") == fn), None)
        if match is None:
            self.send_error(404, f"no such filename in this run: {fn}")
            return True
        # Wrap in a schema envelope; the row itself is passthrough so
        # all fields the row builder produced are visible.
        body = _safe_dumps({
            "schema": "pixcull.api.v1.row.v1",
            "run_id": run_id,
            "row":    match,
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)
        return True

    def _serve_api_v1_run_summary(self, run_id: str) -> bool:
        """V25 — single-run summary doc designed for a mobile app's
        run-detail page. Returns counts + the URL paths to fetch the
        run's various asset endpoints. The mobile client follows the
        embedded paths rather than constructing them — that lets us
        rename or version routes without breaking apps.
        """
        run = _get_run(run_id) or _reload_run_from_disk(run_id)
        if run is None:
            self.send_error(404, "no such run")
            return True
        result = _build_results(run_id)
        summary = result[1] if result else {}
        face_clusters_info = (_build_face_clusters_info(run_id, result[0])
                               if result else {"clusters": [], "n_noise": 0})
        locations_info = (_build_locations_info(result[0], run_id) if result
                          else {"clusters": [], "n_no_gps": 0, "n_total": 0})
        body = _safe_dumps({
            "schema":   "pixcull.api.v1.run",
            "run_id":   run_id,
            "summary":  summary,
            "face_clusters_n":  len(face_clusters_info.get("clusters") or []),
            "locations_n":      len(locations_info.get("clusters") or []),
            "links": {
                "results_html":   f"/results/{run_id}",
                "status":         f"/api/v1/runs/{run_id}/status",
                "decisions":      f"/api/v1/runs/{run_id}/decisions",
                "face_clusters":  f"/api/v1/runs/{run_id}/face_clusters",
                "locations":      f"/api/v1/runs/{run_id}/locations",
                "scores_csv":     f"/api/v1/runs/{run_id}/scores.csv",
                "gallery_zip":    f"/api/v1/runs/{run_id}/gallery.zip",
                "xmp_zip":        f"/api/v1/runs/{run_id}/xmp.zip",
            },
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)
        return True

    # --- V25 CORS + API auth shims -----------------------------------------
    # We override ``end_headers`` so every response under ``/api/v1/`` gets
    # CORS headers without per-handler bookkeeping. Browser-hosted apps
    # served from a different origin (or running off ``file://`` like the
    # V23.x gallery) can fetch the JSON endpoints directly.
    #
    # Auth model:
    #   * Localhost (127.0.0.1 / ::1): no auth required — PixCull is a
    #     local-first app and the existing CLI / browser flows assume
    #     trusted same-machine access.
    #   * Non-localhost: requires ``X-PixCull-API-Key`` matching the
    #     ``PIXCULL_API_KEY`` env var if that var is set. If unset, the
    #     server still accepts non-localhost calls (preserves the V14.0
    #     "LAN demo" behavior); admin can set it to lock down.
    def _api_v1_auth_ok(self) -> bool:
        """V25 — return True if the current request is allowed to hit
        /api/v1 endpoints. See class header comment for the model."""
        client_host = (self.client_address[0] if self.client_address
                       else "")
        if client_host in ("127.0.0.1", "::1", "localhost"):
            return True
        required = os.environ.get("PIXCULL_API_KEY") or ""
        if not required:
            return True
        got = self.headers.get("X-PixCull-API-Key") or ""
        return got == required

    def end_headers(self) -> None:  # noqa: N802 — stdlib override
        path = urlparse(self.path).path
        if path.startswith("/api/v1"):
            # V25.1 — CORS origin allowlist via env var.
            # PIXCULL_API_CORS_ORIGINS is a comma-separated list:
            #   "https://app.example.com,https://staging.example.com"
            # The special value "*" (default when env var unset)
            # echoes the wild-open V25 behavior — fine for localhost
            # development, NOT recommended for any server reachable
            # from the public internet.
            #
            # When the env var is set, we ECHO the matching Origin
            # back in Access-Control-Allow-Origin (per CORS spec —
            # browsers reject "*" when credentials are involved, and
            # an echoed value is the proper way to allow a specific
            # origin). Unknown origins get no CORS header at all,
            # which the browser correctly rejects as a CORS failure.
            allowlist_raw = (os.environ.get("PIXCULL_API_CORS_ORIGINS")
                              or "*").strip()
            allowlist = [s.strip() for s in allowlist_raw.split(",")
                          if s.strip()]
            req_origin = self.headers.get("Origin", "")
            if "*" in allowlist:
                self.send_header("Access-Control-Allow-Origin", "*")
            elif req_origin and req_origin in allowlist:
                self.send_header("Access-Control-Allow-Origin", req_origin)
                # When echoing a specific origin we must also send
                # Vary: Origin so intermediate caches don't serve the
                # wrong-origin response to another origin's preflight.
                self.send_header("Vary", "Origin")
            # else: no Allow-Origin header → browser blocks the
            # request. Servers don't need to send a 403 — silence is
            # the spec-correct rejection.
            self.send_header("Access-Control-Allow-Methods",
                              "GET, POST, OPTIONS")
            self.send_header(
                "Access-Control-Allow-Headers",
                "Content-Type, X-PixCull-API-Key",
            )
            self.send_header("Access-Control-Max-Age", "86400")
        return BaseHTTPRequestHandler.end_headers(self)

    def do_OPTIONS(self) -> None:  # noqa: N802 — CORS preflight
        # Always respond 204 No Content for OPTIONS on /api/v1/* so the
        # browser's preflight succeeds. Auth not required for preflight
        # (CORS spec — the actual request gets auth-checked).
        path = urlparse(self.path).path
        if not path.startswith("/api/v1"):
            self.send_error(404, "preflight only valid on /api/v1/*")
            return
        self.send_response(204)
        self.send_header("Content-Length", "0")
        self.end_headers()

    # --- routes ------------------------------------------------------------
    def _read_request_user(self) -> None:
        """V28.2 — set the active user for this request from either:
        1. ``X-PixCull-User`` request header (third-party / mobile)
        2. ``pixcull_user`` cookie (browser session, set by
           ``POST /api/v1/users/active``)

        Falls through (no-op) when neither is set, in which case
        ``get_active_user()`` returns the env-var default.
        """
        from pixcull.users import set_request_user
        uid = self.headers.get("X-PixCull-User") or ""
        if not uid:
            cookie_hdr = self.headers.get("Cookie") or ""
            for part in cookie_hdr.split(";"):
                k, _, v = part.strip().partition("=")
                if k == "pixcull_user":
                    uid = v.strip()
                    break
        if uid:
            set_request_user(uid)
        else:
            set_request_user(None)

    # ------------------------------------------------------------------
    # v2.16-P2 — declarative GET routing.  do_GET was a 258-line if/elif
    # chain over 65 paths; the two dominant shapes now live in tables
    # (per-route history lives in git blame of the pre-table chain):
    #   _GET_EXACT   path == "/x"           -> zero-arg handler
    #   _GET_PREFIX  path.startswith("/x/") -> handler(tail)  ORDER MATTERS
    # The /api/v1 auth gate and the handful of compound routes (suffix
    # switches, rid/filename splits) stay hand-written in do_GET below,
    # in their original relative order.
    # ------------------------------------------------------------------
    _GET_EXACT: dict = {
        # first-run / privacy / settings
        "/first_run": "_serve_first_run_page",
        "/first_run_status": "_serve_first_run_status",
        "/privacy": "_serve_privacy_page",
        "/settings/error_reports": "_serve_error_reports_settings",
        # verticals registry
        "/verticals": "_serve_verticals_page",
        "/verticals.json": "_serve_verticals_json",
        "/verticals/bulk_thumb": "_serve_vertical_bulk_thumb",
        # root + PWA chrome
        "/": "_serve_upload_page",
        "/manifest.json": "_serve_pwa_manifest",
        "/sw.js": "_serve_pwa_service_worker",
        # admin surfaces
        "/admin": "_serve_admin_page",
        "/admin/perf": "_serve_admin_perf_page",
        "/admin/perf.json": "_serve_admin_perf_json",
        "/admin/bias": "_serve_bias_audit_page",
        "/admin/disagreement": "_serve_disagreement_page",
        "/admin/bias.md": "_serve_bias_audit_markdown",
        # runs / ops
        "/runs": "_serve_runs_list",
        "/storage_info": "_serve_storage_info",
        "/rubric_meta": "_serve_rubric_meta",
        "/retrain_status": "_serve_retrain_status",
        "/license": "_serve_license_status",
        "/license/refresh": "_handle_license_refresh",
        "/sync/download": "_handle_sync_download",
        "/healthz": "_serve_healthz",
        # /api/v1 extras not covered by _dispatch_api_v1_get (the auth
        # gate in do_GET has already run for these)
        "/api/v1/recap": "_serve_daily_recap",
        "/api/v1/bookmarks": "_serve_bookmarks_list",
        "/api/v1/conflicts": "_serve_session_conflicts",
        # standalone pages
        "/history": "_serve_history_page",
        # v2.32-P1 — cross-run library search
        "/library": "_serve_library_page",
        "/api/v1/library/status": "_serve_api_v1_library_status",
        "/api/v1/library/search": "_serve_api_v1_library_search",
        "/companion": "_serve_companion_page",
        "/tether": "_serve_tether_page",
        "/tether/sessions": "_serve_tether_sessions",
    }
    # (prefix, handler, mode, extra_args) — mode: "tail" passes the
    # query-stripped remainder; "raw" passes self.path's remainder (query
    # intact — the ?w= thumb bucket); "full" passes the whole path.
    _GET_PREFIX: tuple = (
        ("/verticals/list/", "_serve_vertical_list", "tail", ()),
        ("/verticals/sample/", "_serve_vertical_sample", "tail", ()),
        ("/verticals/bulk/", "_serve_vertical_bulk_page", "tail", ()),
        ("/docs/illustrations/", "_serve_static_doc_asset", "full", ()),
        ("/docs/brand/", "_serve_static_doc_asset", "full", ()),
        ("/admin/face_audit/", "_serve_face_audit", "tail", ()),
        ("/admin/delivery/", "_serve_delivery_audit", "tail", ()),
        ("/status/", "_serve_status", "tail", ()),
        ("/results/", "_serve_results", "tail", ()),
        ("/decisions/", "_serve_decisions", "tail", ()),
        ("/face_clusters/", "_serve_face_clusters", "tail", ()),
        ("/face_avatar/", "_serve_face_avatar", "tail", ()),
        ("/locations/", "_serve_locations", "tail", ()),
        ("/thumb/", "_serve_image", "raw", (_THUMB_SIZE,)),
        ("/full/", "_serve_image", "raw", (_FULL_SIZE,)),
        ("/face_crop/", "_serve_face_crop", "raw", ()),
        ("/video/data/", "_serve_video_data", "tail", ()),
        ("/video/frame/", "_serve_video_frame", "tail", ()),
        ("/video/", "_serve_video_review", "tail", ()),
        ("/timeline/data/", "_serve_timeline_data", "tail", ()),
        ("/timeline/", "_serve_timeline_page", "tail", ()),
        ("/xmp_zip/", "_serve_xmp_zip", "tail", ()),
        ("/share/", "_serve_share_page", "tail", ()),
        ("/style/distances/", "_serve_style_distances", "tail", ()),
        ("/tether/status/", "_serve_tether_status", "tail", ()),
        ("/gallery_zip/", "_serve_gallery_zip", "tail", ()),
        ("/scores_csv/", "_serve_scores_csv", "tail", ()),
        # v2.18-P0 — FULL-shape paginated rows for the results page's
        # progressive hydration. (The /api/v1/.../rows alias serves the
        # iOS SLIM shape and has shadowed the full v0.13.5 endpoint since
        # P2.1 — discovered while wiring hydration; the page needs every
        # field the inline dump carries, so it gets its own route.)
        ("/results_rows/", "_serve_runs_rows", "tail", ()),
        ("/rubric/", "_serve_rubric", "tail", ()),
        ("/annotation/", "_serve_annotation", "tail", ()),
        ("/next_to_label/", "_serve_next_to_label", "tail", ()),
    )

    def do_GET(self) -> None:  # noqa: N802
        self._read_request_user()       # V28.2
        path = urlparse(self.path).path
        # V25 — versioned API namespace: auth gate FIRST; paths the v1
        # dispatcher doesn't own fall through to the tables (auth already
        # checked once).
        if path.startswith("/api/v1"):
            if not self._api_v1_auth_ok():
                self.send_error(401, "missing or wrong X-PixCull-API-Key")
                return
            if self._dispatch_api_v1_get(path):
                return
        handler = self._GET_EXACT.get(path)
        if handler is not None:
            return getattr(self, handler)()
        # v0.13.5 — paginated rows: compound suffix route
        if path.startswith("/api/v1/runs/") and path.endswith("/rows"):
            return self._serve_runs_rows(
                path[len("/api/v1/runs/"):-len("/rows")])
        # v0.13.1 — per-ref CLIP distances: rid/filename split (a tail
        # without "/" deliberately falls through to 404)
        if path.startswith("/style/refs/"):
            tail = path[len("/style/refs/"):]
            if "/" in tail:
                rid, fn = tail.split("/", 1)
                return self._serve_style_per_ref(rid, unquote(fn))
        # v0.8-P1-3 — short link resolver + QR SVG (suffix switch)
        if path.startswith("/s/"):
            tail = path[len("/s/"):]
            if tail.endswith(".svg"):
                return self._serve_shortlink_qr(tail[:-4])
            return self._serve_shortlink_redirect(tail)
        # v0.8-P2-2 — structured export (suffix switch + explicit 404)
        if path.startswith("/export/structured/"):
            tail = path[len("/export/structured/"):]
            if tail.endswith(".json"):
                return self._serve_export_structured_json(tail[:-5])
            if tail.endswith(".csv"):
                return self._serve_export_structured_csv(tail[:-4])
            self.send_error(404, "expected .json or .csv suffix")
            return
        for prefix, name, mode, extra in self._GET_PREFIX:
            if path.startswith(prefix):
                if mode == "full":
                    return getattr(self, name)(path)
                src = self.path if mode == "raw" else path
                return getattr(self, name)(src[len(prefix):], *extra)
        self.send_error(404, "not found")

    def do_POST(self) -> None:  # noqa: N802
        self._read_request_user()       # V28.2
        path = urlparse(self.path).path
        # V25 — versioned API namespace (POST side).
        if path.startswith("/api/v1"):
            if not self._api_v1_auth_ok():
                self.send_error(401, "missing or wrong X-PixCull-API-Key")
                return
            if self._dispatch_api_v1_post(path):
                return
        # v2.20-P3 — persist a reel candidate Keep/Cull (was localStorage-only)
        if path.startswith("/video/reel_decision/"):
            return self._handle_reel_decision(
                path[len("/video/reel_decision/"):])
        if path == "/analyze":
            return self._handle_analyze_post()
        if path == "/scan_local":
            return self._handle_scan_local()
        # P-UX-21 — sample-data quick-try. Copies the bundled
        # samples/ tree into a fresh demo run + returns the
        # new run_id so the upload page can redirect directly
        # into /results without any model warm-up.
        if path == "/sample_demo":
            return self._handle_sample_demo()
        # P-UX-22 — deliverable buckets export. Body: {name, filenames}
        # → server zips the matching photos + returns a downloadable URL.
        if path.startswith("/buckets/export/"):
            run_id = path[len("/buckets/export/"):]
            return self._handle_bucket_export(run_id)
        # v0.7-P1-4 — issue a fresh share token for the run.
        # POST /share/<run_id>/issue  body: {photographer?, client?, event?, ...}
        # → {ok, token, url}
        if path.startswith("/share/") and path.endswith("/issue"):
            rid = path[len("/share/"):-len("/issue")]
            return self._handle_share_issue(rid)
        # v0.9-P0-5 — client comment from the /share page.
        # POST /share/<run_id>/<token>/comment  body: {body, author?}
        # → {ok, n_comments}
        if (path.startswith("/share/")
                and path.endswith("/comment")
                and path.count("/") == 4):
            tail = path[len("/share/"):-len("/comment")]
            if "/" in tail:
                rid, tok = tail.split("/", 1)
                return self._handle_share_comment(rid, tok)
        # v0.7-P2-1 — train (or retrain) a style-clone profile.
        # POST /style/train/<run_id>  body: {refs: [filename,...]}
        # → {ok, n_refs, profile_summary}
        if path.startswith("/style/train/"):
            rid = path[len("/style/train/"):]
            return self._handle_style_train(rid)
        # v0.8-P0-2 — issue a sync event token for a run.
        # POST /sync/event/issue/<run_id>  body: {label?, ttl_hours?}
        # → {ok, event_id, token, url, qr_url}
        if path.startswith("/sync/event/issue/"):
            rid = path[len("/sync/event/issue/"):]
            return self._handle_sync_event_issue(rid)
        # v0.8-P1-3 — short-link issuer.
        # POST /s/issue  body: {long_url, ttl_hours?, label?}
        # → {ok, short_code, short_url, qr_url, long_url, expires_at}
        if path == "/s/issue":
            return self._handle_shortlink_issue()
        # v0.8-P0-2 — revoke an event
        # POST /sync/event/revoke/<run_id>/<event_id>
        if path.startswith("/sync/event/revoke/"):
            tail = path[len("/sync/event/revoke/"):]
            if "/" in tail:
                rid, eid = tail.split("/", 1)
                return self._handle_sync_event_revoke(rid, eid)
        # v0.9-P1-2 — multiplayer presence heartbeat.
        # POST /sync/event/<token>/presence
        #   body: {client_id, display_name?, last_viewed_filename?,
        #          action?, action_filename?, disconnect?}
        #   → {ok, peer_count, you: {<echoed presence record>}}
        if (path.startswith("/sync/event/")
                and path.endswith("/presence")
                and path.count("/") == 4):
            token = path[len("/sync/event/"):-len("/presence")]
            return self._handle_sync_event_presence(token)
        # v0.10-P0-1 — two-way sync push.  Collaborators send their
        # batched annotation edits here; we append to the host's
        # annotations.jsonl + the existing /changes polling fanouts
        # to all other peers.
        # POST /sync/event/<token>/push
        #   body: {edits: [{filename, decision?, rubric_stars?, ...}, ...]}
        #   → {ok, accepted, rejected, server_ts, rows}
        if (path.startswith("/sync/event/")
                and path.endswith("/push")
                and path.count("/") == 4):
            token = path[len("/sync/event/"):-len("/push")]
            return self._handle_sync_event_push(token)
        # v0.11-P0-3 — WebRTC signaling relay.
        # POST /sync/webrtc/relay
        #   body: {kind, from, to, payload}
        #   → {ok, ts_ms}
        if path == "/sync/webrtc/relay" or path == "/api/v1/sync/webrtc/relay":
            self._serve_sync_webrtc_relay()
            return
        # v0.13.9 — bookmark toggle.
        # POST /api/v1/bookmark  body: {run_id, filename, note?, color?}
        #   → {ok, added: bool, is_bookmarked: bool}
        if path == "/api/v1/bookmark":
            return self._handle_bookmark_toggle()
        # v0.10-P1-4 — audio-photo sync (opt-in, gated on
        # PIXCULL_AUDIO_SYNC=1).  Client posts transcript chunks +
        # we suggest wedding_moment overrides via keyword matching.
        # POST /api/v1/runs/<run_id>/audio_sync
        #   body: {transcripts: [...], window_s?: float}
        #   → {n_matched, suggestions: {filename: moment}, ...}
        if (path.startswith("/api/v1/runs/")
                and path.endswith("/audio_sync")):
            rid = path[len("/api/v1/runs/"):-len("/audio_sync")]
            return self._handle_audio_sync_post(rid)
        # v0.7-P2-2 — tethered live scoring (top-level shortcut routes
        # that call into the canonical P2.2 handlers defined further
        # down in this class).
        if path == "/tether/start":
            return self._handle_tether_start()
        if path.startswith("/tether/") and path.endswith("/stop"):
            sid = path[len("/tether/"):-len("/stop")]
            return self._handle_tether_stop(sid)
        if path == "/browse":
            return self._handle_browse()
        if path.startswith("/export/"):
            return self._handle_export(path[len("/export/"):])
        if path == "/runs/cleanup":
            return self._handle_runs_cleanup()
        # P0.4 — re-run SceneDetector on a run's cached scores.csv,
        # applying V20's "face_count > 0 → not stilllife" correction
        # to existing rows without re-running the full pipeline.
        if path.startswith("/runs/") and path.endswith("/rescan_scene"):
            mid = path[len("/runs/"):-len("/rescan_scene")]
            return self._handle_rescan_scene(mid)
        # P2.3 — apply the active style guide to a run's rows
        # (post-decision; can knock keep → maybe/cull).
        if path.startswith("/runs/") and path.endswith("/apply_style_guide"):
            mid = path[len("/runs/"):-len("/apply_style_guide")]
            return self._handle_apply_style_guide(mid)
        if path.startswith("/annotation/"):
            return self._handle_save_annotation(path[len("/annotation/"):])
        if path.startswith("/face_clusters/") and path.endswith("/label"):
            # V22.1 — update a per-cluster label for a run.
            mid = path[len("/face_clusters/"):-len("/label")]
            return self._handle_face_label_post(mid)
        if path.startswith("/locations/") and path.endswith("/label"):
            # V23.1 — update a per-location label for a run.
            mid = path[len("/locations/"):-len("/label")]
            return self._handle_location_label_post(mid)
        if path == "/retrain":
            return self._handle_retrain()
        if path == "/license":
            return self._handle_license_install()
        if path == "/sync/upload":
            return self._handle_sync_upload()
        # V14.7 — opt-in error reporting
        if path == "/settings/error_reports":
            return self._handle_save_error_reports_settings()
        if path == "/error_reports/submit":
            return self._handle_submit_error_report()
        # V17.12 — browser-side window.onerror / unhandledrejection
        if path == "/error_reports/client_event":
            return self._handle_client_error_event()
        # V17.0 — vertical sample upload
        if path.startswith("/verticals/upload/"):
            return self._handle_vertical_upload(path[len("/verticals/upload/"):])
        # V17.4 — vertical policy tuning + apply / revert
        if path.startswith("/verticals/tune/"):
            return self._handle_vertical_tune(path[len("/verticals/tune/"):])
        if path.startswith("/verticals/apply_override/"):
            return self._handle_vertical_apply_override(
                path[len("/verticals/apply_override/"):])
        if path.startswith("/verticals/revert_override/"):
            return self._handle_vertical_revert_override(
                path[len("/verticals/revert_override/"):])
        # V17.5 — DeepSeek phrase generation
        if path.startswith("/verticals/llm_phrases/"):
            return self._handle_vertical_llm_phrases(
                path[len("/verticals/llm_phrases/"):])
        if path.startswith("/verticals/revert_phrases/"):
            return self._handle_vertical_revert_phrases(
                path[len("/verticals/revert_phrases/"):])
        # V17.6 — per-vertical eval report
        if path.startswith("/verticals/eval/"):
            return self._handle_vertical_eval(
                path[len("/verticals/eval/"):])
        # V17.7 — bulk-classify-from-folder
        if path.startswith("/verticals/bulk_classify/"):
            return self._handle_vertical_bulk_classify(
                path[len("/verticals/bulk_classify/"):])
        if path.startswith("/verticals/bulk_commit/"):
            return self._handle_vertical_bulk_commit(
                path[len("/verticals/bulk_commit/"):])
        # V17.8 — auto-promote human-annotated keep/cull from a
        # vertical-tagged batch into that vertical's sample bank.
        if path.startswith("/verticals/promote_run/"):
            return self._handle_vertical_promote_run(
                path[len("/verticals/promote_run/"):])
        # V17.13 — Unsplash CC0 reference fetcher
        if path.startswith("/verticals/unsplash_fetch/"):
            return self._handle_vertical_unsplash_fetch(
                path[len("/verticals/unsplash_fetch/"):])
        self.send_error(404, "not found")

    def do_DELETE(self) -> None:  # noqa: N802
        path = urlparse(self.path).path
        if path.startswith("/runs/"):
            return self._handle_run_delete(path[len("/runs/"):])
        # V17.0 — DELETE /verticals/sample/<key>/<bucket>/<filename>
        if path.startswith("/verticals/sample/"):
            return self._handle_vertical_sample_delete(
                path[len("/verticals/sample/"):])
        self.send_error(404, "not found")

    # --- handlers ----------------------------------------------------------
    def _serve_upload_page(self) -> None:
        body = _UPLOAD_HTML.encode("utf-8")
        self._send_html(200, body)

    def _serve_bias_audit_page(self) -> None:
        """v0.13-P0-4 — render the bias audit dashboard.

        Pulls cached bias report (24h TTL) from
        ``pixcull.scoring.bias_audit`` and emits a self-contained
        HTML page.  Findings (z > 1.5σ from family mean) surface as
        red callouts at the top; bucket tables below for inspection.

        v0.13.2: accepts ?user=<id> to slice the audit to one
        annotator.  Empty → global audit (legacy behaviour).
        """
        from urllib.parse import parse_qs, urlparse as _up
        from html import escape as _esc
        from pixcull.scoring.bias_audit import get_report, list_annotators
        qs = parse_qs(_up(self.path).query)
        force = (qs.get("force") or ["0"])[0] == "1"
        user_filter = (qs.get("user") or [""])[0].strip()
        annotators = list_annotators(Path.home() / ".pixcull" / "runs")
        report = get_report(
            Path.home() / ".pixcull" / "runs",
            force=force,
            user_filter=user_filter or None,
        )
        # Group buckets by family for table rendering
        by_family: dict[str, list] = {}
        for b in report.buckets:
            by_family.setdefault(b.family, []).append(b)

        # ---- findings block ----
        findings_html = ""
        if report.findings:
            rows_html = "\n".join(
                f"<div class='finding {('over' if f.z_score > 0 else 'under')}'>"
                f"<div class='badge'>{_esc(f.family)} · {_esc(f.value)}</div>"
                f"<div class='metric'>{_esc(f.metric.replace('_', ' '))}: "
                f"<b>{f.bucket_value*100:.1f}%</b> "
                f"(均值 {f.global_mean*100:.1f}% · z={f.z_score:+.2f})</div>"
                f"<div class='suggest'>{_esc(f.suggestion)}</div>"
                f"</div>"
                for f in report.findings
            )
            findings_html = (
                "<section class='findings'>"
                "<h2>🚩 偏差检测 — 高于 1.5σ 阈值的桶</h2>"
                + rows_html +
                "</section>"
            )
        else:
            findings_html = (
                "<section class='findings'><h2>✓ 无偏差告警</h2>"
                "<p>所有桶都在均值 ±1.5σ 内 — rescorer 表现均衡。</p>"
                "</section>"
            )

        # ---- per-family bucket tables ----
        tables_html = ""
        for family in sorted(by_family.keys()):
            tables_html += (
                f"<section class='family'><h2>{_esc(family)}</h2>"
                "<table><thead><tr>"
                "<th>值</th><th>n</th><th>keep%</th><th>cull%</th>"
                "<th>model cull%</th><th>reversal%</th></tr></thead><tbody>"
            )
            buckets_sorted = sorted(by_family[family],
                                     key=lambda b: -b.n)
            for b in buckets_sorted:
                tables_html += (
                    f"<tr class='{'under' if b.under_sampled else ''}'>"
                    f"<td>{_esc(b.value)}</td>"
                    f"<td>{b.n}</td>"
                    f"<td>{b.keep_rate*100:.1f}%</td>"
                    f"<td>{b.cull_rate*100:.1f}%</td>"
                    f"<td>{b.model_cull_rate*100:.1f}%</td>"
                    f"<td>{b.reversal_rate*100:.1f}%</td>"
                    "</tr>"
                )
            tables_html += "</tbody></table></section>"

        from datetime import datetime as _dt
        ts = _dt.fromtimestamp(
            report.timestamp_built).strftime("%Y-%m-%d %H:%M") \
            if report.timestamp_built else "—"
        html_body = (
            "<!DOCTYPE html><html lang='zh'><head><meta charset='utf-8'>"
            "<title>PixCull · 偏差审计</title>"
            "<style>" + _DESIGN_TOKENS_CSS +
            "body{margin:0;background:var(--bg);color:var(--fg);"
            "font:13px/1.55 system-ui,-apple-system;padding:32px;}"
            "h1{margin:0 0 4px;letter-spacing:-0.02em;}"
            ".meta{color:var(--muted);font-size:11.5px;margin-bottom:32px;}"
            ".meta a{color:var(--accent);text-decoration:none;margin-left:14px;}"
            "section{margin:24px 0;}"
            ".findings .finding{padding:14px;border-radius:8px;margin:10px 0;"
            "background:color-mix(in srgb, var(--c-danger) 12%, transparent);"
            "border-left:4px solid var(--c-danger);}"
            ".findings .finding.under{background:color-mix(in srgb, var(--c-warn) 12%, transparent);"
            "border-left-color:var(--c-warn);}"
            ".findings .badge{font-weight:600;letter-spacing:0.02em;"
            "font-size:11.5px;text-transform:uppercase;color:var(--c-danger);"
            "margin-bottom:4px;}"
            ".findings .metric{color:var(--fg);}"
            ".findings .suggest{color:var(--muted);font-size:11.5px;margin-top:4px;}"
            "table{border-collapse:collapse;width:100%;font-size:12px;}"
            "th,td{padding:6px 10px;text-align:left;"
            "border-bottom:1px solid var(--border);}"
            "th{color:var(--muted);font-weight:600;}"
            "tr.under{opacity:0.45;}"
            ".family h2{font-size:14px;color:var(--accent);"
            "letter-spacing:0.02em;text-transform:uppercase;}"
            "</style>" + _THEME_BOOT_HTML + "</head><body>"
            "<h1>偏差审计"
            + (f" · <span style='color:var(--accent);font-size:18px'>"
               f"@{_esc(user_filter)}</span>"
               if user_filter else "")
            + "</h1>"
            f"<div class='meta'>{report.n_total_rows:,} 条记录 · "
            f"{report.n_total_runs} 个 run · 缓存于 {ts}"
            # v0.13.2 — annotator switcher chips
            + (
                "&nbsp;&nbsp;|&nbsp;&nbsp;<span style='color:var(--muted)'>"
                + "切片:</span> "
                + ("<a href='/admin/bias' style='" +
                   (("color:var(--accent)" if user_filter else
                     "color:var(--fg);text-decoration:underline"))
                   + "'>全部</a>"
                   + "".join(
                       f" · <a href='/admin/bias?user={_esc(u)}' style='"
                       + (("color:var(--fg);text-decoration:underline" if u == user_filter
                           else "color:var(--accent)"))
                       + f"'>{_esc(u)}</a>"
                       for u in annotators[:10]))
                if annotators else ""
            )
            + " &nbsp;&nbsp;<a href='/admin/bias"
            + (f"?user={_esc(user_filter)}&force=1" if user_filter
               else "?force=1")
            + "'>↻ 刷新</a></div>"
            + findings_html
            + tables_html
            + _THEME_TOGGLE_HTML + "</body></html>"
        )
        self._send_html(200, html_body.encode("utf-8"))

    def _serve_bias_audit_markdown(self) -> None:
        """v0.13-P2-2 — Markdown export of the bias audit dashboard.

        Studios use this as a client-facing transparency artefact:
        "We audited our AI culling for bias; here's the report."
        The markdown is converter-agnostic — pandoc, Typora, or
        browser print-to-PDF all produce reasonable output.
        """
        from datetime import datetime as _dt
        from pixcull.scoring.bias_audit import get_report
        report = get_report(Path.home() / ".pixcull" / "runs")
        ts = (_dt.fromtimestamp(report.timestamp_built).
              strftime("%Y-%m-%d %H:%M")
              if report.timestamp_built else "—")
        lines: list[str] = []
        lines.append("# PixCull · Bias Audit Report")
        lines.append("")
        lines.append(f"_{report.n_total_rows:,} annotations across "
                     f"{report.n_total_runs} runs · cached at {ts}_")
        lines.append("")
        lines.append("## Summary")
        lines.append("")
        n_warn = len(report.findings)
        if n_warn == 0:
            lines.append(
                "**✓ No bias findings.** Every bucket sits within "
                "±1.5σ of its family mean; the rescorer's decisions "
                "are statistically balanced across the data we've seen."
            )
        else:
            lines.append(
                f"**⚠ {n_warn} bias findings.** The rescorer's "
                f"behaviour deviates by > 1.5σ from the family mean "
                f"in the buckets below.  Each finding includes a "
                f"suggested action."
            )
        lines.append("")
        if report.findings:
            lines.append("## Findings")
            lines.append("")
            lines.append("| Family | Bucket | Metric | Value | Mean | z-score | Suggestion |")
            lines.append("|---|---|---|---|---|---|---|")
            for f in report.findings:
                lines.append(
                    f"| {f.family} | {f.value} | "
                    f"{f.metric.replace('_', ' ')} | "
                    f"{f.bucket_value*100:.1f}% | "
                    f"{f.global_mean*100:.1f}% | "
                    f"{f.z_score:+.2f} | {f.suggestion} |"
                )
            lines.append("")
        # Per-family detail tables
        by_family: dict[str, list] = {}
        for b in report.buckets:
            by_family.setdefault(b.family, []).append(b)
        for family in sorted(by_family.keys()):
            lines.append(f"## {family.title()} buckets")
            lines.append("")
            lines.append("| Bucket | n | keep% | cull% | model cull% | reversal% |")
            lines.append("|---|---|---|---|---|---|")
            for b in sorted(by_family[family], key=lambda x: -x.n):
                tag = " ⚠" if b.under_sampled else ""
                lines.append(
                    f"| {b.value}{tag} | {b.n} | "
                    f"{b.keep_rate*100:.1f}% | "
                    f"{b.cull_rate*100:.1f}% | "
                    f"{b.model_cull_rate*100:.1f}% | "
                    f"{b.reversal_rate*100:.1f}% |"
                )
            lines.append("")
            lines.append("_Rows tagged with ⚠ have fewer than 10 "
                         "samples and are excluded from outlier detection._")
            lines.append("")
        lines.append("---")
        lines.append("")
        lines.append("Generated by PixCull v0.13-P0-4 · "
                     "[Bias audit dashboard](/admin/bias) · "
                     "[Conflict resolution](/admin/disagreement)")
        body = "\n".join(lines).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/markdown; charset=utf-8")
        self.send_header("Content-Disposition",
                         "attachment; filename=pixcull-bias-audit.md")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _serve_disagreement_page(self) -> None:
        """v0.13-P1-3 — conflict-resolution dashboard.

        Builds on ``bias_audit.get_report`` to surface only the
        high-reversal buckets and emits a per-run trend chart based
        on the same annotations.jsonl scan.  Read-only — no actions
        beyond linking to the bias audit + history page.
        """
        from html import escape as _esc
        from pixcull.scoring.bias_audit import get_report
        report = get_report(Path.home() / ".pixcull" / "runs")
        # Sort buckets by reversal rate descending
        high_rev = [
            b for b in report.buckets
            if not b.under_sampled and b.reversal_rate > 0.10
        ]
        high_rev.sort(key=lambda b: -b.reversal_rate)
        # ---- top reversal buckets ----
        rows_html = "\n".join(
            "<tr>"
            f"<td>{_esc(b.family)}</td>"
            f"<td>{_esc(b.value)}</td>"
            f"<td>{b.n}</td>"
            f"<td><b>{b.reversal_rate*100:.1f}%</b></td>"
            f"<td>{b.n_reversals}</td>"
            "</tr>"
            for b in high_rev[:20]
        )
        if not rows_html:
            rows_html = ("<tr><td colspan='5' style='color:#888;"
                         "text-align:center'>无超过 10% 反转率的桶</td></tr>")
        # ---- per-run reversal count ----
        per_run: dict[str, int] = {}
        from pixcull.scoring.bias_audit import _iter_annotation_rows
        for run_name, row in _iter_annotation_rows(
                Path.home() / ".pixcull" / "runs"):
            user = (row.get("decision")
                    or row.get("overall_label") or "").strip().lower()
            model = (row.get("model_decision")
                     or row.get("rescorer_pred") or "").strip().lower()
            if user and model and user != model:
                per_run[run_name] = per_run.get(run_name, 0) + 1
        top_runs = sorted(per_run.items(), key=lambda kv: -kv[1])[:15]
        per_run_html = "\n".join(
            f"<tr><td><a href='/results/{_esc(rn)}'>"
            f"{_esc(rn)}</a></td><td>{cnt}</td></tr>"
            for rn, cnt in top_runs
        )
        if not per_run_html:
            per_run_html = ("<tr><td colspan='2' style='color:#888;"
                            "text-align:center'>无反转记录</td></tr>")
        # v2.28 — static shell extracted to templates/pages/disagreement.html;
        # the row count + the two computed tables splice in at placeholders.
        # Byte-identical to the prior inline build (route-diff verified).
        html_body = (
            _read_template("pages/disagreement.html")
            .replace("<!--__DIS_NROWS_META__-->", f"{report.n_total_rows:,} 条记录 · ")
            .replace("<!--__DIS_ROWS__-->", rows_html)
            .replace("<!--__DIS_PER_RUN__-->", per_run_html)
        )
        self._send_html(200, html_body.encode("utf-8"))

    # ── v2.32-P1 — cross-run library search ──────────────────────────
    def _serve_library_page(self) -> None:
        """GET /library — search across every indexed shoot at once."""
        html = _read_template("pages/library.html").replace(
            "/*__DESIGN_TOKENS_CSS__*/", _DESIGN_TOKENS_CSS)
        self._send_html(200, html.encode("utf-8"))

    def _serve_api_v1_library_status(self) -> None:
        """GET /api/v1/library/status — index size + liveness summary."""
        try:
            from pixcull.scoring import library_index as LX
            st = LX.status()
            payload = {
                "ok": True,
                "schema": "pixcull.api.v1.library.status",
                "n_photos": st["n_photos"],
                "n_runs": st["n_runs"],
                "n_stale": st["n_stale"],
                "disk_bytes": st["disk_bytes"],
            }
        except Exception as exc:                       # noqa: BLE001
            payload = {"ok": False, "error": str(exc)}
        self._send_json(200, _safe_dumps(payload).encode("utf-8"))

    def _serve_api_v1_library_search(self) -> None:
        """GET /api/v1/library/search?q=<text>&k=40 — cross-run hits.

        Stale hits (file not on disk right now) are RETURNED with a flag
        rather than filtered out: an offline drive should read as
        "found it, but it's not reachable", not as "no such photo".
        """
        from urllib.parse import parse_qs, urlparse as _up
        qs = parse_qs(_up(self.path).query)
        query = (qs.get("q") or [""])[0].strip()
        try:
            k = max(1, min(200, int((qs.get("k") or ["40"])[0])))
        except ValueError:
            k = 40
        if not query:
            self._send_json(200, _safe_dumps(
                {"ok": False, "error": "q required"}).encode("utf-8"))
            return
        try:
            from pixcull.scoring import library_index as LX
            from pixcull.scoring.semantic_search import encode_query
            if LX.status()["n_photos"] == 0:
                payload = {"ok": False,
                           "error": "library index is empty — run "
                                    "`pixcull library index` first"}
            else:
                t0 = time.time()
                hits = LX.search(encode_query(query), k=k)
                payload = {
                    "ok": True,
                    "schema": "pixcull.api.v1.library.search",
                    "query": query,
                    "n_hits": len(hits),
                    "elapsed_ms": int((time.time() - t0) * 1000),
                    "hits": hits,
                }
        except Exception as exc:                       # noqa: BLE001
            _dbg("library_search", exc, query)
            payload = {"ok": False, "error": str(exc)}
        self._send_json(200, _safe_dumps(payload).encode("utf-8"))

    def _serve_companion_page(self) -> None:
        """v0.12-P0-2 — second-monitor companion window.

        Renders a stripped-down lightbox that joins the same
        ``pixcull-companion:<run_id>`` BroadcastChannel as the
        primary results page.  Initial photo comes from ?fn=<name>;
        every subsequent nav message from the primary drives the
        <img src> swap.  Closing the companion doesn't break the
        primary's state (channel is best-effort).
        """
        from urllib.parse import parse_qs, urlparse as _up
        qs = parse_qs(_up(self.path).query)
        rid = (qs.get("run_id") or [""])[0]
        fn0 = (qs.get("fn") or [""])[0]
        if not rid:
            self.send_error(400, "run_id required")
            return
        # Resolve initial image URL or empty placeholder.  Match the
        # same /full/<rid>/<fn>?w=... contract the primary uses.
        from html import escape as _esc
        initial_src = (
            f"/full/{_esc(rid)}/{_esc(fn0)}?w=2400" if fn0 else ""
        )
        # Minimalist HTML — no grid, no inspector, just the image.
        # The primary owns all interaction; the companion is read-
        # only mirror.  ESC closes the window.
        html_body = (
            "<!DOCTYPE html>"
            "<html lang='zh'><head><meta charset='utf-8'>"
            "<title>PixCull · 副屏</title>"
            "<style>" + _DESIGN_TOKENS_CSS +
            "html,body{margin:0;background:var(--bg);color:var(--fg);"
            "font:13px/1.4 system-ui,-apple-system;height:100%;}"
            "body{display:flex;flex-direction:column;}"
            ".bar{display:flex;align-items:center;gap:10px;"
            "padding:8px 14px;background:var(--chrome);"
            "backdrop-filter:saturate(180%) blur(12px);}"
            ".bar .badge{background:var(--accent-soft);"
            "color:var(--accent);padding:2px 10px;border-radius:999px;"
            "font-size:11px;font-weight:600;}"
            ".bar .fn{color:var(--muted);font-family:ui-monospace,SF Mono,"
            "Menlo,monospace;font-size:11.5px;flex:1;overflow:hidden;"
            "text-overflow:ellipsis;white-space:nowrap;}"
            ".stage{flex:1;display:flex;align-items:center;"
            "justify-content:center;padding:14px;}"
            "img{max-width:100%;max-height:100%;object-fit:contain;"
            "box-shadow:0 10px 36px rgba(0,0,0,0.6);}"
            ".empty{color:var(--muted);font-size:15px;text-align:center;"
            "max-width:420px;line-height:1.6;}"
            "</style>" + _THEME_BOOT_HTML + "</head><body>"
            "<div class='bar'>"
            "<span class='badge'>🪟 副屏</span>"
            "<span class='fn' id='fnLabel'></span>"
            "<span style='color:var(--muted);font-size:11px'>Esc 关闭</span>"
            "</div>"
            "<div class='stage'>"
            f"  <img id='lbImg' src='{initial_src}' alt='' "
            f"       style='{'display:none' if not initial_src else ''}'>"
            "  <div id='emptyState' class='empty' "
            f"       style='{'display:none' if initial_src else ''}'>"
            "    等候主窗口选定一张照片…<br><span style='color:var(--muted)'>"
            "    (副屏会同步翻页 + 缩放)</span></div>"
            "</div>"
            "<script>(function(){"
            f"const rid='{_esc(rid)}';"
            "const ch=(typeof BroadcastChannel==='function')?"
            "new BroadcastChannel('pixcull-companion:'+rid):null;"
            "const img=document.getElementById('lbImg');"
            "const label=document.getElementById('fnLabel');"
            "const empty=document.getElementById('emptyState');"
            "function nav(fn){"
            "  if(!fn){return;}"
            "  const w=Math.round(Math.min(window.innerWidth,2400)*"
            "    Math.max(1,Math.min(window.devicePixelRatio||1,2)));"
            "  img.src='/full/'+encodeURIComponent(rid)+"
            "    '/'+encodeURIComponent(fn)+'?w='+w;"
            "  img.style.display='';"
            "  empty.style.display='none';"
            "  label.textContent=fn;"
            "}"
            "if(ch){"
            "  ch.addEventListener('message',ev=>{"
            "    const d=ev.data||{};"
            "    if(d.kind==='nav') nav(d.payload);"
            "  });"
            "  /* ping the primary so it sends us the current state */"
            "  ch.postMessage({kind:'request-state'});"
            "}"
            "document.addEventListener('keydown',ev=>{"
            "  if(ev.key==='Escape') window.close();"
            "});"
            f"if({'true' if fn0 else 'false'}) label.textContent='{_esc(fn0)}';"
            "})();</script>"
            + _THEME_TOGGLE_HTML + "</body></html>"
        )
        self._send_html(200, html_body.encode("utf-8"))

    def _serve_pwa_manifest(self) -> bool:
        """v0.10-P2-1 — PWA install manifest.

        Lets the user "Install PixCull" from Chrome/Edge/Safari and
        get a desktop / home-screen icon that opens directly into
        /history.  Solo-photographer path; teams who installed the
        signed .dmg / .msi / .AppImage don't need PWA.

        Icon paths reference docs/brand/* — the same brand SVGs
        we ship as static files in the bundle.
        """
        body = _safe_dumps({
            "name":             "PixCull",
            "short_name":       "PixCull",
            "description":      "Local-first AI photo culling for"
                                 " professional photographers",
            "start_url":        "/history",
            "scope":            "/",
            "display":          "standalone",
            "background_color": "#161616",
            "theme_color":      "#d5b584",
            "orientation":      "any",
            "categories":       ["photo", "productivity", "utilities"],
            "icons": [
                {"src":   "/docs/brand/pixcull-icon-192.png",
                 "sizes": "192x192", "type": "image/png",
                 "purpose": "any maskable"},
                {"src":   "/docs/brand/pixcull-icon-256.png",
                 "sizes": "256x256", "type": "image/png",
                 "purpose": "any"},
                {"src":   "/docs/brand/pixcull-icon-512.png",
                 "sizes": "512x512", "type": "image/png",
                 "purpose": "any"},
            ],
            "shortcuts": [
                {"name":  "Upload a batch",
                 "short_name": "Upload",
                 "url":   "/",
                 "description": "Start a new analysis run"},
                {"name":  "History timeline",
                 "short_name": "History",
                 "url":   "/history",
                 "description": "All past runs"},
                {"name":  "Tethered Live",
                 "short_name": "Tether",
                 "url":   "/tether",
                 "description": "Watch a tether folder live"},
            ],
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type",
                          "application/manifest+json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "public, max-age=300")
        self.end_headers()
        self.wfile.write(body)
        return True

    def _serve_pwa_service_worker(self) -> bool:
        """v0.10-P2-1 — minimal service worker.

        Strategy:
          * Cache the chrome (results.html shell + the brand SVGs)
            on install so the app launches instantly from the
            home-screen icon.
          * Network-first for everything else — runs are MUTABLE
            (annotations change, new photos arrive via tether)
            and we never want to serve a stale grid.
          * No background-sync, no push notifications — keeping
            the service worker tiny + auditable.

        Cache name carries the major-version stamp so a v0.11+
        release naturally invalidates the cache rather than serving
        stale chrome to an upgraded user.
        """
        sw = (
            "// v0.10-P2-1 — minimal PWA service worker.\n"
            "const CACHE = 'pixcull-shell-v0.10';\n"
            "const SHELL = [\n"
            "  '/',\n"
            "  '/manifest.json',\n"
            "];\n"
            "self.addEventListener('install', (e) => {\n"
            "  e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL))\n"
            "    .then(() => self.skipWaiting()));\n"
            "});\n"
            "self.addEventListener('activate', (e) => {\n"
            "  e.waitUntil(\n"
            "    caches.keys().then(keys => Promise.all(\n"
            "      keys.filter(k => k !== CACHE)\n"
            "          .map(k => caches.delete(k))\n"
            "    )).then(() => self.clients.claim())\n"
            "  );\n"
            "});\n"
            "self.addEventListener('fetch', (e) => {\n"
            "  // Only intercept GETs; everything else (POSTs to\n"
            "  // /annotation, /sync/event/<token>/push, etc.) goes\n"
            "  // straight to the network so we don't replay stale\n"
            "  // mutations.\n"
            "  if (e.request.method !== 'GET') return;\n"
            "  const url = new URL(e.request.url);\n"
            "  // Network-first for the actual data; cache the\n"
            "  // shell only.\n"
            "  if (SHELL.includes(url.pathname)) {\n"
            "    e.respondWith(\n"
            "      caches.match(e.request).then(c =>\n"
            "        c || fetch(e.request).then(r => {\n"
            "          const copy = r.clone();\n"
            "          caches.open(CACHE).then(cc =>\n"
            "            cc.put(e.request, copy));\n"
            "          return r;\n"
            "        }))\n"
            "    );\n"
            "  }\n"
            "});\n"
        ).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type",
                          "application/javascript; charset=utf-8")
        self.send_header("Content-Length", str(len(sw)))
        # SW must be uncached so a refresh picks up the new one.
        self.send_header("Cache-Control",
                          "no-cache, no-store, must-revalidate")
        # Required by browsers: SW served from / must claim scope /
        self.send_header("Service-Worker-Allowed", "/")
        self.end_headers()
        self.wfile.write(sw)
        return True

    def _handle_analyze_post(self) -> None:
        # Read multipart payload. Limits live on the server instance so the
        # operator can tune them at startup without editing the source.
        max_bytes = self.server.max_upload_bytes  # type: ignore[attr-defined]
        max_files = self.server.max_upload_files  # type: ignore[attr-defined]

        clen = int(self.headers.get("Content-Length", "0") or "0")
        if clen <= 0:
            self._reject_upload(400, "upload is empty (no Content-Length)")
            return
        if clen > max_bytes:
            mb = clen / 1024 / 1024
            cap_mb = max_bytes / 1024 / 1024
            self._reject_upload(
                413,
                f"上传 {mb:.0f} MB 超过单次上限 {cap_mb:.0f} MB。"
                f"分批上传,或启动时加 --max-upload-mb {int(mb*1.2)} 提升上限。",
            )
            return

        # Disk-space pre-check: refuse if landing this upload would push
        # /tmp under the safety threshold. shutil.disk_usage queries the
        # filesystem of the path's mount; tmpfs / APFS both return real
        # numbers here.
        try:
            disk = shutil.disk_usage(_DEMO_ROOT)
            if disk.free - clen < _MIN_FREE_SPACE_AFTER_BYTES:
                free_mb = disk.free / 1024 / 1024
                need_mb = (clen + _MIN_FREE_SPACE_AFTER_BYTES) / 1024 / 1024
                self._reject_upload(
                    507,
                    f"磁盘空间不足: {_DEMO_ROOT.parent} 当前剩 {free_mb:.0f} MB,"
                    f"这次上传需要 ~{need_mb:.0f} MB。先去 /admin 清理或腾盘。",
                )
                return
        except OSError:
            pass  # disk_usage failure is non-fatal; let the upload try

        ctype = self.headers.get("Content-Type", "")
        if not ctype.startswith("multipart/form-data"):
            self._reject_upload(400, "expected multipart/form-data")
            return

        try:
            form = cgi.FieldStorage(
                fp=self.rfile,
                headers=self.headers,
                environ={
                    "REQUEST_METHOD": "POST",
                    "CONTENT_TYPE": ctype,
                    "CONTENT_LENGTH": str(clen),
                },
            )
        except Exception as exc:  # noqa: BLE001
            self._reject_upload(400, f"multipart parse failed: {exc}")
            return

        run_id = _new_run_id()
        run_root = _run_dir(run_id)
        input_dir = run_root / "input"
        output_dir = run_root / "output"
        input_dir.mkdir(parents=True, exist_ok=True)
        output_dir.mkdir(parents=True, exist_ok=True)

        # Save every uploaded file under the "files" field. Reject non-image
        # extensions silently — keep upload UX permissive but pipeline strict.
        ok_exts = {".jpg", ".jpeg", ".png", ".cr3", ".cr2", ".nef", ".arw", ".dng", ".tif", ".tiff"}
        n_saved = 0
        n_skipped_ext = 0
        if "files" in form:
            files = form["files"]
            items = files if isinstance(files, list) else [files]
            if len(items) > max_files:
                self._reject_upload(
                    413,
                    f"一次上传 {len(items)} 个文件超过上限 {max_files}。"
                    f"分批上传,或启动时加 --max-upload-files {len(items)+50}。",
                )
                # Note: we already drained the request body via FieldStorage;
                # nothing to clean up. Run dirs were created above but are
                # empty — leave them for /admin to sweep.
                return
            for item in items:
                fn = getattr(item, "filename", None) or ""
                if not fn:
                    continue
                # Strip any path components from the upload filename
                safe_name = Path(fn).name
                if Path(safe_name).suffix.lower() not in ok_exts:
                    n_skipped_ext += 1
                    continue
                dst = input_dir / safe_name
                with open(dst, "wb") as f:
                    f.write(item.file.read())
                n_saved += 1

        if n_saved == 0:
            hint = (
                f" {n_skipped_ext} 个文件因后缀不受支持被跳过(只接受 "
                f"{', '.join(sorted(e[1:] for e in ok_exts))})"
                if n_skipped_ext else ""
            )
            self._reject_upload(400, f"上传里没有可用图片。{hint}")
            return

        # V12.0 — license + quota gate
        from pixcull.license import check_quota, increment_usage
        ok, msg = check_quota(n_saved)
        if not ok:
            self._reject_upload(402, msg)
            return
        increment_usage(n_saved)

        rescorer_mode = self.server.rescorer_mode  # type: ignore[attr-defined]
        rescorer_path = self.server.rescorer_path  # type: ignore[attr-defined]
        vlm_mode = self.server.vlm_mode  # type: ignore[attr-defined]
        meta_mode = self.server.meta_mode  # type: ignore[attr-defined]

        _set_run(
            run_id,
            state="queued",
            mode="upload",
            done=0,
            total=n_saved,
            message=f"已收到 {n_saved} 张图,正在排队…",
            input_dir=str(input_dir),
            source_dir=str(input_dir),  # alias used by analyze_in_background
            output_dir=str(output_dir),
            n_uploaded=n_saved,
        )
        threading.Thread(
            target=_analyze_in_background,
            args=(run_id, rescorer_mode, rescorer_path, vlm_mode, meta_mode),
            daemon=True,
        ).start()

        body = json.dumps({"run_id": run_id, "n": n_saved}).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    # --- scan-local mode --------------------------------------------------
    def _handle_bucket_export(self, run_id: str) -> bool:
        """P-UX-22 — bundle a deliverable bucket into a single zip.

        Body: {name: str, filenames: [str, ...]}
          - name:      the bucket name (for the zip filename)
          - filenames: which photos to include (from the user's
                       localStorage bucket-assignment state)

        Response: {ok, zip_url, zip_filename, n_files, n_skipped}

        The user-side bucket state lives in localStorage so we don't
        store it on the server — every call is stateless and just
        zips the explicit filename list against the run's resolved
        on-disk source paths.
        """
        import io
        import zipfile

        run = _get_run(run_id) or _reload_run_from_disk(run_id)
        if run is None:
            self._reject_upload(404, "no such run"); return True

        clen = int(self.headers.get("Content-Length", "0") or "0")
        if clen <= 0 or clen > 1_000_000:
            self._reject_upload(400, "expected JSON body"); return True
        try:
            body_raw = self.rfile.read(clen).decode("utf-8")
            params = json.loads(body_raw)
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            self._reject_upload(400, f"JSON parse failed: {exc}"); return True

        bucket_name = str(params.get("name") or "bucket").strip()
        filenames   = params.get("filenames") or []
        if not isinstance(filenames, list) or not filenames:
            self._reject_upload(400, "filenames must be a non-empty list")
            return True

        # Sanitize the bucket name for the zip filename
        safe_name = "".join(c if c.isalnum() or c in "-_." else "_"
                            for c in bucket_name)[:64] or "bucket"

        # Resolve each filename to an on-disk source. We accept either
        # the run's manifest (scan mode) or input_dir (upload mode).
        zip_buf = io.BytesIO()
        n_files = 0
        n_skipped = 0
        with zipfile.ZipFile(zip_buf, "w", zipfile.ZIP_DEFLATED, allowZip64=False) as zf:
            for fn in filenames:
                if not isinstance(fn, str):
                    n_skipped += 1
                    continue
                src = _resolve_image_source(run, fn)
                if src is None or not src.is_file():
                    n_skipped += 1
                    continue
                try:
                    zf.write(src, arcname=fn)
                    n_files += 1
                except OSError:
                    n_skipped += 1
        zip_bytes = zip_buf.getvalue()

        # Stash the zip under the run's output_dir so /tmp_zip can
        # serve it; same pattern V1.2's XMP-export uses.
        out_dir = Path(run["output_dir"])
        zip_path = out_dir / f"bucket-{safe_name}-{int(time.time())}.zip"
        zip_path.write_bytes(zip_bytes)

        body = _safe_dumps({
            "ok":            True,
            "zip_url":       f"/tmp_zip/{run_id}/{zip_path.name}",
            "zip_filename":  f"{safe_name}.zip",
            "n_files":       n_files,
            "n_skipped":     n_skipped,
            "size_bytes":    len(zip_bytes),
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)
        return True

    # ============================================================
    # v0.7-P1-4 — client delivery share link.
    # POST /share/<run_id>/issue            → mint a new token
    # GET  /share/<run_id>/<token>          → render the read-only
    #                                          delivery page
    # Tokens are persisted to <output_dir>/share_tokens.json so they
    # survive server restarts. The page shows only photos the user
    # marked "keep" (decision == "keep") plus a header with
    # photographer + client labels. Clients open the URL in any
    # browser — no PixCull install required.
    # ============================================================
    def _share_token_path(self, run: dict):
        return Path(run["output_dir"]) / "share_tokens.json"

    def _read_share_tokens(self, run: dict) -> dict:
        p = self._share_token_path(run)
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}

    def _write_share_tokens(self, run: dict, data: dict) -> None:
        p = self._share_token_path(run)
        try:
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(json.dumps(data, ensure_ascii=False, indent=2),
                         encoding="utf-8")
        except OSError as exc:
            _dbg("share/write_tokens", exc, str(p))

    def _handle_share_issue(self, run_id: str) -> None:
        """POST /share/<run_id>/issue
        body: {photographer?, client?, expires_days?}
        → {ok, token, url}
        """
        import secrets

        run = _get_run(run_id) or _reload_run_from_disk(run_id)
        if run is None:
            self.send_error(404, "no such run")
            return
        try:
            n = int(self.headers.get("Content-Length") or "0")
        except ValueError:
            n = 0
        raw = self.rfile.read(n) if n > 0 else b""
        try:
            body = json.loads(raw or b"{}")
        except ValueError:
            body = {}
        if not isinstance(body, dict):
            body = {}
        token = secrets.token_urlsafe(16)
        record = {
            "token":        token,
            "photographer": str(body.get("photographer") or "").strip()[:80],
            "client":       str(body.get("client") or "").strip()[:80],
            # v0.9-P0-5 — event metadata for the portfolio hero block.
            # Optional; defaults to "" + auto-derived date range.
            "event":        str(body.get("event") or "").strip()[:120],
            "event_date":   str(body.get("event_date") or "").strip()[:30],
            "contact":      str(body.get("contact") or "").strip()[:120],
            "issued_at":    datetime.now(timezone.utc).isoformat(),
        }
        try:
            days = int(body.get("expires_days") or 0)
        except (TypeError, ValueError):
            days = 0
        if days > 0:
            from datetime import timedelta
            record["expires_at"] = (
                datetime.now(timezone.utc) + timedelta(days=days)
            ).isoformat()
        tokens = self._read_share_tokens(run)
        tokens[token] = record
        self._write_share_tokens(run, tokens)
        payload = {
            "ok":   True,
            "token": token,
            "url":  f"/share/{run_id}/{token}",
        }
        body_bytes = json.dumps(payload).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body_bytes)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body_bytes)

    def _serve_share_page(self, rel: str) -> None:
        """GET /share/<run_id>/<token> → minimal client-delivery HTML.

        The page is self-contained (inline CSS + <img> referring back to
        /thumb/<run>/<file>). The token is validated against the
        on-disk share_tokens.json; expired or unknown tokens 404.
        """
        rel = unquote(rel).strip("/")
        parts = rel.split("/", 1)
        if len(parts) != 2:
            self.send_error(400, "expected /share/<run_id>/<token>")
            return
        run_id, token = parts
        run = _get_run(run_id) or _reload_run_from_disk(run_id)
        if run is None:
            self.send_error(404, "no such run")
            return
        tokens = self._read_share_tokens(run)
        rec = tokens.get(token)
        if not rec:
            self.send_error(404, "share link not found or revoked")
            return
        # Optional expiry check
        exp = rec.get("expires_at")
        if exp:
            try:
                exp_dt = datetime.fromisoformat(exp)
                if exp_dt < datetime.now(timezone.utc):
                    self.send_error(410, "share link expired")
                    return
            except ValueError:
                pass

        # Load keeps only from scores.csv. We deliberately filter
        # *server-side* so a client can't toggle off the filter from
        # the page (the share contract is "you see what I picked").
        try:
            keeps, meta = self._share_collect_keeps(run)
        except Exception as exc:
            _dbg("share/collect_keeps", exc, run_id)
            self.send_error(500, "failed to read run")
            return

        # Read previously-saved client comments (one append-only file
        # per run; the share page surfaces them under the comment box).
        comments = self._share_read_comments(run)

        photographer = rec.get("photographer") or ""
        client       = rec.get("client") or ""
        event        = rec.get("event") or ""
        event_date   = rec.get("event_date") or ""
        contact      = rec.get("contact") or ""
        html = self._render_share_html(
            run_id, token, photographer, client,
            event, event_date, contact, keeps, meta, comments,
        )
        body = html.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        # Don't index the page; keep it private-by-obscurity (token).
        self.send_header("X-Robots-Tag", "noindex, nofollow")
        self.send_header("Cache-Control", "private, max-age=60")
        self.end_headers()
        self.wfile.write(body)

    def _share_collect_keeps(self, run: dict) -> tuple[list, dict]:
        """Return (rich_keep_rows, run_meta) for the share page.

        v0.9-P0-5 — was previously ``[(filename, score), ...]``.  The
        portfolio redesign needs chapter grouping + metadata tiles +
        date range, so we now return:

          keeps: [{filename, score, scene, wedding_moment, datetime,
                   chapter}, ...]
          meta:  {n_keeps, n_total, ratio, date_first, date_last,
                  scenes: {name: count}, has_chapters: bool}

        Chapter resolves to:
          row["wedding_moment"] if present and non-empty
            (e.g., "ceremony", "vows", "rings", "kiss"),
          else row["scene"] mapped to a friendly bucket,
          else "其他".

        We also collapse annotation/* JSON-on-disk overrides (legacy
        layout) AND annotations.jsonl last-line wins (v0.5+ canonical),
        so a photo the user manually marked keep after the original
        run still shows up.
        """
        import csv as _csv

        scores_path = Path(run["output_dir"]) / "scores.csv"
        if not scores_path.exists():
            return [], {
                "n_keeps": 0, "n_total": 0, "ratio": 0.0,
                "date_first": "", "date_last": "",
                "scenes": {}, "has_chapters": False,
            }

        # Annotation overrides — both layouts.
        ann_overrides: dict[str, str] = {}
        ann_dir = Path(run["output_dir"]) / "annotation"
        if ann_dir.is_dir():
            for f in ann_dir.glob("*.json"):
                try:
                    d = json.loads(f.read_text(encoding="utf-8"))
                    fn = f.stem
                    dec = d.get("decision")
                    if dec in {"keep", "maybe", "cull"}:
                        ann_overrides[fn] = dec
                except (OSError, ValueError):
                    continue
        ann_jsonl = Path(run["output_dir"]) / "annotations.jsonl"
        if ann_jsonl.exists():
            try:
                with open(ann_jsonl, "r", encoding="utf-8") as fh:
                    for line in fh:
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            d = json.loads(line)
                        except ValueError:
                            continue
                        fn = d.get("filename")
                        lbl = d.get("overall_label") or d.get("decision")
                        if fn and lbl in {"keep", "maybe", "cull"}:
                            ann_overrides[fn] = lbl
            except OSError:
                pass

        # Friendly Chinese chapter labels for common scenes / moments.
        _MOMENT_ZH = {
            "ceremony":  "💒 仪式 · Ceremony",
            "vows":      "📝 誓词 · Vows",
            "rings":     "💍 戒指 · Rings",
            "kiss":      "💋 亲吻 · Kiss",
            "entrance":  "🚪 入场 · Entrance",
            "speeches":  "🎤 致词 · Speeches",
            "first_dance": "💃 第一支舞 · First Dance",
            "cake":      "🎂 切蛋糕 · Cake",
            "group":     "👥 合影 · Group Photo",
            "detail":    "🔍 细节 · Details",
            "candid":    "📸 抓拍 · Candid",
            "portrait":  "👤 人像 · Portrait",
        }
        _SCENE_ZH = {
            "landscape":   "🏞 风光 · Landscape",
            "wildlife":    "🦅 野生 · Wildlife",
            "portrait":    "👤 人像 · Portrait",
            "wedding":     "💒 婚礼 · Wedding",
            "sports":      "⚽ 运动 · Sports",
            "street":      "🚶 街拍 · Street",
            "architecture":"🏛 建筑 · Architecture",
            "night":       "🌃 夜景 · Night",
            "macro":       "🔬 微距 · Macro",
            "abstract":    "🎨 抽象 · Abstract",
            "stilllife":   "🍎 静物 · Still Life",
            "documentary": "📰 纪实 · Documentary",
        }

        keeps: list = []
        scenes: dict[str, int] = {}
        dates: list[str] = []
        n_total = 0
        has_chapters = False
        with open(scores_path, "r", encoding="utf-8-sig", newline="") as fh:
            for row in _csv.DictReader(fh):
                n_total += 1
                fn = row.get("filename") or ""
                if not fn:
                    continue
                dec = ann_overrides.get(fn) or row.get("decision") or ""
                if dec != "keep":
                    continue
                try:
                    score = float(row.get("score_final") or 0)
                except ValueError:
                    score = 0.0
                scene = (row.get("scene") or "").strip()
                wmoment = (row.get("wedding_moment") or "").strip()
                dt = (row.get("datetime") or "").strip()
                if dt:
                    dates.append(dt)
                # Chapter: prefer wedding_moment, fall back to scene.
                if wmoment:
                    chapter = _MOMENT_ZH.get(wmoment, wmoment)
                    has_chapters = True
                elif scene:
                    chapter = _SCENE_ZH.get(scene, scene)
                else:
                    chapter = "📷 其他 · Other"
                if scene:
                    scenes[scene] = scenes.get(scene, 0) + 1
                keeps.append({
                    "filename": fn,
                    "score":    score,
                    "scene":    scene,
                    "wedding_moment": wmoment,
                    "datetime": dt,
                    "chapter":  chapter,
                })
        # Sort: best-first within each chapter; chapter ordering follows
        # first-appearance order (preserves wedding chronology).
        keeps.sort(key=lambda r: -r["score"])
        dates.sort()
        meta = {
            "n_keeps":   len(keeps),
            "n_total":   n_total,
            "ratio":     round(len(keeps) / n_total, 4) if n_total else 0.0,
            "date_first": dates[0][:10] if dates else "",
            "date_last":  dates[-1][:10] if dates else "",
            "scenes":     scenes,
            "has_chapters": has_chapters,
        }
        return keeps, meta

    # v0.9-P0-5 — client comment box.  Clients drop short feedback
    # ("re-pick #007 + #023 please") that the photographer reads from
    # within /results.  Stored append-only so audit trail survives
    # even if the photographer later revokes the token.
    def _share_comments_path(self, run: dict) -> Path:
        return Path(run["output_dir"]) / "share_comments.json"

    def _share_read_comments(self, run: dict) -> list[dict]:
        p = self._share_comments_path(run)
        if not p.exists():
            return []
        try:
            data = json.loads(p.read_text("utf-8"))
        except (OSError, ValueError):
            return []
        return data if isinstance(data, list) else []

    def _handle_share_comment(
        self, run_id: str, token: str
    ) -> None:
        """POST /share/<run_id>/<token>/comment  body: {body, author?}
        → {ok, n_comments}  (idempotent on identical (token, body, author)
        within 60s — guards against double-submit on slow networks).
        """
        run = _get_run(run_id) or _reload_run_from_disk(run_id)
        if run is None:
            self.send_error(404, "no such run")
            return
        tokens = self._read_share_tokens(run)
        rec = tokens.get(token)
        if not rec:
            self.send_error(404, "share link not found")
            return
        try:
            n = int(self.headers.get("Content-Length") or "0")
        except ValueError:
            n = 0
        raw = self.rfile.read(n) if n > 0 else b""
        try:
            body = json.loads(raw or b"{}")
        except ValueError:
            body = {}
        if not isinstance(body, dict):
            body = {}
        text = str(body.get("body") or "").strip()[:2000]
        if not text:
            self.send_error(400, "missing 'body'")
            return
        author = str(body.get("author") or rec.get("client") or "").strip()[:80]
        now = datetime.now(timezone.utc).isoformat()
        new_entry = {
            "ts":     now,
            "author": author,
            "body":   text,
            "token":  token,
        }
        comments = self._share_read_comments(run)
        # Idempotency guard (double-submit)
        from datetime import timedelta
        cutoff = datetime.now(timezone.utc) - timedelta(seconds=60)
        for c in comments[-5:]:   # only scan tail
            try:
                ts_dt = datetime.fromisoformat(c.get("ts", ""))
            except ValueError:
                continue
            if (c.get("token") == token and c.get("body") == text
                    and c.get("author") == author and ts_dt >= cutoff):
                self._json_ok({"ok": True, "n_comments": len(comments),
                                "duplicate": True})
                return
        comments.append(new_entry)
        try:
            self._share_comments_path(run).write_text(
                json.dumps(comments, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except OSError as exc:
            _dbg("share/comment_write", exc, run_id)
            self.send_error(500, "failed to save comment")
            return
        self._json_ok({"ok": True, "n_comments": len(comments)})

    def _render_share_html(
        self,
        run_id: str,
        token: str,
        photographer: str,
        client: str,
        event: str,
        event_date: str,
        contact: str,
        keeps: list,
        meta: dict,
        comments: list,
    ) -> str:
        """v0.9-P0-5 — portfolio-style client delivery page.

        Layout:
          1. Workspace bar (PixCull brand + photographer + event)
          2. Hero block (event name in serif, date, photographer/client)
          3. Metadata tiles (4 stat tiles in brand gradient)
          4. Chapter sections (auto-grouped by wedding_moment / scene)
          5. Comment box + recent client comments
          6. Signature footer (photographer + contact + Powered by)
          + Inline JS lightbox (click any card → full-screen view + nav)
        """
        from html import escape as _esc

        # --- Group keeps by chapter, preserve first-appearance order ---
        chapter_order: list[str] = []
        chapter_keeps: dict[str, list[dict]] = {}
        for r in keeps:
            ch = r.get("chapter") or "📷 其他 · Other"
            if ch not in chapter_keeps:
                chapter_keeps[ch] = []
                chapter_order.append(ch)
            chapter_keeps[ch].append(r)

        # Build URLs once
        def _thumb_url(fn: str) -> str:
            return f"/thumb/{run_id}/{_esc(fn)}?w=600"

        def _full_url(fn: str) -> str:
            return f"/full/{run_id}/{_esc(fn)}"

        # --- Card HTML for one filename ---
        def _card(r: dict, idx: int) -> str:
            fn = r["filename"]
            return (
                f'<a class="ph-card" data-idx="{idx}" '
                f'href="{_full_url(fn)}" target="_blank" rel="noopener">'
                f'<img loading="lazy" src="{_thumb_url(fn)}" alt="{_esc(fn)}">'
                f'<div class="ph-cap"><span class="ph-fn">{_esc(fn)}</span></div>'
                f'</a>'
            )

        # --- Chapter sections ---
        all_idx = 0
        chapter_sections: list[str] = []
        flat_filenames: list[str] = []  # for lightbox nav order
        if not keeps:
            chapter_sections.append(
                '<div class="ph-empty">'
                '摄影师还没有挑出片 — 请稍后再来。'
                '</div>'
            )
        else:
            for ch in chapter_order:
                rows = chapter_keeps[ch]
                cards = []
                for r in rows:
                    cards.append(_card(r, all_idx))
                    flat_filenames.append(r["filename"])
                    all_idx += 1
                chapter_sections.append(
                    f'<section class="ph-chapter">'
                    f'  <header class="ph-ch-header">'
                    f'    <h2 class="ph-ch-title">{_esc(ch)}</h2>'
                    f'    <span class="ph-ch-count">{len(rows)} 张</span>'
                    f'  </header>'
                    f'  <div class="ph-grid">{chr(10).join(cards)}</div>'
                    f'</section>'
                )
        all_cards_json = json.dumps(flat_filenames, ensure_ascii=False)

        # --- Hero / metadata ---
        event_title = event or (
            f"{client}'s gallery" if client else "精选交付"
        )
        date_line = ""
        if event_date:
            date_line = event_date
        elif meta.get("date_first") and meta.get("date_last"):
            if meta["date_first"] == meta["date_last"]:
                date_line = meta["date_first"]
            else:
                date_line = f"{meta['date_first']} → {meta['date_last']}"
        ratio_pct = f"{meta.get('ratio', 0) * 100:.1f}%"

        # --- Comments list (newest first) ---
        comments_html = ""
        if comments:
            items = []
            for c in reversed(comments[-50:]):  # cap at last 50
                ts = (c.get("ts") or "")[:16].replace("T", " ")
                a = _esc(c.get("author") or "客户")
                t = _esc(c.get("body") or "").replace("\n", "<br>")
                items.append(
                    f'<li class="ph-comment">'
                    f'<div class="ph-comment-head">'
                    f'  <span class="ph-comment-author">{a}</span>'
                    f'  <span class="ph-comment-ts">{_esc(ts)}</span>'
                    f'</div>'
                    f'<div class="ph-comment-body">{t}</div>'
                    f'</li>'
                )
            comments_html = (
                f'<div class="ph-comment-list-wrap">'
                f'  <h3 class="ph-comment-list-title">'
                f'    最近 {len(comments)} 条留言'
                f'  </h3>'
                f'  <ul class="ph-comment-list">{"".join(items)}</ul>'
                f'</div>'
            )

        contact_html = ""
        if contact:
            contact_html = (
                f'<div class="ph-sig-contact">'
                f'  {_esc(contact)}'
                f'</div>'
            )

        return f"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>{_esc(event_title)} · {_esc(photographer or "PixCull")}</title>
{_THEME_BOOT_HTML}
<style>
{_DESIGN_TOKENS_CSS}
  /* v2.37 — the client delivery page now runs on the SAME design system
     as the rest of the product.
     Until now it carried a third, unrelated palette (--bg #0a0a1e,
     --bg-soft #1a1230 — purple/navy) plus a hard `color-scheme: dark`,
     which meant the one surface a photographer actually sends to their
     client looked like a different piece of software, and could never
     follow the light theme.  Every variable it uses is in the shared
     set, so adopting it is a straight deletion, not a redesign.
     Only the page-specific spring curve stays local. */
  :root {{
    --ease-out: cubic-bezier(0.34, 1.56, 0.64, 1);
  }}
  *,*::before,*::after {{ box-sizing: border-box; }}
  html,body {{ margin: 0; padding: 0; background: var(--bg); color: var(--fg);
    font-family: var(--font-sans); -webkit-font-smoothing: antialiased;
    line-height: 1.5; }}

  /* ===== Workspace bar (sticky brand + photographer) ===== */
  .ph-bar {{
    position: sticky; top: 0; z-index: 5;
    display: flex; align-items: center; gap: 12px;
    padding: 10px 24px;
    background: color-mix(in srgb, var(--chrome) 78%, transparent);
    backdrop-filter: var(--glass-filter);
    -webkit-backdrop-filter: var(--glass-filter);
    box-shadow: var(--glass-edge);
    border-bottom: 1px solid var(--border);
    font-size: 13px;
  }}
  .ph-bar-logo {{ width: 24px; height: 24px; display: flex; }}
  .ph-bar-mark {{ font-weight: 700; letter-spacing: -0.01em; color: var(--fg); }}
  .ph-bar-mark .grad {{
    background: var(--brand-gradient);
    -webkit-background-clip: text; background-clip: text;
    color: transparent;
  }}
  .ph-bar-spacer {{ flex: 1; }}
  .ph-bar-pp {{ color: var(--muted); font-size: 12px; }}
  .ph-bar-pp b {{ color: var(--fg-2); font-weight: 600; margin-right: 4px; }}

  /* ===== Hero block ===== */
  .ph-hero {{
    padding: 80px 24px 60px; text-align: center;
    position: relative; overflow: hidden;
  }}
  .ph-hero::before {{
    /* Soft brand-gradient glow behind the title */
    content: ""; position: absolute; left: 50%; top: 30%;
    width: 720px; height: 480px; transform: translate(-50%, -50%);
    background: var(--brand-gradient); opacity: 0.18;
    filter: blur(80px); pointer-events: none;
  }}
  .ph-hero-event {{
    margin: 0 0 14px; font-family: var(--font-serif);
    font-size: clamp(36px, 6vw, 64px); font-weight: 700;
    letter-spacing: -0.01em; line-height: 1.1;
    background: linear-gradient(180deg, var(--fg) 0%, var(--muted) 100%);
    -webkit-background-clip: text; background-clip: text;
    color: transparent; position: relative;
  }}
  .ph-hero-meta {{
    color: var(--muted); font-size: 14px; letter-spacing: 0.04em;
    text-transform: uppercase; position: relative;
  }}
  .ph-hero-meta b {{ color: var(--fg-2); font-weight: 600; }}
  .ph-hero-meta .sep {{ opacity: 0.4; margin: 0 12px; }}

  /* ===== Stat tiles ===== */
  .ph-tiles {{
    display: grid; grid-template-columns: repeat(4, 1fr);
    gap: 12px; max-width: 880px; margin: 30px auto 60px;
    padding: 0 24px;
  }}
  .ph-tile {{
    background: var(--bg-card);
    border: 1px solid var(--border);
    border-radius: 14px;
    padding: 18px 16px;
    position: relative; overflow: hidden;
  }}
  .ph-tile::before {{
    /* Soft gradient wash bottom-right */
    content: ""; position: absolute; right: -20%; bottom: -50%;
    width: 200%; height: 200%;
    background: var(--brand-gradient-soft);
    opacity: 0.6; pointer-events: none;
  }}
  .ph-tile-v {{
    font-family: var(--font-serif); font-weight: 700;
    font-size: 36px; line-height: 1; letter-spacing: -0.01em;
    background: var(--brand-gradient);
    -webkit-background-clip: text; background-clip: text;
    color: transparent;
    font-variant-numeric: tabular-nums lining-nums;
    position: relative;
  }}
  .ph-tile-k {{
    color: var(--muted); font-size: 11.5px; margin-top: 4px;
    letter-spacing: 0.05em; text-transform: uppercase;
    position: relative;
  }}

  /* ===== Chapter sections ===== */
  main.ph-main {{ max-width: 1280px; margin: 0 auto; padding: 0 24px 40px; }}
  .ph-chapter {{ margin-bottom: 48px; }}
  .ph-ch-header {{
    display: flex; align-items: baseline; gap: 14px;
    padding: 0 0 14px; margin-bottom: 16px;
    border-bottom: 1px solid var(--border);
  }}
  .ph-ch-title {{
    margin: 0; font-family: var(--font-serif); font-weight: 700;
    font-size: 22px; letter-spacing: -0.01em; color: var(--fg);
  }}
  .ph-ch-count {{
    color: var(--muted); font-size: 12px;
    letter-spacing: 0.04em; text-transform: uppercase;
  }}
  .ph-grid {{
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
    gap: 12px;
  }}
  .ph-card {{
    display: block; text-decoration: none; color: inherit;
    background: var(--bg-card); border: 1px solid var(--border);
    border-radius: 10px; overflow: hidden;
    transition: transform 200ms var(--ease-out),
                border-color 200ms var(--ease-out),
                box-shadow 200ms var(--ease-out);
    position: relative;
  }}
  .ph-card:hover {{
    transform: translateY(-3px);
    border-color: var(--focus-ring);
    box-shadow: 0 12px 28px var(--accent-glow);
  }}
  .ph-card img {{
    display: block; width: 100%; aspect-ratio: 3/2;
    object-fit: cover; background: var(--surface-3);
  }}
  .ph-cap {{
    padding: 8px 12px; font-size: 11px; color: var(--muted);
    border-top: 1px solid var(--border);
  }}
  .ph-fn {{
    font-family: ui-monospace, "SF Mono", Menlo, monospace;
    white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
    display: inline-block; max-width: 100%;
  }}
  .ph-empty {{
    text-align: center; color: var(--muted); padding: 80px 12px;
    font-size: 15px;
  }}

  /* ===== Comment box ===== */
  .ph-comments {{
    max-width: 720px; margin: 40px auto 60px; padding: 0 24px;
  }}
  .ph-comment-form {{
    background: var(--bg-card); border: 1px solid var(--border);
    border-radius: 14px; padding: 18px 18px 14px;
  }}
  .ph-comment-form h3 {{
    margin: 0 0 8px; font-family: var(--font-serif); font-weight: 700;
    font-size: 19px; color: var(--fg);
  }}
  .ph-comment-form p {{
    color: var(--muted); font-size: 12.5px; margin: 0 0 12px;
  }}
  .ph-comment-form textarea {{
    width: 100%; min-height: 84px; resize: vertical;
    background: var(--bg); color: var(--fg);
    border: 1px solid var(--border); border-radius: 8px;
    padding: 10px 12px; font: inherit; font-size: 13.5px;
    transition: border-color 160ms var(--ease-out);
  }}
  .ph-comment-form textarea:focus {{
    outline: 0; border-color: var(--accent);
    box-shadow: 0 0 0 3px var(--accent-soft);
  }}
  .ph-comment-form-row {{
    display: flex; gap: 10px; margin-top: 10px;
  }}
  .ph-comment-form input[name="author"] {{
    flex: 1; background: var(--bg); color: var(--fg);
    border: 1px solid var(--border); border-radius: 8px;
    padding: 8px 12px; font: inherit; font-size: 12.5px;
    min-width: 0;
  }}
  .ph-comment-form button {{
    padding: 0 18px; font-size: 13px; font-weight: 600;
    background: var(--brand-gradient); color: var(--on-accent, #161616);
    border: 0; border-radius: 8px; cursor: pointer;
    box-shadow: 0 4px 14px var(--accent-glow);
    transition: filter 160ms var(--ease-out),
                transform 160ms var(--ease-out);
  }}
  .ph-comment-form button:hover {{ filter: brightness(1.08); transform: translateY(-1px); }}
  .ph-comment-form button:disabled {{ filter: grayscale(0.4) brightness(0.6); cursor: not-allowed; }}
  .ph-comment-form-status {{
    font-size: 11.5px; color: var(--muted); margin-top: 8px; min-height: 16px;
  }}
  .ph-comment-form-status.ok {{ color: var(--c-ok, var(--keep)); }}
  .ph-comment-form-status.err {{ color: var(--c-danger); }}
  .ph-comment-list-wrap {{ margin-top: 26px; }}
  .ph-comment-list-title {{
    margin: 0 0 12px; font-size: 12.5px; color: var(--muted);
    letter-spacing: 0.05em; text-transform: uppercase; font-weight: 600;
  }}
  .ph-comment-list {{ list-style: none; margin: 0; padding: 0; }}
  .ph-comment {{
    background: var(--surface-2);
    border: 1px solid var(--border); border-radius: 10px;
    padding: 12px 14px; margin-bottom: 8px;
  }}
  .ph-comment-head {{
    display: flex; align-items: baseline; gap: 10px;
    margin-bottom: 4px; font-size: 12px;
  }}
  .ph-comment-author {{ color: var(--fg-2); font-weight: 600; }}
  .ph-comment-ts {{ color: var(--muted); font-family: ui-monospace, monospace; font-size: 11px; }}
  .ph-comment-body {{ color: var(--fg); font-size: 13.5px; line-height: 1.55; }}

  /* ===== Signature footer ===== */
  footer.ph-foot {{
    border-top: 1px solid var(--border);
    padding: 40px 24px 28px; text-align: center;
    color: var(--muted); font-size: 12px; letter-spacing: 0.04em;
  }}
  .ph-sig {{ margin-bottom: 18px; }}
  .ph-sig-name {{
    font-family: var(--font-serif); font-weight: 700;
    font-size: 22px; color: var(--fg-2);
    letter-spacing: 0; text-transform: none; margin-bottom: 4px;
  }}
  .ph-sig-contact {{
    color: var(--muted); font-size: 11.5px; letter-spacing: 0.02em;
  }}
  .ph-powered a {{
    background: var(--brand-gradient);
    -webkit-background-clip: text; background-clip: text;
    color: transparent;
    text-decoration: none; font-weight: 600;
  }}

  /* ===== Lightbox ===== */
  .ph-lb {{
    position: fixed; inset: 0; z-index: 50;
    background: rgba(0,0,0,0.94);
    display: none; align-items: center; justify-content: center;
    backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px);
  }}
  .ph-lb.show {{ display: flex; }}
  .ph-lb-img {{
    max-width: 95vw; max-height: 88vh;
    object-fit: contain; border-radius: 6px;
    box-shadow: 0 24px 60px rgba(0,0,0,0.7);
  }}
  .ph-lb-caption {{
    position: absolute; bottom: 18px; left: 50%; transform: translateX(-50%);
    color: var(--muted); font-size: 12px;
    font-family: ui-monospace, monospace;
  }}
  .ph-lb-nav {{
    position: absolute; top: 50%; transform: translateY(-50%);
    width: 44px; height: 44px; border-radius: 50%;
    background: rgba(255,255,255,0.08);
    border: 1px solid rgba(255,255,255,0.18);
    color: #fff; font-size: 20px; cursor: pointer;
    display: flex; align-items: center; justify-content: center;
    transition: background 160ms var(--ease-out);
  }}
  .ph-lb-nav:hover {{ background: rgba(255,255,255,0.18); }}
  .ph-lb-prev {{ left: 18px; }}
  .ph-lb-next {{ right: 18px; }}
  .ph-lb-close {{
    position: absolute; top: 16px; right: 16px;
    width: 36px; height: 36px; border-radius: 50%;
    background: rgba(255,255,255,0.06);
    border: 1px solid rgba(255,255,255,0.15);
    color: #fff; cursor: pointer; font-size: 18px;
    display: flex; align-items: center; justify-content: center;
  }}

  @media (max-width: 640px) {{
    .ph-bar {{ padding: 8px 14px; font-size: 12px; }}
    .ph-bar-pp {{ display: none; }}
    .ph-hero {{ padding: 50px 14px 40px; }}
    .ph-tiles {{ grid-template-columns: repeat(2, 1fr); gap: 8px;
                  margin: 18px auto 36px; padding: 0 14px; }}
    .ph-tile {{ padding: 12px 12px; }}
    .ph-tile-v {{ font-size: 26px; }}
    main.ph-main {{ padding: 0 14px 20px; }}
    .ph-grid {{ grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 8px; }}
    .ph-ch-title {{ font-size: 17px; }}
    .ph-comments {{ padding: 0 14px; }}
    .ph-lb-nav {{ width: 36px; height: 36px; font-size: 16px; }}
  }}
</style>
</head>
<body>

  <!-- ===== Sticky brand bar ===== -->
  <div class="ph-bar">
    <span class="ph-bar-logo" aria-hidden="true">
      <svg viewBox="0 0 24 24" fill="none">
        <defs>
          <linearGradient id="pcSharePg" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%"   stop-color="#d5b584"/>
            <stop offset="100%" stop-color="#93743f"/>
          </linearGradient>
        </defs>
        <circle cx="4"  cy="5"  r="1.6" fill="currentColor" opacity="0.32"/>
        <circle cx="20" cy="6"  r="1.4" fill="currentColor" opacity="0.28"/>
        <circle cx="3"  cy="19" r="1.8" fill="currentColor" opacity="0.30"/>
        <circle cx="21" cy="20" r="1.3" fill="currentColor" opacity="0.28"/>
        <circle cx="12" cy="12" r="7"  fill="url(#pcSharePg)"/>
      </svg>
    </span>
    <span class="ph-bar-mark">Pix<span class="grad">Cull</span></span>
    <span class="ph-bar-spacer"></span>
    {f'<span class="ph-bar-pp"><b>摄影师</b>{_esc(photographer)}</span>' if photographer else ''}
  </div>

  <!-- ===== Hero ===== -->
  <section class="ph-hero">
    <h1 class="ph-hero-event">{_esc(event_title)}</h1>
    <p class="ph-hero-meta">
      {f'<b>{_esc(photographer)}</b>' if photographer else ''}
      {('<span class="sep">·</span>' if photographer and client else '')}
      {f'<b>{_esc(client)}</b>' if client else ''}
      {('<span class="sep">·</span>' if (photographer or client) and date_line else '')}
      {f'<b>{_esc(date_line)}</b>' if date_line else ''}
    </p>
  </section>

  <!-- ===== Metadata tiles ===== -->
  <div class="ph-tiles">
    <div class="ph-tile">
      <div class="ph-tile-v">{meta.get('n_keeps', 0)}</div>
      <div class="ph-tile-k">精选</div>
    </div>
    <div class="ph-tile">
      <div class="ph-tile-v">{meta.get('n_total', 0)}</div>
      <div class="ph-tile-k">原片</div>
    </div>
    <div class="ph-tile">
      <div class="ph-tile-v">{ratio_pct}</div>
      <div class="ph-tile-k">入选率</div>
    </div>
    <div class="ph-tile">
      <div class="ph-tile-v">{len(chapter_order)}</div>
      <div class="ph-tile-k">{'章节' if meta.get('has_chapters') else '场景'}</div>
    </div>
  </div>

  <!-- ===== Chapter sections (or empty state) ===== -->
  <main class="ph-main">
    {chr(10).join(chapter_sections)}
  </main>

  <!-- ===== Comment box + recent comments ===== -->
  <div class="ph-comments">
    <form class="ph-comment-form" id="phCommentForm" action="#">
      <h3>留言 / 反馈</h3>
      <p>有想重选 / 重修的照片?在这里告诉摄影师即可,留言会直接出现在他的 PixCull 工作台。</p>
      <textarea name="body" placeholder="例: IMG_023 + IMG_087 可以换张笑得更自然的吗?谢谢!"
                maxlength="2000" required></textarea>
      <div class="ph-comment-form-row">
        <input name="author" placeholder="您的称呼(可选)"
               value="{_esc(client)}" maxlength="80"/>
        <button type="submit" id="phCommentSubmit">发送留言</button>
      </div>
      <div class="ph-comment-form-status" id="phCommentStatus" aria-live="polite"></div>
    </form>
    {comments_html}
  </div>

  <!-- ===== Signature footer ===== -->
  <footer class="ph-foot">
    {f'<div class="ph-sig"><div class="ph-sig-name">{_esc(photographer)}</div>{contact_html}</div>' if photographer else ''}
    <div class="ph-powered">
      Powered by
      <a href="https://github.com/ChrisChen667788/pixcull" rel="noopener" target="_blank">PixCull</a>
      — 本地优先 AI 摄影选片
    </div>
  </footer>

  <!-- ===== Lightbox (inline, vanilla JS) ===== -->
  <div class="ph-lb" id="phLb" role="dialog" aria-hidden="true">
    <button class="ph-lb-close" id="phLbClose" type="button" aria-label="关闭">✕</button>
    <button class="ph-lb-nav ph-lb-prev" id="phLbPrev" type="button" aria-label="上一张">‹</button>
    <img class="ph-lb-img" id="phLbImg" alt=""/>
    <button class="ph-lb-nav ph-lb-next" id="phLbNext" type="button" aria-label="下一张">›</button>
    <div class="ph-lb-caption" id="phLbCaption"></div>
  </div>

<script>
(function() {{
  // ----- Lightbox: click any card opens full-screen viewer -----
  const FNS = {all_cards_json};
  const RUN_ID = {json.dumps(run_id)};
  const lb       = document.getElementById("phLb");
  const lbImg    = document.getElementById("phLbImg");
  const lbCap    = document.getElementById("phLbCaption");
  const lbClose  = document.getElementById("phLbClose");
  const lbPrev   = document.getElementById("phLbPrev");
  const lbNext   = document.getElementById("phLbNext");
  let curIdx = -1;
  function open(i) {{
    if (i < 0 || i >= FNS.length) return;
    curIdx = i;
    const fn = FNS[i];
    lbImg.src = `/full/${{RUN_ID}}/${{encodeURIComponent(fn)}}`;
    lbCap.textContent = `${{fn}} · ${{i + 1}} / ${{FNS.length}}`;
    lb.classList.add("show");
    lb.setAttribute("aria-hidden", "false");
  }}
  function close() {{
    lb.classList.remove("show");
    lb.setAttribute("aria-hidden", "true");
    lbImg.src = "";
  }}
  function step(d) {{
    let i = curIdx + d;
    if (i < 0) i = FNS.length - 1;
    if (i >= FNS.length) i = 0;
    open(i);
  }}
  document.querySelectorAll(".ph-card").forEach((c, i) => {{
    c.addEventListener("click", e => {{
      e.preventDefault();
      open(parseInt(c.dataset.idx, 10));
    }});
  }});
  lbClose.addEventListener("click", close);
  lbPrev.addEventListener("click", () => step(-1));
  lbNext.addEventListener("click", () => step(+1));
  lb.addEventListener("click", e => {{ if (e.target === lb) close(); }});
  document.addEventListener("keydown", e => {{
    if (!lb.classList.contains("show")) return;
    if (e.key === "Escape") close();
    else if (e.key === "ArrowLeft")  step(-1);
    else if (e.key === "ArrowRight") step(+1);
  }});

  // ----- Comment form submit -----
  const form    = document.getElementById("phCommentForm");
  const submit  = document.getElementById("phCommentSubmit");
  const status  = document.getElementById("phCommentStatus");
  form.addEventListener("submit", async e => {{
    e.preventDefault();
    const body   = form.body.value.trim();
    const author = form.author.value.trim();
    if (!body) {{
      status.textContent = "留言不能为空";
      status.className   = "ph-comment-form-status err";
      return;
    }}
    submit.disabled = true;
    status.textContent = "正在发送…";
    status.className = "ph-comment-form-status";
    try {{
      const r = await fetch(`/share/{run_id}/{token}/comment`, {{
        method:  "POST",
        headers: {{"Content-Type": "application/json"}},
        body:    JSON.stringify({{body, author}}),
      }});
      if (!r.ok) {{
        const t = await r.text().catch(() => "");
        throw new Error(`HTTP ${{r.status}} ${{t.slice(0, 60)}}`);
      }}
      status.textContent = "✓ 已发送 — 摄影师会在 PixCull 工作台里看到。";
      status.className = "ph-comment-form-status ok";
      form.body.value = "";
      // Soft reload after 1.5s so the new comment appears below
      setTimeout(() => location.reload(), 1500);
    }} catch (err) {{
      status.textContent = "发送失败:" + err.message;
      status.className = "ph-comment-form-status err";
    }} finally {{
      submit.disabled = false;
    }}
  }});
}})();
</script>
</body>
</html>"""

    # ============================================================
    # v0.7-P2-1 — style-clone V1 endpoints
    # ============================================================
    def _style_profile_path(self, run: dict):
        return Path(run["output_dir"]) / "style_profile.json"

    def _style_distances_path(self, run: dict):
        return Path(run["output_dir"]) / "style_distances.json"

    def _load_scores_rows(self, run: dict) -> list:
        """Read scores.csv into a list of dicts.  Best-effort — a
        missing / unreadable file yields [] (caller treats that as
        "nothing learnable yet", which is the right v1 fallback).
        """
        import csv as _csv

        p = Path(run["output_dir"]) / "scores.csv"
        if not p.exists():
            return []
        rows = []
        try:
            with open(p, "r", encoding="utf-8-sig", newline="") as fh:
                for r in _csv.DictReader(fh):
                    rows.append(dict(r))
        except OSError as exc:
            _dbg("style/load_scores", exc, str(p))
        return rows

    def _handle_style_train(self, run_id: str) -> None:
        """POST /style/train/<run_id>  body: {refs: [filename,...]}
        → {ok, n_refs, profile_summary}

        Pulls the matching rows out of scores.csv, hands them to
        ``learn_style_profile``, persists the resulting profile +
        a full distance map to the run's output dir.  Subsequent
        GET /style/distances/<run_id> calls just read the cached
        map — no re-computation unless retrained.
        """
        run = _get_run(run_id) or _reload_run_from_disk(run_id)
        if run is None:
            self.send_error(404, "no such run")
            return
        try:
            from pixcull.style.clone import (
                compute_distances,
                learn_style_profile,
            )
        except Exception as exc:
            _dbg("style/train/import", exc, run_id)
            self.send_error(500, "style module import failed")
            return
        try:
            n = int(self.headers.get("Content-Length") or "0")
        except ValueError:
            n = 0
        raw = self.rfile.read(n) if n > 0 else b""
        try:
            body = json.loads(raw or b"{}")
        except ValueError:
            body = {}
        refs = body.get("refs") if isinstance(body, dict) else None
        if not isinstance(refs, list) or not refs:
            self.send_error(400, "expected {refs: [filename, ...]}")
            return
        ref_set = {str(x) for x in refs}
        all_rows = self._load_scores_rows(run)
        if not all_rows:
            self.send_error(409, "no scores.csv to train from")
            return
        ref_rows = [r for r in all_rows if r.get("filename") in ref_set]
        if not ref_rows:
            self.send_error(409, "none of the refs matched a scores.csv row")
            return
        profile = learn_style_profile(ref_rows)
        # v0.13.1 — persist the matched ref filename list so the
        # /style/refs/<run>/<filename> endpoint can compute per-ref
        # distances without rebuilding the profile.
        try:
            (Path(run["output_dir"]) / "style_refs.json").write_text(
                json.dumps(
                    [r["filename"] for r in ref_rows],
                    ensure_ascii=False, indent=2,
                ),
                encoding="utf-8",
            )
        except OSError as exc:
            _dbg("style/train/write_refs", exc, run_id)
        # Persist the profile JSON
        try:
            self._style_profile_path(run).write_text(
                json.dumps(profile, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except OSError as exc:
            _dbg("style/train/write_profile", exc, run_id)
            self.send_error(500, "failed to write profile")
            return
        # V1 distances (axis-MAD + scene penalty)
        v1_dists = compute_distances(all_rows, profile)

        # v0.8-P1-1 — V2 (CLIP centroid) layered on top of V1.
        # If the embeddings cache built by P-AI-2 semantic search
        # exists, learn the visual centroid + score every row.
        # Otherwise gracefully fall back to V1 only.
        v2_dists: dict = {}
        v2_summary: dict = {}
        try:
            from pixcull.style import (
                blend, compute_visual_distances, DEFAULT_LAMBDA,
                learn_visual_profile,
            )
            cache_path = Path(run["output_dir"]) / "embeddings.npz"
            v2_profile = learn_visual_profile(list(ref_set), cache_path)
            if v2_profile is not None:
                v2_dists = compute_visual_distances(v2_profile, cache_path)
                # Persist the V2 profile next to V1 (same dir, distinct name)
                try:
                    (Path(run["output_dir"]) / "style_profile_v2.json").write_text(
                        json.dumps(v2_profile, ensure_ascii=False, indent=2),
                        encoding="utf-8",
                    )
                except OSError as exc:
                    _dbg("style/train/write_v2_profile", exc, run_id)
                v2_summary = {
                    "n_refs": v2_profile.get("n_refs", 0),
                    "dim":    v2_profile.get("dim", 0),
                    "model":  v2_profile.get("model", ""),
                }
        except Exception as exc:
            # V2 is best-effort — log + continue with V1 only so a
            # stale cache / missing numpy doesn't fail the whole
            # training call.
            _dbg("style/train/v2_compute", exc, run_id)
            v2_dists = {}
            v2_summary = {}
        # Rich distances map: {filename: {v1, v2?, blend}} so the
        # UI can render dual chips + the client can re-blend
        # without a server round-trip when the user tunes λ.
        try:
            from pixcull.style import blend as _blend, DEFAULT_LAMBDA as _LAM
            blend_fn = _blend
            lam = _LAM
        except Exception:
            blend_fn = None
            lam = 0.3
        all_fns = set(v1_dists) | set(v2_dists)
        rich: dict = {}
        for fn in all_fns:
            entry = {"v1": v1_dists.get(fn)}
            if fn in v2_dists:
                entry["v2"] = v2_dists[fn]
            if blend_fn is not None:
                b = blend_fn(entry.get("v1"), entry.get("v2"), lam)
                if b is not None:
                    entry["blend"] = b
            # Drop any None values so the JSON file stays tidy
            entry = {k: v for k, v in entry.items() if v is not None}
            if entry:
                rich[fn] = entry
        try:
            self._style_distances_path(run).write_text(
                json.dumps(rich, ensure_ascii=False),
                encoding="utf-8",
            )
        except OSError as exc:
            _dbg("style/train/write_distances", exc, run_id)
            # Distances are cacheable but not required to save —
            # the profile is the durable artifact.
        payload = {
            "ok":            True,
            "n_refs":        profile.get("n_refs", 0),
            "n_scored":      len(rich),
            "n_scored_v2":   len(v2_dists),
            "axis_median":   profile.get("axis_median", {}),
            "scene_modes":   profile.get("scene_modes", {}),
            "v2":            v2_summary,
            "lambda_default": lam,
        }
        body_bytes = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body_bytes)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body_bytes)

    # ============================================================
    # v0.8-P0-2 — LAN sync event endpoints
    # ============================================================
    def _handle_sync_event_issue(self, run_id: str) -> None:
        """POST /sync/event/issue/<run_id>
        body: {label?, ttl_hours?, issued_by?}
        → {ok, event_id, token, url, expires_at}
        """
        run = _get_run(run_id) or _reload_run_from_disk(run_id)
        if run is None:
            self.send_error(404, "no such run")
            return
        try:
            from pixcull.sync import issue_event
        except Exception as exc:
            _dbg("sync/import", exc, run_id)
            self.send_error(500, "sync module import failed")
            return
        body = self._read_json_body()
        label = str(body.get("label") or "")
        issued_by = str(body.get("issued_by") or "")
        try:
            ttl = int(body.get("ttl_hours") or 12)
        except (TypeError, ValueError):
            ttl = 12
        run_output_dir = Path(run["output_dir"])
        try:
            sess = issue_event(
                run_output_dir, run_id,
                label=label, issued_by=issued_by, ttl_hours=ttl,
            )
        except Exception as exc:
            _dbg("sync/issue", exc, run_id)
            self.send_error(500, "failed to issue event")
            return
        # v0.10-P0-2 — also broadcast the event on mDNS so peers on
        # the same LAN auto-discover it (saves the user from copy-
        # paste).  Best-effort: if zeroconf isn't installed, this
        # silently no-ops and URL sharing still works.
        try:
            from pixcull.sync import advertise_event
            adv_port = int(getattr(self.server, "server_port", 0) or 0)
            if adv_port:
                handle = advertise_event(
                    event_id=sess.event_id,
                    label=label,
                    run_id=run_id,
                    port=adv_port,
                    token=sess.token,
                )
                if handle is not None:
                    _MDNS_ADVERTS[sess.event_id] = handle
        except Exception as exc:
            _dbg("sync/advertise", exc, run_id)
        # Join URL is the existing /results/<run_id> page with ?event=<token>
        # query param; the JS shim detects the param and switches into
        # collaborative-polling mode.
        self._json_ok({
            "ok":          True,
            "event_id":    sess.event_id,
            "token":       sess.token,
            "url":         f"/results/{run_id}?event={sess.token}",
            "expires_at":  sess.expires_at,
        })

    def _handle_sync_event_revoke(self, run_id: str, event_id: str) -> None:
        # v0.10-P0-2 — also unadvertise from mDNS so the toast on
        # other peers' LAN goes quiet immediately.
        try:
            from pixcull.sync import unadvertise_event
            handle = _MDNS_ADVERTS.pop(event_id, None)
            if handle is not None:
                unadvertise_event(handle)
        except Exception:
            pass
        run = _get_run(run_id) or _reload_run_from_disk(run_id)
        if run is None:
            self.send_error(404, "no such run")
            return
        try:
            from pixcull.sync import revoke_event
        except Exception as exc:
            _dbg("sync/import", exc, run_id)
            self.send_error(500, "sync module import failed")
            return
        run_output_dir = Path(run["output_dir"])
        changed = revoke_event(run_output_dir, event_id)
        self._json_ok({"ok": True, "changed": bool(changed)})

    def _serve_sync_event_changes(self, token: str) -> bool:
        """GET /api/v1/sync/event/<token>/changes?since=<ms>

        We scan ALL runs' events/ dirs for a matching token because
        the client only knows the token, not the run_id.  Linear
        scan is fine for the v1 single-host model — at most a few
        runs per machine.
        """
        from urllib.parse import parse_qs, urlparse as _up
        try:
            from pixcull.sync import (
                compute_changes_since, find_event_by_token,
            )
        except Exception as exc:
            _dbg("sync/import", exc, "changes")
            self.send_error(500, "sync module import failed")
            return True
        # Walk demo root for runs and look for a matching token.
        # In a busy server this would be cached; v1 prioritises
        # correctness over speed.
        sess = None
        run_dir_match = None
        if _DEMO_ROOT.is_dir():
            for child in _DEMO_ROOT.iterdir():
                if not child.is_dir():
                    continue
                out_dir = child / "output"
                if not out_dir.is_dir():
                    continue
                found = find_event_by_token(out_dir, token)
                if found is not None:
                    sess = found
                    run_dir_match = out_dir
                    break
        if sess is None or run_dir_match is None:
            self.send_error(404, "no such event")
            return True
        if not sess.is_active():
            self.send_error(410, "event revoked or expired")
            return True
        qs = parse_qs(_up(self.path).query)
        try:
            since_ms = int((qs.get("since") or ["0"])[0])
        except (TypeError, ValueError):
            since_ms = 0
        # Try the canonical v0.5+ JSONL file first; fall back to the
        # legacy directory of *.json files (older runs, manual edits).
        ann_jsonl = run_dir_match / "annotations.jsonl"
        ann_dir = run_dir_match / "annotation"
        src = ann_jsonl if ann_jsonl.exists() else ann_dir
        annotations, server_ts = compute_changes_since(src, since_ms)
        body = _safe_dumps({
            "schema":      "pixcull.sync.changes/v1",
            "run_id":      sess.run_id,
            "event_id":    sess.event_id,
            "server_ts":   server_ts,
            "annotations": annotations,
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)
        return True

    # ============================================================
    # v0.9-P1-2 — multiplayer presence
    # ============================================================
    def _find_event_and_dir(self, token: str):
        """Walk demo runs and return (session, run_output_dir) for the
        first matching token, or (None, None) if not found.  Used by
        both the presence-GET and presence-POST handlers — the v1
        protocol carries no run_id in the URL on purpose so guests
        only need to remember the token.
        """
        try:
            from pixcull.sync import find_event_by_token
        except Exception as exc:
            _dbg("sync/import", exc, "presence")
            return None, None
        if not _DEMO_ROOT.is_dir():
            return None, None
        for child in _DEMO_ROOT.iterdir():
            if not child.is_dir():
                continue
            out_dir = child / "output"
            if not out_dir.is_dir():
                continue
            found = find_event_by_token(out_dir, token)
            if found is not None:
                return found, out_dir
        return None, None

    def _serve_sync_event_presence(self, token: str) -> bool:
        """GET /api/v1/sync/event/<token>/presence
        → {schema, server_ts, peers: [...]}.
        Optional ?exclude=<client_id> hides the requesting peer from
        the response — handy so the UI doesn't display itself.
        """
        from urllib.parse import parse_qs, urlparse as _up
        try:
            from pixcull.sync import read_presence
        except Exception as exc:
            _dbg("sync/import", exc, "presence")
            self.send_error(500, "presence import failed")
            return True
        sess, out_dir = self._find_event_and_dir(token)
        if sess is None or out_dir is None:
            self.send_error(404, "no such event")
            return True
        if not sess.is_active():
            self.send_error(410, "event revoked or expired")
            return True
        qs = parse_qs(_up(self.path).query)
        exclude = (qs.get("exclude") or [""])[0]
        peers_map = read_presence(out_dir, sess.event_id)
        peers = [rec for cid, rec in peers_map.items() if cid != exclude]
        peers.sort(key=lambda r: int(r.get("last_seen_ms") or 0), reverse=True)
        body = _safe_dumps({
            "schema":    "pixcull.sync.presence/v1",
            "event_id":  sess.event_id,
            "run_id":    sess.run_id,
            "server_ts": int(time.time() * 1000),
            "peers":     peers,
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)
        return True

    def _handle_sync_event_presence(self, token: str) -> bool:
        """POST /sync/event/<token>/presence — heartbeat or disconnect.

        Both heartbeat and disconnect go through here so the client
        can fire-and-forget via ``navigator.sendBeacon`` on
        ``visibilitychange`` / ``pagehide``.  Body shape:

          {client_id, display_name?, last_viewed_filename?,
           action?, action_filename?, disconnect?: bool}

        Returns {ok, peer_count, you}.  Never returns an error for
        well-formed disconnect calls (so sendBeacon never warns).
        """
        try:
            from pixcull.sync import (
                drop_peer, read_presence, update_presence,
            )
        except Exception as exc:
            _dbg("sync/import", exc, "presence")
            self.send_error(500, "presence import failed")
            return True
        sess, out_dir = self._find_event_and_dir(token)
        if sess is None or out_dir is None:
            self.send_error(404, "no such event")
            return True
        if not sess.is_active():
            self.send_error(410, "event revoked or expired")
            return True
        body = self._read_json_body()
        client_id = str(body.get("client_id") or "").strip()[:64]
        if not client_id:
            self.send_error(400, "missing client_id")
            return True
        if body.get("disconnect"):
            drop_peer(out_dir, sess.event_id, client_id)
            self._json_ok({"ok": True, "dropped": True})
            return True
        try:
            you = update_presence(
                out_dir, sess.event_id, client_id,
                display_name        = str(body.get("display_name") or "").strip()[:60] or None,
                last_viewed_filename= (str(body.get("last_viewed_filename") or "").strip() or None),
                action              = str(body.get("action") or "").strip() or None,
                action_filename     = (str(body.get("action_filename") or "").strip() or None),
            )
        except ValueError as exc:
            self.send_error(400, str(exc))
            return True
        except Exception as exc:
            _dbg("sync/presence", exc, sess.event_id)
            self.send_error(500, "presence update failed")
            return True
        peer_count = len(read_presence(out_dir, sess.event_id))
        self._json_ok({
            "ok":         True,
            "you":        you,
            "peer_count": peer_count,
        })
        return True

    def _serve_sync_discover(self) -> bool:
        """v0.10-P0-2 — GET /api/v1/sync/discover

        Returns the active mDNS PixCull sync sessions visible on
        this LAN.  Query params:
          timeout: float seconds (default 2.0, capped at 5.0 so a
                   slow LAN can't hang the response forever).

        Response shape:
          {schema, available: bool, sessions: [...]}

        available=False means zeroconf isn't installed — the JS
        side hides the auto-detect toast in that case.
        """
        from urllib.parse import parse_qs, urlparse as _up
        try:
            from pixcull.sync import (
                ZEROCONF_AVAILABLE, discover_events,
            )
        except Exception as exc:
            _dbg("sync/import", exc, "discover")
            self.send_error(500, "discovery import failed")
            return True
        if not ZEROCONF_AVAILABLE:
            body = _safe_dumps({
                "schema":    "pixcull.sync.discover/v1",
                "available": False,
                "sessions":  [],
                "hint":      "install with: pip install -e '.[sync]'",
            }).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type",
                             "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return True
        qs = parse_qs(_up(self.path).query)
        try:
            timeout = float((qs.get("timeout") or ["2.0"])[0])
        except (TypeError, ValueError):
            timeout = 2.0
        timeout = max(0.2, min(5.0, timeout))
        # Exclude our own advertisements — collaborators care about
        # OTHER hosts, not the one they're already talking to.
        own_eids = set(_MDNS_ADVERTS.keys())
        sessions = discover_events(
            timeout=timeout,
            exclude_self_event_ids=own_eids,
        )
        body = _safe_dumps({
            "schema":    "pixcull.sync.discover/v1",
            "available": True,
            "sessions":  sessions,
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)
        return True

    def _serve_sync_webrtc_inbox(self) -> bool:
        """v0.11-P0-3 — GET /api/v1/sync/webrtc/inbox?peer=<id>&since=<ms>.

        Returns every signaling message addressed to this peer since
        ``since_ms``.  Used by the browser-side RTCPeerConnection
        negotiator during the brief SDP+ICE exchange window; polling
        stops once the data-channel opens.
        """
        from urllib.parse import parse_qs, urlparse as _up
        try:
            from pixcull.sync.webrtc import default_relay, handle_get_inbox
        except Exception as exc:
            _dbg("webrtc/import", exc, "inbox")
            self.send_error(500, "webrtc import failed")
            return True
        qs = parse_qs(_up(self.path).query)
        peer = (qs.get("peer") or [""])[0]
        try:
            since_ms = int((qs.get("since") or ["0"])[0])
        except (TypeError, ValueError):
            since_ms = 0
        status, payload = handle_get_inbox(default_relay(), peer, since_ms)
        body = _safe_dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)
        return True

    def _serve_sync_webrtc_relay(self) -> bool:
        """v0.11-P0-3 — POST /api/v1/sync/webrtc/relay.

        Body schema:
            {kind: "offer"|"answer"|"candidate"|"bye",
             from: "<peer-id>", to: "<peer-id>",
             payload: <SDP dict or ICE candidate dict>}

        The server NEVER inspects ``payload`` — it just forwards it
        intact to the recipient's inbox.  No image data, no
        annotations, no identifiable photographer content ever
        passes through here.
        """
        try:
            from pixcull.sync.webrtc import default_relay, handle_post
        except Exception as exc:
            _dbg("webrtc/import", exc, "relay")
            self.send_error(500, "webrtc import failed")
            return True
        length = int(self.headers.get("Content-Length", "0") or "0")
        if length <= 0 or length > 64 * 1024:
            # 64 KB is generous for SDP; an attacker-large body is
            # almost certainly noise.
            self.send_error(413, "body too large")
            return True
        body_in = self.rfile.read(length)
        status, payload = handle_post(default_relay(), body_in)
        body = _safe_dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)
        return True

    def _handle_sync_event_push(self, token: str) -> bool:
        """v0.10-P0-1 — POST /sync/event/<token>/push.

        Body shape:
          {edits: [
             {filename, decision?, rubric_stars?, cull_reason?,
              client_id?, client_ts_ms?, edited_by?},
             ...
          ]}

        Append each edit to the host's annotations.jsonl.  Other
        peers see the writes via the next /changes poll cycle —
        no extra fan-out needed because the same JSONL is the
        single source of truth.
        """
        try:
            from pixcull.sync import push_edits
        except Exception as exc:
            _dbg("sync/import", exc, "push")
            self.send_error(500, "push import failed")
            return True
        sess, out_dir = self._find_event_and_dir(token)
        if sess is None or out_dir is None:
            self.send_error(404, "no such event")
            return True
        if not sess.is_active():
            self.send_error(410, "event revoked or expired")
            return True
        body = self._read_json_body()
        edits = body.get("edits")
        if not isinstance(edits, list):
            self.send_error(400, "missing or non-list 'edits'")
            return True
        # Defensive cap so a single push can't blast the host's
        # disk.  500 edits per request is plenty (a fast-typing
        # photographer hits maybe 60-80 edits per minute).
        if len(edits) > 500:
            self.send_error(413, "too many edits per push (max 500)")
            return True
        try:
            summary = push_edits(
                out_dir, edits, event_id=sess.event_id,
            )
        except ValueError as exc:
            self.send_error(400, str(exc))
            return True
        except Exception as exc:
            _dbg("sync/push", exc, sess.event_id)
            self.send_error(500, "push failed")
            return True
        self._json_ok(summary)
        return True

    # ============================================================
    # v0.8-P1-3 — short links + QR
    # ============================================================
    def _handle_shortlink_issue(self) -> None:
        """POST /s/issue  body: {long_url, ttl_hours?, label?}

        Long URL can be either an absolute URL the client has in
        hand (e.g. from /share/issue or /sync/event/issue), or a
        relative path starting with "/" — in which case the
        response wraps it as origin-relative so the QR encodes a
        complete URL the recipient's phone can open.

        Idempotent: same long_url → same short_code (see
        pixcull.shortlink.issue).
        """
        try:
            from pixcull.shortlink import issue as _issue
        except Exception as exc:
            _dbg("shortlink/import", exc, "issue")
            self.send_error(500, "shortlink module import failed")
            return
        body = self._read_json_body()
        long_url = body.get("long_url") or ""
        if not isinstance(long_url, str) or not long_url.strip():
            self.send_error(400, "missing 'long_url'")
            return
        try:
            ttl = int(body.get("ttl_hours") or (24 * 30))
        except (TypeError, ValueError):
            ttl = 24 * 30
        label = str(body.get("label") or "")[:120]
        try:
            rec = _issue(_DEMO_ROOT, long_url, ttl_hours=ttl, label=label)
        except ValueError as exc:
            self.send_error(400, str(exc))
            return
        except Exception as exc:
            _dbg("shortlink/issue", exc, long_url[:60])
            self.send_error(500, "failed to issue short link")
            return
        code = rec["short_code"]
        self._json_ok({
            "ok":         True,
            "short_code": code,
            "short_url":  f"/s/{code}",
            "qr_url":     f"/s/{code}.svg",
            "long_url":   rec["long_url"],
            "expires_at": rec.get("expires_at"),
        })

    def _serve_shortlink_redirect(self, code: str) -> None:
        """GET /s/<code> → 302 → long URL (404 missing, 410 expired)."""
        try:
            from pixcull.shortlink import resolve as _resolve
        except Exception as exc:
            _dbg("shortlink/import", exc, "redirect")
            self.send_error(500, "shortlink module import failed")
            return
        rec = _resolve(_DEMO_ROOT, code)
        if rec is None:
            self.send_error(404, "unknown short code")
            return
        if rec.get("expired"):
            self.send_error(410, "short link expired")
            return
        long_url = str(rec.get("long_url") or "")
        if not long_url:
            self.send_error(500, "store missing long_url")
            return
        self.send_response(302)
        self.send_header("Location", long_url)
        # noindex so search engines don't follow + index shared links
        self.send_header("X-Robots-Tag", "noindex, nofollow")
        # Don't cache redirects — short link store can be revoked
        # at any time.
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def _serve_shortlink_qr(self, code: str) -> None:
        """GET /s/<code>.svg → inline QR pointing at the LONG url.

        The QR encodes the full origin-prefixed URL so the recipient's
        phone camera can scan it directly without depending on
        /s/<code> resolving correctly on their network (e.g. a guest
        on a different Wi-Fi.  We still default to /s/<code> as the
        href but the QR carries the absolute long_url.)
        """
        try:
            from pixcull.shortlink import resolve as _resolve
            from pixcull.qrcode_svg import to_svg
        except Exception as exc:
            _dbg("shortlink/qr/import", exc, "qr")
            self.send_error(500, "shortlink/qr import failed")
            return
        rec = _resolve(_DEMO_ROOT, code)
        if rec is None:
            self.send_error(404, "unknown short code")
            return
        if rec.get("expired"):
            self.send_error(410, "short link expired")
            return
        long_url = str(rec.get("long_url") or "")
        if not long_url:
            self.send_error(500, "store missing long_url")
            return
        # If long_url is origin-relative ("/..."), prepend the host
        # so the QR resolves to a complete absolute URL.  Use the
        # Host header so behind-proxy installs still produce the
        # right user-facing origin.
        if long_url.startswith("/"):
            host = self.headers.get("Host") or "localhost"
            scheme = "https" if self.headers.get(
                "X-Forwarded-Proto", "").lower() == "https" else "http"
            long_url = f"{scheme}://{host}{long_url}"
        try:
            svg = to_svg(long_url)
        except ValueError as exc:
            # URL too long for v10 — degrade with a tiny "URL too long"
            # placeholder rather than 500.
            _dbg("shortlink/qr/encode", exc, code)
            self.send_error(400, "url too long for QR")
            return
        body = svg.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "image/svg+xml; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        # QRs are deterministic per (code, host) → cache aggressively
        self.send_header("Cache-Control", "public, max-age=3600")
        self.end_headers()
        self.wfile.write(body)

    def _serve_static_doc_asset(self, path: str) -> None:
        """v0.13.14 — serve images / SVGs under docs/illustrations/
        and docs/brand/.  Path-traversal-safe, immutable cache.
        """
        repo_root = _repo_root() or _pkg_root().parent
        # Strip leading slash + resolve under repo root
        rel = path.lstrip("/")
        target = (repo_root / rel).resolve()
        # Reject anything that resolves outside the repo
        try:
            target.relative_to(repo_root)
        except ValueError:
            self.send_error(403, "path traversal")
            return
        if not target.exists() or not target.is_file():
            self.send_error(404, "not found")
            return
        # Content-type detection by extension
        suffix = target.suffix.lower()
        ctype = {
            ".png":  "image/png",
            ".jpg":  "image/jpeg",
            ".jpeg": "image/jpeg",
            ".webp": "image/webp",
            ".svg":  "image/svg+xml",
            ".gif":  "image/gif",
            ".ico":  "image/x-icon",
            ".woff2":"font/woff2",
        }.get(suffix, "application/octet-stream")
        try:
            data = target.read_bytes()
        except OSError as exc:
            self.send_error(500, f"read failed: {exc}")
            return
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control",
                         "public, max-age=31536000, immutable")
        self.end_headers()
        self.wfile.write(data)

    # ------------------------------------------------------------------
    # v2.0-P0-4 — video review surface.
    # ------------------------------------------------------------------
    def _handle_reel_decision(self, tail: str) -> None:
        """v2.20-P3 — POST /video/reel_decision/<run_id> {rank, decision}.

        The review page's Keep/Cull used to live only in localStorage; now
        each toggle appends to <run>/reel_decisions.jsonl (last line wins
        per rank) and the cross-run taste profile is rebuilt, so future
        ``pixcull reel`` ranking learns the shooter's preference.
        """
        rid = _safe_run_id(tail)
        if rid is None:
            return self._send_json(
                400, json.dumps({"ok": False, "error": "bad run_id"}).encode())
        run_dir = _run_dir(rid)
        if not run_dir.exists():
            self.send_error(404, "no such run")
            return
        clen = int(self.headers.get("Content-Length", "0") or "0")
        if clen <= 0 or clen > 4096:
            self.send_error(400, "expected small JSON body")
            return
        try:
            body = json.loads(self.rfile.read(clen).decode("utf-8"))
            rank = int(body.get("rank"))
            decision = str(body.get("decision") or "")
        except (UnicodeDecodeError, ValueError, TypeError):
            self.send_error(400, "bad JSON body")
            return
        if decision not in ("keep", "cull", ""):
            self.send_error(400, "decision must be keep | cull | ''")
            return
        rec = {"rank": rank, "decision": decision,
               "at_ms": int(time.time() * 1000)}
        with open(run_dir / "reel_decisions.jsonl", "a",
                  encoding="utf-8") as fh:
            fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
        n_profile = _rebuild_reel_profile()
        out = json.dumps({"ok": True, "n_profile": n_profile}).encode()
        self._send_json(200, out)

    def _serve_video_data(self, tail: str) -> None:
        """GET /video/data/<run_id> — bundle manifest + temporal + reel."""
        rid = _safe_run_id(tail)
        if rid is None:
            return self._send_json(
                400, json.dumps({"ok": False, "error": "bad run_id"}).encode())
        run_dir = _run_dir(rid)
        temporal_path = run_dir / "temporal.json"
        if not temporal_path.exists():
            return self._send_json(404, json.dumps({
                "ok": False,
                "error": "not a video run (no temporal.json) — run "
                         "`pixcull video <path>` first",
            }, ensure_ascii=False).encode())
        frames_dir = _video_frames_dir(run_dir)
        manifest = {}
        if frames_dir is not None:
            try:
                manifest = json.loads(
                    (frames_dir / "manifest.json").read_text("utf-8"))
            except (OSError, ValueError):
                manifest = {}
        try:
            temporal = json.loads(temporal_path.read_text("utf-8"))
        except (OSError, json.JSONDecodeError):
            temporal = {}
        # v2.19-P2(视频玻璃盒) — audio events ride along when the run has
        # them (laughter / applause / music from audio_events.json); the
        # review timeline draws them as a bottom-lane overlay. None when
        # absent — the UI hides the lane.
        audio = None
        try:
            ap = run_dir / "audio_events.json"
            if ap.exists():
                audio = json.loads(ap.read_text("utf-8"))
        except (OSError, ValueError):
            audio = None
        reel = []
        reel_path = run_dir / "reel_candidates.json"
        if reel_path.exists():
            try:
                reel = json.loads(reel_path.read_text("utf-8"))
            except (OSError, ValueError):
                reel = []
        try:
            from pixcull.scoring.color_grade import list_presets, list_cubes
            grades = list_presets() + list_cubes()   # + v2.1 user .cube LUTs
        except Exception:
            grades = [{"id": "none", "label": "Original"}]
        # v2.2-P2-1 — GPS travel-map track (lazy-extracted, cached to gps.json).
        gps_payload = None
        try:
            from pixcull.io.gps_map import gps_points_for_video, project_track
            gps_cache = run_dir / "gps.json"
            if gps_cache.exists():
                raw = json.loads(gps_cache.read_text("utf-8"))
            else:
                src = manifest.get("source_path")
                raw = (gps_points_for_video(Path(src))
                       if src and Path(src).exists()
                       else {"points": [], "source": ""})
                try:
                    gps_cache.write_text(
                        json.dumps(raw, ensure_ascii=False), encoding="utf-8")
                except OSError:
                    pass
            proj = project_track(raw.get("points", []))
            if proj:
                gps_payload = {**proj, "source": raw.get("source", "")}
        except Exception:
            gps_payload = None
        # v2.43-P1 — transcript, when `pixcull transcribe` has been run.
        # None (not []) when absent, so the panel can tell "no transcript
        # yet" apart from "transcribed, and the clip is silent".
        transcript = None
        try:
            from pixcull.scoring.transcribe import load_transcript
            _t = load_transcript(run_dir)
            if _t is not None:
                transcript = _t.to_dict()
        except (OSError, ValueError, ImportError) as exc:
            # Narrow on purpose. The first draft caught bare Exception and
            # swallowed a NameError from getting this very variable wrong
            # (`run` instead of `run_dir`) — the page rendered fine with an
            # empty panel and nothing said why. A transcript must not 500
            # the page, but it must not hide a bug either.
            print(f"[transcript] unreadable for {rid}: {exc}")
            transcript = None
        body = json.dumps({
            "ok": True,
            "run_id": rid,
            "frame_base": f"/video/frame/{rid}/",
            "manifest": manifest,
            "temporal": temporal,
            "reel": reel,
            "audio": audio,
            "grades": grades,
            "gps": gps_payload,
            "transcript": transcript,
        }, ensure_ascii=False).encode("utf-8")
        self._send_json(200, body)

    def _serve_video_frame(self, tail: str) -> None:
        """GET /video/frame/<run_id>/<frame_id> — serve one extracted frame."""
        tail = unquote(tail)
        if "/" not in tail:
            return self.send_error(400, "expected run_id/frame_id")
        rid_raw, frame_id = tail.split("/", 1)
        rid = _safe_run_id(rid_raw)
        if rid is None:
            return self.send_error(400, "bad run_id")
        frames_dir = _video_frames_dir(_run_dir(rid))
        if frames_dir is None:
            return self.send_error(404, "no such video run")
        name = Path(frame_id).name
        if not name.lower().endswith(".jpg"):
            name += ".jpg"
        target = (frames_dir / name).resolve()
        try:
            target.relative_to(frames_dir.resolve())
        except ValueError:
            return self.send_error(403, "path traversal")
        if not target.is_file():
            return self.send_error(404, f"no frame {name}")
        try:
            data = target.read_bytes()
        except OSError as exc:
            return self.send_error(500, f"read failed: {exc}")
        # v2.0-P2-2 — optional ?grade=<preset> film look + ?w=<px> proxy
        # for the scrubber's per-candidate preview thumbnails.
        from urllib.parse import parse_qs, urlsplit
        qs = parse_qs(urlsplit(self.path).query)
        grade = (qs.get("grade") or ["none"])[0]
        try:
            want_w = int((qs.get("w") or ["0"])[0])
        except (TypeError, ValueError):
            want_w = 0
        if (grade and grade != "none") or want_w > 0:
            try:
                from pixcull.scoring.color_grade import grade_image_bytes
                data = grade_image_bytes(
                    data, grade, max_w=want_w or None)
            except Exception:  # pragma: no cover - never fail the frame
                pass
        self.send_response(200)
        self.send_header("Content-Type", "image/jpeg")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control",
                         "public, max-age=31536000, immutable")
        self.send_header("Vary", "Accept")
        self.end_headers()
        self.wfile.write(data)

    def _serve_video_review(self, tail: str) -> None:
        """GET /video/<run_id> — the video-native lightbox review page."""
        rid = _safe_run_id(tail)
        if rid is None:
            return self.send_error(400, "bad run_id")
        if not (_run_dir(rid) / "temporal.json").exists():
            body = (
                "<!DOCTYPE html><meta charset='utf-8'>"
                "<title>PixCull · 视频审片</title>"
                "<body style='background:#161616;color:#e6e6e6;"
                "font:14px/1.6 system-ui;padding:48px;text-align:center'>"
                "<h2>这不是一个视频 run</h2>"
                "<p>该 run 缺少 <code>temporal.json</code>。请先运行 "
                "<code>pixcull video &lt;path&gt;</code> 生成关键帧 + 时间评分 "
                "+ reel 候选,再来这里审片。</p>"
                "</body>"
            ).encode("utf-8")
            return self._send_html(404, body)
        body = _render_video_review_html(rid).encode("utf-8")
        self._send_html(200, body)

    def _serve_timeline_data(self, tail: str) -> None:
        """GET /timeline/data/<run_id> — merged photo + video timeline."""
        rid = _safe_run_id(tail)
        if rid is None:
            return self._send_json(
                400, json.dumps({"ok": False, "error": "bad run_id"}).encode())
        photos = _photo_timeline_items(rid)
        videos = _video_timeline_items()
        items = build_joint_timeline(photos, videos)
        body = json.dumps({
            "ok": True, "run_id": rid,
            "photo_count": len(photos), "video_count": len(videos),
            "items": items,
        }, ensure_ascii=False).encode("utf-8")
        self._send_json(200, body)

    def _serve_timeline_page(self, tail: str) -> None:
        """GET /timeline/<run_id> — joint photo + video timeline page."""
        rid = _safe_run_id(tail)
        if rid is None:
            return self.send_error(400, "bad run_id")
        self._send_html(200, _render_timeline_html(rid).encode("utf-8"))

    def _serve_healthz(self) -> None:
        """v0.13.10 — operational health probe.

        Returns a structured ok/not-ok per check.  Used by launch
        scripts, LAN guests verifying the host, and the dogfood
        bug collector.  Never returns 5xx — even when individual
        checks fail, we return 200 with per-check status (the
        client decides whether to consider the host healthy).
        """
        import shutil as _sh
        checks: list[dict] = []
        # Disk space — < 1 GB free is concerning
        try:
            usage = _sh.disk_usage(str(_DEMO_ROOT.parent
                                       if _DEMO_ROOT.exists()
                                       else Path.home()))
            free_gb = usage.free / (1024 ** 3)
            checks.append({
                "name":   "disk_free",
                "ok":     free_gb >= 1.0,
                "detail": f"{free_gb:.1f} GB free",
            })
        except Exception as exc:
            checks.append({
                "name":   "disk_free",
                "ok":     False,
                "detail": f"probe failed: {exc}",
            })
        # Demo root writable
        try:
            _DEMO_ROOT.mkdir(parents=True, exist_ok=True)
            probe = _DEMO_ROOT / ".healthz_probe"
            probe.write_text("ok", encoding="utf-8")
            probe.unlink()
            checks.append({"name": "demo_root_writable", "ok": True,
                           "detail": str(_DEMO_ROOT)})
        except Exception as exc:
            checks.append({"name": "demo_root_writable", "ok": False,
                           "detail": str(exc)})
        # Models available — check models/ dir
        _rr_models = _repo_root()
        models_dir = (_rr_models / "models") if _rr_models else Path("/nonexistent")
        n_models = len(list(models_dir.glob("*.joblib"))) \
            if models_dir.exists() else 0
        checks.append({
            "name":   "models",
            "ok":     n_models > 0,
            "detail": f"{n_models} joblib files",
        })
        # Locale catalogue — should have ≥ 5 (zh/en/ja/ko/es minimum)
        locale_dir = _pkg_root() / "locale"
        n_locales = len(list(locale_dir.glob("*.json"))) \
            if locale_dir.exists() else 0
        checks.append({
            "name":   "locales",
            "ok":     n_locales >= 5,
            "detail": f"{n_locales} locale files",
        })
        ok_all = all(c["ok"] for c in checks)
        body = _safe_dumps({
            "ok":     ok_all,
            "checks": checks,
            "uptime_s": int(time.time() - _SERVER_BOOT_TIME)
            if "_SERVER_BOOT_TIME" in globals() else None,
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type",
                         "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _serve_daily_recap(self) -> None:
        """v0.13.9 — GET /api/v1/recap?date=YYYY-MM-DD"""
        from urllib.parse import parse_qs, urlparse as _up
        qs = parse_qs(_up(self.path).query)
        date_iso = (qs.get("date") or [""])[0].strip() or None
        try:
            from pixcull.workflow import daily_recap
            from dataclasses import asdict
        except Exception as exc:
            self.send_error(500, f"workflow module import failed: {exc}")
            return
        recap = daily_recap(
            Path.home() / ".pixcull" / "runs",
            date_iso=date_iso,
        )
        body = _safe_dumps({
            "ok":    True,
            "recap": asdict(recap),
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type",
                         "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _serve_bookmarks_list(self) -> None:
        """v0.13.9 — GET /api/v1/bookmarks?run=<run_id>"""
        from urllib.parse import parse_qs, urlparse as _up
        from dataclasses import asdict
        qs = parse_qs(_up(self.path).query)
        run_id = (qs.get("run") or [""])[0].strip() or None
        try:
            from pixcull.workflow import list_bookmarks
        except Exception as exc:
            self.send_error(500, f"workflow import failed: {exc}")
            return
        bookmarks = list_bookmarks(run_id)
        body = _safe_dumps({
            "ok":        True,
            "bookmarks": [asdict(b) for b in bookmarks],
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type",
                         "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _serve_session_conflicts(self) -> None:
        """v0.13.9 — GET /api/v1/conflicts?run=<run_id>"""
        from urllib.parse import parse_qs, urlparse as _up
        qs = parse_qs(_up(self.path).query)
        run_id = (qs.get("run") or [""])[0].strip()
        if not run_id:
            self.send_error(400, "run param required")
            return
        try:
            from pixcull.workflow import session_conflicts
        except Exception as exc:
            self.send_error(500, f"workflow import failed: {exc}")
            return
        conflicts = session_conflicts(
            Path.home() / ".pixcull" / "runs", run_id)
        body = _safe_dumps({
            "ok":        True,
            "run_id":    run_id,
            "conflicts": conflicts,
            "count":     len(conflicts),
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type",
                         "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _handle_bookmark_toggle(self) -> None:
        """v0.13.9 — POST /api/v1/bookmark.

        Body: ``{run_id, filename, note?, color?}``.  Adds if absent,
        removes if present.  Returns whether the photo is now
        bookmarked.
        """
        try:
            length = int(self.headers.get("Content-Length", "0") or "0")
        except ValueError:
            length = 0
        if length <= 0 or length > 8192:
            self.send_error(400, "expected JSON body ≤ 8 KB")
            return
        try:
            params = json.loads(self.rfile.read(length).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            self.send_error(400, f"invalid JSON: {exc}")
            return
        run_id = str(params.get("run_id") or "").strip()
        filename = str(params.get("filename") or "").strip()
        note = str(params.get("note") or "")[:500]
        color = str(params.get("color") or "blue")
        if not run_id or not filename:
            self.send_error(400, "run_id + filename required")
            return
        try:
            from pixcull.workflow import is_bookmarked, toggle_bookmark
        except Exception as exc:
            self.send_error(500, f"workflow import failed: {exc}")
            return
        try:
            added = toggle_bookmark(run_id, filename, note=note, color=color)
        except ValueError as exc:
            self.send_error(400, str(exc))
            return
        body = _safe_dumps({
            "ok":            True,
            "added":         added,
            "is_bookmarked": is_bookmarked(run_id, filename),
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type",
                         "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _serve_runs_rows(self, run_id: str) -> None:
        """v0.13.5 — paginated rows endpoint.

        Returns a slice of the run's scores.csv as JSON, suitable for
        virtual-scroll grids that don't want to inline all rows in
        the HTML payload.

        Query params:
          * ``offset`` (default 0)
          * ``limit``  (default 200, max 1000)

        Response:
          ``{ok, run_id, offset, limit, total, rows: [...]}``

        Each row contains the same fields the inline JSON dump
        provides, so the client can use it as a drop-in replacement.
        """
        from urllib.parse import parse_qs, urlparse as _up
        qs = parse_qs(_up(self.path).query)
        try:
            offset = max(0, int((qs.get("offset") or ["0"])[0]))
        except (TypeError, ValueError):
            offset = 0
        try:
            limit = int((qs.get("limit") or ["200"])[0])
        except (TypeError, ValueError):
            limit = 200
        # Clamp to a sane range.  1000 is more than any reasonable
        # virtual-scroll window;  going higher would defeat the
        # purpose (re-introduce the JSON-dump bloat we're avoiding).
        limit = max(1, min(1000, limit))

        run = _get_run(run_id) or _reload_run_from_disk(run_id)
        if run is None:
            self.send_error(404, "no such run")
            return
        # Lean on the same _build_results helper that the inline
        # template path uses — guarantees identical fields.
        result = _build_results(run_id)
        if result is None:
            self.send_error(404, "no results yet")
            return
        rows, _meta = result
        total = len(rows)
        slice_rows = rows[offset:offset + limit]
        body = _safe_dumps({
            "schema": "pixcull.runs.rows/v1",
            "ok":     True,
            "run_id": run_id,
            "offset": offset,
            "limit":  limit,
            "total":  total,
            "rows":   slice_rows,
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type",
                         "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        # Make pagination metadata explicit for clients
        self.send_header("X-Total-Count", str(total))
        self.send_header("X-Offset", str(offset))
        self.send_header("X-Limit", str(limit))
        self.end_headers()
        self.wfile.write(body)

    def _serve_style_per_ref(self, run_id: str, filename: str) -> None:
        """v0.13.1 — GET /style/refs/<run_id>/<filename>

        Returns ``{ok, target, refs: [{filename, distance, rank}, ...]}``
        — the per-reference CLIP cosine distance breakdown for the
        target photo, so the Inspector's "🔭 视觉" chip popover can
        show WHICH references drive the aggregate distance.

        Reads:
          * ``output/style_profile_v2.json`` for the ref list (the same
            file ``_handle_style_train`` writes)
          * ``output/embeddings.npz`` for the CLIP vector cache

        Returns 200 with empty refs list when no profile has been
        trained yet — caller renders "train a style profile first"
        in the UI rather than failing.
        """
        run = _get_run(run_id) or _reload_run_from_disk(run_id)
        if run is None:
            self.send_error(404, "no such run")
            return
        # Resolve the ref list — the profile's ``n_refs`` is the
        # count, but we need the actual filenames.  Best path:
        # the profile dict carries them when learn_visual_profile
        # was called.  In v0.13.1 we extend learn_visual_profile
        # to persist the ref list.  For backward compatibility we
        # also accept a sibling ``style_refs.json`` written by the
        # train handler.
        out_dir = Path(run["output_dir"])
        refs_path = out_dir / "style_refs.json"
        refs: list[str] = []
        if refs_path.exists():
            try:
                refs = json.loads(refs_path.read_text(encoding="utf-8"))
                if not isinstance(refs, list):
                    refs = []
            except (OSError, json.JSONDecodeError):
                refs = []
        if not refs:
            # No profile trained yet (or stale schema) — return empty
            self._json_ok({
                "ok":     True,
                "target": filename,
                "refs":   [],
                "hint":   "no style profile yet — POST /style/train/"
                          + run_id + " with {refs:[...]}",
            })
            return
        try:
            from pixcull.style import compute_per_ref_distances
        except Exception as exc:
            _dbg("style/refs/import", exc, run_id)
            self.send_error(500, "style module import failed")
            return
        cache_path = out_dir / "embeddings.npz"
        try:
            per_ref = compute_per_ref_distances(
                filename, refs, cache_path,
            )
        except Exception as exc:
            _dbg("style/refs/compute", exc, run_id)
            per_ref = []
        self._json_ok({
            "ok":     True,
            "target": filename,
            "refs":   per_ref,
            "n_refs": len(refs),
        })

    def _serve_style_distances(self, run_id: str) -> None:
        """GET /style/distances/<run_id> → {filename: distance, ...}

        Returns the persisted distance map or an empty {} when no
        profile has been trained yet.  We never re-derive on the
        fly — train explicitly via POST /style/train/<run_id>.
        """
        run = _get_run(run_id) or _reload_run_from_disk(run_id)
        if run is None:
            self.send_error(404, "no such run")
            return
        path = self._style_distances_path(run)
        if not path.exists():
            body = b"{}"
        else:
            try:
                body = path.read_bytes()
            except OSError as exc:
                _dbg("style/serve_distances", exc, run_id)
                body = b"{}"
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    # ============================================================
    # v0.7-P2-2 — tethered live scoring HTTP wiring
    # ============================================================
    def _json_ok(self, payload: dict, status: int = 200) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _read_json_body(self) -> dict:
        try:
            n = int(self.headers.get("Content-Length") or "0")
        except ValueError:
            n = 0
        raw = self.rfile.read(n) if n > 0 else b""
        try:
            d = json.loads(raw or b"{}")
        except ValueError:
            d = {}
        return d if isinstance(d, dict) else {}

    # ============================================================
    # v0.7-P2-4 — history timeline page (/history)
    #
    # Walks _DEMO_ROOT for every run dir, harvests:
    #   - run_id (folder name)
    #   - last-modified mtime (for sorting)
    #   - scores.csv summary (count by decision, first thumb)
    #   - manifest.json (for source label) when present
    # Renders a date-sorted card grid. Each card links to
    # /results/<run_id>. Self-contained HTML — reuses
    # _DESIGN_TOKENS_CSS for visual consistency.
    # ============================================================
    def _collect_history_entries(self) -> list[dict]:
        """Scan _DEMO_ROOT for runs, summarise each.

        Best-effort: a missing scores.csv or manifest never throws
        — we just emit a card with zeros and let the user click
        through to see the (possibly broken) results page.
        """
        import csv as _csv

        entries: list[dict] = []
        if not _DEMO_ROOT.is_dir():
            return entries
        for child in _DEMO_ROOT.iterdir():
            if not child.is_dir():
                continue
            run_id = child.name
            if run_id.startswith("."):
                continue
            output_dir = child / "output"
            scores = output_dir / "scores.csv"
            manifest = output_dir / "manifest.json"
            # Use the most recently-touched file in the dir as a
            # proxy for "when did this run finish" — robust to
            # systems where dir mtime is misleading.
            try:
                mtime = child.stat().st_mtime
                for sub in (scores, manifest, output_dir):
                    if sub.exists():
                        m = sub.stat().st_mtime
                        if m > mtime:
                            mtime = m
            except OSError:
                continue

            n_total = n_keep = n_maybe = n_cull = 0
            first_filename: str | None = None
            if scores.exists():
                try:
                    with open(scores, "r", encoding="utf-8-sig",
                              newline="") as fh:
                        for row in _csv.DictReader(fh):
                            n_total += 1
                            d = row.get("decision") or ""
                            if d == "keep":
                                n_keep += 1
                            elif d == "maybe":
                                n_maybe += 1
                            elif d == "cull":
                                n_cull += 1
                            if first_filename is None:
                                first_filename = row.get("filename") or None
                except OSError as exc:
                    _dbg("history/scores_read", exc, str(scores))

            source_label = ""
            if manifest.exists():
                try:
                    m = json.loads(manifest.read_text(encoding="utf-8"))
                    # Manifest schema varies — try the most common
                    # fields. Fall back to "scan" if any are set.
                    if isinstance(m, dict):
                        source_label = (
                            m.get("source_dir")
                            or m.get("input_dir")
                            or "scan"
                        )
                except (OSError, ValueError):
                    pass
            elif (child / "input").is_dir():
                source_label = "上传"

            entries.append({
                "run_id":          run_id,
                "mtime":           mtime,
                "n_total":         n_total,
                "n_keep":          n_keep,
                "n_maybe":         n_maybe,
                "n_cull":          n_cull,
                "first_filename":  first_filename,
                "source_label":    source_label,
            })
        # Newest first
        entries.sort(key=lambda e: e["mtime"], reverse=True)
        return entries

    def _serve_history_page(self) -> None:
        entries = self._collect_history_entries()
        # Build the cards
        from html import escape as _esc

        def _fmt_mtime(t: float) -> str:
            """v0.13.7 — emit ISO date that the client-side JS will
            re-format via Intl.DateTimeFormat for the current locale.
            We can't know the user's locale on the server (it depends
            on browser Accept-Language + user override), so the SSR
            value is a stable ISO string + a data-iso attribute the
            client hydrates."""
            try:
                return datetime.fromtimestamp(t).strftime("%Y-%m-%d %H:%M")
            except (ValueError, OSError):
                return ""

        def _decision_bar(e: dict) -> str:
            tot = max(e["n_total"], 1)
            kw = round(e["n_keep"] / tot * 100, 1)
            mw = round(e["n_maybe"] / tot * 100, 1)
            cw = round(e["n_cull"] / tot * 100, 1)
            return (
                '<div class="bar" title="' +
                _esc(f"keep {e['n_keep']} · maybe {e['n_maybe']} · cull {e['n_cull']}") +
                f'"><span class="seg k" style="width:{kw}%"></span>'
                f'<span class="seg m" style="width:{mw}%"></span>'
                f'<span class="seg c" style="width:{cw}%"></span></div>'
            )

        cards = []
        for e in entries:
            thumb = ""
            if e["first_filename"]:
                thumb = (
                    f'<img loading="lazy" '
                    f'src="/thumb/{_esc(e["run_id"])}/{_esc(e["first_filename"])}?w=420" '
                    f'alt="thumbnail">'
                )
            else:
                thumb = '<div class="no-thumb">·</div>'
            # v0.13.7 — emit ISO-8601 in data-iso so the client-side
            # script can Intl-format per current locale (pt → "29 mai
            # 2026, 21:32"; ar → "٢٩ مايو ٢٠٢٦ ٢١:٣٢"; etc.).  Falls
            # back to the SSR fallback string when JS is off.
            try:
                iso = datetime.fromtimestamp(e["mtime"]).isoformat()
            except (ValueError, OSError):
                iso = ""
            # v2.1-P0-2 — flag video runs in history with a 🎬 marker so
            # they're discoverable as a "video review" entry point.
            _vid_mark = ("🎬 " if is_video_run(e["run_id"]) else "")
            cards.append(
                f'<a class="card" href="/results/{_esc(e["run_id"])}">'
                f'<div class="thumb">{thumb}</div>'
                f'<div class="meta">'
                f'<div class="rid" title="{_esc(e["run_id"])}">{_vid_mark}{_esc(e["run_id"])}</div>'
                f'<div class="when" data-iso="{_esc(iso)}">'
                f'{_fmt_mtime(e["mtime"])}'
                + (f' · <span class="src">{_esc(str(e["source_label"]))}</span>' if e["source_label"] else "")
                + f'</div>'
                f'{_decision_bar(e)}'
                f'<div class="counts">{e["n_total"]} 张 · '
                f'<span class="k">{e["n_keep"]}</span> · '
                f'<span class="m">{e["n_maybe"]}</span> · '
                f'<span class="c">{e["n_cull"]}</span></div>'
                f'</div>'
                f'</a>'
            )
        # v0.13.14 — painter-quality empty state via MiniMax-generated
        # illustration.  Replaces the v0.9-P2-3 line-art SVG with a
        # 1024×768 watercolor PNG matching the brand's indigo+pink
        # editorial palette.  Falls back to the SVG sprite from
        # results.html (#art-empty-history) when the PNG 404s — keeps
        # offline / first-run rendering safe.
        empty_history_svg = (
            '<img src="/docs/illustrations/art-empty-history.png" '
            'alt="" style="width:300px;max-width:80vw;height:auto;'
            'border-radius:16px;margin-bottom:18px;'
            'box-shadow:0 16px 48px rgba(0,0,0,0.4),'
            '0 0 0 1px rgba(213,181,132,0.18) inset;"'
            ' onerror="this.style.display=\'none\'">'
        )
        cards_html = "\n".join(cards) if cards else (
            '<div class="empty" style="text-align:center;padding:40px 24px;max-width:480px;margin:0 auto">'
            + empty_history_svg
            + '<div style="font-size:18px;font-weight:600;color:var(--fg);'
              'letter-spacing:-0.01em">还没有跑过任何 run</div>'
              '<div style="margin-top:8px;color:var(--muted);font-size:13px;line-height:1.6">'
              '不需要先上传你自己的照片 — 用 6 张内置示例数据就能 '
              '<b>30 秒</b>看到完整 PixCull 选片流程,'
              '包括 6 轴评分 · attribution heatmap · 客户分享链接。</div>'
              # v0.13.4 — Primary "try a demo" CTA + secondary upload link.
              # Old empty state only linked back to upload, which forced new
              # users to either (a) wait minutes for first-run model download
              # + analysis, or (b) bounce.  The demo button drops them into
              # /results in < 5 seconds, lowering the bounce gate by 99%.
              '<div style="margin-top:22px;display:flex;flex-direction:column;align-items:center;gap:10px">'
              '<button id="historyTryDemoBtn" '
              'style="padding:11px 22px;border-radius:999px;border:0;'
              'font-weight:600;font-size:13px;cursor:pointer;'
              'background:linear-gradient(135deg,#d5b584 0%,#93743f 100%);'
              'color:#fff;box-shadow:0 4px 14px rgba(213,181,132,0.40)" '
              'onclick="(async()=>{this.disabled=true;this.textContent=\'载入中…\';'
              'try{const r=await fetch(\'/sample_demo\',{method:\'POST\'});'
              'const d=await r.json();if(d.ok&&d.run_id){location.href=\'/results/\'+d.run_id;}'
              'else{this.textContent=\'失败 · 重试\';this.disabled=false;}}'
              'catch(e){this.textContent=\'失败 · 重试\';this.disabled=false;}})()">'
              '🎬 用示例数据 30 秒体验</button>'
              '<a href="/" style="color:var(--muted);font-size:12.5px;'
              'text-decoration:none;border-bottom:1px dashed var(--muted)">'
              '或上传我自己的照片 →</a></div>'
              '</div>'
        )

        # v2.28 — extracted to templates/pages/history.html. The static
        # shell (+ shared design-tokens CSS) is a template; the two runtime
        # injections — the run count and the run cards — splice in at
        # placeholders. Byte-identical to the prior inline build (route-diff).
        page = (
            _read_template("pages/history.html")
            .replace("/*__DESIGN_TOKENS_CSS__*/", _DESIGN_TOKENS_CSS)
            .replace("<!--__HISTORY_COUNT__-->", f"{len(entries)} 个 run")
            .replace("<!--__HISTORY_CARDS__-->", cards_html)
        )
        body = page.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    # NOTE — _handle_tether_start / _handle_tether_stop already exist
    # further down (P2.2 base implementation). Top-level /tether/start
    # + /tether/<sid>/stop POST routes (above, in do_POST) call those
    # canonical handlers — we deliberately don't redefine them here.

    def _serve_tether_sessions(self) -> None:
        """GET /tether/sessions → {sessions: [...]}.

        Mirrors the /api/v1/tether GET endpoint but at the top level
        so the v0.7-P2-2 control panel (/tether) can fetch without
        the auth/cors layer.
        """
        try:
            from pixcull import tether as _tether_mod
            payload = {"sessions": _tether_mod.list_sessions()}
        except Exception as exc:
            _dbg("tether/list", exc, "")
            payload = {"sessions": [], "error": str(exc)}
        self._json_ok(payload)

    def _serve_tether_status(self, session_id: str) -> None:
        """GET /tether/status/<session_id> → status snapshot."""
        try:
            from pixcull import tether as _tether_mod
        except Exception as exc:
            _dbg("tether/import", exc, "status")
            self.send_error(500, "tether module import failed")
            return
        s = _tether_mod.get_session(session_id)
        if s is None:
            self.send_error(404, "no such tether session")
            return
        self._json_ok(s.status())

    def _serve_tether_page(self) -> None:
        """GET /tether → minimal control panel for tethered live scoring.

        Self-contained; reuses the upload-page dark palette via
        _DESIGN_TOKENS_CSS so the page stays consistent with the
        rest of the product.
        """
        # v2.28 — extracted to templates/pages/tether.html (fully static
        # shell; only the shared design-tokens CSS is spliced in, same as
        # the v2.16 page extractions). Byte-identical to the prior inline
        # r"""...""" + _DESIGN_TOKENS_CSS build (route-diff verified).
        page = _read_template("pages/tether.html").replace(
            "/*__DESIGN_TOKENS_CSS__*/", _DESIGN_TOKENS_CSS)
        body = page.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _handle_sample_demo(self) -> None:
        """P-UX-21 — instant sample-data path.

        Copies the bundled ``samples/`` directory (pre-scored 6-photo
        landscape + wildlife set) into a fresh demo run so visitors
        can hit /results without uploading anything or waiting on
        model warm-up.

        The sample scores.csv was generated procedurally with realistic
        rubric stars per scene. The 6 input JPGs are 1280×853 gradients
        (~40 KB each) — small enough to ship in the repo, varied enough
        to demonstrate keep/maybe/cull across landscape + wildlife +
        architecture verticals.

        POST /sample_demo  → {ok, run_id, url}
        """
        import shutil
        import secrets as _secrets

        # Project root contains a samples/ tree we ship in-repo
        proj_root = _repo_root() or _pkg_root().parent
        src = proj_root / "samples" / "output"
        if not (src / "scores.csv").is_file():
            self._reject_upload(500, "samples/ not bundled with this build")
            return
        run_id = "sample_" + _secrets.token_hex(4)
        dst = _DEMO_ROOT / run_id / "output"
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(src, dst, dirs_exist_ok=True)

        # Manifest in samples/output points at samples/input/*.jpg with
        # absolute paths. Those paths were computed at sample-generation
        # time and may not match this checkout — rewrite them based on
        # the actual on-disk location now.
        manifest_path = dst / "manifest.json"
        if manifest_path.is_file():
            try:
                manifest = json.loads(manifest_path.read_text("utf-8"))
                samples_input = proj_root / "samples" / "input"
                fixed = {
                    fn: str(samples_input / fn)
                    for fn in manifest.keys()
                    if (samples_input / fn).is_file()
                }
                manifest_path.write_text(
                    json.dumps(fixed, ensure_ascii=False, indent=2),
                    encoding="utf-8",
                )
            except (OSError, json.JSONDecodeError):
                pass

        # Register the run with the in-memory store as a "scan-mode"
        # run so /thumb + /full + /results work without a re-analysis.
        with _RUNS_LOCK:
            _RUNS[run_id] = {
                "run_id":     run_id,
                "output_dir": str(dst),
                "input_dir":  "",
                "mode":       "scan",
                "source_dir": str(proj_root / "samples" / "input"),
                "state":      "done",
                "started_at": time.time(),
                "finished_at": time.time(),
                "vertical":   None,
            }

        body = _safe_dumps({
            "ok":     True,
            "run_id": run_id,
            "url":    f"/results/{run_id}",
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _handle_scan_local(self) -> None:
        """Analyze a local folder *in place*. No file copy, no upload.

        Body: {folder: "/abs/path"} — the path is interpreted on the
        SERVER's filesystem. This is the right mode for users who already
        have their RAW collection organized on disk and don't want to
        duplicate gigabytes into /tmp.

        We import list_images here too so the file count + sample list
        is available immediately (no need to wait for the analyzer thread
        to start). The pipeline thread re-walks the dir; that walk is
        cheap relative to the actual analysis.
        """
        clen = int(self.headers.get("Content-Length", "0") or "0")
        if clen <= 0 or clen > 65536:
            self._reject_upload(400, "expected small JSON body with {folder}")
            return
        try:
            params = json.loads(self.rfile.read(clen).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            self._reject_upload(400, f"JSON parse failed: {exc}")
            return
        folder_str = (params.get("folder") or "").strip()
        if not folder_str:
            self._reject_upload(400, "需要 folder 字段:服务端的绝对文件夹路径")
            return
        # V17.0 — optional vertical override. Empty / unknown key is
        # treated as "auto detect" (no override), matching the
        # dropdown's first option.
        vertical = (params.get("vertical") or "").strip().lower()
        if vertical:
            from pixcull import verticals as vmod
            if vmod.get_vertical(vertical) is None:
                vertical = ""  # silently fall back to auto-detect

        # Expand ~/ and resolve symlinks so the user can paste either an
        # absolute path or a tilde-relative one.
        folder = Path(folder_str).expanduser()
        try:
            folder = folder.resolve()
        except OSError as exc:
            self._reject_upload(400, f"路径解析失败: {exc}")
            return
        if not folder.exists():
            self._reject_upload(404, f"路径不存在: {folder}")
            return
        if not folder.is_dir():
            self._reject_upload(400, f"不是文件夹: {folder}")
            return

        # Count images. Reuse the project's loader so we apply the exact
        # same suffix filter the pipeline will use — no surprises like
        # "browser saw 50 files but pipeline only analyzed 32".
        from pixcull.io.loader import list_images
        try:
            paths = list_images(folder)
        except Exception as exc:  # noqa: BLE001
            self._reject_upload(500, f"扫描失败: {exc}")
            return
        if not paths:
            self._reject_upload(
                400,
                f"在 {folder} 下没找到可分析的图片(支持 jpg/png/cr3/cr2/nef/arw/dng/tif)",
            )
            return

        n = len(paths)
        # V12.0 — license + monthly quota gate. Free tier 100/月.
        from pixcull.license import check_quota, increment_usage
        ok, msg = check_quota(n)
        if not ok:
            self._reject_upload(402, msg)
            return
        increment_usage(n)

        run_id = _new_run_id()
        run_root = _run_dir(run_id)
        output_dir = run_root / "output"
        output_dir.mkdir(parents=True, exist_ok=True)

        # Persist the file manifest so /thumb/<run_id>/<filename> can
        # resolve "filename → absolute original path" later, even if the
        # server restarts mid-run. Plain JSON, one entry per analyzed
        # image. Names are basename-only — pipeline's CSV uses bare names
        # too.
        manifest = {p.name: str(p) for p in paths}
        (output_dir / "manifest.json").write_text(
            json.dumps(manifest, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

        rescorer_mode = self.server.rescorer_mode  # type: ignore[attr-defined]
        rescorer_path = self.server.rescorer_path  # type: ignore[attr-defined]
        vlm_mode = self.server.vlm_mode  # type: ignore[attr-defined]
        meta_mode = self.server.meta_mode  # type: ignore[attr-defined]

        _set_run(
            run_id,
            state="queued",
            mode="scan",
            done=0,
            total=n,
            message=f"已索引 {n} 张图,准备分析(原图不复制)…",
            source_dir=str(folder),
            output_dir=str(output_dir),
            n_uploaded=n,
            origin_folder=str(folder),
            vertical=vertical or None,   # V17.0 — None = auto-detect
        )
        threading.Thread(
            target=_analyze_in_background,
            args=(run_id, rescorer_mode, rescorer_path, vlm_mode, meta_mode),
            daemon=True,
        ).start()

        body = json.dumps({
            "run_id": run_id,
            "n": n,
            "folder": str(folder),
            "sample": [p.name for p in paths[:5]],
        }, ensure_ascii=False).encode("utf-8")
        self._send_json(200, body)

    def _handle_browse(self) -> None:
        """Server-side directory listing for the folder picker.

        Body: {path?: str}  (omit or empty = $HOME)

        Returns: {path, parent, entries: [{name, is_dir, n_images}]}

        We only list directories + show an image-count hint per dir. Files
        themselves aren't listed (pipeline doesn't operate on individual
        files, only folders). Hidden dirs (.*) are skipped to keep the
        UI clean — pose a folder explicitly if you need to scan one.
        """
        clen = int(self.headers.get("Content-Length", "0") or "0")
        body_bytes = self.rfile.read(clen) if clen > 0 else b"{}"
        try:
            params = json.loads(body_bytes.decode("utf-8") or "{}")
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            self._reject_upload(400, f"JSON parse failed: {exc}")
            return

        target_str = (params.get("path") or "").strip() or str(Path.home())
        target = Path(target_str).expanduser()
        try:
            target = target.resolve()
        except OSError as exc:
            self._reject_upload(400, f"路径解析失败: {exc}")
            return
        if not target.is_dir():
            self._reject_upload(404, f"不是文件夹: {target}")
            return

        # Quick image counter — same suffix set as the pipeline. Counting
        # one level down is cheap; recursive count would scale poorly
        # for deep trees.
        IMG_EXTS = {".jpg", ".jpeg", ".png", ".cr3", ".cr2", ".nef", ".arw", ".dng", ".tif", ".tiff"}
        entries = []
        try:
            for child in sorted(target.iterdir(), key=lambda x: x.name.lower()):
                # Skip hidden + system dirs unless target itself is hidden
                if child.name.startswith(".") and not target.name.startswith("."):
                    continue
                if child.is_dir():
                    n_imgs = 0
                    try:
                        for f in child.iterdir():
                            if f.is_file() and f.suffix.lower() in IMG_EXTS:
                                n_imgs += 1
                    except (OSError, PermissionError):
                        n_imgs = -1  # signal "couldn't read"
                    entries.append({
                        "name": child.name,
                        "is_dir": True,
                        "n_images": n_imgs,
                    })
        except PermissionError:
            self._reject_upload(403, f"没有权限读取: {target}")
            return

        # Top-level direct image count — useful when the user lands on
        # a folder that already holds images at its root.
        n_imgs_here = 0
        try:
            for f in target.iterdir():
                if f.is_file() and f.suffix.lower() in IMG_EXTS:
                    n_imgs_here += 1
        except OSError as exc:
            _dbg("browse/iterdir", exc, str(target))

        body = json.dumps({
            "path": str(target),
            "parent": str(target.parent) if target.parent != target else None,
            "n_images_here": n_imgs_here,
            "entries": entries,
        }, ensure_ascii=False).encode("utf-8")
        self._send_json(200, body)

    def _serve_status(self, run_id: str) -> None:
        run = _get_run(run_id)
        if run is None:
            self.send_error(404, "no such run")
            return
        # Strip path fields that the browser doesn't need
        view = {
            k: v for k, v in run.items()
            if k not in ("input_dir", "output_dir")
        }
        body = json.dumps(view, ensure_ascii=False).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _serve_results(self, run_id: str) -> None:
        result = _build_results(run_id)
        if result is None:
            # V14.0 — distinguish "run hasn't started/doesn't exist" from
            # "run finished but produced no analyzable images". The first
            # is a real 404; the second is a polite "your batch contained
            # 0 valid images, here's why" page.
            run = _get_run(run_id) or _reload_run_from_disk(run_id)
            if run is None:
                self.send_error(
                    404,
                    "no such run — run_id may be wrong or expired",
                )
                return
            # Run exists but no scores.csv yet — pipeline still running
            self.send_error(
                425,  # Too Early — semantically correct for "not done yet"
                "results not ready — pipeline may still be running. "
                "Refresh in a few seconds.",
            )
            return
        rows, summary = result
        # V22.1 — assemble per-cluster summary + per-run labels for the
        # UI filter pill row. Labels live in <output_dir>/face_labels.json
        # so they survive server restarts (V22.0's clusters are
        # run-scoped; V22.2+ will add cross-run inheritance).
        face_clusters_info = _build_face_clusters_info(run_id, rows)
        # V23 — GPS location clusters + per-cluster "best" picker.
        locations_info = _build_locations_info(rows, run_id)
        # v2.18-P0 — progressive hydration for big runs. Inlining 5k rows of
        # JSON made the HTML multi-MB and parse-bound; now only the first
        # slice ships inline and the page pulls the rest in the background
        # via /api/v1/runs/<id>/rows (same _build_results fields, localhost
        # auth passes). summary / face_clusters / locations stay computed
        # over the FULL row set, so every count is correct from first paint.
        # PIXCULL_INLINE_ROWS overrides the threshold; 0 disables (inline all).
        try:
            _inline_max = int(os.environ.get("PIXCULL_INLINE_ROWS", "800"))
        except ValueError:
            _inline_max = 800
        inline_rows = rows
        rows_meta = None
        if _inline_max > 0 and len(rows) > _inline_max:
            inline_rows = rows[:_inline_max]
            rows_meta = {"total": len(rows), "inlined": _inline_max,
                         "slice": 1000}
        payload = {
            "run_id": run_id,
            "rows": inline_rows,
            "rows_meta": rows_meta,
            "summary": summary,
            "face_clusters": face_clusters_info,
            "locations": locations_info,
            "video": _build_video_payload(run_id),  # v2.2-P0-2; None=photo run
        }
        # _safe_dumps strips NaN/Infinity (V14.0) so JS JSON.parse never
        # blows up on a stray inf in score_final or a NaN in axis stars.
        # V19.4.1 — hot-reloadable template (loaded from disk per request,
        # mtime-cached). Editing pixcull/report/templates/results.html
        # picks up on the next /results hit; no server restart required.
        html = _results_html_template().replace(
            "__PAYLOAD__",
            _safe_dumps(payload).replace("</", "<\\/"),
        )
        # v2.1-P0-2 — discoverability: a video run gets a floating
        # "🎬 视频审片" button into the P0-4 review surface (and the
        # joint photo+video timeline).  Pure additive inject before
        # </body>; photo runs are untouched.
        rid_safe = _safe_run_id(run_id)
        if rid_safe and is_video_run(rid_safe):
            badge = (
                '<div id="videoReviewCta" style="position:fixed;right:18px;'
                'bottom:18px;z-index:9999;display:flex;gap:8px;align-items:center">'
                f'<a href="/timeline/{rid_safe}" title="照片+视频联合时间线" '
                'style="background:#14161b;color:#eaca98;border:1px solid #d5b584;'
                'text-decoration:none;padding:9px 13px;border-radius:22px;'
                'font:12px system-ui">🗓 联合时间线</a>'
                f'<a href="/video/{rid_safe}" title="视频原生审片 · 时间线 scrubber" '
                'style="background:#d5b584;color:#fff;text-decoration:none;'
                'padding:10px 16px;border-radius:22px;font:13px system-ui;'
                'box-shadow:0 4px 16px rgba(213,181,132,.5)">🎬 视频审片 →</a></div>'
            )
            html = html.replace("</body>", badge + "</body>", 1)
        self._send_html(200, html.encode("utf-8"))

    def _serve_decisions(self, run_id: str) -> None:
        """V21.2 — minimal JSON for the Lightroom plugin write-back.

        Lightroom Lua plugins want as little to parse as possible; this
        endpoint returns ``{filename: decision, ...}`` plus a small
        summary block. The Lr ``WriteBackDecisions.lua`` script reads
        it, maps decisions to star ratings + reject flags
        (keep → 5★, maybe → 3★, cull → reject), and applies them via
        ``LrPhoto:setRawMetadata``.

        Schema:
            {
              "run_id":   str,
              "schema":   "pixcull.decisions.v1",
              "decisions": {filename: "keep"|"maybe"|"cull", ...},
              "summary":  {keep: N, maybe: N, cull: N, total: N},
              "src_paths": {filename: "/abs/path", ...}   # optional
            }

        ``src_paths`` is included so the Lr plugin can match its
        catalog photos by absolute path rather than basename (basename
        collisions across folders are real: every Canon shoot has
        an IMG_0001.jpg). The plugin falls back to basename matching
        if abs paths don't appear in the catalog.
        """
        result = _build_results(run_id)
        if result is None:
            run = _get_run(run_id) or _reload_run_from_disk(run_id)
            if run is None:
                self.send_error(404, "no such run")
                return
            self.send_error(425, "results not ready — pipeline still running")
            return
        rows, summary = result
        decisions: dict[str, str] = {}
        src_paths: dict[str, str] = {}
        for r in rows:
            fn = r.get("filename")
            dec = r.get("decision")
            if not fn or not dec:
                continue
            decisions[fn] = dec
            # Read src_path from the run's scores.csv if available — we
            # already have it in the row builder via ``path``.
            p = r.get("src_path") or r.get("path")
            if p:
                src_paths[fn] = p
        payload = {
            "run_id":    run_id,
            "schema":    "pixcull.decisions.v1",
            "decisions": decisions,
            "summary":   {
                "keep":  sum(1 for v in decisions.values() if v == "keep"),
                "maybe": sum(1 for v in decisions.values() if v == "maybe"),
                "cull":  sum(1 for v in decisions.values() if v == "cull"),
                "total": len(decisions),
            },
            "src_paths": src_paths,
        }
        body = _safe_dumps(payload).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _serve_locations(self, run_id: str) -> None:
        """V23 — GPS location cluster summary for a run.

        Returns the same block we inline into the results-page payload,
        but available as a standalone JSON endpoint for refresh after
        the user picks "select per-location best" so the UI can show
        an updated decision summary.
        """
        result = _build_results(run_id)
        if result is None:
            run = _get_run(run_id) or _reload_run_from_disk(run_id)
            if run is None:
                self.send_error(404, "no such run")
                return
            self.send_error(425, "results not ready")
            return
        rows, _summary = result
        info = _build_locations_info(rows, run_id)
        info["run_id"] = run_id
        info["schema"] = "pixcull.locations.v1"
        body = _safe_dumps(info).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    # --- V28 multi-user / team endpoints ----------------------------------
    def _serve_tether_list(self) -> bool:
        """P2.2 — list active tether sessions."""
        from pixcull.tether import list_sessions
        body = _safe_dumps({
            "schema":   "pixcull.tether.list.v1",
            "sessions": list_sessions(),
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)
        return True

    def _handle_tether_start(self) -> bool:
        """P2.2 — POST /api/v1/tether/start with body
        ``{folder: str, vertical?: str}``. Starts a watcher thread
        that polls the folder for new images and auto-analyzes them.
        Returns the session_id (= run_id) so the caller can hit
        /api/v1/runs/<id>/rows to watch results stream in.
        """
        n = int(self.headers.get("Content-Length") or "0")
        try:
            body = json.loads(self.rfile.read(n).decode("utf-8") or "{}")
        except (json.JSONDecodeError, UnicodeDecodeError):
            self.send_error(400, "invalid JSON")
            return True
        folder = str(body.get("folder") or "").strip()
        if not folder:
            self.send_error(400, "missing 'folder'")
            return True
        vertical = body.get("vertical") or None
        from pixcull.tether import start_session
        try:
            session = start_session(Path(folder), vertical=vertical)
        except ValueError as exc:
            self.send_error(400, str(exc))
            return True
        out = _safe_dumps({
            "ok":          True,
            "session_id":  session.session_id,
            "run_id":      session.run_id,
            "status":      session.status(),
            "results_url": f"/results/{session.run_id}",
        }).encode("utf-8")
        self.send_response(201)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(out)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(out)
        return True

    def _handle_tether_stop(self, session_id: str) -> bool:
        """P2.2 — POST /api/v1/tether/<session>/stop. Idempotent."""
        from pixcull.tether import stop_session
        ok = stop_session(session_id)
        body = _safe_dumps({
            "ok":         ok,
            "session_id": session_id,
        }).encode("utf-8")
        self.send_response(200 if ok else 404)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)
        return True

    def _serve_sync_status(self) -> bool:
        """INFRA-2 — sync configuration + per-subtree state for the
        active user. See pixcull.sync.status() for the shape."""
        from pixcull.sync import status as sync_status
        body = _safe_dumps(sync_status()).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)
        return True

    def _handle_sync_configure(self) -> bool:
        """INFRA-2 — POST /api/v1/sync_configure with body
        ``{user_id?: str, team_id?: str}`` (one of). Wires the
        sync subtrees for that user/team (symlinks them through
        the shared target). Idempotent.
        """
        n = int(self.headers.get("Content-Length") or "0")
        try:
            body = json.loads(self.rfile.read(n).decode("utf-8") or "{}")
        except (json.JSONDecodeError, UnicodeDecodeError):
            self.send_error(400, "invalid JSON")
            return True
        uid = str(body.get("user_id") or "").strip()
        tid = str(body.get("team_id") or "").strip()
        if not uid and not tid:
            self.send_error(400, "expected user_id or team_id")
            return True
        from pixcull.sync import (
            configure_sync_for_user, configure_sync_for_team,
        )
        if uid:
            result = configure_sync_for_user(uid)
        else:
            result = configure_sync_for_team(tid)
        out = _safe_dumps(result).encode("utf-8")
        self.send_response(200 if result.get("ok") else 400)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(out)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(out)
        return True

    def _serve_llm_budget(self) -> bool:
        """INFRA-4 — daily LLM spend ledger snapshot.

        Returns ``{date_utc, today_yuan, cap_yuan, remaining_yuan,
        calls_today, over_cap, by_model, all_dates[:30]}``. Cap is
        from ``PIXCULL_LLM_BUDGET_YUAN`` env (default 10 yuan/day).
        """
        from pixcull.llm_budget import snapshot
        body = _safe_dumps(snapshot()).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)
        return True

    def _serve_users_list(self) -> bool:
        """V28 — list all user profiles + which one is active."""
        from pixcull.users import list_users, get_active_user
        body = _safe_dumps({
            "schema":   "pixcull.api.v1.users.list",
            "active":   get_active_user(),
            "users":    list_users(),
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)
        return True

    def _serve_users_active(self) -> bool:
        """V28 — just the active user id. Useful for the UI to show
        ``Logged in as: <id>`` in the corner.
        """
        from pixcull.users import get_active_user
        body = _safe_dumps({"active": get_active_user()}).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)
        return True

    def _serve_team_taste(self) -> bool:
        """v0.10-P1-1 — GET /api/v1/team_taste

        Walks every user under <data_root>/users/<uid>/preferences.json
        and emits the team baseline + per-user discrepancy report.
        Caller-side UI (admin page) renders the high-z-score pairs
        first so a studio lead sees "小李 偏好 composition +0.18
        over team mean" at the top.
        """
        try:
            from pixcull.team import (
                aggregate_taste, discrepancy_report, load_user_taste,
            )
            from pixcull.users import list_users, user_root
        except Exception as exc:
            _dbg("team_taste/import", exc, "init")
            self.send_error(500, "team module import failed")
            return True
        try:
            users = list_users()
        except Exception as exc:
            _dbg("team_taste/list_users", exc, "init")
            users = []
        per_user_tastes: dict[str, dict[str, float]] = {}
        for u in users:
            uid = u.get("user_id") if isinstance(u, dict) else None
            if not uid:
                continue
            try:
                root = user_root(uid)
            except Exception:
                continue
            pref_path = Path(root) / "preferences.json"
            taste = load_user_taste(pref_path)
            if taste is not None:
                per_user_tastes[uid] = taste
        base = aggregate_taste(per_user_tastes)
        disc = discrepancy_report(per_user_tastes, baseline=base)
        body = _safe_dumps({
            "schema":     "pixcull.api.v1.team_taste/v1",
            "n_users":    len(per_user_tastes),
            "baseline":   base,
            "discrepancy": disc,
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)
        return True

    def _handle_users_active_post(self) -> bool:
        """V28.2 — POST /api/v1/users/active with body
        ``{user_id: str}`` sets the ``pixcull_user`` cookie. The
        cookie applies only to this browser session; the env var
        baseline is unchanged. Pass empty string / no body to
        clear the cookie (revert to env-var default).

        The cookie is HttpOnly so JS can't read it (mitigates the
        XSS-leaks-active-user attack vector), SameSite=Lax so it
        survives cross-tab navigation but not cross-site requests.
        """
        from pixcull.users import _USER_ID_RE
        n = int(self.headers.get("Content-Length") or "0")
        try:
            body = json.loads(self.rfile.read(n).decode("utf-8") or "{}")
        except (json.JSONDecodeError, UnicodeDecodeError):
            self.send_error(400, "invalid JSON")
            return True
        uid = str(body.get("user_id") or "").strip()
        # Validate against the same allowlist as create_user. Empty
        # input is OK — that's the "clear cookie" signal.
        if uid and not _USER_ID_RE.match(uid):
            self.send_error(400, "invalid user_id format")
            return True
        out_body = _safe_dumps({
            "ok":     True,
            "active": uid or "default",
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(out_body)))
        # Cookie management: set when uid is non-empty, expire (Max-Age=0)
        # when it's the empty "clear" signal.
        if uid:
            self.send_header(
                "Set-Cookie",
                f"pixcull_user={uid}; Path=/; HttpOnly; "
                f"SameSite=Lax; Max-Age=2592000",   # 30 days
            )
        else:
            self.send_header(
                "Set-Cookie",
                "pixcull_user=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0",
            )
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(out_body)
        return True

    def _handle_users_create(self) -> bool:
        """V28 — POST /api/v1/users with body {user_id: str}.
        Creates a new profile dir. Idempotent.
        """
        from pixcull.users import create_user
        n = int(self.headers.get("Content-Length") or "0")
        try:
            body = json.loads(self.rfile.read(n).decode("utf-8") or "{}")
        except (json.JSONDecodeError, UnicodeDecodeError):
            self.send_error(400, "invalid JSON")
            return True
        try:
            result = create_user(str(body.get("user_id") or ""))
        except ValueError as exc:
            self.send_error(400, str(exc))
            return True
        # INFRA-2 — auto-wire sync if a shared target is configured.
        # No-op (and no error) when PIXCULL_SYNC_DIR isn't set, so
        # single-machine installs are unaffected.
        sync_result = None
        try:
            from pixcull.sync import configure_sync_for_user
            sync_result = configure_sync_for_user(result["user_id"])
        except Exception as exc:  # noqa: BLE001
            sync_result = {"ok": False, "error": str(exc)}
        out_body: dict = {"ok": True, **result}
        if sync_result and sync_result.get("ok"):
            out_body["sync"] = "configured"
        out = _safe_dumps(out_body).encode("utf-8")
        self.send_response(201 if result["created"] else 200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(out)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(out)
        return True

    def _handle_team_subscribe(self, user_id: str) -> bool:
        """V28 — POST /api/v1/users/<uid>/team_subscribe with body
        {vertical: str, team_id: str|""}.
        Empty team_id = unsubscribe (restore personal bank).
        """
        from pixcull.users import subscribe_to_team_vertical
        n = int(self.headers.get("Content-Length") or "0")
        try:
            body = json.loads(self.rfile.read(n).decode("utf-8") or "{}")
        except (json.JSONDecodeError, UnicodeDecodeError):
            self.send_error(400, "invalid JSON")
            return True
        try:
            result = subscribe_to_team_vertical(
                user_id,
                str(body.get("vertical") or ""),
                str(body.get("team_id") or ""),
            )
        except (ValueError, KeyError) as exc:
            self.send_error(400, str(exc))
            return True
        out = _safe_dumps({"ok": True, **result}).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(out)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(out)
        return True

    def _handle_auto_caption(self, run_id: str) -> None:
        """P2.5 — generate per-photo IPTC captions for a run.

        Body (all optional):
            ``{polish: bool, decisions: ["keep", ...]}``

        Default: ``polish=false`` (compose mode, zero API cost,
        offline). ``decisions`` defaults to ``["keep"]`` — we don't
        waste captions on rows the photographer is going to discard.

        The generated captions land at
        ``<output>/auto_captions.json`` and the next /export run
        picks them up automatically (V29 sidecar / V29.1 embedded).
        """
        run = _get_run(run_id) or _reload_run_from_disk(run_id)
        if run is None:
            self.send_error(404, "no such run")
            return
        result = _build_results(run_id)
        if result is None:
            self.send_error(425, "results not ready")
            return
        rows, _summary = result
        n = int(self.headers.get("Content-Length") or "0")
        params: dict = {}
        if n > 0:
            try:
                params = json.loads(self.rfile.read(n).decode("utf-8")
                                      or "{}")
            except (json.JSONDecodeError, UnicodeDecodeError):
                self.send_error(400, "invalid JSON body")
                return
        polish = bool(params.get("polish") or False)
        decisions = tuple(params.get("decisions") or ["keep"])

        from pixcull.scoring.caption_gen import generate_for_run
        face_labels = _load_face_labels(run_id)
        location_labels = _load_location_labels(run_id)
        output_dir = Path(run["output_dir"])
        info = generate_for_run(
            rows, output_dir,
            face_labels=face_labels,
            location_labels=location_labels,
            polish=polish,
            decisions=decisions,
        )
        body = _safe_dumps({
            "ok":          True,
            "run_id":      run_id,
            "polish":      polish,
            "decisions":   list(decisions),
            **info,
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _handle_location_label_post(self, run_id: str) -> None:
        """V23.1 — POST /locations/<run_id>/label with body
        ``{cluster_id: int, label: str}``. Empty label = remove.
        Mirrors V22.1's face-label handler.
        """
        run = _get_run(run_id) or _reload_run_from_disk(run_id)
        if run is None:
            self.send_error(404, "no such run")
            return
        n = int(self.headers.get("Content-Length") or "0")
        try:
            body = json.loads(self.rfile.read(n).decode("utf-8") or "{}")
        except (json.JSONDecodeError, UnicodeDecodeError):
            self.send_error(400, "invalid JSON body")
            return
        try:
            cid = int(body.get("cluster_id"))
        except (TypeError, ValueError):
            self.send_error(400, "cluster_id must be int")
            return
        label = str(body.get("label") or "").strip()
        if len(label) > 60:        # locations get a bit more room
            label = label[:60]
        labels = _load_location_labels(run_id)
        if label:
            labels[cid] = label
        else:
            labels.pop(cid, None)
        if not _save_location_labels(run_id, labels):
            self.send_error(500, "failed to persist labels")
            return
        out_body = _safe_dumps({
            "ok":     True,
            "run_id": run_id,
            "labels": {str(k): v for k, v in labels.items()},
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(out_body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(out_body)

    def _serve_face_avatar(self, rel: str) -> None:
        """V22.3 — serve a per-cluster face crop JPEG.

        URL: /face_avatar/<run_id>/<cluster_id>
        File: <output_dir>/face_avatars/cluster_<cluster_id>.jpg

        Returns 404 if the avatar doesn't exist (no faces in run, or
        run pre-dates V22.3 — UI falls back to text-only pill).
        """
        parts = unquote(rel).split("/", 1)
        if len(parts) != 2:
            self.send_error(400, "expected /<run_id>/<cluster_id>")
            return
        run_id, cid_str = parts
        try:
            cid = int(cid_str)
        except ValueError:
            self.send_error(400, "cluster_id must be int")
            return
        run = _get_run(run_id) or _reload_run_from_disk(run_id)
        if run is None:
            self.send_error(404, "no such run")
            return
        p = Path(run["output_dir"]) / "face_avatars" / f"cluster_{cid}.jpg"
        if not p.exists():
            self.send_error(404, "no avatar for this cluster")
            return
        data = p.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", "image/jpeg")
        self.send_header("Content-Length", str(len(data)))
        # Long cache — avatars are content-stable per (run_id, cluster_id)
        self.send_header("Cache-Control", "public, max-age=86400")
        self.end_headers()
        self.wfile.write(data)

    def _serve_face_clusters(self, run_id: str) -> None:
        """V22.1 — face cluster summary + labels for a run.

        Returns the same block we inline into the results-page payload,
        but available as a standalone JSON endpoint so the UI can
        refresh after a label edit without re-rendering the whole
        results page.
        """
        result = _build_results(run_id)
        if result is None:
            run = _get_run(run_id) or _reload_run_from_disk(run_id)
            if run is None:
                self.send_error(404, "no such run")
                return
            self.send_error(425, "results not ready")
            return
        rows, _summary = result
        info = _build_face_clusters_info(run_id, rows)
        info["run_id"] = run_id
        info["schema"] = "pixcull.face_clusters.v1"
        body = _safe_dumps(info).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _handle_face_label_post(self, run_id: str) -> None:
        """V22.1 — POST /face_clusters/<run_id>/label with body
        {cluster_id: int, label: str} to set a cluster's label.

        Empty / whitespace-only label removes the entry (treat as "unlabel").
        Returns {ok: true, labels: {...latest...}} on success.
        """
        run = _get_run(run_id) or _reload_run_from_disk(run_id)
        if run is None:
            self.send_error(404, "no such run")
            return
        n = int(self.headers.get("Content-Length") or "0")
        try:
            body = json.loads(self.rfile.read(n).decode("utf-8") or "{}")
        except (json.JSONDecodeError, UnicodeDecodeError):
            self.send_error(400, "invalid JSON body")
            return
        try:
            cid = int(body.get("cluster_id"))
        except (TypeError, ValueError):
            self.send_error(400, "cluster_id must be int")
            return
        label = str(body.get("label") or "").strip()
        # Length cap so a typo doesn't write a megabyte filename.
        if len(label) > 40:
            label = label[:40]

        labels = _load_face_labels(run_id)
        if label:
            labels[cid] = label
        else:
            labels.pop(cid, None)
        if not _save_face_labels(run_id, labels):
            self.send_error(500, "failed to persist labels")
            return

        # V22.2 — when a cluster gets a non-empty label, promote its
        # centroid into the active user's global face library so the
        # label can be auto-inherited in future runs. Unsubscribe
        # (empty label) is a no-op on the library — we don't try to
        # remove past centroids, since the user might re-label later.
        if label:
            try:
                from pixcull.pipeline.face_library import (
                    load_run_centroids, add_to_library,
                )
                from pixcull.users import get_active_user, user_root
                run_dir = Path(run["output_dir"])
                cents = load_run_centroids(run_dir)
                if cents is not None:
                    cluster_ids_arr, centroids = cents
                    # Find the centroid for this specific cluster id
                    matches = (cluster_ids_arr == cid).nonzero()[0]
                    if len(matches) > 0:
                        idx = int(matches[0])
                        add_to_library(
                            user_root(get_active_user()),
                            label,
                            centroids[idx],
                        )
            except Exception as exc:  # noqa: BLE001
                # Library promotion failed — log but don't error the
                # label save (the label is still saved per-run).
                print(f"[label_post] library promotion skipped: "
                      f"{type(exc).__name__}: {exc}", file=sys.stderr)
        out_body = _safe_dumps({
            "ok":     True,
            "run_id": run_id,
            "labels": {str(k): v for k, v in labels.items()},
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(out_body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(out_body)

    def _serve_image(self, rel: str, size: int) -> None:
        # Format: <run_id>/<filename>[?w=N]
        # V14.1 — the client may pass ?w=<viewport_width> so we cap
        # decode at that pixel size. On a 1280-wide laptop a 50-MP
        # JPEG used to materialize 6720×4480 RGB pixels in RAM before
        # downsizing to 1600 — about 90 MB of intermediate data per
        # lightbox click. With ?w= we serve a cache bucket sized to
        # what the client can actually display.
        rel = unquote(rel)
        # Strip + parse query string before run/fn split
        from urllib.parse import parse_qs, urlsplit
        sp = urlsplit("/" + rel)  # path-shaped helper, not a real URL
        rel_path = sp.path.lstrip("/")
        qs = parse_qs(sp.query) if sp.query else {}
        try:
            req_w = int(qs.get("w", ["0"])[0])
        except (TypeError, ValueError):
            req_w = 0
        # Clamp to a sane range. Below 600 isn't worth caching (smaller
        # than every lightbox); above 4096 is past 5K monitors. We round
        # to a few buckets so caches can be reused across slightly
        # different client widths (1280 + 1300 + 1320 all hit the same
        # 1280 bucket).
        #
        # v0.6 (4/5) — also support sub-_THUMB_SIZE buckets [200, 280,
        # 420] so callers that already know they need a tiny thumb
        # (filmstrip strip is 64px tall = ~120-180px wide; similar-
        # photos row is similar) can pull a 200px JPEG instead of the
        # default 420. Halves the bytes per filmstrip photo and cuts
        # decode time on long batches; the new cache key (".200.v3.jpg")
        # never collides with the existing 420 cache.
        if req_w > 0:
            if req_w <= _THUMB_SIZE:
                small_buckets = [200, 280, _THUMB_SIZE]
                chosen = next(
                    (b for b in small_buckets if req_w <= b),
                    small_buckets[-1],
                )
                size = min(chosen, size)
            else:
                buckets = [800, 1200, 1600, 2000, 2400, 3200, 4000]
                chosen = next(
                    (b for b in buckets if req_w <= b), buckets[-1]
                )
                size = min(chosen, size) if size > _THUMB_SIZE else size
        if "/" not in rel_path:
            self.send_error(400, "expected run_id/filename")
            return
        run_id, fn = rel_path.split("/", 1)
        run = _get_run(run_id)
        if run is None:
            # Fall back to disk: maybe the run is from a previous session.
            # Pull mode + source from the on-disk manifest if present.
            run = _reload_run_from_disk(run_id)
        if run is None:
            self.send_error(404, "no such run")
            return

        # Resolve filename to a real on-disk source. In upload mode the
        # answer is ``input_dir/<filename>``; in scan mode we look it up
        # in the manifest written when the run started, since the
        # originals live in an arbitrary user folder.
        src = _resolve_image_source(run, Path(fn).name)
        if src is None or not src.exists():
            self.send_error(404, f"not found: {fn}")
            return

        cache_dir = Path(run["output_dir"]) / "thumbs"
        cache_dir.mkdir(parents=True, exist_ok=True)
        # V16.1 — cache key bumped to v2 so stale caches generated
        # before EXIF auto-rotate (which displayed phone-shot portrait
        # JPEGs in their on-disk landscape orientation) are invalidated
        # without a manual ``rm -rf /tmp/pixcull_demo``. Old .jpg files
        # remain on disk but aren't read; admin-page "清理" still
        # cleans them.
        # V26 — cache key bumped to v3 because the loader logic
        # changed: for RAW files at sizes ≥ 1600 we now use
        # ``load_image_for_display`` (quality-preserving full
        # postprocess when the embedded JPEG is too small) instead
        # of the fast ``load_image`` (which always took the
        # embedded thumbnail). Existing v2 caches for RAW would
        # serve a soft preview where the user expects a sharp one.
        # v0.13.5 — WebP content negotiation.  Chrome / Firefox /
        # Safari (since 14) / Edge all send `Accept: image/webp` —
        # WebP at the same visual quality is ~25-35% smaller than
        # JPEG.  Falls back to JPEG when the client doesn't advertise.
        accept_hdr = self.headers.get("Accept", "")
        # The client can also force-disable via ?fmt=jpg (debug)
        force_fmt = qs.get("fmt", [""])[0].lower()
        want_webp = (
            force_fmt != "jpg"
            and "image/webp" in accept_hdr.lower()
            # We only encode WebP for SMALL caches (≤ THUMB_SIZE) so
            # the lightbox's high-res 4K JPEG stays untouched — pros'
            # workflow expects baseline JPEG for the loupe.
            and size <= _THUMB_SIZE
        )
        ext = "webp" if want_webp else "jpg"
        cache_path = cache_dir / f"{src.name}.{size}.v3.{ext}"
        if not cache_path.exists():
            # V26: large requests get the display loader, small
            # ones (thumbnail grid) keep the fast path.
            if size >= 1600:
                from pixcull.io.loader import load_image_for_display
                img = load_image_for_display(src, max_side=size)
            else:
                from pixcull.io.loader import load_image
                img = load_image(src, max_side=size)
            if img is None:
                self.send_error(500, "image decode failed")
                return
            quality = 78 if size <= _THUMB_SIZE else 88
            if want_webp:
                # WebP method=4 is the sweet spot (~4× slower encode
                # than JPEG, ~30% smaller output).  method=6 is +5%
                # smaller but 12× slower; not worth it for a one-shot
                # cache.  ``lossless=False`` is implicit at this quality.
                try:
                    img.save(cache_path, "WEBP",
                             quality=quality, method=4)
                except (OSError, ValueError, KeyError):
                    # Older Pillow / unsupported build — fall back.
                    cache_path = cache_path.with_suffix(".jpg")
                    img.save(cache_path, "JPEG", quality=quality, optimize=True)
                    want_webp = False
            else:
                img.save(cache_path, "JPEG", quality=quality, optimize=True)
        data = cache_path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type",
                         "image/webp" if want_webp else "image/jpeg")
        self.send_header("Content-Length", str(len(data)))
        self.send_header(
            "Cache-Control", "public, max-age=31536000, immutable"
        )
        # v0.13.5 — make the WebP path debuggable via Vary so a CDN
        # would cache both variants per Accept header.
        if size <= _THUMB_SIZE:
            self.send_header("Vary", "Accept")
        self.end_headers()
        self.wfile.write(data)

    def _handle_export(self, run_id: str) -> None:
        """Write XMP sidecars for every analyzed image in the run.

        Body: {target?: "tmp" | "alongside"}  (default "tmp")

        ``tmp``        — Write to ``<run_id>/output/xmp/`` and zip up.
                         Always available. User downloads + manually
                         drops next to originals on the LR/C1 side.
        ``alongside``  — Scan-mode only. Write each <name>.xmp directly
                         next to its original image. Lightroom picks it
                         up on next "Read Metadata from File" without
                         any manual file moving.

        We never touch the user's originals' bytes — only write a new
        sibling .xmp file. If a sidecar already exists with the same
        name, ``write_xmp`` overwrites it (documented behavior).
        """
        run = _get_run(run_id)
        if run is None:
            run = _reload_run_from_disk(run_id)
        if run is None:
            self.send_error(404, "no such run")
            return
        # State check uses live dict; reloaded runs are assumed "done"
        # because the only way to get here without state=done is a
        # session restart, which by definition can only happen after
        # the previous analyzer thread exited.
        live = _get_run(run_id)
        if live and live.get("state") not in ("done", None):
            self.send_error(409, "run not finished yet")
            return

        # Read optional body for target mode
        clen = int(self.headers.get("Content-Length", "0") or "0")
        target_mode = "tmp"
        if clen > 0:
            try:
                params = json.loads(self.rfile.read(clen).decode("utf-8") or "{}")
                target_mode = params.get("target", "tmp")
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                _dbg("export/parse_body", exc)
        # V29.1 — new "embedded" mode writes IPTC INTO the original
        # file via exiftool. Same scope rules as "alongside": only
        # works for scanned runs where we know the originals.
        if target_mode not in ("tmp", "alongside", "embedded"):
            self._reject_upload(
                400,
                "target must be 'tmp' / 'alongside' / 'embedded'",
            )
            return
        if target_mode in ("alongside", "embedded") and run.get("mode") != "scan":
            self._reject_upload(
                400,
                "'alongside' / 'embedded' 模式只在扫描本地文件夹时可用 —— "
                "上传模式没有原图位置可写。",
            )
            return
        if target_mode == "embedded":
            from pixcull.io.iptc_embed import is_available, install_hint
            if not is_available():
                self._reject_upload(
                    500,
                    "embedded 模式需要 exiftool。\n" + install_hint(),
                )
                return

        result = _build_results(run_id)
        if result is None:
            self.send_error(500, "no results to export")
            return
        rows, _ = result

        from pixcull.io.xmp import (
            write_xmp, decision_to_xmp, build_iptc_fields_from_row,
        )

        output_dir = Path(run["output_dir"])
        xmp_dir = output_dir / "xmp"
        xmp_dir.mkdir(parents=True, exist_ok=True)

        # V29 — surface face cluster labels + run vertical for IPTC
        # keyword generation. ``face_labels`` is {cluster_id: label};
        # ``vertical`` is the per-run scoring override (V17.0+).
        face_labels = _load_face_labels(run_id)
        run_vertical = run.get("vertical") or None
        # P2.5 — load any pre-computed auto-captions for this run.
        # When present, ``build_iptc_fields_from_row`` uses them as
        # IPTC:Caption-Abstract instead of the V20-advice bullets.
        from pixcull.scoring.caption_gen import load_captions
        auto_captions_map = load_captions(output_dir)

        written = 0
        skipped = 0
        per_decision: Counter[str] = Counter()
        for r in rows:
            fn = r["filename"]
            decision = r["decision"]
            stars, label = decision_to_xmp(decision)
            # V29 — IPTC fields (keywords / description / headline)
            # derived from the row + advice + face labels.
            iptc = build_iptc_fields_from_row(
                r,
                advice=r.get("advice") or None,
                face_labels=face_labels,
                vertical=run_vertical,
                run_id=run_id,
                auto_caption=auto_captions_map.get(fn),
            )
            if target_mode == "alongside":
                src = _resolve_image_source(run, fn)
                if src is None:
                    skipped += 1
                    continue
                # Sidecar lands at <orig_dir>/<stem>.xmp
                write_xmp(src, stars, label,
                          keywords=iptc["keywords"],
                          description=iptc["description"],
                          headline=iptc["headline"])
            elif target_mode == "embedded":
                # V29.1 — write IPTC into the original via exiftool.
                # No sidecar; metadata travels with the file.
                src = _resolve_image_source(run, fn)
                if src is None:
                    skipped += 1
                    continue
                from pixcull.io.iptc_embed import write_iptc_to_file
                ok = write_iptc_to_file(
                    src,
                    rating=stars, color_label=label,
                    keywords=iptc["keywords"],
                    description=iptc["description"],
                    headline=iptc["headline"],
                )
                if not ok:
                    skipped += 1
                    continue
            else:
                virtual = xmp_dir / Path(fn).name
                write_xmp(virtual, stars, label,
                          keywords=iptc["keywords"],
                          description=iptc["description"],
                          headline=iptc["headline"])
            written += 1
            per_decision[decision] += 1

        response = {
            "written": written,
            "skipped": skipped,
            "per_decision": dict(per_decision),
            "target": target_mode,
        }
        if target_mode == "tmp":
            response["zip_url"] = f"/xmp_zip/{run_id}"
            response["xmp_dir"] = str(xmp_dir)
        else:
            response["origin_folder"] = run.get("origin_folder") or run.get("source_dir")

        body = json.dumps(response, ensure_ascii=False).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _serve_scores_csv(self, run_id: str) -> None:
        """V9.3: download scores.csv directly. Includes the BOM for
        Excel-friendly Chinese display + an attachment Content-Disposition
        so the browser saves it instead of rendering."""
        run = _get_run(run_id) or _reload_run_from_disk(run_id)
        if run is None:
            self.send_error(404, "no such run")
            return
        csv_path = Path(run["output_dir"]) / "scores.csv"
        if not csv_path.exists():
            self.send_error(404, "scores.csv not generated yet")
            return
        # Prepend a UTF-8 BOM so Excel doesn't show 中文 as garbled.
        data = b"\xef\xbb\xbf" + csv_path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", "text/csv; charset=utf-8")
        self.send_header(
            "Content-Disposition",
            f'attachment; filename="pixcull_{run_id}_scores.csv"',
        )
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    # ============================================================
    # v0.8-P2-2 — structured CSV / JSON export
    #
    # Goes BEYOND the legacy scores.csv (which is just the analyser's
    # native dump) by joining in:
    #   * latest annotation per filename (decision / cull_reason /
    #     rubric_human_stars / overall_label)
    #   * bucket assignments (which delivery buckets a filename
    #     belongs to — but those live in localStorage, so we surface
    #     server-side annotations only)
    #   * style distance map (v0.7-P2-1 + v0.8-P1-1) — v1, v2, blend
    #
    # The "Lr Catalog import template" (.lrcat-ready SQLite) is a
    # bigger lift (LR's catalog schema is undocumented, reverse-
    # engineered binary) → deferred to v0.9 / v1.0.  V1 here gives
    # pros a clean JSON pipe into their own Lr-import scripts.
    # ============================================================
    def _collect_structured_rows(self, run: dict) -> list[dict]:
        """Merge scores.csv + annotations.jsonl + style_distances.json
        into one list of per-filename dicts.

        Returns rows in scores.csv order so existing pipelines that
        rely on row ordering keep working.
        """
        import csv as _csv

        output_dir = Path(run["output_dir"])
        scores_path = output_dir / "scores.csv"
        if not scores_path.exists():
            return []
        rows: list[dict] = []
        try:
            with open(scores_path, "r", encoding="utf-8-sig", newline="") as fh:
                for r in _csv.DictReader(fh):
                    rows.append(dict(r))
        except OSError as exc:
            _dbg("export/structured/scores_read", exc, str(scores_path))
            return []
        # Latest annotation per filename (annotations.jsonl is
        # append-only, last line wins).
        ann_by_fn: dict = {}
        ann_path = output_dir / "annotations.jsonl"
        if ann_path.exists():
            try:
                with open(ann_path, "r", encoding="utf-8") as fh:
                    for line in fh:
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            row = json.loads(line)
                        except ValueError:
                            continue
                        if not isinstance(row, dict):
                            continue
                        fn = row.get("filename")
                        if isinstance(fn, str) and fn:
                            ann_by_fn[fn] = row
            except OSError as exc:
                _dbg("export/structured/ann_read", exc, str(ann_path))
        # Style distances (rich shape {v1, v2?, blend})
        style_path = output_dir / "style_distances.json"
        style_map: dict = {}
        if style_path.exists():
            try:
                style_map = json.loads(style_path.read_text("utf-8"))
                if not isinstance(style_map, dict):
                    style_map = {}
            except (OSError, ValueError):
                style_map = {}
        # Merge
        for r in rows:
            fn = r.get("filename") or ""
            ann = ann_by_fn.get(fn) or {}
            # Annotation overrides win for decision / cull_reason
            if ann.get("overall_label"):
                r["decision_human"] = ann.get("overall_label")
            if ann.get("cull_reason"):
                r["cull_reason_human"] = ann.get("cull_reason")
            r["annotation_timestamp"] = ann.get("timestamp")
            r["annotation_source"] = ann.get("source")
            # Style distances
            sd = style_map.get(fn)
            if isinstance(sd, (int, float)):
                r["style_distance"] = sd
                r["style_distance_v1"] = sd
            elif isinstance(sd, dict):
                if "v1" in sd:    r["style_distance_v1"] = sd["v1"]
                if "v2" in sd:    r["style_distance_v2"] = sd["v2"]
                if "blend" in sd: r["style_distance"] = sd["blend"]
        return rows

    def _serve_export_structured_json(self, run_id: str) -> None:
        """GET /export/structured/<run>.json → {schema, run_id, rows: [...]}

        Schema is pixcull.export.structured/v1 — every row carries
        every scores.csv column plus annotation + style-distance
        overlays.  Useful for users writing their own LR-import
        scripts or feeding the data into a separate analytics
        pipeline.
        """
        run = _get_run(run_id) or _reload_run_from_disk(run_id)
        if run is None:
            self.send_error(404, "no such run")
            return
        rows = self._collect_structured_rows(run)
        payload = {
            "schema":      "pixcull.export.structured/v1",
            "run_id":      run_id,
            "exported_at": datetime.now(timezone.utc).isoformat(),
            "n_rows":      len(rows),
            "rows":        rows,
        }
        body = json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header(
            "Content-Disposition",
            f'attachment; filename="pixcull_{run_id}_structured.json"',
        )
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _serve_export_structured_csv(self, run_id: str) -> None:
        """GET /export/structured/<run>.csv → same data as JSON variant
        but in a flat CSV (one row per filename, union of all keys
        as columns; missing → empty cell).
        """
        import csv as _csv
        import io

        run = _get_run(run_id) or _reload_run_from_disk(run_id)
        if run is None:
            self.send_error(404, "no such run")
            return
        rows = self._collect_structured_rows(run)
        if not rows:
            self.send_error(404, "no rows to export")
            return
        # Union of columns, preserving the order: scores.csv-natural
        # columns first (taken from the first row), then any
        # additional keys appended in encounter order.
        seen: dict = {}
        for r in rows:
            for k in r.keys():
                if k not in seen:
                    seen[k] = True
        fieldnames = list(seen.keys())
        buf = io.StringIO()
        # BOM for Excel
        buf.write("﻿")
        writer = _csv.DictWriter(buf, fieldnames=fieldnames)
        writer.writeheader()
        for r in rows:
            writer.writerow({k: r.get(k, "") for k in fieldnames})
        body = buf.getvalue().encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/csv; charset=utf-8")
        self.send_header(
            "Content-Disposition",
            f'attachment; filename="pixcull_{run_id}_structured.csv"',
        )
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _serve_gallery_zip(self, rel: str) -> None:
        """V23.x — standalone HTML gallery export for a run.

        URL: /gallery_zip/<run_id>?include=keep[,maybe[,cull]]

        Default is keep-only (the typical client deliverable). Pass
        ``include=keep,maybe`` to also surface ambiguous shots, or
        ``include=keep,maybe,cull`` to dump everything.

        Streams the assembled zip as ``Content-Disposition: attachment``
        so the browser saves it instead of opening it.
        """
        # Split run_id from query string
        if "?" in rel:
            run_id, qs = rel.split("?", 1)
        else:
            run_id, qs = rel, ""
        from urllib.parse import parse_qs
        qparams = parse_qs(qs)
        include_raw = qparams.get("include", ["keep"])[0]
        include = tuple(
            x.strip() for x in include_raw.split(",")
            if x.strip() in ("keep", "maybe", "cull")
        ) or ("keep",)

        result = _build_results(run_id)
        if result is None:
            run = _get_run(run_id) or _reload_run_from_disk(run_id)
            if run is None:
                self.send_error(404, "no such run")
                return
            self.send_error(425, "results not ready")
            return
        rows, _summary = result

        from pixcull.report.gallery import build_gallery_zip
        try:
            data = build_gallery_zip(
                run_id, rows, include_decisions=include,
            )
        except Exception as exc:  # noqa: BLE001
            self.send_error(500, f"gallery build failed: {exc}")
            return

        title_decisions = "_".join(include)
        self.send_response(200)
        self.send_header("Content-Type", "application/zip")
        self.send_header(
            "Content-Disposition",
            f'attachment; filename="pixcull_{run_id}_gallery_{title_decisions}.zip"',
        )
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _serve_xmp_zip(self, run_id: str) -> None:
        """Stream all sidecars + a README into a single zip download."""
        import zipfile

        run = _get_run(run_id) or _reload_run_from_disk(run_id)
        if run is None:
            self.send_error(404, "no such run")
            return
        xmp_dir = Path(run["output_dir"]) / "xmp"
        if not xmp_dir.exists():
            self.send_error(404, "no xmp exported yet — POST /export first")
            return

        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
            for sidecar in sorted(xmp_dir.glob("*.xmp")):
                zf.write(sidecar, arcname=sidecar.name)
            zf.writestr(
                "README.txt",
                _XMP_README.format(
                    run_id=run_id,
                    n=len(list(xmp_dir.glob("*.xmp"))),
                ),
            )
        data = buf.getvalue()
        self.send_response(200)
        self.send_header("Content-Type", "application/zip")
        self.send_header(
            "Content-Disposition",
            f'attachment; filename="pixcull_{run_id}_xmp.zip"',
        )
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    # --- rubric / annotation (V2.0) ---------------------------------------
    def _serve_rubric_meta(self) -> None:
        """Static rubric definition: axis names + descriptors + checklist.

        Sent once on results-page load so the client can render the
        annotation form locally without re-requesting on every image.
        """
        from pixcull.scoring.rubric import RUBRIC_AXES
        meta = [
            {
                "name": a.name,
                "label_zh": a.label_zh,
                "label_en": a.label_en,
                "description_zh": a.description_zh,
                "rubric_descriptors": list(a.rubric_descriptors),
                "checklist": [{"key": k, "weight": w} for k, w in a.checklist],
            }
            for a in RUBRIC_AXES
        ]
        self._send_json(200, json.dumps(
            {"axes": meta}, ensure_ascii=False
        ).encode("utf-8"))

    def _serve_rubric(self, rel: str) -> None:
        """GET /rubric/<run_id> → all auto-decomposed rubric scores
        for this run. Read straight off rubric.jsonl on disk so the
        client can sort/filter without holding everything in memory.
        """
        run_id = unquote(rel)
        run = _get_run(run_id) or _reload_run_from_disk(run_id)
        if run is None:
            self.send_error(404, "no such run")
            return
        rubric_path = Path(run["output_dir"]) / "rubric.jsonl"
        if not rubric_path.exists():
            self.send_error(404, "rubric.jsonl missing — pre-V2 run?")
            return
        # V14.1: cached read. Both files keyed by (path, mtime) so
        # they're invalidated as soon as a new annotation lands.
        rows = list(_read_jsonl_cached(rubric_path))
        ann_path = Path(run["output_dir"]) / "annotations.jsonl"
        human_by_fn = _read_human_by_fn_cached(ann_path)
        for r in rows:
            fn = r.get("filename")
            if fn in human_by_fn:
                r["human"] = human_by_fn[fn]
        self._send_json(200, _safe_dumps(
            {"run_id": run_id, "rows": rows}
        ).encode("utf-8"))

    def _serve_annotation(self, rel: str) -> None:
        """GET /annotation/<run_id>/<filename> → the latest human
        rubric for that one image, or the auto-decomposed one if no
        human label exists yet. Used by the annotation modal to
        pre-fill the form.
        """
        rel = unquote(rel)
        if "/" not in rel:
            self.send_error(400, "expected run_id/filename")
            return
        run_id, fn = rel.split("/", 1)
        run = _get_run(run_id) or _reload_run_from_disk(run_id)
        if run is None:
            self.send_error(404, "no such run")
            return
        # V14.1: cached. Walk in reverse for latest-wins on the human
        # side; auto rubric is keyed by filename so we just dict-lookup.
        ann_path = Path(run["output_dir"]) / "annotations.jsonl"
        latest_human = _read_human_by_fn_cached(ann_path).get(fn)
        if latest_human is not None:
            self._send_json(200, _safe_dumps(
                {"source": "human", "data": latest_human},
            ).encode("utf-8"))
            return
        # Fall back to auto from rubric.jsonl
        rubric_path = Path(run["output_dir"]) / "rubric.jsonl"
        if rubric_path.exists():
            for rec in _read_jsonl_cached(rubric_path):
                if rec.get("filename") == fn:
                    self._send_json(200, _safe_dumps(
                        {"source": "auto", "data": rec},
                    ).encode("utf-8"))
                    return
        self.send_error(404, f"no rubric for {fn}")

    def _handle_save_annotation(self, rel: str) -> None:
        """POST /annotation/<run_id>/<filename> with body
        {axes: {name: {stars, rationale}}, overall_label, overall_rationale}.

        Append-only: every save creates a new line. Latest wins on read.
        This makes the annotation file replayable, audit-friendly, and
        merge-safe across multiple annotators on a LAN deploy.
        """
        rel = unquote(rel)
        if "/" not in rel:
            self._reject_upload(400, "expected run_id/filename")
            return
        run_id, fn = rel.split("/", 1)
        run = _get_run(run_id) or _reload_run_from_disk(run_id)
        if run is None:
            self._reject_upload(404, "no such run")
            return
        clen = int(self.headers.get("Content-Length", "0") or "0")
        if clen <= 0 or clen > 65536:
            self._reject_upload(400, "expected JSON body")
            return
        try:
            params = json.loads(self.rfile.read(clen).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            self._reject_upload(400, f"JSON parse failed: {exc}")
            return

        from pixcull.scoring.rubric import RUBRIC_AXES, get_axis
        valid_axes = {a.name for a in RUBRIC_AXES}

        axes_in = params.get("axes") or {}
        clean_axes: dict[str, dict] = {}
        for name, axis_data in axes_in.items():
            if name not in valid_axes:
                continue  # silently drop typos
            try:
                _ = get_axis(name)
            except KeyError:
                continue
            stars = axis_data.get("stars")
            if stars is not None:
                try:
                    stars_f = float(stars)
                    if not 1.0 <= stars_f <= 5.0:
                        stars_f = max(1.0, min(5.0, stars_f))
                except (TypeError, ValueError):
                    stars_f = None
            else:
                stars_f = None
            clean_axes[name] = {
                "stars": stars_f,
                "checklist_pass": None,  # human override; recompute on display
                "rationale": str(axis_data.get("rationale", ""))[:1000],
                "source": "human",
            }

        # P-UX-4 — optional cull_reason. Only meaningful when
        # overall_label == "cull"; silently dropped otherwise so a
        # later relabel to keep doesn't carry a stale reason. Tokens
        # outside the taxonomy are dropped (treated same as "no
        # reason given") rather than rejected — keeps the wire format
        # forgiving for old clients sending free-form text.
        overall_label_clean = str(params.get("overall_label", ""))[:32]
        cull_reason_in = str(params.get("cull_reason", "") or "").strip().lower()
        cull_reason_clean = (
            cull_reason_in if (
                overall_label_clean == "cull"
                and cull_reason_in in _CULL_REASONS
            ) else ""
        )

        record = {
            "filename": fn,
            "axes": clean_axes,
            "overall_label": overall_label_clean,
            "overall_rationale": str(params.get("overall_rationale", ""))[:1000],
            "cull_reason": cull_reason_clean,
            "source": "human",
            "timestamp": time.time(),
        }
        # v0.12-P0-3 — capture the model's decision BEFORE this human
        # override.  Two purposes:
        #   1. Hard-example mining (v0.11-P1-4) keys on this — when
        #      the model was certain + the user overrode, that pair is
        #      the highest-info row in the next training cycle.
        #   2. /admin/bias (v0.13-P0-4) computes reversal rates per
        #      scene off these pairs.
        # Read from the current scores.csv if the row exists; missing
        # is fine (silently omit fields).
        try:
            from pixcull.io import scores as _sc  # lazy — only on save
        except Exception:
            _sc = None
        if _sc is not None:
            try:
                csv_path = Path(run["output_dir"]) / "scores.csv"
                if csv_path.exists():
                    # Skim only — we don't need the full DataFrame here
                    import csv as _csv
                    with csv_path.open("r", encoding="utf-8-sig") as fh:
                        rdr = _csv.DictReader(fh)
                        for r in rdr:
                            if r.get("filename") == fn:
                                if r.get("decision"):
                                    record["model_decision"] = r["decision"]
                                if r.get("rescorer_pred"):
                                    record["rescorer_pred"] = r["rescorer_pred"]
                                if r.get("rescorer_prob_keep"):
                                    try:
                                        record["rescorer_prob_keep"] = float(
                                            r["rescorer_prob_keep"])
                                    except (TypeError, ValueError):
                                        pass
                                if r.get("scene"):
                                    record["scene"] = r["scene"]
                                if r.get("vertical"):
                                    record["vertical"] = r["vertical"]
                                break
            except Exception:
                # Best-effort — never break a save on capture failure
                pass
        ann_path = Path(run["output_dir"]) / "annotations.jsonl"
        ann_path.parent.mkdir(parents=True, exist_ok=True)
        with open(ann_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")

        # v0.12-P0-3 — invalidate hard-example cache when the user
        # just produced a reversal.  Next next_to_label call will see
        # the fresh evidence.
        if (record.get("model_decision")
                and overall_label_clean
                and record["model_decision"] != overall_label_clean):
            try:
                from pixcull.scoring.hard_examples import clear_cache
                clear_cache()
            except Exception:
                pass

        # V11.2 — auto-retrain trigger. Each annotation increments a
        # global counter; once the threshold is crossed AND no retrain
        # is currently running, spawn one. The user gets a personalized
        # picking model that improves silently as they label.
        global _annotations_since_retrain
        with _RUNS_LOCK:
            _annotations_since_retrain += 1
            should_train = (
                _annotations_since_retrain >= _AUTO_RETRAIN_THRESHOLD
                and _RETRAIN_STATE.get("state") != "running"
            )
            if should_train:
                _annotations_since_retrain = 0

        if should_train:
            print(f"[auto-retrain] threshold reached, spawning retrain",
                  file=sys.stderr)
            threading.Thread(
                target=_retrain_in_background,
                args=(True, True),
                daemon=True,
            ).start()

        self._send_json(200, json.dumps(
            {
                "ok": True, "filename": fn,
                "auto_retrain_spawned": should_train,
                "annotations_since_retrain": _annotations_since_retrain,
            },
            ensure_ascii=False,
        ).encode("utf-8"))

    def _serve_next_to_label(self, rel: str) -> None:
        """Active-learning queue: pick the next most-informative image
        for this run that hasn't been human-labeled yet.

        Priority (decreasing):
          1. rule decision and rescorer disagree (the article's
             "where is the model wrong?" — highest signal)
          2. rescorer prob_keep in [0.4, 0.7] (uncertain region)
          3. burst clusters where decisions split (peer-comparable)
          4. rubric axes near the median (a 3★ that could go either
             way is a strong train-time signal)
          5. fallback: lowest score_final among unlabeled

        P2.4 — also accepts ``?n=<N>`` to return the TOP-N queue at
        once instead of just the single next item. When ``n > 1``
        the response shape switches to a ``queue`` array of
        ``{filename, why, priority_rank}`` entries.
        """
        # P2.4 — split rel into run_id + query string. Most callers
        # pass just the run_id; the new "?n=N" form supports batch.
        path_q = rel.split("?", 1)
        run_id = unquote(path_q[0])
        from urllib.parse import parse_qs
        qparams = parse_qs(path_q[1]) if len(path_q) > 1 else {}
        try:
            n_requested = int(qparams.get("n", ["1"])[0])
        except (ValueError, TypeError):
            n_requested = 1
        n_requested = max(1, min(200, n_requested))   # clamp to sane range

        run = _get_run(run_id) or _reload_run_from_disk(run_id)
        if run is None:
            self.send_error(404, "no such run")
            return

        result = _build_results(run_id)
        if result is None:
            self.send_error(404, "no results yet")
            return
        rows, _ = result

        # Filter out images already human-labeled (V14.1: cached read)
        ann_path = Path(run["output_dir"]) / "annotations.jsonl"
        labeled = set(_read_human_by_fn_cached(ann_path).keys())
        candidates = [r for r in rows if r["filename"] not in labeled]
        if not candidates:
            self._send_json(200, json.dumps(
                {"done": True, "n_labeled": len(labeled),
                 "message": "已标完本批所有图片"},
                ensure_ascii=False,
            ).encode("utf-8"))
            return

        # v0.11-P1-4 — hard-example mining.  Look across this user's
        # past runs for "model was certain, user overrode" rows and
        # boost current candidates that match the same scene / vertical.
        try:
            from pixcull.scoring.hard_examples import get_stats as _he_stats
            from pathlib import Path as _Path
            _hard_stats = _he_stats(_Path.home() / ".pixcull" / "runs")
        except Exception:
            _hard_stats = None

        def priority(r: dict) -> tuple:
            # Lower tuple = higher priority. -bool flips True→0 (top).
            rescorer_disagrees = (
                r.get("rescorer_pred") is not None
                and r["rescorer_pred"] != r["decision"]
            )
            prob = r.get("rescorer_prob_keep")
            uncertainty = (
                abs(0.55 - prob)
                if prob is not None else 1.0
            )
            score = r.get("score_final") or 0.5
            # v0.11-P1-4 — hard-example boost (0..1 — higher = more
            # boost). We subtract from the sort tuple so larger boost
            # → earlier in queue.
            he_boost = 0.0
            if _hard_stats is not None:
                he_boost = _hard_stats.boost_for(
                    scene=str(r.get("scene", "") or ""),
                    vertical=str(r.get("vertical", "") or r.get("scene", "")),
                )
            return (
                -int(rescorer_disagrees),  # disagreement first
                -round(he_boost, 2),        # v0.11-P1-4 hard-example
                uncertainty,                # then most uncertain
                abs(score - 0.5),           # then score near 0.5
            )

        candidates.sort(key=priority)

        # P2.4 — helper to assemble a per-candidate explanation string.
        # Returns a list of short reason fragments suitable for the UI
        # tooltip. Identical logic to the legacy single-item path, just
        # factored out so the batch path can reuse it.
        def _reasons_for(c: dict) -> list[str]:
            reasons: list[str] = []
            if (c.get("rescorer_pred") is not None
                    and c["rescorer_pred"] != c["decision"]):
                prob = c.get("rescorer_prob_keep")
                prob_str = f" (P={prob:.2f})" if prob is not None else ""
                reasons.append(
                    f"规则=={c['decision']} 但 rescorer=={c['rescorer_pred']}{prob_str}"
                )
            if (c.get("rescorer_prob_keep") is not None
                    and 0.40 <= c["rescorer_prob_keep"] <= 0.70):
                reasons.append(
                    f"rescorer 不确定区 (P={c['rescorer_prob_keep']:.2f})"
                )
            score = c.get("score_final")
            if score is not None and 0.35 <= score <= 0.65:
                reasons.append(f"score_final={score:.2f} 临界")
            # v0.11-P1-4 — hard-example surface
            if _hard_stats is not None:
                he_boost = _hard_stats.boost_for(
                    scene=str(c.get("scene", "") or ""),
                    vertical=str(c.get("vertical", "") or c.get("scene", "")),
                )
                if he_boost >= 0.5:
                    reasons.append(
                        f"hard-example 场景 (历史反转 boost={he_boost:.2f})"
                    )
            if not reasons:
                reasons.append("queue 中未标注的下一张")
            return reasons

        # P2.4 — batch mode returns the top-N as a queue array. Used
        # by the "🎯 主动学习" filter pill in the results page. Each
        # entry carries its priority_rank (1-based) for the UI badge.
        if n_requested > 1:
            queue = []
            for i, c in enumerate(candidates[:n_requested]):
                queue.append({
                    "filename":       c["filename"],
                    "priority_rank":  i + 1,
                    "why":            "; ".join(_reasons_for(c)),
                    "decision":       c.get("decision"),
                    "score_final":    c.get("score_final"),
                    "rescorer_pred":  c.get("rescorer_pred"),
                })
            self._send_json(200, json.dumps({
                "schema":      "pixcull.next_to_label.queue.v1",
                "run_id":      run_id,
                "n_total":     len(rows),
                "n_labeled":   len(labeled),
                "n_remaining": len(candidates),
                "n_returned":  len(queue),
                "queue":       queue,
            }, ensure_ascii=False).encode("utf-8"))
            return

        # Legacy single-item path
        chosen = candidates[0]
        self._send_json(200, json.dumps({
            "filename": chosen["filename"],
            "n_total": len(rows),
            "n_labeled": len(labeled),
            "n_remaining": len(candidates),
            "why": "; ".join(_reasons_for(chosen)),
            "row": chosen,
        }, ensure_ascii=False).encode("utf-8"))

    # --- V2.1 retrain ------------------------------------------------------
    def _handle_retrain(self) -> None:
        """Trigger a per-axis rescorer retrain in a background thread.

        Does the same job as ``scripts/build_axis_training_set.py +
        scripts/train_axis_rescorers.py`` but as a one-click admin op.
        Read-only by design — the existing models stay loaded by the
        orchestrator until the next ``run_pipeline`` call rebinds them.

        Body (all optional): {include_auto: bool, also_goldenset: bool}
        """
        clen = int(self.headers.get("Content-Length", "0") or "0")
        params: dict = {}
        if clen > 0:
            try:
                params = json.loads(self.rfile.read(clen).decode("utf-8") or "{}")
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                _dbg("retrain/parse_body", exc)

        global _RETRAIN_STATE
        with _RUNS_LOCK:
            if _RETRAIN_STATE.get("state") == "running":
                self._reject_upload(409, "已有训练任务在跑,等完成再来")
                return
            _RETRAIN_STATE = {
                "state": "queued",
                "started_at": time.time(),
                "message": "排队中",
            }

        threading.Thread(
            target=_retrain_in_background,
            args=(bool(params.get("include_auto", True)),
                  bool(params.get("also_goldenset", True))),
            daemon=True,
        ).start()
        self._send_json(200, json.dumps(
            {"ok": True, "message": "训练已启动,GET /retrain_status 看进度"},
            ensure_ascii=False,
        ).encode("utf-8"))

    def _serve_license_status(self) -> None:
        """V12.0: GET license + quota status JSON.

        V15.1: when the dev-mode kill switch is on, advertise unlimited
        + zero-used so the frontend badge stops rendering "FREE 0/100"
        for the duration of testing. ``dev_mode: true`` lets a future
        UI render a distinct chip ("DEV") if needed.
        """
        from pixcull.license import (
            load_license, usage_this_month, status_line,
            _quota_disabled,
        )
        lic = load_license()
        dev = _quota_disabled()
        body = json.dumps({
            "tier": "dev" if dev else lic.tier,
            "is_pro": True if dev else lic.is_pro,
            "is_unlimited": True if dev else lic.is_unlimited,
            "monthly_quota": -1 if dev else lic.monthly_quota,
            "used_this_month": 0 if dev else usage_this_month(),
            "expires_at": None if dev else lic.expires_at,
            "days_remaining": None if dev else lic.days_remaining,
            "email": lic.email,
            "status_line": status_line(),
            "dev_mode": dev,
        }, ensure_ascii=False).encode("utf-8")
        self._send_json(200, body)

    def _handle_license_install(self) -> None:
        """V12.0: POST {token: '...'} to install a license token."""
        clen = int(self.headers.get("Content-Length", "0") or "0")
        if clen <= 0 or clen > 65536:
            self._reject_upload(400, "expected JSON body with token")
            return
        try:
            params = json.loads(self.rfile.read(clen).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            self._reject_upload(400, f"JSON parse failed: {exc}")
            return
        token = (params.get("token") or "").strip()
        if not token:
            self._reject_upload(400, "缺少 token 字段")
            return
        from pixcull.license import install_license
        lic = install_license(token)
        if lic is None:
            self._reject_upload(400, "license token 验证失败 — 已过期或被篡改")
            return
        body = json.dumps({
            "ok": True,
            "tier": lic.tier,
            "expires_at": lic.expires_at,
            "monthly_quota": lic.monthly_quota,
            "message": f"已激活 {lic.tier.upper()} · 重启服务后立即生效",
        }, ensure_ascii=False).encode("utf-8")
        self._send_json(200, body)

    def _handle_license_refresh(self) -> None:
        """V12.1: trigger a cloud-side license refresh.

        Useful after the user pays for renewal — they hit this and
        the server pushes the rotated token back. Also called daily
        in the background by maybe_cloud_refresh's debouncer.
        """
        from pixcull.license import maybe_cloud_refresh
        result = maybe_cloud_refresh(force=True)
        body = json.dumps(result, ensure_ascii=False).encode("utf-8")
        self._send_json(200, body)

    def _handle_sync_upload(self) -> None:
        """V12.1: push all annotations from all local runs to cloud.

        Pro+ only. Walks every run's annotations.jsonl, joins them
        into a single payload, posts to the cloud sync endpoint.
        """
        from pixcull.license import cloud_sync_upload
        records: list[dict] = []
        for run_dir in sorted(_DEMO_ROOT.iterdir()):
            if not run_dir.is_dir():
                continue
            ann = run_dir / "output" / "annotations.jsonl"
            if not ann.exists():
                continue
            with open(ann, encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        rec = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    rec["__run_id"] = run_dir.name
                    records.append(rec)
        result = cloud_sync_upload(records)
        result["uploaded"] = len(records)
        self._send_json(200 if result.get("ok") else 402,
                         json.dumps(result, ensure_ascii=False).encode("utf-8"))

    def _handle_sync_download(self) -> None:
        """V12.1: pull annotations from cloud + merge into local runs.

        Annotations from cloud arrive with __run_id; for each, append
        to the matching local run's annotations.jsonl (or skip if the
        run isn't on this machine — the user can re-scan to materialize).
        """
        from pixcull.license import cloud_sync_download
        result = cloud_sync_download()
        if not result.get("ok"):
            self._send_json(402,
                json.dumps(result, ensure_ascii=False).encode("utf-8"))
            return

        merged = 0
        skipped_unknown_run = 0
        for rec in result.get("annotations", []):
            run_id = rec.get("__run_id", "")
            if not run_id:
                continue
            run_dir = _DEMO_ROOT / run_id
            if not run_dir.exists():
                skipped_unknown_run += 1
                continue
            ann_path = run_dir / "output" / "annotations.jsonl"
            ann_path.parent.mkdir(parents=True, exist_ok=True)
            with open(ann_path, "a", encoding="utf-8") as f:
                # Strip the sync-only field before writing
                clean = {k: v for k, v in rec.items() if k != "__run_id"}
                f.write(json.dumps(clean, ensure_ascii=False) + "\n")
            merged += 1
        result["merged"] = merged
        result["skipped_unknown_run"] = skipped_unknown_run
        self._send_json(200, json.dumps(result, ensure_ascii=False).encode("utf-8"))

    def _serve_retrain_status(self) -> None:
        """Return the latest retrain run's state + per-axis CV metrics."""
        with _RUNS_LOCK:
            state = dict(_RETRAIN_STATE)
            # V11.2 — surface auto-retrain progress for admin UI
            state["auto_retrain"] = {
                "threshold": _AUTO_RETRAIN_THRESHOLD,
                "annotations_since_last": _annotations_since_retrain,
                "remaining_until_trigger":
                    max(0, _AUTO_RETRAIN_THRESHOLD - _annotations_since_retrain),
            }
        # Augment with on-disk meta if available (last-completed run)
        meta_path = Path("models/rescorer_axis_meta.json")
        if meta_path.exists():
            try:
                state["last_meta"] = json.loads(meta_path.read_text("utf-8"))
            except (OSError, json.JSONDecodeError) as exc:
                _dbg("retrain_status/meta", exc, str(meta_path))
        self._send_json(200, json.dumps(state, ensure_ascii=False).encode("utf-8"))

    # --- V14.6 first-run page + status ------------------------------------
    def _serve_first_run_page(self) -> None:
        body = _FIRST_RUN_HTML.encode("utf-8")
        self._send_html(200, body)

    def _serve_first_run_status(self) -> None:
        body = _safe_dumps(first_run_snapshot()).encode("utf-8")
        self._send_json(200, body)

    # --- V17.0 verticals --------------------------------------------------
    def _serve_verticals_page(self) -> None:
        body = _VERTICALS_HTML.encode("utf-8")
        self._send_html(200, body)

    def _serve_verticals_json(self) -> None:
        from pixcull import verticals as vmod
        body = _safe_dumps(vmod.registry_with_progress()).encode("utf-8")
        self._send_json(200, body)

    def _serve_vertical_list(self, rel: str) -> None:
        """V17.1: GET /verticals/list/<key>/<bucket> → sample listing.

        Drives the /verticals drawer's sample grid. Returns the same
        shape verticals.list_samples produces ({filename, size, mtime})
        plus the bucket counts so the UI can update the tab labels
        ("好片 (12)" / "待剔除 (5)") without a second roundtrip.
        """
        from pixcull import verticals as vmod
        rel = unquote(rel)
        parts = rel.split("/", 1)
        if len(parts) != 2:
            self.send_error(404, "expected key/bucket")
            return
        key, bucket = parts
        if vmod.get_vertical(key) is None:
            self.send_error(404, f"unknown vertical: {key}")
            return
        if bucket not in vmod.ALLOWED_BUCKETS:
            self.send_error(400, "bucket must be 'good' or 'bad'")
            return
        try:
            samples = vmod.list_samples(key, bucket)
        except ValueError as exc:
            # Defensive — get_vertical already vetted the key, but if a
            # future refactor diverges the two paths this catches it.
            self.send_error(404, str(exc))
            return
        body = _safe_dumps({
            "key":     key,
            "bucket":  bucket,
            "samples": samples,
            "counts":  vmod.count_samples(key),
        }).encode("utf-8")
        self._send_json(200, body)

    def _serve_vertical_sample(self, rel: str) -> None:
        """GET /verticals/sample/<key>/<bucket>/<filename> → image bytes.

        Path-shaped (not query string) so we can ``<img src="...">``
        directly in the verticals page sample grid.
        """
        from pixcull import verticals as vmod
        rel = unquote(rel)
        parts = rel.split("/", 2)
        if len(parts) != 3:
            self.send_error(404, "expected key/bucket/filename")
            return
        key, bucket, fn = parts
        p = vmod.sample_path(key, bucket, fn)
        if p is None:
            self.send_error(404, "no such sample")
            return
        try:
            data = p.read_bytes()
        except OSError as exc:
            _dbg("vertical_sample/read", exc, str(p))
            self.send_error(500, "read failed")
            return
        ext = p.suffix.lower()
        ctype = ("image/jpeg" if ext in (".jpg", ".jpeg") else
                 "image/png" if ext == ".png" else
                 "image/heic" if ext in (".heic", ".heif") else
                 "application/octet-stream")
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "public, max-age=86400")
        self.end_headers()
        self.wfile.write(data)

    def _handle_vertical_upload(self, key: str) -> None:
        """POST /verticals/upload/<key>?bucket=good|bad

        Multipart upload — same machinery as /analyze, but persists into
        the vertical sample bank instead of /tmp.

        V17.5 fix — ``key`` is delivered already path-stripped (do_POST
        called urlparse(self.path).path). To read ``?bucket=...`` we go
        back to ``self.path`` itself, not the ``key`` slice.
        """
        from pixcull import verticals as vmod
        from urllib.parse import parse_qs, urlsplit
        key = unquote(key.strip("/"))
        full = urlsplit(self.path)
        qs = parse_qs(full.query) if full.query else {}
        bucket = (qs.get("bucket", ["good"])[0] or "good").lower()
        if bucket not in vmod.ALLOWED_BUCKETS:
            self._reject_upload(400, "bucket must be 'good' or 'bad'")
            return
        if vmod.get_vertical(key) is None:
            self._reject_upload(404, f"unknown vertical: {key}")
            return
        ctype = self.headers.get("Content-Type", "")
        if not ctype.startswith("multipart/form-data"):
            self._reject_upload(400, "expected multipart/form-data")
            return
        try:
            form = cgi.FieldStorage(
                fp=self.rfile, headers=self.headers,
                environ={"REQUEST_METHOD": "POST", "CONTENT_TYPE": ctype},
                keep_blank_values=True,
            )
        except Exception as exc:
            self._reject_upload(400, f"multipart parse failed: {exc}")
            return
        saved: list[dict] = []
        for field_name in form.keys():
            field = form[field_name]
            for item in (field if isinstance(field, list) else [field]):
                if not getattr(item, "filename", None):
                    continue
                content = item.file.read()
                if not content:
                    continue
                # Cap each upload at 32 MB so a runaway can't fill the
                # vertical bank.
                if len(content) > 32 * 1024 * 1024:
                    continue
                saved.append(vmod.save_sample(
                    key, bucket, item.filename, content,
                ))
        body = _safe_dumps({
            "ok": True, "key": key, "bucket": bucket,
            "saved": saved,
            "counts": vmod.count_samples(key),
        }).encode("utf-8")
        self._send_json(200, body)

    def _handle_vertical_tune(self, key: str) -> None:
        """V17.4 — POST /verticals/tune/<key>

        Run policy_tuner.tune_vertical(key) → return JSON result.
        Does NOT persist the override (user reviews before applying).

        Body is empty / ignored.
        """
        from pixcull import verticals as vmod
        key = unquote(key.strip("/"))
        if vmod.get_vertical(key) is None:
            self._reject_upload(404, f"unknown vertical: {key}")
            return
        try:
            from pixcull import policy_tuner as pt
            from dataclasses import asdict
            result = pt.tune_vertical(key)
            payload = asdict(result)
            # V17.10 — keep the FULL grid (~5KB for 121 cells) so the
            # tune modal can render the F1 heatmap. Also expose
            # ``grid_top12`` sorted-by-F1 for tabular display.
            full_grid = payload.get("grid", [])
            payload["grid_top12"] = sorted(full_grid,
                                              key=lambda x: -x["f1"])[:12]
            # ``grid`` stays as-is (full 11×11)
        except ValueError as exc:
            # Predictable user errors (no samples / unknown key) → 400
            self._reject_upload(400, str(exc))
            return
        except Exception as exc:  # noqa: BLE001
            traceback.print_exc(file=sys.stderr)
            _capture_exception("verticals.tune", exc, {"key": key})  # V17.12
            self._reject_upload(500, f"调参失败: {type(exc).__name__}: {exc}")
            return
        self._send_json(200, _safe_dumps(payload).encode("utf-8"))

    def _handle_vertical_apply_override(self, key: str) -> None:
        """V17.4 — POST /verticals/apply_override/<key>

        Body: ``{keep_min_delta, cull_max_delta, baseline, tuned, ...}``
        — typically the result of a prior /verticals/tune call. Saves
        the override so subsequent runs of decide() pick it up.
        """
        from pixcull import verticals as vmod
        key = unquote(key.strip("/"))
        if vmod.get_vertical(key) is None:
            self._reject_upload(404, f"unknown vertical: {key}")
            return
        clen = int(self.headers.get("Content-Length", "0") or "0")
        if clen <= 0 or clen > 1024 * 1024:
            self._reject_upload(400, "expected JSON body with tune result")
            return
        try:
            params = json.loads(self.rfile.read(clen).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            self._reject_upload(400, f"JSON parse failed: {exc}")
            return
        try:
            from pixcull import policy_tuner as pt
            # Reconstruct just enough of TuneResult for save_override.
            res = pt.TuneResult(
                vertical=key,
                n_good=int(params.get("n_good", 0)),
                n_bad=int(params.get("n_bad", 0)),
                base_keep_min=float(params.get("base_keep_min", 0.65)),
                base_cull_max=float(params.get("base_cull_max", 0.40)),
                baseline_delta_keep=float(params.get("baseline_delta_keep", 0.0)),
                baseline_delta_cull=float(params.get("baseline_delta_cull", 0.0)),
                baseline=params.get("baseline") or {},
                tuned_delta_keep=float(params["tuned_delta_keep"]),
                tuned_delta_cull=float(params["tuned_delta_cull"]),
                tuned=params.get("tuned") or {},
            )
            pt.save_override(key, res)
        except (KeyError, TypeError, ValueError) as exc:
            self._reject_upload(400, f"参数错误: {exc}")
            return
        body = _safe_dumps({
            "ok": True,
            "key": key,
            "override_path": str(__import__("pixcull.policy_tuner",
                                              fromlist=["override_path"])
                                  .override_path(key)),
        }).encode("utf-8")
        self._send_json(200, body)

    def _handle_vertical_revert_override(self, key: str) -> None:
        """V17.4 — POST /verticals/revert_override/<key>

        Deletes the override file so the registry default takes over.
        """
        from pixcull import verticals as vmod
        from pixcull import policy_tuner as pt
        key = unquote(key.strip("/"))
        if vmod.get_vertical(key) is None:
            self._reject_upload(404, f"unknown vertical: {key}")
            return
        ok = pt.delete_override(key)
        body = _safe_dumps({"ok": ok, "key": key,
                              "had_override": ok}).encode("utf-8")
        self._send_json(200, body)

    # ---------- V17.5 phrase generator ----------
    def _handle_vertical_llm_phrases(self, key: str) -> None:
        """POST /verticals/llm_phrases/<key>

        Profile good samples → DeepSeek V4-Flash → save phrase override.
        Returns the result so the UI can show what was generated for
        review. Failure modes:
          400 — no DeepSeek key, no samples, malformed LLM JSON
          404 — unknown vertical
          500 — unexpected DeepSeek/network error
        """
        from pixcull import verticals as vmod
        key = unquote(key.strip("/"))
        if vmod.get_vertical(key) is None:
            self._reject_upload(404, f"unknown vertical: {key}")
            return
        try:
            from pixcull import phrase_generator as pg
            from dataclasses import asdict
            result = pg.generate_phrases(key)
            pg.save_phrase_override(key, result)
            payload = asdict(result)
            payload["ok"] = True
        except ValueError as exc:
            self._reject_upload(400, str(exc))
            return
        except Exception as exc:  # noqa: BLE001
            traceback.print_exc(file=sys.stderr)
            _capture_exception("verticals.llm_phrases", exc, {"key": key})  # V17.12
            self._reject_upload(500,
                f"DeepSeek 调用失败: {type(exc).__name__}: {exc}")
            return
        self._send_json(200, _safe_dumps(payload).encode("utf-8"))

    def _handle_vertical_revert_phrases(self, key: str) -> None:
        """POST /verticals/revert_phrases/<key> — delete phrase override."""
        from pixcull import verticals as vmod
        from pixcull import phrase_generator as pg
        key = unquote(key.strip("/"))
        if vmod.get_vertical(key) is None:
            self._reject_upload(404, f"unknown vertical: {key}")
            return
        ok = pg.delete_phrase_override(key)
        body = _safe_dumps({"ok": ok, "key": key,
                              "had_override": ok}).encode("utf-8")
        self._send_json(200, body)

    # ---------- V17.6 per-vertical eval report ----------
    def _handle_vertical_eval(self, key: str) -> None:
        """POST /verticals/eval/<key>

        Runs the rule pipeline + (effective) policy on every sample
        of the vertical, returns:
          * confusion matrix (good→keep/maybe/cull, bad→...)
          * F1 / precision / recall / accuracy
          * per-axis metric distributions
          * lists of misclassified filenames (false-keep + false-cull)
            so the user can click into them to investigate

        Body is empty / ignored.
        """
        from pixcull import verticals as vmod
        key = unquote(key.strip("/"))
        v = vmod.get_vertical(key)
        if v is None:
            self._reject_upload(404, f"unknown vertical: {key}")
            return
        counts = vmod.count_samples(key)
        if counts["total"] < 1:
            self._reject_upload(400,
                f"vertical '{key}' has no samples — upload some via /verticals first")
            return
        try:
            from pixcull import policy_tuner as pt
            from pixcull.scoring.decision import Decision
            from pixcull.config import PixCullConfig

            samples = pt.analyze_samples(key)
            if not samples:
                self._reject_upload(500,
                    "0 samples could be analyzed — check launcher log for errors")
                return

            # Use the EFFECTIVE policy (override-merged) so the report
            # reflects what `decide()` would actually do at scoring time.
            config = PixCullConfig.load()
            base_keep, base_cull = pt._baseline_thresholds(config)
            eff = vmod.get_effective_policy(key)
            kmin = max(0.0, min(1.0, base_keep + (eff.keep_min_delta if eff else 0)))
            cmax = max(0.0, min(1.0, base_cull + (eff.cull_max_delta if eff else 0)))
            tol = frozenset(eff.tolerated_flags) if eff else frozenset()

            preds = [pt._apply_thresholds(
                s.final_score, s.flags, s.scene,
                keep_min=kmin, cull_max=cmax,
                tolerated_flags=tol,
            ) for s in samples]

            # Confusion: (truth_bucket → {keep, maybe, cull})
            confusion = {
                "good": {"keep": 0, "maybe": 0, "cull": 0},
                "bad":  {"keep": 0, "maybe": 0, "cull": 0},
            }
            misclassified_keep: list[dict] = []   # bad shots that survived
            misclassified_cull: list[dict] = []   # good shots wrongly culled
            for s, p in zip(samples, preds):
                pname = "keep" if p is Decision.KEEP else \
                        "maybe" if p is Decision.MAYBE else "cull"
                confusion[s.bucket][pname] += 1
                # Misclassifications: bad-shot kept = false-positive;
                # good-shot culled = false-negative.
                if s.bucket == "bad" and p is not Decision.CULL:
                    misclassified_keep.append({
                        "filename": s.filename,
                        "score":    round(s.final_score, 3),
                        "pred":     pname,
                        "scene":    s.scene,
                        "flags":    s.flags,
                    })
                elif s.bucket == "good" and p is Decision.CULL:
                    misclassified_cull.append({
                        "filename": s.filename,
                        "score":    round(s.final_score, 3),
                        "pred":     pname,
                        "scene":    s.scene,
                        "flags":    s.flags,
                    })

            metrics = pt.binary_metrics(preds, [s.bucket for s in samples])

            # Per-axis metric averages — useful diagnostic ("user's good
            # shots avg subject_fraction=0.18, low compared to default
            # 0.30 threshold").
            metric_names = ("subject_fraction", "canon_lead_room",
                              "canon_thirds_concentration",
                              "canon_figure_ground", "score_moment",
                              "laion_aes", "laplacian_subject")
            axis_distrib: dict[str, dict] = {}
            # We only have final_score on SamplePoint; deeper metrics
            # require re-fetching. For V17.6 we keep this lean — just
            # the score distribution by bucket.
            from statistics import mean, median
            for bucket in ("good", "bad"):
                vs = [s.final_score for s in samples if s.bucket == bucket]
                axis_distrib[bucket] = {
                    "n":      len(vs),
                    "score_mean":   round(mean(vs), 3) if vs else 0.0,
                    "score_median": round(median(vs), 3) if vs else 0.0,
                    "score_min":    round(min(vs), 3) if vs else 0.0,
                    "score_max":    round(max(vs), 3) if vs else 0.0,
                }
            payload = {
                "ok":        True,
                "vertical":  key,
                "vertical_zh": v.zh,
                "vertical_icon": v.icon,
                "n_total":   len(samples),
                "n_good":    sum(1 for s in samples if s.bucket == "good"),
                "n_bad":     sum(1 for s in samples if s.bucket == "bad"),
                "thresholds_used": {
                    "keep_min":         round(kmin, 3),
                    "cull_max":         round(cmax, 3),
                    "tolerated_flags":  sorted(tol),
                    "is_override":      bool(eff and (
                        eff.keep_min_delta != v.policy.keep_min_delta
                        or eff.cull_max_delta != v.policy.cull_max_delta
                    )),
                },
                "confusion":     confusion,
                "metrics":       metrics,
                "score_distrib": axis_distrib,
                "misclassified_keep": misclassified_keep[:20],
                "misclassified_cull": misclassified_cull[:20],
            }
        except ValueError as exc:
            self._reject_upload(400, str(exc))
            return
        except Exception as exc:  # noqa: BLE001
            traceback.print_exc(file=sys.stderr)
            _capture_exception("verticals.eval", exc, {"key": key})  # V17.12
            self._reject_upload(500, f"评估失败: {type(exc).__name__}: {exc}")
            return
        self._send_json(200, _safe_dumps(payload).encode("utf-8"))

    # ---------- V17.7 bulk classify from folder ----------
    def _serve_vertical_bulk_page(self, key: str) -> None:
        """GET /verticals/bulk/<key> — full-page bulk classifier UI."""
        from pixcull import verticals as vmod
        key = unquote(key.strip("/"))
        v = vmod.get_vertical(key)
        if v is None:
            self.send_error(404, f"unknown vertical: {key}")
            return
        html = _VERTICAL_BULK_HTML.replace(
            "__VKEY__", key
        ).replace(
            "__VICON__", v.icon
        ).replace(
            "__VZH__", v.zh
        )
        self._send_html(200, html.encode("utf-8"))

    def _serve_vertical_bulk_thumb(self) -> None:
        """GET /verticals/bulk_thumb?path=<abs>&size=<px>

        Serves a JPEG thumbnail of a file the user just scanned via
        bulk_classify. Path is whitelisted against the in-process
        scan registry so this can't be used to probe random parts
        of the filesystem.
        """
        from urllib.parse import parse_qs, urlsplit
        full = urlsplit(self.path)
        qs = parse_qs(full.query) if full.query else {}
        raw_path = (qs.get("path", [""])[0] or "").strip()
        try:
            size = int(qs.get("size", ["240"])[0])
        except (TypeError, ValueError):
            size = 240
        size = max(80, min(800, size))
        if not raw_path:
            self.send_error(400, "missing path")
            return
        p = Path(unquote(raw_path))
        if not _bulk_path_allowed(p):
            self.send_error(403, "path not in scan whitelist")
            return
        if not p.is_file():
            self.send_error(404, "no such file")
            return
        try:
            from pixcull.io.loader import load_image
            img = load_image(p, max_side=size)
        except Exception as exc:
            _dbg("bulk_thumb/load_image", exc, str(p))
            img = None
        if img is None:
            self.send_error(500, "decode failed")
            return
        from io import BytesIO
        buf = BytesIO()
        img.save(buf, "JPEG", quality=78, optimize=True)
        data = buf.getvalue()
        self.send_response(200)
        self.send_header("Content-Type", "image/jpeg")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "public, max-age=3600")
        self.end_headers()
        self.wfile.write(data)

    def _handle_vertical_bulk_classify(self, key: str) -> None:
        """POST /verticals/bulk_classify/<key>

        Body: {folder: "/abs/path", limit?: int (default 100)}

        Walks the folder, runs the rule pipeline (analyze_one +
        fuse_score + decide with the vertical's effective policy),
        returns one row per image with the SUGGESTED bucket so the
        user can review + adjust before committing.

        Capped at ``limit`` images to keep the response time bounded
        (~1-5s per image for the heavy detectors).
        """
        from pixcull import verticals as vmod
        key = unquote(key.strip("/"))
        v = vmod.get_vertical(key)
        if v is None:
            self._reject_upload(404, f"unknown vertical: {key}")
            return
        clen = int(self.headers.get("Content-Length", "0") or "0")
        if clen <= 0 or clen > 65536:
            self._reject_upload(400, "expected JSON body with {folder, limit?}")
            return
        try:
            params = json.loads(self.rfile.read(clen).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            self._reject_upload(400, f"JSON parse failed: {exc}")
            return
        folder_str = (params.get("folder") or "").strip()
        if not folder_str:
            self._reject_upload(400, "需要 folder 字段")
            return
        folder = Path(folder_str).expanduser()
        try:
            folder = folder.resolve()
        except OSError as exc:
            self._reject_upload(400, f"路径解析失败: {exc}")
            return
        if not folder.is_dir():
            self._reject_upload(400, f"不是文件夹: {folder}")
            return
        try:
            limit = int(params.get("limit", 100))
        except (TypeError, ValueError):
            limit = 100
        limit = max(1, min(500, limit))

        try:
            from pixcull.io.loader import list_images
            from pixcull.pipeline.worker import analyze_one
            from pixcull.scoring.fusion import fuse_score
            from pixcull.scoring.decision import decide, Decision
            from pixcull.scoring.style_modes import detect_style_modes
            from pixcull.config import PixCullConfig

            paths = list_images(folder)[:limit]
            if not paths:
                self._reject_upload(
                    400, f"在 {folder} 找不到可分析图片(支持 jpg/png/cr3/cr2/nef/arw)")
                return

            # Register the paths in the bulk whitelist so the
            # subsequent /verticals/bulk_thumb calls can resolve them.
            _bulk_register_paths(paths)

            config = PixCullConfig.load()
            items: list[dict] = []
            for p in paths:
                try:
                    row = analyze_one(p)
                except Exception as exc:
                    _dbg("bulk_classify/analyze", exc, str(p))
                    continue
                if row is None:
                    continue
                scene = str(row.get("scene") or "")
                flags = list(row.get("flags") or [])
                try:
                    dims = fuse_score(row, flags, scene, config)
                except Exception:
                    continue
                dec, _r = decide(
                    dims["final"], flags, config,
                    scene=scene, vertical=key,
                )
                # Suggested bucket — keep → good, cull → bad,
                # maybe → skip (user decides).
                suggested = "good" if dec is Decision.KEEP \
                       else "bad"  if dec is Decision.CULL \
                       else "skip"
                try:
                    sp = detect_style_modes(row)
                    styles = sorted(sp.modes)
                except Exception:
                    styles = []
                items.append({
                    "src_path":      str(p),
                    "filename":      p.name,
                    "score":         round(float(dims["final"]), 3),
                    "decision":      dec.value,
                    "suggested":     suggested,
                    "scene":         scene,
                    "styles":        styles,
                    "flags":         flags,
                })
            # Sort by score desc so highest-confidence keeps land first
            items.sort(key=lambda x: -x["score"])
        except Exception as exc:  # noqa: BLE001
            traceback.print_exc(file=sys.stderr)
            _capture_exception("verticals.bulk_classify", exc,
                                 {"key": key, "folder": str(folder)})  # V17.12
            self._reject_upload(500, f"分析失败: {type(exc).__name__}: {exc}")
            return

        body = _safe_dumps({
            "ok":           True,
            "key":          key,
            "folder":       str(folder),
            "n_total":      len(items),
            "items":        items,
        }).encode("utf-8")
        self._send_json(200, body)

    def _handle_vertical_bulk_commit(self, key: str) -> None:
        """POST /verticals/bulk_commit/<key>

        Body: {assignments: [{src_path, bucket}, ...]}
        Where bucket ∈ {good, bad}. Anything else is silently skipped
        (the frontend uses "skip" to mean "don't commit this one").

        Each assignment's src_path must be in the bulk whitelist set
        by the most recent bulk_classify call. Bytes are READ from
        disk and saved into the vertical's good/bad dir via the
        existing ``save_sample`` helper (which hashes filenames to
        avoid collisions).
        """
        from pixcull import verticals as vmod
        key = unquote(key.strip("/"))
        v = vmod.get_vertical(key)
        if v is None:
            self._reject_upload(404, f"unknown vertical: {key}")
            return
        clen = int(self.headers.get("Content-Length", "0") or "0")
        if clen <= 0 or clen > 4 * 1024 * 1024:
            self._reject_upload(400, "expected JSON body with assignments[]")
            return
        try:
            params = json.loads(self.rfile.read(clen).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            self._reject_upload(400, f"JSON parse failed: {exc}")
            return
        assigns = params.get("assignments")
        if not isinstance(assigns, list):
            self._reject_upload(400, "assignments must be a list")
            return

        saved: list[dict] = []
        skipped: list[dict] = []
        for a in assigns:
            if not isinstance(a, dict):
                continue
            src = (a.get("src_path") or "").strip()
            bucket = (a.get("bucket") or "").strip().lower()
            if bucket not in vmod.ALLOWED_BUCKETS:
                skipped.append({"src_path": src, "reason": f"bad bucket={bucket}"})
                continue
            p = Path(src)
            if not _bulk_path_allowed(p):
                skipped.append({"src_path": src, "reason": "not in whitelist"})
                continue
            if not p.is_file():
                skipped.append({"src_path": src, "reason": "no such file"})
                continue
            try:
                # Cap individual files at 32 MB (same as direct upload)
                data = p.read_bytes()
                if len(data) > 32 * 1024 * 1024:
                    skipped.append({"src_path": src, "reason": "file > 32 MB"})
                    continue
                info = vmod.save_sample(key, bucket, p.name, data)
                saved.append({"src_path": src, "bucket": bucket, **info})
            except Exception as exc:
                skipped.append({"src_path": src,
                                  "reason": f"{type(exc).__name__}: {exc}"})

        body = _safe_dumps({
            "ok":      True,
            "key":     key,
            "saved":   saved,
            "skipped": skipped,
            "counts":  vmod.count_samples(key),
        }).encode("utf-8")
        self._send_json(200, body)

    # ---------- V17.13 Unsplash CC0 reference fetcher ----------
    def _handle_vertical_unsplash_fetch(self, key: str) -> None:
        """POST /verticals/unsplash_fetch/<key>

        Body: {query?, bucket? (default "good"), count? (default 15,
        cap 30), orientation? (landscape/portrait/squarish)}

        Pulls top-relevant CC0 photos from Unsplash for the requested
        query, downloads them into the vertical's sample bank.
        Photographer credits saved to ``unsplash_attributions.json``
        sidecar.
        """
        from pixcull import verticals as vmod
        key = unquote(key.strip("/"))
        v = vmod.get_vertical(key)
        if v is None:
            self._reject_upload(404, f"unknown vertical: {key}")
            return
        clen = int(self.headers.get("Content-Length", "0") or "0")
        params: dict = {}
        if clen > 0 and clen < 8192:
            try:
                params = json.loads(self.rfile.read(clen).decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                self._reject_upload(400, f"JSON parse failed: {exc}")
                return
        try:
            from pixcull import unsplash as up
            from dataclasses import asdict
            # Resolve defaults — let the caller override piecewise.
            defaults = up.default_query_for(key)
            query = (params.get("query") or defaults["query"]).strip()
            orientation = (params.get("orientation")
                              or defaults.get("orientation") or "landscape")
            bucket = (params.get("bucket") or "good").strip().lower()
            try:
                count = int(params.get("count", 15))
            except (TypeError, ValueError):
                count = 15
            result = up.populate_vertical(
                key, query=query, bucket=bucket,
                count=count, orientation=orientation,
            )
            payload = asdict(result)
            payload["counts"] = vmod.count_samples(key)
            payload["ok"] = True
        except ValueError as exc:
            # Predictable user errors: no key, no vertical, bad bucket
            self._reject_upload(400, str(exc))
            return
        except Exception as exc:  # noqa: BLE001
            traceback.print_exc(file=sys.stderr)
            _capture_exception("verticals.unsplash_fetch", exc,
                                 {"key": key})
            self._reject_upload(500,
                f"Unsplash 拉取失败: {type(exc).__name__}: {exc}")
            return
        self._send_json(200, _safe_dumps(payload).encode("utf-8"))

    # ---------- V17.8 auto-promote run's human keep/cull ----------
    def _handle_vertical_promote_run(self, run_id: str) -> None:
        """POST /verticals/promote_run/<run_id>

        Reads the run's annotations.jsonl, picks every entry whose
        ``overall_label`` is keep / cull (the user's human verdict),
        looks up the run's ``vertical`` tag, then copies each
        annotated file's bytes into that vertical's good/bad bank.

        Why this matters
        ----------------
        The annotation flow (rubric modal → save → next-to-label)
        produces a high-signal dataset every time the user labels a
        batch. Without V17.8 those labels live only in the run's
        ``annotations.jsonl`` and never feed back into the vertical's
        sample bank — so the V17.4 tuner / V17.5 LLM never see them.
        Promoting closes the loop: run → label → sample bank → next
        run's policy is shaped by what the user just taught us.

        Idempotency
        -----------
        ``save_sample`` names files by SHA-256 of the content. Re-
        promoting the same run silently overwrites with identical
        bytes; no duplicates.

        Body is empty / ignored.
        """
        from pixcull import verticals as vmod
        run_id = unquote(run_id.strip("/"))
        run = _get_run(run_id) or _reload_run_from_disk(run_id)
        if run is None:
            self._reject_upload(404, f"unknown run: {run_id}")
            return
        vertical_key = run.get("vertical")
        if not vertical_key:
            self._reject_upload(
                400,
                "this run wasn't tagged with a vertical — "
                "rerun the batch with the vertical dropdown set",
            )
            return
        v = vmod.get_vertical(vertical_key)
        if v is None:
            self._reject_upload(404, f"unknown vertical: {vertical_key}")
            return

        # Walk annotations.jsonl, build {filename: overall_label}
        output_dir = Path(run["output_dir"])
        ann_path = output_dir / "annotations.jsonl"
        if not ann_path.exists():
            self._reject_upload(400,
                "this run has no human annotations to promote")
            return
        human_by_fn: dict[str, str] = {}   # filename → keep/cull
        try:
            for line in ann_path.read_text("utf-8").splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                except json.JSONDecodeError:
                    continue
                fn = rec.get("filename")
                lbl = (rec.get("overall_label") or "").strip().lower()
                if fn and lbl in ("keep", "cull"):
                    human_by_fn[fn] = lbl   # latest line wins
        except OSError as exc:
            self._reject_upload(500, f"无法读 annotations.jsonl: {exc}")
            return

        if not human_by_fn:
            self._reject_upload(
                400,
                "no human keep/cull annotations found — label some "
                "images with overall_label first",
            )
            return

        # Resolve filename → original-bytes source path. In scan mode
        # we have a manifest.json; in upload mode files live under
        # the run's input dir. Use the existing helper.
        saved: list[dict] = []
        skipped: list[dict] = []
        for fn, lbl in human_by_fn.items():
            src = _resolve_image_source(run, Path(fn).name)
            if src is None or not src.exists():
                skipped.append({"filename": fn, "reason": "source missing"})
                continue
            bucket = "good" if lbl == "keep" else "bad"
            try:
                data = src.read_bytes()
                if len(data) > 32 * 1024 * 1024:
                    skipped.append({"filename": fn, "reason": "> 32 MB"})
                    continue
                info = vmod.save_sample(vertical_key, bucket, src.name, data)
                saved.append({
                    "filename": fn, "bucket": bucket, **info,
                })
            except Exception as exc:  # noqa: BLE001
                skipped.append({
                    "filename": fn,
                    "reason": f"{type(exc).__name__}: {exc}",
                })

        body = _safe_dumps({
            "ok":           True,
            "run_id":       run_id,
            "vertical":     vertical_key,
            "vertical_zh":  v.zh,
            "n_promoted":   len(saved),
            "n_skipped":    len(skipped),
            "saved":        saved,
            "skipped":      skipped,
            "counts":       vmod.count_samples(vertical_key),
        }).encode("utf-8")
        self._send_json(200, body)

    def _handle_vertical_sample_delete(self, rel: str) -> None:
        from pixcull import verticals as vmod
        rel = unquote(rel)
        parts = rel.split("/", 2)
        if len(parts) != 3:
            self._reject_upload(400, "expected key/bucket/filename")
            return
        key, bucket, fn = parts
        ok = vmod.delete_sample(key, bucket, fn)
        body = _safe_dumps({
            "ok": ok,
            "counts": vmod.count_samples(key) if ok else None,
        }).encode("utf-8")
        self._send_json(200 if ok else 404, body)

    # --- V14.7 opt-in error reporting -------------------------------------
    def _serve_privacy_page(self) -> None:
        body = _PRIVACY_HTML.encode("utf-8")
        self._send_html(200, body)

    def _serve_error_reports_settings(self) -> None:
        """GET — read current opt-in state from config.json. Default OFF."""
        cfg = _load_user_config()
        body = _safe_dumps({
            "enabled":  bool(cfg.get("error_reports_enabled")),
            "endpoint": str(cfg.get("error_reports_endpoint", "") or ""),
        }).encode("utf-8")
        self._send_json(200, body)

    def _handle_save_error_reports_settings(self) -> None:
        """POST {enabled, endpoint?} — persist opt-in toggle to config.json."""
        clen = int(self.headers.get("Content-Length", "0") or "0")
        try:
            data = json.loads(self.rfile.read(clen).decode("utf-8") or "{}")
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            self._reject_upload(400, f"invalid JSON: {exc}")
            return
        enabled = bool(data.get("enabled"))
        endpoint = str(data.get("endpoint", "") or "").strip()
        cfg = _load_user_config()
        cfg["error_reports_enabled"] = enabled
        if endpoint:
            cfg["error_reports_endpoint"] = endpoint
        elif "error_reports_endpoint" in cfg:
            # Clear stale endpoint when user blanks it
            cfg["error_reports_endpoint"] = ""
        _save_user_config(cfg)
        body = _safe_dumps({
            "ok": True, "enabled": enabled, "endpoint": endpoint,
        }).encode("utf-8")
        self._send_json(200, body)

    def _handle_submit_error_report(self) -> None:
        """POST — manually submit a redacted report payload now."""
        clen = int(self.headers.get("Content-Length", "0") or "0")
        try:
            data = json.loads(self.rfile.read(clen).decode("utf-8") or "{}") if clen else {}
        except (UnicodeDecodeError, json.JSONDecodeError):
            data = {}
        from pixcull import error_reporting as er
        cfg = _load_user_config()
        result = er.submit_report(
            cfg,
            app_version="14.7.0",
            log_dir=_app_data_dir() / "logs",
            reason=str(data.get("reason", "manual")),
            extra={"trigger": "user-clicked-submit"},
        )
        body = _safe_dumps(result).encode("utf-8")
        # 200 even on dry-run / disabled — the result body explains.
        self._send_json(200, body)

    def _handle_client_error_event(self) -> None:
        """V17.12 — POST /error_reports/client_event

        Browser-side window.onerror / unhandledrejection hits this.
        Captured fields are bounded + redacted before going through
        the V14.7 submit pipeline. Respects opt-in (200 always; body
        explains).

        Body: {message, source, lineno, colno, stack?, kind?,
               url?, ua?}
        """
        clen = int(self.headers.get("Content-Length", "0") or "0")
        if clen > 32 * 1024:
            self._reject_upload(400, "client-event payload too large")
            return
        try:
            data = json.loads(self.rfile.read(clen).decode("utf-8") or "{}") if clen else {}
        except (UnicodeDecodeError, json.JSONDecodeError):
            data = {}
        _capture_client_event(data)
        self._send_json(200, _safe_dumps({"ok": True}).encode("utf-8"))

    # --- storage admin -----------------------------------------------------
    def _serve_admin_page(self) -> None:
        body = _ADMIN_HTML.encode("utf-8")
        self._send_html(200, body)

    # v0.7-P0-3 — performance debug page.  Lightweight: same template
    # frame as /admin, but populated with process RSS, # active runs,
    # /tmp/pixcull_demo size, and per-run row counts. Refreshes every
    # 4 s via fetch() to /admin/perf.json so the operator can watch
    # how big-batch runs grow over time.
    def _serve_admin_perf_page(self) -> None:
        body = _ADMIN_PERF_HTML.encode("utf-8")
        self._send_html(200, body)

    def _serve_admin_perf_json(self) -> None:
        import resource
        import shutil
        snap: dict = {}
        # Process RSS (Linux: KB; macOS: bytes).
        try:
            r = resource.getrusage(resource.RUSAGE_SELF)
            rss = r.ru_maxrss
            if sys.platform != "darwin":
                rss *= 1024  # KB → bytes on Linux
            snap["rss_bytes"] = rss
        except Exception:
            snap["rss_bytes"] = None
        # /tmp/pixcull_demo total bytes (cap shallow-walk depth so
        # this stays fast even on 5k-photo runs).
        demo_root = Path("/tmp/pixcull_demo")
        try:
            total = 0
            run_sizes: dict = {}
            if demo_root.exists():
                for entry in demo_root.iterdir():
                    if not entry.is_dir():
                        continue
                    sz = sum(
                        f.stat().st_size for f in entry.rglob("*")
                        if f.is_file()
                    )
                    total += sz
                    run_sizes[entry.name] = sz
            snap["disk_total_bytes"] = total
            snap["disk_per_run"] = run_sizes
        except Exception:
            snap["disk_total_bytes"] = None
            snap["disk_per_run"] = {}
        # Active runs in memory.
        try:
            with _RUNS_LOCK:
                snap["active_runs"] = len(_RUNS)
                snap["run_row_counts"] = {
                    rid: int(r.get("summary", {}).get("n_total", 0))
                    for rid, r in _RUNS.items()
                }
        except Exception:
            snap["active_runs"] = None
            snap["run_row_counts"] = {}
        # Free disk on the demo partition.
        try:
            du = shutil.disk_usage(demo_root if demo_root.exists() else "/tmp")
            snap["disk_free_bytes"] = du.free
            snap["disk_total_partition_bytes"] = du.total
        except Exception:
            snap["disk_free_bytes"] = None
            snap["disk_total_partition_bytes"] = None
        self._send_json(
            200, _safe_dumps(snap).encode("utf-8")
        )

    # P-AI-4.1 — face library quality audit page.  Loads the run's
    # face_centroids.npz + the user-root library, applies the three
    # P-AI-4 audits (cluster precision, fragmentation, cross-run
    # continuity), renders an HTML report.  ``?format=json`` returns
    # the same data as JSON for tooling.
    def _serve_face_audit(self, run_id: str) -> bool:
        run_id = unquote(run_id).split("?")[0]
        run = _get_run(run_id) or _reload_run_from_disk(run_id)
        if run is None:
            self._reject_upload(404, f"no such run {run_id!r}")
            return True
        # Parse the optional ?format=json query string
        want_json = "format=json" in (self.path or "")

        try:
            import numpy as np
            from pixcull.pipeline.face_audit import (
                CLUSTER_PAIR_OUTLIER_SIM,
                cluster_precision_audit,
                cross_run_continuity_audit,
                library_fragmentation_audit,
            )
            from pixcull.pipeline.face_library import (
                load_library,
                load_run_centroids,
            )
            from pixcull.users import get_active_user, user_root as _user_root_fn
        except ImportError as exc:
            self._reject_upload(500, f"face audit imports failed: {exc}")
            return True

        out_dir = Path(run["output_dir"])
        user_root = _user_root_fn(get_active_user())

        # ---- Cluster precision ----------------------------------
        # Need per-cluster member embeddings.  Read rows.parquet /
        # scores.csv to assemble {cluster_id: [face_embeddings...]}.
        cluster_reports: list[dict] = []
        try:
            scores_path = out_dir / "scores.csv"
            if scores_path.exists():
                import pandas as pd
                df = pd.read_csv(scores_path)
                if "face_cluster_id" in df.columns \
                   and "face_embeddings" in df.columns:
                    import json as _json
                    by_cluster: dict[int, list[list[float]]] = {}
                    for _, row in df.iterrows():
                        cid = row.get("face_cluster_id")
                        if cid is None or pd.isna(cid):
                            continue
                        embs_raw = row.get("face_embeddings")
                        try:
                            embs = _json.loads(embs_raw) \
                                if isinstance(embs_raw, str) else []
                        except (ValueError, TypeError):
                            embs = []
                        # face_embeddings is list-of-list (one per face);
                        # take all of them
                        for e in embs:
                            if isinstance(e, list) and e:
                                by_cluster.setdefault(int(cid), []).append(e)
                    for cid, embs in by_cluster.items():
                        rpt = cluster_precision_audit(embs, cluster_id=cid)
                        cluster_reports.append({
                            "cluster_id":      rpt.cluster_id,
                            "n_members":       rpt.n_members,
                            "min_pair_sim":    round(rpt.min_pair_sim, 3),
                            "mean_pair_sim":   round(rpt.mean_pair_sim, 3),
                            "n_outliers":      len(rpt.outlier_indices),
                            "polluted":        rpt.polluted,
                        })
        except (OSError, ValueError, KeyError):
            cluster_reports = []

        # ---- Library fragmentation ------------------------------
        frag_reports: list[dict] = []
        try:
            labels, lib_centroids = load_library(user_root)
            if len(labels) > 0:
                by_label: dict[str, list[list[float]]] = {}
                for lab, c in zip(labels, lib_centroids):
                    by_label.setdefault(str(lab), []).append(list(c))
                for r in library_fragmentation_audit(by_label):
                    frag_reports.append({
                        "label":       r.label,
                        "n_centroids": r.n_centroids,
                        "fragmented":  r.fragmented,
                    })
        except (OSError, ValueError):
            frag_reports = []

        # ---- Cross-run continuity -------------------------------
        continuity: dict = {"n_current_clusters": 0,
                            "n_matched_to_library": 0,
                            "match_rate": 0.0}
        try:
            this_run = load_run_centroids(out_dir)
            labels, lib_centroids = load_library(user_root)
            if this_run is not None and len(lib_centroids) > 0:
                _, cur_centroids = this_run
                cur_list = [list(c) for c in cur_centroids]
                lib_list = [list(c) for c in lib_centroids]
                cont = cross_run_continuity_audit(cur_list, lib_list)
                continuity = {
                    "n_current_clusters":   cont.n_current_clusters,
                    "n_matched_to_library": cont.n_matched_to_library,
                    "match_rate":           cont.match_rate,
                }
        except (OSError, ValueError):
            pass

        payload = {
            "run_id":            run_id,
            "outlier_threshold": CLUSTER_PAIR_OUTLIER_SIM,
            "cluster_precision": cluster_reports,
            "library_fragmentation": frag_reports,
            "continuity":        continuity,
        }

        if want_json:
            self._send_json(200,
                _safe_dumps(payload).encode("utf-8"))
            return True

        # ---- HTML render ----------------------------------------
        html = _render_face_audit_html(payload)
        self._send_html(200, html.encode("utf-8"))
        return True

    # P-PRO-7.1 — full delivery audit page.  Subprocess-runs
    # ``scripts/cli_audit.py`` on the run's scores.csv + image input
    # dir, then wraps the resulting Markdown report in a minimal
    # HTML chrome so the photographer can read it in the browser
    # without dropping to a terminal.  ``?format=md`` returns the
    # raw markdown for piping into a PR / issue.
    def _serve_delivery_audit(self, run_id: str) -> bool:
        import shlex
        import subprocess
        run_id = unquote(run_id).split("?")[0]
        run = _get_run(run_id) or _reload_run_from_disk(run_id)
        if run is None:
            self._reject_upload(404, f"no such run {run_id!r}")
            return True
        want_md = "format=md" in (self.path or "")
        preset = "western"
        if "preset=chinese" in (self.path or ""):
            preset = "chinese"

        out_dir = Path(run["output_dir"])
        scores_csv = out_dir / "scores.csv"
        if not scores_csv.exists():
            self._reject_upload(404,
                f"no scores.csv at {scores_csv} — run hasn't completed?")
            return True
        # Image root: prefer input/ for upload-mode runs; scan-mode
        # runs carry absolute paths in scores.csv so leave None.
        input_dir = out_dir.parent / "input"
        cli_path = Path(__file__).resolve().parent / "cli_audit.py"

        cmd = [
            sys.executable, str(cli_path),
            "--scores-csv", str(scores_csv),
            "--mandatory-preset", preset,
        ]
        if input_dir.is_dir():
            cmd += ["--image-root", str(input_dir)]
        # User-root for the face library audit
        try:
            from pixcull.users import get_active_user, user_root as _ur
            uroot = _ur(get_active_user())
            if uroot:
                cmd += ["--user-root", str(uroot)]
        except ImportError:
            pass

        # Time-bound the subprocess so a stuck audit doesn't hang the
        # server.  60s is generous (real audits land in <30s).
        try:
            proc = subprocess.run(
                cmd, capture_output=True, text=True, timeout=90,
                env={**os.environ, "PYTHONPATH":
                     str(_repo_root() or _pkg_root().parent) +
                     ":" + os.environ.get("PYTHONPATH", "")},
            )
        except subprocess.TimeoutExpired:
            self._reject_upload(504, "audit timed out (>90s)")
            return True
        if proc.returncode != 0:
            self._reject_upload(500,
                f"cli_audit failed (exit {proc.returncode}): "
                f"{proc.stderr[:500]}")
            return True
        md = proc.stdout

        if want_md:
            self.send_response(200)
            self.send_header("Content-Type",
                             "text/markdown; charset=utf-8")
            self.send_header("Content-Length",
                             str(len(md.encode("utf-8"))))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(md.encode("utf-8"))
            return True

        html = _render_delivery_audit_html(run_id, md, preset)
        self._send_html(200, html.encode("utf-8"))
        return True

    def _serve_runs_list(self) -> None:
        body = json.dumps({"runs": _enumerate_runs()},
                          ensure_ascii=False).encode("utf-8")
        self._send_json(200, body)

    def _serve_storage_info(self) -> None:
        body = json.dumps(_storage_info(),
                          ensure_ascii=False).encode("utf-8")
        self._send_json(200, body)

    def _handle_run_delete(self, run_id: str) -> None:
        ok, msg = _delete_run(unquote(run_id))
        status = 200 if ok else 404 if msg == "no such run" else 400
        body = json.dumps({"ok": ok, "message": msg, "run_id": run_id},
                          ensure_ascii=False).encode("utf-8")
        self._send_json(status, body)

    def _handle_rescan_scene(self, run_id: str) -> None:
        """P0.4 — re-run SceneDetector on the cached scores.csv rows
        of a run, applying V20's face-aware stilllife correction.

        Pre-V20 SceneDetector mis-tagged a meaningful fraction of
        indoor portrait / event shots as ``stilllife`` (CLIP's
        "product in studio" prompt is a magnet for warm indoor lighting
        with a centered subject). V20's worker.py added a correction
        path — "if face_count > 0 and scene == stilllife, walk
        scene_probs in descending order and pick the next non-
        stilllife class". That fix only takes effect on NEW scans;
        existing cached runs still carry the bad tags.

        This endpoint applies the correction to cached scores.csv
        rows IN-PLACE without re-running the full pipeline. Only
        rows with face_count > 0 are touched; the corrected scene
        is whichever non-stilllife class scored second-best in
        scene_probs. When ``scene_probs`` isn't preserved on disk
        (pre-V8.2 scans), we fall back to "portrait" as a safe
        default since face_count > 0 strongly suggests that scene.

        Method: POST so the action is deliberate (admin button only).
        """
        run = _get_run(run_id) or _reload_run_from_disk(run_id)
        if run is None:
            self.send_error(404, "no such run")
            return
        scores_path = Path(run["output_dir"]) / "scores.csv"
        if not scores_path.exists():
            self.send_error(404, "no scores.csv to re-scene")
            return
        import pandas as pd
        df = pd.read_csv(scores_path)
        if "scene" not in df.columns or "face_count" not in df.columns:
            self.send_error(
                400,
                "scores.csv schema doesn't have scene + face_count — "
                "this run is too old to re-scene cheaply. Re-scan the "
                "folder instead.",
            )
            return

        # Backup the existing scores.csv before mutating
        backup = scores_path.with_suffix(
            f".csv.bak.{int(time.time())}"
        )
        try:
            scores_path.rename(backup)
        except OSError as exc:
            self.send_error(500, f"backup failed: {exc}")
            return

        # The set of "bad" stilllife tags we want to correct
        mask = (
            (df["scene"].astype(str) == "stilllife")
            & (df["face_count"].fillna(0).astype(float) > 0)
        )
        n_candidates = int(mask.sum())

        # Try to read the per-row scene_probs (a JSON string column
        # since V8.2). When present, parse it and pick the
        # highest-probability non-stilllife class. Otherwise default
        # to "portrait" since face_count > 0 strongly suggests that.
        corrected: list[tuple[int, str]] = []
        if "scene_probs" in df.columns:
            import ast
            for idx in df.index[mask].tolist():
                raw = df.at[idx, "scene_probs"]
                pick = "portrait"
                if isinstance(raw, str) and raw:
                    try:
                        probs = ast.literal_eval(raw)
                        if isinstance(probs, dict):
                            ranked = sorted(
                                probs.items(), key=lambda kv: -float(kv[1]),
                            )
                            for name, _p in ranked:
                                if name != "stilllife":
                                    pick = name
                                    break
                    except (ValueError, SyntaxError, TypeError):
                        pass
                corrected.append((idx, pick))
        else:
            for idx in df.index[mask].tolist():
                corrected.append((idx, "portrait"))

        for idx, new_scene in corrected:
            df.at[idx, "scene"] = new_scene
        df.to_csv(scores_path, index=False)

        body = _safe_dumps({
            "ok":         True,
            "run_id":     run_id,
            "n_total":    int(len(df)),
            "n_corrected": len(corrected),
            "scene_redistribution":
                {k: int(v) for k, v in
                 pd.Series([c[1] for c in corrected]).value_counts().items()}
                if corrected else {},
            "backup_path": str(backup),
            "note": "scores.csv 已更新;刷新结果页即可看到新的 scene 分布。",
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _handle_apply_style_guide(self, run_id: str) -> None:
        """P2.3 — apply the active user's style guide to a run.

        Runs every rule against every row, tallies violations, and
        OPTIONALLY adjusts the decision column when a rule's
        ``on_violation`` is ``maybe`` or ``cull``. Reports a per-
        rule violation count + total adjustments back.

        Body (optional):
            {dry_run: bool}   — when True, don't mutate scores.csv,
                                just report what WOULD change.
        """
        run = _get_run(run_id) or _reload_run_from_disk(run_id)
        if run is None:
            self.send_error(404, "no such run")
            return
        n = int(self.headers.get("Content-Length") or "0")
        params: dict = {}
        if n > 0:
            try:
                params = json.loads(self.rfile.read(n).decode("utf-8")
                                      or "{}")
            except (json.JSONDecodeError, UnicodeDecodeError):
                self.send_error(400, "invalid JSON body")
                return
        dry_run = bool(params.get("dry_run") or False)

        from pixcull.scoring.style_guide import (
            load_style_guide, apply_style_guide,
        )
        guide = load_style_guide()
        if not guide:
            body = _safe_dumps({
                "ok": True, "run_id": run_id,
                "message": "no style guide configured for active user "
                           "(no <user_root>/style_guide.yaml and no "
                           "subscribed team guide)",
                "violations_n": 0, "decision_changes": 0,
            }).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type",
                              "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)
            return

        result = _build_results(run_id)
        if result is None:
            self.send_error(425, "results not ready")
            return
        rows, _summary = result

        scores_path = Path(run["output_dir"]) / "scores.csv"
        import pandas as pd
        df = pd.read_csv(scores_path)

        per_rule_count: dict[str, int] = {}
        decision_changes = 0
        sample_violations: list[dict] = []
        for i, r in enumerate(rows):
            src = r.get("src_path") or r.get("path")
            res = apply_style_guide(
                r, guide,
                image_path=Path(src) if src else None,
            )
            for v in res["violations"]:
                per_rule_count[v["rule_id"]] = (
                    per_rule_count.get(v["rule_id"], 0) + 1
                )
                if len(sample_violations) < 8:
                    sample_violations.append({
                        "filename": r["filename"],
                        **v,
                    })
            new_dec = res["new_decision"]
            if new_dec and new_dec != r["decision"]:
                decision_changes += 1
                if not dry_run:
                    # Update scores.csv in place
                    match = df["filename"] == r["filename"]
                    df.loc[match, "decision"] = new_dec

        if not dry_run and decision_changes > 0:
            backup = scores_path.with_suffix(
                f".csv.bak.{int(time.time())}"
            )
            try:
                scores_path.rename(backup)
                df.to_csv(scores_path, index=False)
            except OSError as exc:
                self.send_error(500, f"write failed: {exc}")
                return

        body = _safe_dumps({
            "ok":               True,
            "run_id":           run_id,
            "dry_run":          dry_run,
            "guide_name":       guide.get("name") or "(unnamed)",
            "n_rows":           int(len(df)),
            "violations_n":     sum(per_rule_count.values()),
            "per_rule_count":   per_rule_count,
            "decision_changes": decision_changes,
            "sample_violations": sample_violations,
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _handle_runs_cleanup(self) -> None:
        """Bulk delete by policy. Body: {older_than_hours?, keep_last?}.

        Both filters are optional; if both are provided we apply them as
        an intersection ("older than X AND not in newest K").

        Per-run busy state: a run still marked ``running`` is never
        deleted (would corrupt the analyzing thread). The user can wait
        or kill the server and retry.
        """
        clen = int(self.headers.get("Content-Length", "0") or "0")
        body_bytes = self.rfile.read(clen) if clen > 0 else b"{}"
        try:
            params = json.loads(body_bytes.decode("utf-8") or "{}")
        except (UnicodeDecodeError, json.JSONDecodeError):
            self.send_error(400, "expected JSON body")
            return

        older = params.get("older_than_hours")
        keep_last = params.get("keep_last")

        runs = _enumerate_runs()  # newest first
        candidates: list[dict] = list(runs)

        # Skip in-progress runs unconditionally; they own files we'd corrupt.
        candidates = [r for r in candidates if r.get("state") != "running"]

        # "Keep last K" — preserve the K newest, mark the rest as candidates.
        if isinstance(keep_last, int) and keep_last >= 0:
            candidates = candidates[keep_last:]

        # "Older than N hours" — must be older than the cutoff.
        if isinstance(older, (int, float)) and older >= 0:
            cutoff = time.time() - float(older) * 3600
            candidates = [r for r in candidates if (r["mtime"] or 0) < cutoff]

        results = []
        freed_bytes = 0
        for r in candidates:
            ok, msg = _delete_run(r["run_id"])
            results.append({
                "run_id": r["run_id"],
                "ok": ok,
                "message": msg,
                "size_bytes": r["size_bytes"],
            })
            if ok:
                freed_bytes += r["size_bytes"]

        body = json.dumps({
            "candidates_considered": len(candidates),
            "deleted": sum(1 for r in results if r["ok"]),
            "freed_bytes": freed_bytes,
            "results": results,
        }, ensure_ascii=False).encode("utf-8")
        self._send_json(200, body)

    # --- utilities ---------------------------------------------------------
    def _send_html(self, status: int, body: bytes) -> None:
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _send_json(self, status: int, body: bytes) -> None:
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _reject_upload(self, status: int, message: str) -> None:
        """Send a JSON error reply for an /analyze failure.

        Replaces the default ``send_error`` HTML stub — the upload page's
        JS surfaces ``data.error`` directly, so a clean string beats a
        BaseHTTPRequestHandler error page being scraped into a textbox.
        """
        body = json.dumps({"error": message}, ensure_ascii=False).encode("utf-8")
        self._send_json(status, body)


# ---------------------------------------------------------------------------
# Server bootstrap.
# ---------------------------------------------------------------------------
def _load_app_config_into_env() -> None:
    """V17.5 — when serve_demo is launched directly (not via the .app),
    ``DEEPSEEK_API_KEY`` won't be set even if the user previously
    configured it via the launcher menu. Read the same config.json the
    launcher writes to so dev-mode runs match production behavior.
    """
    if os.environ.get("DEEPSEEK_API_KEY"):
        return  # already set, don't override
    import sys as _sys
    if _sys.platform == "darwin":
        cfg_path = Path.home() / "Library" / "Application Support" / "PixCull" / "config.json"
    else:
        cfg_path = Path.home() / ".pixcull" / "config.json"
    if not cfg_path.exists():
        return
    try:
        cfg = json.loads(cfg_path.read_text("utf-8"))
        if cfg.get("deepseek_api_key"):
            os.environ["DEEPSEEK_API_KEY"] = cfg["deepseek_api_key"]
            print(f"  config: loaded DeepSeek key from {cfg_path}",
                  file=sys.stderr)
    except (OSError, json.JSONDecodeError) as exc:
        _dbg("load_app_config", exc, str(cfg_path))


def main() -> None:
    _load_app_config_into_env()
    parser = argparse.ArgumentParser(
        description="PixCull web demo — upload images and see decisions."
    )
    parser.add_argument(
        "--port", type=int, default=_DEFAULT_PORT,
        help=f"Preferred port (default {_DEFAULT_PORT}; auto-fallback if busy)"
    )
    parser.add_argument(
        "--host", default="127.0.0.1",
        help="Bind address (default 127.0.0.1 — localhost only). "
             "Use 0.0.0.0 to expose to LAN. WARNING: no auth, only do this "
             "on networks you trust.",
    )
    parser.add_argument(
        "--no-open", action="store_true",
        help="Don't open a browser tab on startup",
    )
    parser.add_argument(
        "--rescorer-mode", default="auto",
        choices=("auto", "off", "shadow", "adjudicate"),
        help="V1.2 rescorer mode. 'auto' (default) uses 'shadow' if "
             "models/rescorer_v1.joblib exists, else 'off'. 'shadow' shows "
             "the model's keep/maybe prediction next to each card without "
             "changing decisions; 'adjudicate' lets the model promote "
             "rule-maybe rows to keep when confident.",
    )
    parser.add_argument(
        "--rescorer-path", default=None,
        help="Path to rescorer joblib (default: models/rescorer_v1.joblib)",
    )
    parser.add_argument(
        "--auto-prune-hours", type=float, default=None,
        help="On startup, delete every existing run dir older than N hours. "
             "Off by default — admin panel does the same job interactively.",
    )
    parser.add_argument(
        "--max-upload-mb", type=int,
        default=_MAX_UPLOAD_BYTES_DEFAULT // 1024 // 1024,
        help=f"Per-request upload size cap in MB. Default "
             f"{_MAX_UPLOAD_BYTES_DEFAULT // 1024 // 1024} MB "
             f"(≈130-260 RAW shots). Raise for bigger batches.",
    )
    parser.add_argument(
        "--max-upload-files", type=int, default=_MAX_UPLOAD_FILES_DEFAULT,
        help=f"Per-request file count cap. Default {_MAX_UPLOAD_FILES_DEFAULT}.",
    )
    parser.add_argument(
        "--vlm-mode", default="off",
        help="V3.0 VLM-as-judge backend (sees pixels). Default off. "
             "Values: 'off' | 'local' | 'local:<repo>' | 'deepseek' | "
             "'minimax' | 'openai'. Note: as of 2026-04 DeepSeek's API is "
             "TEXT ONLY — use 'local' for vision and 'deepseek' for the "
             "meta judge below.",
    )
    parser.add_argument(
        "--meta-mode", default="off",
        help="V3.1 meta-judge: text LLM consolidates all signals "
             "(rule + V2.1 model + VLM + detector metrics) into a "
             "calibrated final verdict. Off by default. Values: "
             "'off' | 'deepseek' (V4-Flash) | 'deepseek:deepseek-v4-pro'. "
             "Requires DEEPSEEK_API_KEY env var. ~¥0.003/image.",
    )
    args = parser.parse_args()

    _DEMO_ROOT.mkdir(parents=True, exist_ok=True)

    if args.auto_prune_hours is not None and args.auto_prune_hours >= 0:
        cutoff = time.time() - args.auto_prune_hours * 3600
        pruned = 0
        freed = 0
        for r in _enumerate_runs():
            if (r["mtime"] or 0) < cutoff and r.get("state") != "running":
                ok, _ = _delete_run(r["run_id"])
                if ok:
                    pruned += 1
                    freed += r["size_bytes"]
        if pruned:
            mb = freed / 1024 / 1024
            print(f"  auto-prune: deleted {pruned} run(s) older than "
                  f"{args.auto_prune_hours}h, freed {mb:.1f} MB")

    # Resolve rescorer 'auto': use shadow if a model file is present at the
    # default (or user-specified) location, else fall through to off. This
    # makes the demo "self-tuning" — fresh checkouts work, trained
    # checkouts get the V1.1 head turned on for free.
    rescorer_path = args.rescorer_path or "models/rescorer_v1.joblib"
    rescorer_mode = args.rescorer_mode
    if rescorer_mode == "auto":
        rescorer_mode = "shadow" if Path(rescorer_path).exists() else "off"

    port = _pick_port(args.port, args.host)
    server = ThreadingHTTPServer((args.host, port), _Handler)
    server.rescorer_mode = rescorer_mode  # type: ignore[attr-defined]
    server.rescorer_path = rescorer_path  # type: ignore[attr-defined]
    server.max_upload_bytes = args.max_upload_mb * 1024 * 1024  # type: ignore[attr-defined]
    server.max_upload_files = args.max_upload_files  # type: ignore[attr-defined]
    server.vlm_mode = args.vlm_mode  # type: ignore[attr-defined]
    server.meta_mode = args.meta_mode  # type: ignore[attr-defined]

    # Print URLs the user can paste into a browser. On 0.0.0.0 we also
    # show the LAN IP so the operator knows the address to share rather
    # than running ifconfig themselves.
    local_url = f"http://127.0.0.1:{port}/"
    print(f"PixCull demo serving on {args.host}:{port}")
    print(f"  local:   {local_url}")
    if args.host == "0.0.0.0":
        ip = _local_ipv4()
        if ip:
            print(f"  LAN:     http://{ip}:{port}/  (share this with phones / other laptops)")
        else:
            print("  LAN:     <couldn't detect IP — run `ipconfig getifaddr en0`>")
        print("  ⚠  exposed to LAN with no auth — only run on trusted networks")
    print(f"  output:  {_DEMO_ROOT}/<run_id>/")
    if args.rescorer_mode == "auto":
        print(f"  rescorer: {rescorer_mode} (auto-resolved; model at {rescorer_path})")
    else:
        print(f"  rescorer: {rescorer_mode} (forced; model at {rescorer_path})")
    print(f"  upload limits: {args.max_upload_mb} MB / {args.max_upload_files} files per request")
    if args.vlm_mode != "off":
        print(f"  VLM mode: {args.vlm_mode} (V3.0 — adds ~10s/img local, ~2s/img API)")
    if args.meta_mode != "off":
        print(f"  Meta-judge: {args.meta_mode} (V3.1 — adds ~5-10s/img · ~¥0.003/img)")
    if not args.no_open and args.host in ("127.0.0.1", "localhost"):
        threading.Timer(0.4, lambda: webbrowser.open(local_url)).start()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down.")
        server.server_close()


# README that ships inside the XMP zip download. Tells the user what to
# do with the sidecars on the Lightroom / Capture One side.
_XMP_README = """PixCull XMP sidecar export — run {run_id}

This zip contains {n} XMP sidecar files, one per analyzed image.
Each <filename>.xmp encodes the pipeline's decision as:

  keep   →  5 stars + Green label
  maybe  →  3 stars + Yellow label
  cull   →  1 star  + Red label

How to apply (Lightroom Classic):
  1. Place each .xmp next to its image (same stem, same folder)
  2. In LR Library → Metadata → Read Metadata from File
  3. Or set Edit → Catalog Settings → "Automatically write changes into XMP"

How to apply (Capture One):
  1. Place each .xmp next to its image
  2. C1 reads on import; if already imported, right-click → Sync Metadata

The sidecar files only carry rating + label. Develop adjustments, keywords,
and other Lightroom metadata are untouched.
"""


# ---------------------------------------------------------------------------
# HTML — kept inline for single-file shippability, except results.html
# which V19.4.1 split out to support hot-reloadable edits without restart:
#   _UPLOAD_HTML            GET /            drag-drop + status panel
#   results.html [external] GET /results/    decision grid (data → __PAYLOAD__)
#   _FIRST_RUN_HTML         GET /first_run   model-warming progress (V14.6)
#   _ADMIN_HTML             GET /admin       storage / runs admin
# ---------------------------------------------------------------------------

# V14.6 — first-run progress page. Polls /first_run_status every
# 1.5 s to drive a progress bar with per-step labels. On phase ==
# "done" it celebrates briefly, then redirects to "/". On phase ==
# "skipped" or "idle" (i.e. user opened this URL after first-run
# already completed), it auto-redirects so the page is harmless.
#
# Visual style mirrors the upload page: same dark bg, same accent
# blue, same Inter/SF stack — feels like the same app, not a
# bootstrap loader.
# v2.16-P0 — extracted to templates/pages/first_run.html (217 lines of inline HTML);
# loaded via the same _read_template as video_review/timeline (v2.5).
_FIRST_RUN_HTML = _read_template("pages/first_run.html")


# V14.7 — privacy disclosure page. Linked from the admin opt-in toggle
# so the user knows EXACTLY what gets collected before flipping it on.
# Hard-coded list mirrors the redaction patterns in
# pixcull/error_reporting.py — keep them in sync if you add more.
# v2.16-P0 — extracted to templates/pages/privacy.html (109 lines of inline HTML);
# loaded via the same _read_template as video_review/timeline (v2.5).
_PRIVACY_HTML = _read_template("pages/privacy.html")


# V17.0 — verticals page. Photographers seed each of 10 verticals
# (风光 / 拍鸟 / 婚纱 / cosplay / 儿童 / 宠物 / 旅拍 / 活动 / 运动 / 野生)
# with reference shots they consider "good" or "bad" so per-vertical
# eval and tuning have ground truth to work from.
# v2.16-P0 — extracted to templates/pages/verticals.html (1850 lines of inline HTML);
# loaded via the same _read_template as video_review/timeline (v2.5).
_VERTICALS_HTML = _read_template("pages/verticals.html")


# V17.7 — bulk-classify-from-folder UI. Placeholders __VKEY__,
# __VICON__, __VZH__ are substituted server-side per vertical.
# v2.16-P0 — extracted to templates/pages/vertical_bulk.html (335 lines of inline HTML);
# loaded via the same _read_template as video_review/timeline (v2.5).
_VERTICAL_BULK_HTML = _read_template("pages/vertical_bulk.html")


# v2.16-P0 — extracted to templates/pages/upload.html (1716 lines of inline HTML);
# loaded via the same _read_template as video_review/timeline (v2.5).
_UPLOAD_HTML = _read_template("pages/upload.html").replace(
    "/*__DESIGN_TOKENS_CSS__*/", _DESIGN_TOKENS_CSS)


# V19.4.1 — _RESULTS_HTML moved to pixcull/report/templates/results.html.
# Loaded via _results_html_template() above; hot-reloadable on edit.


def _render_delivery_audit_html(run_id: str, md: str, preset: str) -> str:
    """P-PRO-7.1 — wrap the cli_audit Markdown output in browser
    HTML.  Lightweight Markdown→HTML conversion (regex-based) so we
    don't pull in a markdown library; the CLI output uses a stable
    subset (## headings, | tables |, ``- bullets``, **bold**).
    """
    import html as _html
    import re as _re

    def _md_to_html(text: str) -> str:
        # Escape first
        out = _html.escape(text)
        # ## Headings → <h2>
        out = _re.sub(r"^## +(.+)$",
                      r"<h2>\1</h2>", out, flags=_re.MULTILINE)
        # # Heading → <h1>
        out = _re.sub(r"^# +(.+)$",
                      r"<h1>\1</h1>", out, flags=_re.MULTILINE)
        # **bold**
        out = _re.sub(r"\*\*([^*\n]+)\*\*", r"<b>\1</b>", out)
        # `inline code`
        out = _re.sub(r"`([^`\n]+)`", r"<code>\1</code>", out)
        # _italic_ for the timestamp line + similar
        out = _re.sub(r"(?<!\w)_([^_\n]+)_(?!\w)", r"<i>\1</i>", out)

        # Tables: blocks of | … | lines.  Convert each contiguous
        # block by detecting the separator line ``| --- | --- |`` etc.
        def _tablize(block: str) -> str:
            lines = block.strip().splitlines()
            if len(lines) < 2:
                return block
            head_cells = [c.strip() for c in lines[0].strip("|").split("|")]
            rows_html = []
            for ln in lines[2:]:                       # skip separator
                cells = [c.strip() for c in ln.strip("|").split("|")]
                tds = "".join(f"<td>{c}</td>" for c in cells)
                rows_html.append(f"<tr>{tds}</tr>")
            ths = "".join(f"<th>{c}</th>" for c in head_cells)
            return ("<table><thead><tr>" + ths + "</tr></thead>"
                    "<tbody>" + "".join(rows_html) + "</tbody></table>")

        # Find tables (any 2+ consecutive lines starting with |)
        def _table_repl(m: _re.Match) -> str:
            return _tablize(m.group(0))
        out = _re.sub(
            r"(?:^\|.*\|$\n){2,}",
            _table_repl, out, flags=_re.MULTILINE,
        )

        # Bullets:  "  - foo" or "- foo"
        out = _re.sub(r"^( {0,4})- +(.+)$",
                      r"\1<li>\2</li>", out, flags=_re.MULTILINE)
        # Wrap consecutive <li> in <ul>
        out = _re.sub(r"(?:<li>.+</li>\n)+",
                      lambda m: "<ul>" + m.group(0) + "</ul>", out)

        # Paragraph break: double newline → </p><p>
        # (cheap; the markdown is short enough that we just wrap
        # the whole thing in a div with white-space: pre-line)
        return out

    body = _md_to_html(md)
    preset_label = "中式" if preset == "chinese" else "西式"
    preset_url = ("?preset=western" if preset == "chinese"
                  else "?preset=chinese")
    preset_alt = "西式" if preset == "chinese" else "中式"

    return (
        "<!DOCTYPE html><html lang='zh'><head>"
        "<meta charset='utf-8'>"
        f"<title>交付审计 · {_html.escape(run_id)}</title>"
        "<style>"
        "body{margin:0;background:#161616;color:#e9ecf2;"
        "font:13px/1.6 -apple-system,Segoe UI,PingFang SC,sans-serif}"
        "header{padding:18px 24px;border-bottom:1px solid #232830;"
        "display:flex;align-items:center;gap:12px;flex-wrap:wrap}"
        "header h1{margin:0;font-size:16px;font-weight:700;flex:1}"
        "header a,header span.preset{font-size:11.5px;color:#a8b2c1;"
        "text-decoration:none;padding:4px 10px;border-radius:6px;"
        "border:1px solid #232830}"
        "header a:hover{color:#fff}"
        "main{padding:18px 24px;max-width:920px;line-height:1.7}"
        "h1{font-size:20px;margin:0 0 4px}"
        "h2{font-size:13px;margin:32px 0 12px;color:#a8b2c1;"
        "text-transform:uppercase;letter-spacing:.04em;"
        "padding-bottom:6px;border-bottom:1px solid #1c2027}"
        "b{color:#fff}"
        "i{color:#7a8696;font-style:normal;font-size:11.5px}"
        "code{font-family:ui-monospace,monospace;font-size:11.5px;"
        "padding:1px 5px;background:#11141a;border-radius:3px;"
        "color:#eaca98}"
        "table{width:100%;border-collapse:collapse;font-size:12px;"
        "background:#11141a;border:1px solid #232830;border-radius:6px;"
        "overflow:hidden;margin:6px 0 16px}"
        "th{text-align:left;padding:8px 12px;background:#161a21;"
        "color:#a8b2c1;font-weight:600;font-size:11px;"
        "letter-spacing:.04em;text-transform:uppercase;"
        "border-bottom:1px solid #232830}"
        "td{padding:7px 12px;border-bottom:1px solid #1c2027}"
        "tr:last-child td{border-bottom:none}"
        "ul{margin:6px 0 16px;padding-left:18px}"
        "li{margin:2px 0}"
        "footer{padding:18px 24px;color:#7a8696;font-size:11.5px;"
        "border-top:1px solid #232830}"
        "</style></head><body>"
        f"<header><h1>📋 交付审计 · run "
        f"<code>{_html.escape(run_id)}</code></h1>"
        f"<span class='preset'>mandatory: {preset_label}</span>"
        f"<a href='/admin/delivery/{_html.escape(run_id)}{preset_url}'"
        f">切换 {preset_alt} 预设</a>"
        f"<a href='/admin/delivery/{_html.escape(run_id)}?format=md'>原 Markdown</a>"
        "<a href='/admin'>← 返回 admin</a>"
        "</header>"
        f"<main>{body}</main>"
        "<footer>P-PRO-7.1 · 数据来源:scripts/cli_audit.py · 包含 P-CORE-2 / "
        "P-AI-4 / P-PRO-4 / P-PRO-6 / P-PRO-7 五段审计</footer>"
        "</body></html>"
    )


def _render_face_audit_html(payload: dict) -> str:
    """P-AI-4.1 — minimal HTML report for the face library audit page.

    Inline CSS / no external dependencies so it works behind the
    same single-binary serve_demo.py as everything else.  Renders
    three sections: per-cluster precision, library fragmentation,
    cross-run continuity.
    """
    import html as _html
    run_id = _html.escape(str(payload.get("run_id", "")))
    threshold = float(payload.get("outlier_threshold", 0.0))
    cont = payload.get("continuity", {}) or {}
    clusters = payload.get("cluster_precision", []) or []
    frags    = payload.get("library_fragmentation", []) or []

    # --- per-cluster precision rows ---
    cluster_rows = ""
    polluted_n = sum(1 for c in clusters if c.get("polluted"))
    if not clusters:
        cluster_rows = "<tr><td colspan='5' class='muted'>没有可审计的 face 簇(运行中没有人脸或 face_embeddings 列缺失)</td></tr>"
    else:
        for c in clusters:
            cls = "polluted" if c.get("polluted") else "clean"
            cluster_rows += (
                f"<tr class='{cls}'>"
                f"<td>{_html.escape(str(c.get('cluster_id', '?')))}</td>"
                f"<td>{c.get('n_members', 0)}</td>"
                f"<td>{c.get('min_pair_sim', 0):.3f}</td>"
                f"<td>{c.get('mean_pair_sim', 0):.3f}</td>"
                f"<td>{'⚠ 污染' if c.get('polluted') else '✓ 干净'} ({c.get('n_outliers', 0)} 离群)</td>"
                f"</tr>"
            )

    # --- fragmentation rows ---
    frag_rows = ""
    frag_n = sum(1 for f in frags if f.get("fragmented"))
    if not frags:
        frag_rows = "<tr><td colspan='3' class='muted'>face library 是空的 —— 还没标注过身份</td></tr>"
    else:
        for f in frags:
            cls = "polluted" if f.get("fragmented") else "clean"
            frag_rows += (
                f"<tr class='{cls}'>"
                f"<td>{_html.escape(str(f.get('label', '')))}</td>"
                f"<td>{f.get('n_centroids', 0)}</td>"
                f"<td>{'⚠ 接近上限' if f.get('fragmented') else '✓ 充裕'}</td>"
                f"</tr>"
            )

    return (
        "<!DOCTYPE html><html lang='zh'><head>"
        "<meta charset='utf-8'>"
        f"<title>face 库审计 · {run_id}</title>"
        "<style>"
        "body{margin:0;background:#161616;color:#e9ecf2;"
        "font:13px/1.5 -apple-system,Segoe UI,PingFang SC,sans-serif}"
        "header{padding:18px 24px;border-bottom:1px solid #232830}"
        "h1{margin:0;font-size:16px;font-weight:700}"
        "h1 a{color:#a8b2c1;font-weight:400;text-decoration:none;"
        "margin-left:12px;font-size:12px}"
        ".muted{color:#7a8696}"
        "main{padding:18px 24px;max-width:960px}"
        "section{margin-bottom:28px}"
        "h2{font-size:13px;font-weight:600;letter-spacing:.04em;"
        "text-transform:uppercase;color:#a8b2c1;margin:0 0 10px}"
        ".kpis{display:flex;gap:18px;margin-bottom:10px;flex-wrap:wrap}"
        ".kpi{padding:8px 12px;background:#11141a;border:1px solid #232830;"
        "border-radius:6px;font-size:11.5px}"
        ".kpi b{font-size:14px;color:#fff;display:block;line-height:1.1}"
        ".kpi.warn b{color:#d6a443}"
        ".kpi.bad b{color:#e0604e}"
        ".kpi.good b{color:#63bd7f}"
        "table{width:100%;border-collapse:collapse;font-size:12px;"
        "background:#11141a;border:1px solid #232830;border-radius:6px;"
        "overflow:hidden}"
        "th{text-align:left;padding:8px 12px;background:#161a21;"
        "color:#a8b2c1;font-weight:600;font-size:11px;"
        "letter-spacing:.04em;text-transform:uppercase;"
        "border-bottom:1px solid #232830}"
        "td{padding:7px 12px;border-bottom:1px solid #1c2027}"
        "tr:last-child td{border-bottom:none}"
        "tr.polluted{background:rgba(224,96,78,0.06)}"
        "tr.polluted td:last-child{color:#ff9a9a}"
        "tr.clean td:last-child{color:#7fe1b8}"
        "footer{padding:18px 24px;color:#7a8696;font-size:11.5px;"
        "border-top:1px solid #232830}"
        "</style></head><body>"
        f"<header><h1>👤 face 库审计 · run <code>{run_id}</code>"
        f"  <a href='/admin'>← 返回 admin</a>"
        f"  <a href='/admin/face_audit/{run_id}?format=json'>JSON</a>"
        f"</h1></header>"
        "<main>"
        "<section><h2>跨 run 连续性</h2>"
        "<div class='kpis'>"
        f"<div class='kpi'>本 run 的 face 簇 <b>{cont.get('n_current_clusters', 0)}</b></div>"
        f"<div class='kpi'>匹配到历史身份 <b>{cont.get('n_matched_to_library', 0)}</b></div>"
        f"<div class='kpi {'good' if cont.get('match_rate', 0) >= 70 else 'warn' if cont.get('match_rate', 0) >= 40 else 'bad'}'>"
        f"匹配率 <b>{cont.get('match_rate', 0):.1f}%</b></div>"
        "</div>"
        "<p class='muted'>跨 run 匹配率持续下降是身份漂移的信号 —— 检查光线 / 嵌入模型变更。</p>"
        "</section>"
        "<section><h2>本 run 簇精度</h2>"
        f"<div class='kpis'><div class='kpi {'bad' if polluted_n else 'good'}'>"
        f"污染簇 <b>{polluted_n}</b></div>"
        f"<div class='kpi'>总簇数 <b>{len(clusters)}</b></div>"
        f"<div class='kpi'>离群阈值 <b>{threshold:.2f}</b></div>"
        "</div>"
        "<table><thead><tr><th>cluster id</th><th>成员</th>"
        "<th>最低对相似度</th><th>平均对相似度</th><th>状态</th></tr></thead>"
        f"<tbody>{cluster_rows}</tbody></table>"
        "</section>"
        "<section><h2>身份库碎片化(每标签 ≤ 16 centroid)</h2>"
        f"<div class='kpis'><div class='kpi {'warn' if frag_n else 'good'}'>"
        f"接近上限的标签 <b>{frag_n}</b></div>"
        f"<div class='kpi'>已知标签 <b>{len(frags)}</b></div>"
        "</div>"
        "<table><thead><tr><th>标签</th><th>centroid 数</th><th>状态</th></tr></thead>"
        f"<tbody>{frag_rows}</tbody></table>"
        "</section>"
        "</main>"
        "<footer>P-AI-4.1 · 报表数据来源:本 run 的 face_centroids.npz + 用户 root 下的 face_library</footer>"
        "</body></html>"
    )


# v2.16-P0 — extracted to templates/pages/admin.html (662 lines of inline HTML);
# loaded via the same _read_template as video_review/timeline (v2.5).
_ADMIN_HTML = _read_template("pages/admin.html").replace(
    "/*__DESIGN_TOKENS_CSS__*/", _DESIGN_TOKENS_CSS)


# v0.7-P0-3 — performance debug page.  Self-contained HTML with the
# same _DESIGN_TOKENS_CSS palette as upload/admin so light/dark
# themes apply uniformly.  Auto-refreshes every 4 s via /admin/perf.json.
#
# v0.9-P2-2 — the per-run section is now a first-class data table:
#  * every column sorts on click (asc → desc → original)
#  * a toolbar of checkboxes hides / shows columns
#  * column headers are drag-to-reorder
#  * a row count + last-refreshed timestamp grounds the live data
#  * preferences (column order + visibility) persist in localStorage
#    so a power user's layout survives the next admin session
# v2.16-P0 — extracted to templates/pages/admin_perf.html (476 lines of inline HTML);
# loaded via the same _read_template as video_review/timeline (v2.5).
_ADMIN_PERF_HTML = _read_template("pages/admin_perf.html").replace(
    "/*__DESIGN_TOKENS_CSS__*/", _DESIGN_TOKENS_CSS)


if __name__ == "__main__":
    main()
