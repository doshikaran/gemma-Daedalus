from pathlib import Path
from functools import lru_cache
import json

# Define the locale directory relative to the package
_LOCALE_DIR = Path(__file__).parent / "locales"

# Define supported locales and default locale
SUPPORTED_LOCALES = [
    "en_US", "zh_CN", "ja_JP", "ko_KR", "es_ES", "de_DE", "fr_FR", "it_IT", "pt_BR", "nl_NL", "tr_TR", "ru_RU", "ar_SA"
]
DEFAULT_LOCALE = "en_US"

def load_locale(lang: str | None = DEFAULT_LOCALE) -> dict[str, str]:
    """
    Loads a locale dictionary from the specified language.
    """
    norm = _normalize_lang(lang)
    return _load_locale_normalized(norm)

@lru_cache(maxsize=8)
def _load_locale_normalized(norm: str) -> dict[str, str]:
    """
    LRU-cached locale loader keyed by the *normalised* name.
    """
    p = _LOCALE_DIR / f"{norm}.json"
    if not p.exists():
        if norm != DEFAULT_LOCALE:
            return _load_locale_normalized(DEFAULT_LOCALE)
        return {}
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    if not isinstance(data, dict):
        return {}
    # Only str -> str entries.
    return {str(k): str(v) for k, v in data.items() if isinstance(v, str)}

def _normalize_lang(lang: str | None) -> str:
    """
    Normalise an Accept-Language fragment into one of SUPPORTED_LOCALES.
    """
    if not lang:
        return DEFAULT_LOCALE
    s = str(lang).lower().replace("_", "-").split(",")[0].strip()
    if s.startswith("zh"):
        return "zh_CN"
    if s.startswith("en"):
        return "en_US"
    if s.startswith("ja"):
        return "ja_JP"
    if s.startswith("ko"):
        return "ko_KR"
    if s.startswith("es"):
        return "es_ES"
    if s.startswith("de"):
        return "de_DE"
    if s.startswith("fr"):
        return "fr_FR"
    if s.startswith("it"):
        return "it_IT"
    if s.startswith("pt"):
        return "pt_BR"
    if s.startswith("nl"):
        return "nl_NL"
    if s.startswith("tr"):
        return "tr_TR"
    if s.startswith("ru"):
        return "ru_RU"
    if s.startswith("ar"):
        return "ar_SA"
    return DEFAULT_LOCALE

def t(key: str, lang: str = DEFAULT_LOCALE) -> str:
    """
    Translate  under . Missing keys return the key.
    """
    table = load_locale(lang)
    return table.get(key, key)

def all_keys(lang: str = DEFAULT_LOCALE) -> list[str]:
    """
    Sorted list of all keys defined for .
    """
    return sorted(load_locale(lang).keys())

__all__ = [
    "SUPPORTED_LOCALES",
    "DEFAULT_LOCALE",
    "load_locale",
    "t",
    "all_keys",
]
