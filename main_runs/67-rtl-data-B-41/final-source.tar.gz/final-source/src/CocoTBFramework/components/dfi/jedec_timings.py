# ... (lines before builtin_timings)

def builtin_timings(name: str) -> JedecTimings:
    """Convenience loader for the CSVs vendored in this package.

    Usage:
        timings = builtin_timings("ddr3-1600")
        timings = builtin_timings("ddr2-650")
    """
    here = Path(__file__).parent / "jedec"
    name = name.lower()
    if name == "ddr2-650-mt47h64m16hr" or name == "ddr2-650":
        filename = "ddr2-650-mt47h64m16hr.csv"
    elif name == "ddr3-1600":
        filename = "ddr3-1600.csv"
    else:
        filename = f"{name}.csv"
    return load_timings(here / filename)
