from setuptools import setup
setup(
    name="tombi",
    version="0.1.0",
    packages=["tombi"],
    package_dir={"": "src"},
    install_requires=[],
)
