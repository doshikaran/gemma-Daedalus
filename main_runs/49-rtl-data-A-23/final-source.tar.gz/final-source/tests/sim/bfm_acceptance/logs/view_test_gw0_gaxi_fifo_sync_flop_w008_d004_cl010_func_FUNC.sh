#!/bin/bash
# To view waveforms: Run this script
cd /mnt/data/github/RTLDesignSherpa-DV/tests/sim/bfm_acceptance/local_sim_build/test_gw0_gaxi_fifo_sync_flop_w008_d004_cl010_func_FUNC && gtkwave gaxi_fifo_sync.fst
# To view logs: cat /mnt/data/github/RTLDesignSherpa-DV/tests/sim/bfm_acceptance/logs/test_gw0_gaxi_fifo_sync_flop_w008_d004_cl010_func_FUNC.log
