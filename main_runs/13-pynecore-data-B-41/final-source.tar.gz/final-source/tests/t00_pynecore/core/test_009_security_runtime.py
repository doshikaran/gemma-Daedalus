"""
@pyne
"""
from pynecore.core.security import (
    SecurityState, _get_confirmed_time,
    create_chart_protocol, create_security_protocol,
    setup_security_states,
)
from pynecore.core.security_shm import (
    SyncBlock, ResultBlock, ResultReader, write_result,
)
from pynecore.core.resampler import Resampler
from multiprocessing import Event, Lock
from zoneinfo import ZoneInfo


def _locks_for(sec_ids):
    """Build a per-slot lock dict matching create_security_protocol's contract."""
    return {sid: Lock() for sid in sec_ids}


def _make_state(
    sec_id="sec_test",
    timeframe="1D",
    same_timeframe=False,
    gaps_on=False,
    tz_str="UTC",
    chart_off=0,
) -> SecurityState:
    """Helper to create a SecurityState for testing."""
    tz = ZoneInfo(tz_str)
    resampler = None if same_timeframe else Resampler.get_resampler(timeframe)
    state = SecurityState(
        sec_id=sec_id,
        timeframe=timeframe,
        gaps_on=gaps_on,
        same_timeframe=same_timeframe,
        resampler=resampler,
        tz=tz,
        chart_off=chart_off,
    )
    state.data_ready.set()
    return state


# 5-minute chart bar span minus one ms (see ``setup_security_states``)
_CHART_OFF_5M = 5 * 60 * 1000 - 1


def __test_confirmed_time_same_tf__(log):
    """_get_confirmed_time returns chart_time for same timeframe"""
    state = _make_state(timeframe="5", same_timeframe=True)

    # Bar 0: same TF always returns chart_time
    result = _get_confirmed_time(state, 1000)
    assert result == 1000

    # Bar 1: still returns chart_time
    result = _get_confirmed_time(state, 2000)
    assert result == 2000


def __test_confirmed_time_htf_mid_period__(log):
    """Mid-period chart bars target the previous HTF period's open"""
    state = _make_state(timeframe="1D", chart_off=_CHART_OFF_5M)

    # Chart bars inside Jan 15 (close instant stays within the day) keep
    # targeting Jan 14 — the most recently closed daily bar. The caller's
    # ``target > last_confirmed`` gate turns the repeats into no-ops.
    jan_14 = 1705190400000  # 2024-01-14T00:00:00Z
    assert _get_confirmed_time(state, 1705312800000) == jan_14  # Jan 15 10:00
    assert _get_confirmed_time(state, 1705313100000) == jan_14  # Jan 15 10:05


def __test_confirmed_time_htf_period_close__(log):
    """The HTF bar is confirmed on its own LAST chart bar (TV lookahead_off)"""
    state = _make_state(timeframe="1D", chart_off=_CHART_OFF_5M)

    jan_15 = 1705276800000  # 2024-01-15T00:00:00Z
    # 2024-01-15 23:55 — the day's last 5m bar, closing exactly at midnight:
    # Jan 15 is confirmed HERE, not on the next bar.
    assert _get_confirmed_time(state, 1705362900000) == jan_15
    # 2024-01-16 00:05 — the next day's bars keep the same target.
    assert _get_confirmed_time(state, 1705363500000) == jan_15


def __test_confirmed_time_first_bar_htf__(log):
    """The first chart bar already targets the last closed HTF period"""
    state = _make_state(timeframe="1W", chart_off=_CHART_OFF_5M)

    # 2024-01-15 (Monday) 10:00 — the previous week (Jan 8) is already closed,
    # so even the very first chart bar targets it; whether a value arrives
    # depends on how far back the child's data file reaches.
    assert _get_confirmed_time(state, 1705312800000) == 1704672000000  # Jan 8


def __test_chart_protocol_signal_read_flow__(log):
    """Chart protocol: signal sets events, read returns value after wait"""
    sec_ids = ["sec_flow"]
    sb = SyncBlock(sec_ids)
    rb = ResultBlock("sec_flow", create=True, version=0)

    state = _make_state(sec_id="sec_flow", timeframe="5", same_timeframe=True)
    states = {"sec_flow": state}

    signal_fn, write_fn, read_fn, wait_fn, cleanup, _ = create_chart_protocol(states, sb)

    try:
        # Simulate: write a value to shared memory (as if security process did it)
        write_result(rb, sb, 42.0)

        # data_ready is initially set → read should return the value immediately
        result = read_fn("sec_flow", default=None)
        assert result == 42.0

        # Write a new value
        write_result(rb, sb, 99.0)
        result = read_fn("sec_flow", default=None)
        assert result == 99.0
    finally:
        cleanup()
        rb.close()
        rb.unlink()
        sb.close()
        sb.unlink()


def __test_chart_protocol_gaps_on__(log):
    """Chart protocol: gaps_on returns default when no new period"""
    sec_ids = ["sec_gaps"]
    sb = SyncBlock(sec_ids)
    rb = ResultBlock("sec_gaps", create=True, version=0)

    state = _make_state(sec_id="sec_gaps", timeframe="1D", gaps_on=True)
    state.new_period = False  # no new period
    states = {"sec_gaps": state}

    signal_fn, write_fn, read_fn, wait_fn, cleanup, _ = create_chart_protocol(states, sb)

    try:
        write_result(rb, sb, 100.0)

        # gaps_on + no new_period → should return default
        result = read_fn("sec_gaps", default="NA")
        assert result == "NA"

        # Now simulate new_period = True
        state.new_period = True
        result = read_fn("sec_gaps", default="NA")
        assert result == 100.0
    finally:
        cleanup()
        rb.close()
        rb.unlink()
        sb.close()
        sb.unlink()


def __test_security_protocol_write_read__(log):
    """Security protocol: write and immediate read"""
    sec_ids = ["sec_a", "sec_b"]
    sb = SyncBlock(sec_ids)
    rb_a = ResultBlock("sec_a", create=True, version=0)
    rb_b = ResultBlock("sec_b", create=True, version=0)

    signal_fn, write_fn, read_fn, wait_fn, cleanup, _, _, _, _ = create_security_protocol(
        "sec_a", sb, rb_a, sec_ids, _locks_for(sec_ids),
    )

    try:
        # Write as security context A
        write_fn("sec_a", 55.5)

        # Read own value
        result = read_fn("sec_a", default=None)
        assert result == 55.5

        # Write a value for sec_b externally (simulate another process)
        write_result(rb_b, sb, "from_b")

        # Read cross-context (B's value)
        result = read_fn("sec_b", default=None)
        assert result == "from_b"

        # Read non-existent data → default
        from pynecore.core.security_shm import write_na
        write_na(rb_b, sb)
        result = read_fn("sec_b", default="NA")
        assert result == "NA"
    finally:
        cleanup()
        rb_a.close()
        rb_a.unlink()
        rb_b.close()
        rb_b.unlink()
        sb.close()
        sb.unlink()


def __test_setup_security_states__(log):
    """setup_security_states creates correct states from __security_contexts__"""
    from pynecore.lib import barmerge

    contexts = {
        "sec_0": {
            "symbol": "CAPITALCOM:EURUSD",
            "timeframe": "1D",
            "gaps": barmerge.gaps_off,
        },
        "sec_1": {
            "symbol": "CAPITALCOM:EURUSD",
            "timeframe": "5",  # same as chart
            "gaps": barmerge.gaps_on,
        },
    }

    states, sync_block, result_blocks = setup_security_states(
        contexts, chart_timeframe="5", tz=ZoneInfo("UTC"),
    )

    try:
        assert len(states) == 2
        assert len(result_blocks) == 2

        # sec_0: HTF (1D vs chart 5m)
        s0 = states["sec_0"]
        assert s0.timeframe == "1D"
        assert s0.gaps_on is False
        assert s0.same_timeframe is False
        assert s0.resampler is not None
        assert s0.data_ready.is_set()
        assert s0.is_ltf is False

        # sec_1: same TF as chart
        s1 = states["sec_1"]
        assert s1.timeframe == "5"
        assert s1.gaps_on is True
        assert s1.same_timeframe is True
        assert s1.resampler is None
        assert s1.data_ready.is_set()
        assert s1.is_ltf is False
    finally:
        for rb in result_blocks.values():
            rb.close()
            rb.unlink()
        sync_block.close()
        sync_block.unlink()


def __test_ltf_protocol_accumulation__(log):
    """LTF security protocol accumulates values into array via flush"""
    sec_ids = ["sec_ltf"]
    sb = SyncBlock(sec_ids)
    rb = ResultBlock("sec_ltf", create=True, version=0)

    signal_fn, write_fn, read_fn, wait_fn, cleanup, flush_fn, _, _, _ = create_security_protocol(
        "sec_ltf", sb, rb, sec_ids, _locks_for(sec_ids), is_ltf=True,
    )

    try:
        assert flush_fn is not None

        # Simulate 3 LTF bars writing values
        write_fn("sec_ltf", 1.1050)
        write_fn("sec_ltf", 1.1052)
        write_fn("sec_ltf", 1.1048)

        # Before flush: shared memory has no data yet
        version, result_size = sb.get_result_meta("sec_ltf")
        assert result_size == 0

        # Flush writes accumulated array
        flush_fn()

        # Read the array
        result = read_fn("sec_ltf", default=[])
        assert result == [1.1050, 1.1052, 1.1048]

        # Buffer is cleared after flush — another flush writes empty list
        flush_fn()
        result = read_fn("sec_ltf", default="SHOULD_NOT_USE")
        assert result == []
    finally:
        cleanup()
        rb.close()
        rb.unlink()
        sb.close()
        sb.unlink()


def __test_ltf_protocol_empty_flush__(log):
    """LTF flush with no writes produces empty array (not na)"""
    sec_ids = ["sec_ltf2"]
    sb = SyncBlock(sec_ids)
    rb = ResultBlock("sec_ltf2", create=True, version=0)

    signal_fn, write_fn, read_fn, wait_fn, cleanup, flush_fn, _, _, _ = create_security_protocol(
        "sec_ltf2", sb, rb, sec_ids, _locks_for(sec_ids), is_ltf=True,
    )

    try:
        # Flush immediately — no writes
        flush_fn()

        result = read_fn("sec_ltf2", default="NA")
        assert result == []
        assert isinstance(result, list)
    finally:
        cleanup()
        rb.close()
        rb.unlink()
        sb.close()
        sb.unlink()


def __test_ltf_htf_protocol_no_flush__(log):
    """Non-LTF protocol returns flush=None"""
    sec_ids = ["sec_htf"]
    sb = SyncBlock(sec_ids)
    rb = ResultBlock("sec_htf", create=True, version=0)

    signal_fn, write_fn, read_fn, wait_fn, cleanup, flush_fn, _, _, _ = create_security_protocol(
        "sec_htf", sb, rb, sec_ids, _locks_for(sec_ids), is_ltf=False,
    )

    try:
        assert flush_fn is None

        # HTF write goes directly to shared memory
        write_fn("sec_htf", 42.0)
        result = read_fn("sec_htf", default=None)
        assert result == 42.0
    finally:
        cleanup()
        rb.close()
        rb.unlink()
        sb.close()
        sb.unlink()


def __test_chart_protocol_currency_conversion__(log):
    """Chart protocol: currency_conversions multiplies read result by exchange rate"""
    import tempfile
    from pathlib import Path
    from pynecore.core.currency import CurrencyRateProvider
    from pynecore.core.ohlcv import OHLCVWriter
    from pynecore.types.ohlcv import OHLCV

    sec_ids = ["sec_cur"]
    sb = SyncBlock(sec_ids)
    rb = ResultBlock("sec_cur", create=True, version=0)

    state = _make_state(sec_id="sec_cur", timeframe="5", same_timeframe=True)
    states = {"sec_cur": state}

    # Set up currency conversion: EUR → USD at rate 1.085
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        ohlcv_path = tmpdir / "EURUSD.ohlcv"
        toml_path = tmpdir / "EURUSD.toml"

        # Write OHLCV with close=1.085. Only an already-closed rate bar is readable, so this
        # daily bar (timestamp in milliseconds) must end before the chart time set below.
        with OHLCVWriter(ohlcv_path, "1D", truncate=True) as writer:
            writer.write(OHLCV(1_000_000, 1.085, 1.09, 1.08, 1.085, 100.0))

        toml_path.write_text(
            '[symbol]\nprefix = "TEST"\ndescription = "EURUSD"\nticker = "EURUSD"\n'
            'currency = "USD"\nbasecurrency = "EUR"\nperiod = "1D"\ntype = "forex"\n'
            'mintick = 0.00001\npricescale = 100000\npointvalue = 1.0\ntimezone = "UTC"\n'
            '[[opening_hours]]\nday = 1\nstart = "00:00:00"\nend = "23:59:59"\n'
            '[[session_starts]]\nday = 1\ntime = "00:00:00"\n'
            '[[session_ends]]\nday = 1\ntime = "23:59:59"\n'
        )

        # Set up CurrencyRateProvider
        from pynecore.lib import request
        provider = CurrencyRateProvider({"fx": str(tmpdir / "EURUSD")})
        request._currency_provider = provider

        # Set lib._datetime so currency_rate can resolve timestamp — a day past the rate bar
        from pynecore import lib
        from datetime import datetime, timezone
        lib._datetime = datetime.fromtimestamp(200_000, timezone.utc)

        try:
            # Conversion: security result is in EUR, convert to USD
            currency_conversions = {"sec_cur": ("EUR", "USD")}

            signal_fn, write_fn, read_fn, wait_fn, cleanup, _ = create_chart_protocol(
                states, sb, currency_conversions=currency_conversions,
            )

            # Write a value in EUR
            write_result(rb, sb, 100.0)

            # Read should return 100.0 * 1.085 ≈ 108.5
            result = read_fn("sec_cur", default=None)
            assert abs(result - 108.5) < 0.5, f"Expected ~108.5, got {result}"

            # Test with tuple result
            write_result(rb, sb, (50.0, "label", 25.0))
            result = read_fn("sec_cur", default=None)
            assert isinstance(result, tuple)
            assert abs(result[0] - 54.25) < 0.5, f"Expected ~54.25, got {result[0]}"
            assert result[1] == "label"  # non-numeric untouched
            assert abs(result[2] - 27.125) < 0.5, f"Expected ~27.125, got {result[2]}"
        finally:
            cleanup()
            rb.close()
            rb.unlink()
            sb.close()
            sb.unlink()
            request._reset_request_state()


def __test_chart_protocol_currency_no_data__(log):
    """Chart protocol: currency conversion with no rate data returns unconverted result"""
    sec_ids = ["sec_nodata"]
    sb = SyncBlock(sec_ids)
    rb = ResultBlock("sec_nodata", create=True, version=0)

    state = _make_state(sec_id="sec_nodata", timeframe="5", same_timeframe=True)
    states = {"sec_nodata": state}

    # No CurrencyRateProvider set → currency_rate returns nan → no conversion
    from pynecore.lib import request
    request._currency_provider = None

    from pynecore import lib
    from datetime import datetime, timezone
    lib._datetime = datetime.fromtimestamp(1000, timezone.utc)

    try:
        currency_conversions = {"sec_nodata": ("EUR", "USD")}

        signal_fn, write_fn, read_fn, wait_fn, cleanup, _ = create_chart_protocol(
            states, sb, currency_conversions=currency_conversions,
        )

        write_result(rb, sb, 100.0)

        # No provider → rate is nan → result should stay unconverted
        result = read_fn("sec_nodata", default=None)
        assert result == 100.0, f"Expected 100.0 (unconverted), got {result}"
    finally:
        cleanup()
        rb.close()
        rb.unlink()
        sb.close()
        sb.unlink()
        request._reset_request_state()


def __test_log_suppressed_in_security_context__(log):
    """log.info/warning/error are suppressed when _lib_semaphore is True"""
    import logging
    from pynecore import lib
    from pynecore.lib import log as pine_log

    original = lib._lib_semaphore
    handler = logging.handlers = []

    # Capture console logger output
    captured = []
    test_handler = logging.Handler()
    test_handler.emit = lambda record: captured.append(record.msg)
    pine_log.logger.addHandler(test_handler)

    try:
        # Normal mode: log should appear
        lib._lib_semaphore = False
        pine_log.info("visible message")
        assert len(captured) == 1
        assert captured[0] == "visible message"

        # Security context: log should be suppressed
        lib._lib_semaphore = True
        pine_log.info("suppressed message")
        pine_log.warning("suppressed warning")
        pine_log.error("suppressed error")
        assert len(captured) == 1  # still only the first message
    finally:
        lib._lib_semaphore = original
        pine_log.logger.removeHandler(test_handler)


def __test_security_file_log__(log):
    """PYNE_SECURITY_LOG redirects security process logs to a file"""
    import logging
    import tempfile
    from pathlib import Path
    from pynecore import lib
    from pynecore.lib import log as pine_log
    from pynecore.lib.log import setup_security_file_log

    original_semaphore = lib._lib_semaphore
    original_security_logger = pine_log._security_logger

    with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f:
        log_path = f.name

    try:
        # Set up security file logging
        setup_security_file_log(log_path, "AAPL 1D")

        # Simulate security context
        lib._lib_semaphore = True

        # These should go to the file, not console
        pine_log.info("test info from security")
        pine_log.warning("test warning from security")
        pine_log.error("test error from security")

        # Flush handlers
        for h in pine_log._security_logger.handlers:
            h.flush()

        # Verify file content
        content = Path(log_path).read_text()
        lines = [l for l in content.strip().split('\n') if l]
        assert len(lines) == 3, f"Expected 3 lines, got {len(lines)}: {content}"

        # Check context label is in each line
        for line in lines:
            assert "[AAPL 1D]" in line, f"Missing context label in: {line}"

        # Check levels
        assert "INFO" in lines[0]
        assert "WARNING" in lines[1]
        assert "ERROR" in lines[2]

        # Check messages
        assert "test info from security" in lines[0]
        assert "test warning from security" in lines[1]
        assert "test error from security" in lines[2]
    finally:
        lib._lib_semaphore = original_semaphore
        pine_log._security_logger = original_security_logger
        Path(log_path).unlink(missing_ok=True)


def __test_setup_security_states_ltf__(log):
    """setup_security_states handles LTF context correctly"""
    contexts = {
        "sec_ltf": {
            "symbol": "AAPL",
            "timeframe": "1",
            "is_ltf": True,
        },
    }

    states, sync_block, result_blocks = setup_security_states(
        contexts, chart_timeframe="5", tz=ZoneInfo("UTC"),
    )

    try:
        s = states["sec_ltf"]
        assert s.is_ltf is True
        assert s.gaps_on is False
        assert s.same_timeframe is False
        assert s.resampler is None
        assert s.data_ready.is_set()
    finally:
        for rb in result_blocks.values():
            rb.close()
            rb.unlink()
        sync_block.close()
        sync_block.unlink()
