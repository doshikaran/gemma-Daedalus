"""
Tests for the live runner async/sync bridge.
"""
import asyncio
import threading
import time
from datetime import UTC, datetime, time as datetime_time, timedelta

from pynecore.core.live_runner import live_ohlcv_generator, LiveBarStreamer
from pynecore.core.script_runner import LIVE_TRANSITION
from pynecore.core.syminfo import SymInfo, SymInfoInterval
from pynecore.types.ohlcv import OHLCV


def _make_ohlcv(timestamp: int, close: float = 100.0, is_closed: bool = True) -> OHLCV:
    return OHLCV(timestamp=timestamp, open=close, high=close + 1,
                 low=close - 1, close=close, volume=1000.0, is_closed=is_closed)


def _drain(provider, *args, **kwargs) -> tuple[list[OHLCV], list[OHLCV]]:
    """Consume the live iterator and split out the pre/post LIVE_TRANSITION halves.

    Returns ``(catchup_bars, live_bars)`` — the warmup catch-up batch
    (empty in tests where the producer hasn't queued anything by the
    time the consumer hits its first ``get_nowait``) and everything
    yielded after the in-band transition sentinel. Tests typically only
    care about ``live_bars``; the split makes the boundary explicit.
    """
    catchup: list[OHLCV] = []
    live: list[OHLCV] = []
    seen_transition = False
    for item in live_ohlcv_generator(provider, *args, **kwargs):
        if item is LIVE_TRANSITION:
            seen_transition = True
            continue
        if seen_transition:
            live.append(item)
        else:
            catchup.append(item)
    return catchup, live


class MockLiveProvider:
    """Mock LiveProviderPlugin for testing the bridge."""

    def __init__(self, bar_updates: list[OHLCV]):
        self._bar_updates = bar_updates
        self._index = 0
        self._connected = False
        self.reconnect_delay = 0.01
        self.max_reconnect_delay = 0.05
        self.feed_timeout_bars = 3

    async def connect(self):
        self._connected = True

    async def disconnect(self):
        self._connected = False

    @property
    def is_connected(self):
        return self._connected

    async def watch_ohlcv(self, symbol: str, timeframe: str) -> OHLCV:
        if self._index >= len(self._bar_updates):
            raise asyncio.CancelledError()

        bar = self._bar_updates[self._index]
        self._index += 1
        await asyncio.sleep(0.001)
        return bar

    def normalize_symbol(self, symbol: str) -> str:
        return symbol

    async def on_disconnect(self):
        pass

    async def on_reconnect(self):
        pass

    async def can_shutdown(self):
        return True


def __test_live_generator_yields_all_bar_updates__():
    """live_ohlcv_generator yields both intra-bar and closed bar updates after the transition"""
    updates = [
        _make_ohlcv(1000, is_closed=False, close=100.0),
        _make_ohlcv(1000, is_closed=True, close=101.0),
        _make_ohlcv(2000, is_closed=False, close=102.0),
        _make_ohlcv(2000, is_closed=True, close=103.0),
    ]

    provider = MockLiveProvider(updates)
    _, bars = _drain(provider, "BTC/USDT", "1D")

    assert len(bars) == 4
    assert not bars[0].is_closed
    assert bars[0].close == 100.0
    assert bars[1].is_closed
    assert bars[1].close == 101.0
    assert not bars[2].is_closed
    assert bars[3].is_closed


def __test_live_generator_filters_old_bars__():
    """live_ohlcv_generator skips bars strictly older than last_historical_timestamp.

    A bar at exactly ``last_historical_timestamp`` MUST pass through —
    that's the close of the still-open last-warmup bar (e.g.
    Capital.com's REST history includes the currently-forming bar, and
    the WS push for its close has the same timestamp). The script_runner
    live loop recognises the same-timestamp first live update as a
    continuation of the last warmup bar.
    """
    updates = [
        _make_ohlcv(1000, is_closed=True, close=100.0),
        _make_ohlcv(2000, is_closed=True, close=200.0),
        _make_ohlcv(3000, is_closed=True, close=300.0),
    ]

    provider = MockLiveProvider(updates)
    _, bars = _drain(provider, "BTC/USDT", "1D",
                     last_historical_timestamp=2000)

    assert len(bars) == 2
    assert bars[0].timestamp == 2000
    assert bars[0].close == 200.0
    assert bars[1].timestamp == 3000
    assert bars[1].close == 300.0


def __test_live_generator_yields_ohlcv_objects__():
    """live_ohlcv_generator yields OHLCV objects directly"""
    updates = [
        _make_ohlcv(1000, is_closed=True),
    ]

    provider = MockLiveProvider(updates)
    _, bars = _drain(provider, "BTC/USDT", "1D")

    assert len(bars) == 1
    assert isinstance(bars[0], OHLCV)
    assert bars[0].is_closed is True


def __test_live_generator_connects_and_disconnects__():
    """live_ohlcv_generator calls connect on start and disconnect on finish"""
    updates = [
        _make_ohlcv(1000, is_closed=True),
    ]

    provider = MockLiveProvider(updates)
    list(live_ohlcv_generator(provider, "BTC/USDT", "1D"))

    assert not provider.is_connected


def __test_live_generator_empty_stream__():
    """live_ohlcv_generator emits LIVE_TRANSITION even for an empty stream"""
    provider = MockLiveProvider([])
    items = list(live_ohlcv_generator(provider, "BTC/USDT", "1D"))
    assert items == [LIVE_TRANSITION]


def __test_live_generator_emits_transition_sentinel__():
    """live_ohlcv_generator yields one LIVE_TRANSITION sentinel between catch-up and live."""
    updates = [_make_ohlcv(1000, is_closed=True), _make_ohlcv(2000, is_closed=True)]
    provider = MockLiveProvider(updates)

    items = list(live_ohlcv_generator(provider, "BTC/USDT", "1D"))
    transitions = [i for i, x in enumerate(items) if x is LIVE_TRANSITION]
    assert len(transitions) == 1, f"expected exactly one LIVE_TRANSITION, got {len(transitions)}"


class DelayedShutdownProvider(MockLiveProvider):
    """Provider that delays shutdown for a number of can_shutdown() calls."""

    def __init__(self, bar_updates: list[OHLCV], deny_count: int = 2):
        super().__init__(bar_updates)
        self._deny_count = deny_count
        self._shutdown_calls = 0

    async def can_shutdown(self):
        self._shutdown_calls += 1
        if self._shutdown_calls <= self._deny_count:
            return False
        return True


def __test_graceful_shutdown_waits_for_can_shutdown__():
    """Shutdown waits until can_shutdown() returns True"""
    updates = [_make_ohlcv(1000, is_closed=True)]
    provider = DelayedShutdownProvider(updates, deny_count=2)

    list(live_ohlcv_generator(provider, "BTC/USDT", "1D", shutdown_timeout=10.0))

    assert provider._shutdown_calls == 3
    assert not provider.is_connected


def __test_graceful_shutdown_timeout_forces_disconnect__():
    """Shutdown force-disconnects after timeout even if can_shutdown() returns False"""

    class NeverReadyProvider(MockLiveProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._shutdown_calls = 0

        async def can_shutdown(self):
            self._shutdown_calls += 1
            return False

    updates = [_make_ohlcv(1000, is_closed=True)]
    provider = NeverReadyProvider(updates)

    start = time.monotonic()
    list(live_ohlcv_generator(provider, "BTC/USDT", "1D", shutdown_timeout=2.0))
    elapsed = time.monotonic() - start

    assert provider._shutdown_calls >= 1
    assert elapsed < 5.0
    assert not provider.is_connected


def __test_graceful_shutdown_zero_timeout_waits_until_ready__():
    """shutdown_timeout=0 waits indefinitely until can_shutdown() returns True"""
    updates = [_make_ohlcv(1000, is_closed=True)]
    provider = DelayedShutdownProvider(updates, deny_count=3)

    list(live_ohlcv_generator(provider, "BTC/USDT", "1D", shutdown_timeout=0))

    assert provider._shutdown_calls == 4
    assert not provider.is_connected


# --- Reconnect behavior tests ---

class ReconnectTrackingProvider(MockLiveProvider):
    """Provider that records connect/disconnect call order and fails once."""

    def __init__(self, bar_updates: list[OHLCV], fail_at_index: int = 1):
        super().__init__(bar_updates)
        self._fail_at_index = fail_at_index
        self._failed = False
        self.call_log: list[str] = []

    async def connect(self):
        self.call_log.append('connect')
        self._connected = True

    async def disconnect(self):
        self.call_log.append('disconnect')
        self._connected = False

    async def watch_ohlcv(self, symbol: str, timeframe: str) -> OHLCV:
        if not self._failed and self._index == self._fail_at_index:
            self._failed = True
            raise ConnectionError("Simulated connection loss")
        return await super().watch_ohlcv(symbol, timeframe)


def __test_reconnect_calls_disconnect_before_connect__():
    """Reconnect path calls disconnect() before connect() to prevent resource leaks"""
    updates = [
        _make_ohlcv(1000, is_closed=True, close=100.0),
        _make_ohlcv(2000, is_closed=True, close=200.0),
        _make_ohlcv(3000, is_closed=True, close=300.0),
    ]

    provider = ReconnectTrackingProvider(updates, fail_at_index=1)
    _, bars = _drain(provider, "BTC/USDT", "1D")

    # Should have: connect, [fail], disconnect, connect, ..., disconnect (shutdown)
    assert provider.call_log[0] == 'connect'

    # Find the reconnect sequence: after the first connect, there should be
    # disconnect followed by connect before the final shutdown disconnect
    post_initial = provider.call_log[1:]
    assert 'disconnect' in post_initial
    disc_idx = post_initial.index('disconnect')
    assert disc_idx + 1 < len(post_initial)
    assert post_initial[disc_idx + 1] == 'connect'

    # Data should still come through after reconnect
    assert len(bars) >= 1


def __test_reconnect_retries_indefinitely_and_recovers__():
    """Reconnect has no attempt cap: an outage longer than any fixed limit
    is ridden out and the stream resumes once the provider recovers.

    A live bot must never give up on a network outage — the historical
    behaviour (raise after ``max_reconnect_attempts``, default 10) killed
    the run ~17 minutes into a router restart. 15 consecutive failures
    here is comfortably past that old cap, so passing proves the limit is
    gone, and the final real bar proves the stream survives the outage.
    """

    class FlakyProvider(MockLiveProvider):
        def __init__(self, fail_count: int):
            super().__init__([_make_ohlcv(1000, is_closed=True, close=100.0)])
            self.reconnect_delay = 0.001
            self.max_reconnect_delay = 0.002
            self.connect_calls = 0
            self._remaining_failures = fail_count

        async def connect(self):
            self.connect_calls += 1
            self._connected = True

        async def watch_ohlcv(self, symbol: str, timeframe: str) -> OHLCV:
            if self._remaining_failures > 0:
                self._remaining_failures -= 1
                raise ConnectionError("Simulated long outage")
            return await super().watch_ohlcv(symbol, timeframe)

    provider = FlakyProvider(fail_count=15)
    _, bars = _drain(provider, "BTC/USDT", "1D")

    assert len(bars) == 1
    assert bars[0].close == 100.0
    # Initial connect + one reconnect per failed watch call.
    assert provider.connect_calls >= 15


# --- Initial connect retry tests ---

class InitialConnectFlakyProvider(MockLiveProvider):
    """Provider whose first ``connect()`` calls fail with a transient error.

    Reproduces a startup socket/TLS reset — the raw ``ConnectionResetError``
    ([Errno 54]) that killed the live run before the handshake. The initial
    connect must ride it out on the backoff path and only then stream.
    """

    def __init__(self, bar_updates: list[OHLCV], fail_count: int,
                 exc: BaseException | None = None):
        super().__init__(bar_updates)
        self.reconnect_delay = 0.001
        self.max_reconnect_delay = 0.002
        self.connect_calls = 0
        self._remaining_failures = fail_count
        self._exc = exc or ConnectionResetError(54, "Connection reset by peer")

    async def connect(self):
        self.connect_calls += 1
        if self._remaining_failures > 0:
            self._remaining_failures -= 1
            raise self._exc
        self._connected = True


def __test_initial_connect_retries_transient_reset__():
    """A transient reset on the first connect is ridden out, not fatal.

    Before the fix, a ``ConnectionResetError`` out of the initial
    ``provider.connect()`` propagated raw and killed the run with a traceback
    and ``exit 1``. It must now be classified transient and retried on the
    startup backoff path so the stream survives and delivers its bars.
    """
    provider = InitialConnectFlakyProvider(
        [_make_ohlcv(1000, is_closed=True, close=100.0)], fail_count=3)
    _, bars = _drain(provider, "BTC/USDT", "1D")

    assert provider.connect_calls == 4  # 3 transient failures + 1 success
    assert len(bars) == 1
    assert bars[0].close == 100.0


def __test_initial_connect_permanent_error_fails_fast__():
    """A permanent (non-transient) initial connect error is not retried.

    A misconfiguration (bad symbol / credentials) surfaces as a plain
    ``ValueError`` here — not ``OSError``-derived and not a retryable
    ``ProviderError`` — so it must be raised on the first attempt instead of
    looping. With ``raise_on_connect_failure`` the real cause surfaces to the
    constructing caller.
    """
    import pytest

    provider = InitialConnectFlakyProvider(
        [_make_ohlcv(1000, is_closed=True, close=100.0)], fail_count=99,
        exc=ValueError("unknown symbol"))

    with pytest.raises(ValueError, match="unknown symbol"):
        list(live_ohlcv_generator(
            provider, "BTC/USDT", "1D", raise_on_connect_failure=True))

    assert provider.connect_calls == 1


def __test_initial_connect_uses_provider_timeout_and_cancels_stalled_attempt__():
    """A provider-specific startup bound cancels a connect that never returns."""
    import pytest

    class StalledProvider(MockLiveProvider):
        initial_connect_timeout = 0.05

        async def connect(self):
            await asyncio.Event().wait()

    provider = StalledProvider([])
    started = time.monotonic()

    with pytest.raises(
        TimeoutError,
        match="initial provider connection exceeded its timeout",
    ):
        list(
            live_ohlcv_generator(
                provider,
                "BTC/USDT",
                "1D",
                raise_on_connect_failure=True,
            )
        )

    assert time.monotonic() - started < 1.0
    assert not provider.is_connected


def __test_initial_connect_timeout_ignores_a_swallowed_cancellation__():
    """A connect that suppresses its cancellation is still a startup failure.

    The deadline is decided on "did ``connect()`` finish in time", not on how it
    reacted to the cancellation — otherwise a provider that catches the
    ``CancelledError`` and returns would be reported as connected long after the
    bound, and the broker would start trading against it.
    """
    import pytest

    class CancellationSwallowingProvider(MockLiveProvider):
        initial_connect_timeout = 0.05

        async def connect(self):
            try:
                await asyncio.Event().wait()
            except asyncio.CancelledError:
                pass

    provider = CancellationSwallowingProvider([])
    started = time.monotonic()

    with pytest.raises(
        TimeoutError,
        match="initial provider connection exceeded its timeout",
    ):
        list(
            live_ohlcv_generator(
                provider,
                "BTC/USDT",
                "1D",
                raise_on_connect_failure=True,
            )
        )

    assert time.monotonic() - started < 1.0
    assert not provider.is_connected


def __test_late_landing_connect_is_disconnected_after_teardown__():
    """A handshake that lands AFTER the deadline must not survive teardown.

    The cancellation sent to a timed-out ``connect()`` is best-effort, so a
    provider that swallows it can still open the connection once the startup
    failure has already been reported and ``disconnect()`` has run. On a
    caller-owned loop that task stays alive, so the runner chains a closing
    ``disconnect()`` onto it instead of leaving a live venue connection behind a
    failed startup.
    """
    import pytest

    second_disconnect = threading.Event()

    class LateConnectProvider(MockLiveProvider):
        initial_connect_timeout = 0.05

        def __init__(self, bar_updates):
            super().__init__(bar_updates)
            self.disconnect_calls = 0

        async def connect(self):
            try:
                await asyncio.Event().wait()
            except asyncio.CancelledError:
                # Swallow it and finish the handshake anyway — past the bound.
                self._connected = True

        async def disconnect(self):
            self.disconnect_calls += 1
            self._connected = False
            if self.disconnect_calls >= 2:
                second_disconnect.set()

    loop = asyncio.new_event_loop()
    loop_ready = threading.Event()

    def _drive_loop() -> None:
        asyncio.set_event_loop(loop)
        loop.call_soon(loop_ready.set)
        loop.run_forever()

    loop_thread = threading.Thread(target=_drive_loop, daemon=True)
    loop_thread.start()
    loop_ready.wait(timeout=2.0)

    provider = LateConnectProvider([])
    try:
        with pytest.raises(
            TimeoutError,
            match="initial provider connection exceeded its timeout",
        ):
            list(
                live_ohlcv_generator(
                    provider,
                    "BTC/USDT",
                    "1D",
                    event_loop=loop,
                    raise_on_connect_failure=True,
                )
            )

        assert second_disconnect.wait(timeout=2.0)
        assert not provider.is_connected
    finally:
        loop.call_soon_threadsafe(loop.stop)
        loop_thread.join(timeout=2.0)
        loop.close()


def __test_late_landing_connect_cleanup_completes_on_the_owned_loop__():
    """The closing ``disconnect()`` must finish before the runner's own loop dies.

    On the default ``event_loop=None`` path the producer thread runs
    ``asyncio.run``, which closes the loop right after its exit-time task sweep.
    A disconnect merely *scheduled* from a done-callback at that point is
    destroyed while pending — the venue connection would stay open behind a
    startup that reported failure — so teardown has to drive it to completion
    while the loop is still its own.
    """
    import pytest

    class LateConnectProvider(MockLiveProvider):
        initial_connect_timeout = 0.05

        def __init__(self, bar_updates):
            super().__init__(bar_updates)
            self.disconnect_completions = 0

        async def connect(self):
            try:
                await asyncio.Event().wait()
            except asyncio.CancelledError:
                # Swallow it and finish the handshake anyway — past the bound.
                self._connected = True

        async def disconnect(self):
            # A real close is a multi-step handshake (unsubscribe, close frame,
            # socket teardown); every step needs a loop that is still running.
            # ``asyncio.run``'s post-sweep phase only turns the loop a handful of
            # times, so a close scheduled that late cannot get through this.
            for _ in range(500):
                await asyncio.sleep(0)
            self._connected = False
            self.disconnect_completions += 1

    provider = LateConnectProvider([])

    with pytest.raises(
        TimeoutError,
        match="initial provider connection exceeded its timeout",
    ):
        list(
            live_ohlcv_generator(
                provider,
                "BTC/USDT",
                "1D",
                raise_on_connect_failure=True,
            )
        )

    assert provider.disconnect_completions == 2
    assert not provider.is_connected


def __test_late_landing_connect_closes_itself_past_the_grace_window__():
    """A handshake landing after teardown's window must still close itself.

    Teardown can only hold the provider loop open for a bounded window — a
    handshake that never finishes must not hold the shutdown. What lands after
    that window used to be left to a done-callback, which on the
    ``event_loop=None`` path fires while ``asyncio.run`` is already tearing the
    loop down: the disconnect it schedules is not part of the exit-time task
    sweep, so it is destroyed while pending and the venue connection survives a
    startup that reported failure. Carrying the closing ``disconnect()`` inside
    the connect task instead makes it part of what that sweep already awaits.
    """
    import pytest
    from pynecore.core import live_runner as _live_runner_mod

    closed_after_landing = threading.Event()

    class _SlowLateConnectProvider(MockLiveProvider):
        initial_connect_timeout = 0.05

        async def connect(self):
            # Swallow every cancellation and finish the handshake anyway, well
            # past the window teardown is willing to wait for it.
            deadline = time.monotonic() + 0.5
            while time.monotonic() < deadline:
                try:
                    await asyncio.sleep(0.5)
                except asyncio.CancelledError:
                    continue
            self._connected = True

        async def disconnect(self):
            # A real close is a multi-step handshake (unsubscribe, close frame,
            # socket teardown); every step needs a loop that is still turning.
            for _ in range(500):
                await asyncio.sleep(0)
            if self._connected:
                # Only the close that follows the LATE landing has anything to
                # do — teardown's own disconnect ran before the handshake
                # completed, on a provider that was not connected yet.
                self._connected = False
                closed_after_landing.set()

    provider = _SlowLateConnectProvider([])
    _orig_grace = _live_runner_mod._LATE_CONNECT_GRACE_S
    # Shorter than the handshake, so the landing is guaranteed to fall OUTSIDE
    # the window teardown waits out inline.
    _live_runner_mod._LATE_CONNECT_GRACE_S = 0.05
    try:
        with pytest.raises(
            TimeoutError,
            match="initial provider connection exceeded its timeout",
        ):
            list(
                live_ohlcv_generator(
                    provider,
                    "BTC/USDT",
                    "1D",
                    raise_on_connect_failure=True,
                )
            )

        assert closed_after_landing.wait(timeout=5.0), \
            "late handshake stayed connected past teardown"
        assert not provider.is_connected
    finally:
        _live_runner_mod._LATE_CONNECT_GRACE_S = _orig_grace


def __test_uncancelling_late_connect_is_still_closed__():
    """A handshake that ``uncancel()``s itself is still an abandoned one.

    Suppressing a ``CancelledError`` and then calling
    :meth:`asyncio.Task.uncancel` is the documented way for a coroutine to adopt
    a cancellation — and it zeroes the ``Task.cancelling()`` counter. Reading
    abandonment off that counter therefore let such a handshake pass for an
    ordinary success: no closing ``disconnect()`` ran and the venue connection
    outlived a startup that had already reported failure. The runner marks the
    handshake abandoned itself, before it cancels, so ``uncancel()`` cannot
    erase the decision.
    """
    import pytest
    from pynecore.core import live_runner as _live_runner_mod

    closed_after_landing = threading.Event()

    class _UncancellingConnectProvider(MockLiveProvider):
        initial_connect_timeout = 0.05

        @staticmethod
        def _adopt_cancellation() -> None:
            task = asyncio.current_task()
            if task is not None:
                task.uncancel()

        async def connect(self):
            # Land well past the window teardown waits out inline, so the
            # provider's own disconnect() has definitely already run against a
            # not-yet-connected provider by the time the handshake completes.
            deadline = time.monotonic() + 0.3
            while time.monotonic() < deadline:
                try:
                    await asyncio.sleep(0.3)
                except asyncio.CancelledError:
                    self._adopt_cancellation()
            self._connected = True

        async def disconnect(self):
            if self._connected:
                self._connected = False
                closed_after_landing.set()

    provider = _UncancellingConnectProvider([])
    _orig_grace = _live_runner_mod._LATE_CONNECT_GRACE_S
    _live_runner_mod._LATE_CONNECT_GRACE_S = 0.05
    try:
        with pytest.raises(
            TimeoutError,
            match="initial provider connection exceeded its timeout",
        ):
            list(
                live_ohlcv_generator(
                    provider,
                    "BTC/USDT",
                    "1D",
                    raise_on_connect_failure=True,
                )
            )

        assert closed_after_landing.wait(timeout=5.0), \
            "handshake that uncancelled itself kept its connection open"
        assert not provider.is_connected
    finally:
        _live_runner_mod._LATE_CONNECT_GRACE_S = _orig_grace


def __test_wedged_hook_does_not_hold_the_provider_thread__():
    """A hook that never stops suppressing its cancel must not pin teardown.

    Detaching the hook lets ``_graceful_shutdown`` run, but it does not end the
    provider thread: the owned loop's exit sweep used to gather every leftover
    task without a deadline, so the wedged hook kept the thread alive — and with
    ``shutdown_timeout=0`` ("wait forever") the consumer's join has no bound of
    its own, so ``close()`` never returned. The sweep is bounded now: the loop
    closes without the hook and the thread ends.
    """
    from pynecore.core import live_runner as _live_runner_mod

    class _WedgedReconnectProvider(MockLiveProvider):
        def __init__(self):
            super().__init__([])
            self.reconnect_entered = threading.Event()
            self._connect_calls = 0

        async def connect(self):
            self._connect_calls += 1
            if self._connect_calls == 1:
                self._connected = True
                return
            self.reconnect_entered.set()
            # Never finishes, and never lets a cancellation through.
            while True:
                try:
                    await asyncio.sleep(0.05)
                except asyncio.CancelledError:
                    continue

        async def watch_ohlcv(self, symbol: str, timeframe: str) -> OHLCV:
            self._connected = False
            raise ConnectionError("feed dropped")

    provider = _WedgedReconnectProvider()
    _orig_hook_grace = _live_runner_mod._HOOK_CANCEL_GRACE_S
    _orig_late_grace = _live_runner_mod._LATE_CONNECT_GRACE_S
    _orig_sweep_grace = _live_runner_mod._LOOP_SWEEP_GRACE_S
    _live_runner_mod._HOOK_CANCEL_GRACE_S = 0.05
    _live_runner_mod._LATE_CONNECT_GRACE_S = 0.05
    _live_runner_mod._LOOP_SWEEP_GRACE_S = 0.05
    try:
        before = {t.ident for t in threading.enumerate()}
        # ``shutdown_timeout=0`` = wait forever: the join below has no bound, so
        # only a thread that really ends can let ``close()`` return.
        gen = live_ohlcv_generator(
            provider, "BTC/USDT", "1D", shutdown_timeout=0,
        )
        producer = next(
            t for t in threading.enumerate()
            if t.name == "live-provider" and t.ident not in before
        )
        it = iter(gen)
        next(it)  # LIVE_TRANSITION — the first connect() succeeded

        assert provider.reconnect_entered.wait(timeout=5.0), \
            "runner never reached the wedged reconnect"

        # Closing on another thread so a regression fails the test instead of
        # hanging it: the pre-fix behaviour blocks here forever.
        closed = threading.Event()

        def _close_generator() -> None:
            gen.close()
            closed.set()

        closer = threading.Thread(target=_close_generator, daemon=True)
        closer.start()
        assert closed.wait(timeout=10.0), \
            "shutdown hung on a hook that never stops suppressing its cancel"

        producer.join(timeout=2.0)
        assert not producer.is_alive(), "provider thread outlived the shutdown"
    finally:
        _live_runner_mod._HOOK_CANCEL_GRACE_S = _orig_hook_grace
        _live_runner_mod._LATE_CONNECT_GRACE_S = _orig_late_grace
        _live_runner_mod._LOOP_SWEEP_GRACE_S = _orig_sweep_grace


def __test_blocking_hook_in_executor_does_not_hold_the_provider_thread__():
    """A hook's blocking SDK call must not pin teardown from the executor.

    Cancelling a hook that ran its blocking call through ``asyncio.to_thread``
    ends the TASK at once but not the executor WORKER, so the bounded task sweep
    sees nothing pending — and the loop wind-down that follows used to JOIN that
    worker without a deadline, keeping the provider thread (and with
    ``shutdown_timeout=0`` the consumer's join) alive for as long as the SDK call
    ran. Neither wind-down step can outlast its window now.
    """
    from pynecore.core import live_runner as _live_runner_mod

    class _ExecutorWedgedProvider(MockLiveProvider):
        def __init__(self):
            super().__init__([])
            self.reconnect_entered = threading.Event()
            self.release = threading.Event()
            self._connect_calls = 0

        async def connect(self):
            self._connect_calls += 1
            if self._connect_calls == 1:
                self._connected = True
                return
            self.reconnect_entered.set()
            # Blocking SDK call parked in the loop's default executor: the
            # cancellation below reaches the task, never this worker.
            await asyncio.to_thread(self.release.wait)

        async def watch_ohlcv(self, symbol: str, timeframe: str) -> OHLCV:
            self._connected = False
            raise ConnectionError("feed dropped")

    provider = _ExecutorWedgedProvider()
    _orig_hook_grace = _live_runner_mod._HOOK_CANCEL_GRACE_S
    _orig_late_grace = _live_runner_mod._LATE_CONNECT_GRACE_S
    _orig_sweep_grace = _live_runner_mod._LOOP_SWEEP_GRACE_S
    _live_runner_mod._HOOK_CANCEL_GRACE_S = 0.05
    _live_runner_mod._LATE_CONNECT_GRACE_S = 0.05
    _live_runner_mod._LOOP_SWEEP_GRACE_S = 0.05
    try:
        before = {t.ident for t in threading.enumerate()}
        # ``shutdown_timeout=0`` = wait forever: nothing but a thread that really
        # ends can let ``close()`` return.
        gen = live_ohlcv_generator(
            provider, "BTC/USDT", "1D", shutdown_timeout=0,
        )
        producer = next(
            t for t in threading.enumerate()
            if t.name == "live-provider" and t.ident not in before
        )
        it = iter(gen)
        next(it)  # LIVE_TRANSITION — the first connect() succeeded

        assert provider.reconnect_entered.wait(timeout=5.0), \
            "runner never reached the blocking reconnect"

        # Closing on another thread so a regression fails the test instead of
        # hanging it: the pre-fix behaviour blocks here until the worker returns.
        closed = threading.Event()

        def _close_generator() -> None:
            gen.close()
            closed.set()

        closer = threading.Thread(target=_close_generator, daemon=True)
        closer.start()
        assert closed.wait(timeout=10.0), \
            "shutdown hung on a blocking hook parked in the default executor"

        producer.join(timeout=2.0)
        assert not producer.is_alive(), "provider thread outlived the shutdown"
    finally:
        # Let the executor worker go: it is NOT a daemon thread, so leaving it
        # blocked would wedge interpreter exit rather than just this test.
        provider.release.set()
        _live_runner_mod._HOOK_CANCEL_GRACE_S = _orig_hook_grace
        _live_runner_mod._LATE_CONNECT_GRACE_S = _orig_late_grace
        _live_runner_mod._LOOP_SWEEP_GRACE_S = _orig_sweep_grace


def __test_startup_failure_does_not_wait_for_the_shutdown_budget__():
    """A ``connect()`` that never stops cancelling must not hold up startup.

    Such a task keeps the producer thread's loop alive forever, so the reap on
    the failure path is bounded by the startup window — not by
    ``shutdown_timeout``, whose "0 = wait forever" setting would otherwise hang
    the caller instead of handing it the real connect error.
    """
    import pytest

    class NeverStoppingProvider(MockLiveProvider):
        initial_connect_timeout = 0.05

        async def connect(self):
            while True:
                try:
                    await asyncio.Event().wait()
                except asyncio.CancelledError:
                    continue

    provider = NeverStoppingProvider([])
    started = time.monotonic()

    with pytest.raises(
        TimeoutError,
        match="initial provider connection exceeded its timeout",
    ):
        list(
            live_ohlcv_generator(
                provider,
                "BTC/USDT",
                "1D",
                shutdown_timeout=0.0,  # "wait forever" for a real shutdown
                raise_on_connect_failure=True,
            )
        )

    assert time.monotonic() - started < 3.0


# --- Queue overflow tests ---

class FloodProvider(MockLiveProvider):
    """Provider that generates a burst of intra-bar updates, then closed bars."""

    def __init__(self, intra_bar_count: int, closed_bars: list[OHLCV]):
        all_updates: list[OHLCV] = []
        # Generate many intra-bar updates (same timestamp, is_closed=False)
        for i in range(intra_bar_count):
            all_updates.append(_make_ohlcv(1000, is_closed=False, close=100.0 + i * 0.01))
        # Then the actual closed bars
        all_updates.extend(closed_bars)
        super().__init__(all_updates)


def __test_queue_overflow_preserves_closed_bars__():
    """When queue is full, intra-bar updates may be dropped but closed bars are never lost"""
    closed_bars = [
        _make_ohlcv(1000, is_closed=True, close=150.0),
        _make_ohlcv(2000, is_closed=True, close=250.0),
    ]

    # 200 intra-bar updates will overflow the 100-item queue
    provider = FloodProvider(intra_bar_count=200, closed_bars=closed_bars)
    _, bars = _drain(provider, "BTC/USDT", "1D")

    # All closed bars must be present
    closed_received = [b for b in bars if b.is_closed]
    assert len(closed_received) == 2
    assert closed_received[0].close == 150.0
    assert closed_received[1].close == 250.0


# --- normalize_symbol tests ---

class NormalizingProvider(MockLiveProvider):
    """Provider that tracks which symbol was passed to watch_ohlcv."""

    def __init__(self, bar_updates: list[OHLCV]):
        super().__init__(bar_updates)
        self.received_symbols: list[str] = []

    def normalize_symbol(self, symbol: str) -> str:
        # Strip "exchange:" prefix
        if ':' in symbol:
            return symbol.split(':', 1)[1]
        return symbol

    async def watch_ohlcv(self, symbol: str, timeframe: str) -> OHLCV:
        self.received_symbols.append(symbol)
        return await super().watch_ohlcv(symbol, timeframe)


def __test_normalize_symbol_applied_to_watch_ohlcv__():
    """Framework calls normalize_symbol() before passing symbol to watch_ohlcv"""
    updates = [_make_ohlcv(1000, is_closed=True)]
    provider = NormalizingProvider(updates)

    list(live_ohlcv_generator(provider, "binance:BTC/USDT", "1D"))

    assert all(s == "BTC/USDT" for s in provider.received_symbols)


# --- Idle-bar synthesis (boundary watchdog) tests ---

class _IdleAfterFirstBar(MockLiveProvider):
    """Sends pre-canned bars then blocks indefinitely.

    Used to drive the boundary watchdog: once the queue is exhausted,
    ``watch_ohlcv`` never returns, so the only way a bar lands in
    ``bar_queue`` afterwards is via the framework's idle-bar synthesis.
    """

    async def watch_ohlcv(self, symbol: str, timeframe: str) -> OHLCV:
        if self._index < len(self._bar_updates):
            bar = self._bar_updates[self._index]
            self._index += 1
            await asyncio.sleep(0.001)
            return bar
        # Block until the consumer cancels the loop. ``stop_event`` set
        # by the generator's finally tears the thread down via the outer
        # CancelledError path, so we don't need to react to it here.
        await asyncio.sleep(60)
        raise asyncio.CancelledError()


def __test_live_generator_synthesises_idle_bars_at_tf_boundary__():
    """The framework fills idle TF intervals with zero-volume CLOSED bars.

    Capital.com's WS only emits ``ohlc.event`` for bars that contained
    at least one tick — idle minutes produce no event, freezing
    ``bar_index`` while REST history later returns those zero-volume
    bars. The framework's boundary watchdog synthesises one filler per
    missed TF interval (O=H=L=C=last close, V=0) so live and replay
    step in lockstep.

    Setup: real bar with a stale timestamp (200 s ago, more than two
    1-minute TF intervals + grace) — the watchdog therefore fires on
    the very first iteration and immediately catches up.
    """
    base_ts = (int(time.time()) - 200) * 1000
    updates = [_make_ohlcv(base_ts, is_closed=True, close=100.0)]
    provider = _IdleAfterFirstBar(updates)

    bars: list[OHLCV] = []
    seen_transition = False
    for item in live_ohlcv_generator(provider, "BTC/USDT", "1"):
        if item is LIVE_TRANSITION:
            seen_transition = True
            continue
        if not seen_transition:
            continue
        bars.append(item)
        if len(bars) >= 3:
            break

    assert bars[0].timestamp == base_ts
    assert bars[0].volume == 1000.0  # real bar, untouched

    # Subsequent bars are synth fillers. The watchdog advances the
    # baseline by one TF per emission; each filler carries the previous
    # close as O=H=L=C and zero volume.
    for i in range(1, 3):
        assert bars[i].timestamp == base_ts + 60_000 * i, (
            f"synth bar {i} timestamp {bars[i].timestamp} "
            f"!= expected {base_ts + 60_000 * i}"
        )
        assert bars[i].open == 100.0
        assert bars[i].high == 100.0
        assert bars[i].low == 100.0
        assert bars[i].close == 100.0
        assert bars[i].volume == 0.0
        assert bars[i].is_closed


class _LateBarAfterIdle(MockLiveProvider):
    """Sends one bar, blocks long enough for the watchdog to synth, then sends a bar with the same boundary timestamp."""

    def __init__(self, bar_updates: list[OHLCV], block_seconds: float = 0.3):
        super().__init__(bar_updates)
        self._block_seconds = block_seconds
        self._blocked = False

    async def watch_ohlcv(self, symbol: str, timeframe: str) -> OHLCV:
        if self._index == 1 and not self._blocked:
            # Stall once between bar 0 and bar 1 — long enough for the
            # watchdog to synth a filler at the next boundary.
            self._blocked = True
            await asyncio.sleep(self._block_seconds)
        return await super().watch_ohlcv(symbol, timeframe)


def __test_live_generator_drops_late_real_bar_for_already_synthesised_boundary__():
    """A late real ``ohlc.event`` for an already-synthesised slot is dropped.

    Without dedup the consumer would see two CLOSED bars on the same TF
    boundary — the synth (already published, possibly already executed
    against the script) and the late real bar with conflicting OHLCV.
    Drop the real one: the synth's flat values are now the authoritative
    live record for that minute.
    """
    base_ts = (int(time.time()) - 200) * 1000
    updates = [
        _make_ohlcv(base_ts, is_closed=True, close=100.0),
        # Late real bar arrives one TF later — same boundary the
        # watchdog will synthesise while we sleep below.
        _make_ohlcv(base_ts + 60_000, is_closed=True, close=999.0),
    ]
    provider = _LateBarAfterIdle(updates, block_seconds=0.3)

    bars: list[OHLCV] = []
    seen_transition = False
    for item in live_ohlcv_generator(provider, "BTC/USDT", "1"):
        if item is LIVE_TRANSITION:
            seen_transition = True
            continue
        if not seen_transition:
            continue
        bars.append(item)
        if len(bars) >= 2:
            break

    assert bars[0].timestamp == base_ts
    assert bars[0].close == 100.0
    # Second bar must be the synth (V=0, close=100), NOT the late real
    # bar with close=999. The late one was dropped by the dedup.
    assert bars[1].timestamp == base_ts + 60_000
    assert bars[1].volume == 0.0
    assert bars[1].close == 100.0


# --- Connection error from listener death tests ---

class ListenerDeathProvider(MockLiveProvider):
    """Provider that simulates WebSocket listener dying mid-stream."""

    def __init__(self, bar_updates: list[OHLCV], die_at_index: int = 2):
        super().__init__(bar_updates)
        self._die_at_index = die_at_index
        self._died = False
        self._reconnected = False

    async def watch_ohlcv(self, symbol: str, timeframe: str) -> OHLCV:
        if not self._died and self._index == self._die_at_index:
            self._died = True
            raise ConnectionError("WebSocket listener disconnected")
        if self._died and not self._reconnected:
            self._reconnected = True
        return await super().watch_ohlcv(symbol, timeframe)


def __test_connection_error_triggers_reconnect__():
    """ConnectionError from watch_ohlcv triggers reconnect and resumes streaming"""
    updates = [
        _make_ohlcv(1000, is_closed=True, close=100.0),
        _make_ohlcv(2000, is_closed=True, close=200.0),
        _make_ohlcv(3000, is_closed=True, close=300.0),
        _make_ohlcv(4000, is_closed=True, close=400.0),
    ]

    provider = ListenerDeathProvider(updates, die_at_index=2)
    _, bars = _drain(provider, "BTC/USDT", "1D")

    # Should get bars from before and after the simulated death
    assert len(bars) >= 2
    assert provider._reconnected


class _ReconnectHookFailureProvider(MockLiveProvider):
    """Fails the first reconnect hook while keeping the connection marked live."""

    def __init__(self):
        super().__init__([_make_ohlcv(1_000, is_closed=True)])
        self.reconnect_delay = 0.0
        self.max_reconnect_delay = 0.0
        self.connect_calls = 0
        self.reconnect_calls = 0
        self.watch_calls = 0
        self.watch_before_success = False
        self.reconnect_succeeded = False

    async def connect(self):
        self.connect_calls += 1
        self._connected = True

    async def on_reconnect(self):
        self.reconnect_calls += 1
        if self.reconnect_calls == 1:
            raise ConnectionError("history handshake incomplete")
        self.reconnect_succeeded = True

    async def watch_ohlcv(self, symbol: str, timeframe: str) -> OHLCV:
        self.watch_calls += 1
        if self.watch_calls == 1:
            raise ConnectionError("feed dropped")
        if not self.reconnect_succeeded:
            self.watch_before_success = True
            raise AssertionError("watch resumed before reconnect handshake")
        return await super().watch_ohlcv(symbol, timeframe)


def __test_reconnect_hook_failure_forces_fresh_connection_before_watch__():
    """A failed reconnect hook invalidates that connection before streaming resumes."""
    provider = _ReconnectHookFailureProvider()

    _, bars = _drain(provider, "BTC/USDT", "1D")

    assert [bar.timestamp for bar in bars] == [1_000]
    assert provider.connect_calls == 3
    assert provider.reconnect_calls == 2
    assert not provider.watch_before_success


# --- Session-gate tests ---

def _make_syminfo(opening_hours, timezone: str = "UTC"):
    """Build a minimal SymInfo with the given opening_hours + timezone.

    Only the fields read by ``live_ohlcv_generator``'s session gate are
    populated meaningfully; the rest get throw-away values.
    """
    return SymInfo(
        prefix="TEST",
        description="test",
        ticker="TEST",
        currency="USD",
        period="1",
        type="forex",
        mintick=0.0001,
        pricescale=10000,
        minmove=1,
        pointvalue=1.0,
        mincontract=1.0,
        opening_hours=opening_hours,
        session_starts=[],
        session_ends=[],
        timezone=timezone,
    )


class _ReconnectHookSessionBoundaryProvider(_ReconnectHookFailureProvider):
    """Moves through close and reopen after the first reconnect hook fails."""

    def __init__(
        self,
        syminfo: SymInfo,
        closed_hours: list[SymInfoInterval],
        open_hours: list[SymInfoInterval],
    ):
        super().__init__()
        self.syminfo = syminfo
        self.closed_hours = list(closed_hours)
        self.open_hours = list(open_hours)
        self.reopen_fired = False
        self.reconnect_before_reopen = False

    def _reopen(self, _timer_arg: object | None = None) -> None:
        self.syminfo.opening_hours[:] = self.open_hours
        self.reopen_fired = True

    async def on_reconnect(self):
        self.reconnect_calls += 1
        if self.reconnect_calls == 1:
            self.syminfo.opening_hours[:] = self.closed_hours
            asyncio.get_running_loop().call_later(0.005, self._reopen, None)
            raise ConnectionError("history handshake incomplete at session close")
        if not self.reopen_fired:
            self.reconnect_before_reopen = True
        self.reconnect_succeeded = True


def __test_failed_reconnect_generation_survives_neither_close_nor_reopen__():
    """A failed handshake remains quarantined across a close→reopen boundary."""
    open_hours = [
        SymInfoInterval(
            day=day,
            start=datetime_time(0, 0),
            end=datetime_time(23, 59, 59),
        )
        for day in range(7)
    ]
    now = datetime.now(UTC)
    closed_start = now + timedelta(hours=12)
    closed_end = closed_start + timedelta(minutes=5)
    closed_hours = [
        SymInfoInterval(
            day=day,
            start=closed_start.time().replace(tzinfo=None),
            end=closed_end.time().replace(tzinfo=None),
        )
        for day in range(7)
    ]
    syminfo = _make_syminfo(open_hours, timezone="UTC")
    provider = _ReconnectHookSessionBoundaryProvider(
        syminfo,
        closed_hours,
        open_hours,
    )

    from pynecore.core import live_runner as _live_runner_mod
    original_closed_wait = _live_runner_mod._CLOSED_WINDOW_SLEEP_S
    _live_runner_mod._CLOSED_WINDOW_SLEEP_S = 0.01
    try:
        _, bars = _drain(provider, "TEST", "1D", syminfo=syminfo)
    finally:
        _live_runner_mod._CLOSED_WINDOW_SLEEP_S = original_closed_wait

    assert [bar.timestamp for bar in bars] == [1_000]
    assert provider.reopen_fired
    assert provider.connect_calls == 3
    assert provider.reconnect_calls == 2
    assert not provider.reconnect_before_reopen
    assert not provider.watch_before_success


class _IdleThenCancelProvider(MockLiveProvider):
    """Yields pre-canned bars, then raises CancelledError after a fixed
    number of idle ``watch_ohlcv`` calls.

    The framework's ``wait_for`` cancels any in-flight ``asyncio.sleep``
    when its timeout elapses, so a sleep-then-raise pattern never gets
    to the raise statement — counting idle invocations works regardless.
    Each idle call lives only as long as the framework's ``effective_timeout``
    (down to 0.05 s once the synth deadline is in the past), so the test
    completes within ``max_idle_calls × 0.05 s`` wall time.
    """

    def __init__(self, bar_updates: list[OHLCV], max_idle_calls: int = 30):
        super().__init__(bar_updates)
        self._idle_calls = 0
        self._max_idle_calls = max_idle_calls

    async def watch_ohlcv(self, symbol: str, timeframe: str) -> OHLCV:
        if self._index < len(self._bar_updates):
            bar = self._bar_updates[self._index]
            self._index += 1
            await asyncio.sleep(0.001)
            return bar
        self._idle_calls += 1
        if self._idle_calls >= self._max_idle_calls:
            raise asyncio.CancelledError()
        # Park until ``wait_for`` cancels us so the framework synth deadline
        # (boundary_remaining < 0 → effective_timeout=0.05 s) can elapse
        # and the gate is actually exercised every iteration.
        await asyncio.sleep(10.0)
        raise asyncio.CancelledError()


def __test_synth_gate_suppresses_synth_during_known_closed_window__():
    """When syminfo.opening_hours says market closed, no idle synth is emitted.

    Setup: a SymInfo with a single 5-minute weekday interval anchored
    12 hours away from ``synth_ts`` (one timeframe past ``base_ts``).
    Pinning the open interval to ``synth_ts``'s opposite half-day keeps
    the test deterministic regardless of wall-clock time, while still
    exercising the closed-window gate for the slot the watchdog tries
    to synth. The synth deadline elapses (real bar 200s in the past on
    1m TF) but the gate intercepts before any V=0 OHLCV lands in queue.
    """
    base_ts = (int(time.time()) - 200) * 1000
    synth_ts = base_ts + 60_000
    synth_dt = datetime.fromtimestamp(synth_ts / 1000, tz=UTC)
    open_dt = synth_dt + timedelta(hours=12)
    open_time = datetime_time(open_dt.hour, open_dt.minute, 0)
    close_dt = open_dt + timedelta(minutes=5)
    close_time = datetime_time(close_dt.hour, close_dt.minute, 0)
    closed_calendar = [
        SymInfoInterval(day=d, start=open_time, end=close_time)
        for d in range(7)
    ]
    syminfo = _make_syminfo(closed_calendar, timezone="UTC")

    updates = [_make_ohlcv(base_ts, is_closed=True, close=100.0)]
    provider = _IdleThenCancelProvider(updates, max_idle_calls=20)

    # Shrink the closed-window sleep so the test does not spend the full
    # 30s production cadence per gated timeout. With ``max_idle_calls=20``
    # the unpatched value would block the suite for ~10 minutes per run.
    from pynecore.core import live_runner as _live_runner_mod
    _orig_sleep = _live_runner_mod._CLOSED_WINDOW_SLEEP_S
    _live_runner_mod._CLOSED_WINDOW_SLEEP_S = 0.05
    try:
        _, bars = _drain(provider, "TEST", "1", syminfo=syminfo)
    finally:
        _live_runner_mod._CLOSED_WINDOW_SLEEP_S = _orig_sleep

    # Only the real bar (volume=1000) was emitted. No V=0 synth filler.
    real_bars = [b for b in bars if b.volume > 0]
    synth_bars = [b for b in bars if b.volume == 0.0]
    assert len(real_bars) == 1
    assert real_bars[0].timestamp == base_ts
    assert synth_bars == [], (
        f"expected no synth bars during closed window, got {len(synth_bars)}"
    )


def __test_synth_gate_passthrough_when_opening_hours_empty__():
    """Empty syminfo.opening_hours preserves legacy 24/7 synth behaviour.

    Mirrors __test_live_generator_synthesises_idle_bars_at_tf_boundary__
    but with an explicit empty-calendar SymInfo to verify the gate does
    NOT short-circuit when there is no calendar data.
    """
    syminfo = _make_syminfo([], timezone="UTC")

    base_ts = (int(time.time()) - 200) * 1000
    updates = [_make_ohlcv(base_ts, is_closed=True, close=100.0)]
    provider = _IdleAfterFirstBar(updates)

    bars: list[OHLCV] = []
    seen_transition = False
    for item in live_ohlcv_generator(provider, "TEST", "1", syminfo=syminfo):
        if item is LIVE_TRANSITION:
            seen_transition = True
            continue
        if not seen_transition:
            continue
        bars.append(item)
        if len(bars) >= 3:
            break

    # First bar real, next two are V=0 synth fillers (no gate suppression).
    assert bars[0].volume == 1000.0
    assert bars[1].volume == 0.0
    assert bars[2].volume == 0.0
    assert bars[1].timestamp == base_ts + 60_000
    assert bars[2].timestamp == base_ts + 120_000


# --- Feed-liveness watchdog tests ---

class _SilentFeedProvider(MockLiveProvider):
    """Connected-looking provider whose feed goes silent after its bars.

    ``watch_ohlcv`` serves the pre-canned bars, then parks forever (each
    park is cancelled by the framework's ``wait_for`` timeout).
    ``is_connected`` stays True throughout, so only the feed-liveness
    watchdog can drive a reconnect — the dead-subscription / half-open-
    socket failure mode. Ends the run by raising ``CancelledError`` once
    ``connect()`` was called ``stop_after_connects`` times, or after
    ``max_idle_calls`` silent ``watch_ohlcv`` invocations.
    """

    def __init__(self, bar_updates: list[OHLCV], *,
                 stop_after_connects: int | None = None,
                 max_idle_calls: int | None = None):
        super().__init__(bar_updates)
        self.connect_calls = 0
        self._stop_after_connects = stop_after_connects
        self._idle_calls = 0
        self._max_idle_calls = max_idle_calls

    async def connect(self):
        self.connect_calls += 1
        self._connected = True

    async def watch_ohlcv(self, symbol: str, timeframe: str) -> OHLCV:
        if (self._stop_after_connects is not None
                and self.connect_calls >= self._stop_after_connects):
            raise asyncio.CancelledError()
        if self._index < len(self._bar_updates):
            bar = self._bar_updates[self._index]
            self._index += 1
            await asyncio.sleep(0.001)
            return bar
        self._idle_calls += 1
        if (self._max_idle_calls is not None
                and self._idle_calls >= self._max_idle_calls):
            raise asyncio.CancelledError()
        await asyncio.sleep(10.0)
        raise asyncio.CancelledError()


def __test_feed_staleness_watchdog_forces_reconnect__():
    """A connected-but-silent feed is reconnected during an open session.

    The failure mode this guards: the transport looks healthy
    (``is_connected`` True) but the server-side subscription is gone or
    the socket is half-open, so ``watch_ohlcv`` never returns and idle-bar
    synthesis would otherwise run the strategy on a frozen price forever.
    With ``feed_timeout_bars=1`` on a 1-second timeframe (staleness floor
    shrunk for test speed) the threshold is ~1 s, so the watchdog must
    drive ``connect()`` again within the test's few-second budget without
    the provider ever raising a ConnectionError.
    """
    base_ts = (int(time.time()) - 30) * 1000
    updates = [_make_ohlcv(base_ts, is_closed=True, close=100.0)]
    provider = _SilentFeedProvider(updates, stop_after_connects=2)
    provider.feed_timeout_bars = 1

    from pynecore.core import live_runner as _live_runner_mod
    _orig_floor = _live_runner_mod._FEED_STALE_FLOOR_S
    _live_runner_mod._FEED_STALE_FLOOR_S = 0.2
    try:
        _drain(provider, "TEST", "1S")
    finally:
        _live_runner_mod._FEED_STALE_FLOOR_S = _orig_floor

    assert provider.connect_calls >= 2, (
        "feed-liveness watchdog should have forced a reconnect on a "
        "connected-but-silent feed"
    )


def __test_feed_staleness_watchdog_disabled_with_none__():
    """``feed_timeout_bars=None`` keeps a silent-but-connected feed running.

    Same silent-feed setup as the positive test, but with the watchdog
    disabled there must be no reconnect — idle-bar synthesis keeps
    filling slots on the single original connection.

    ``base_ts`` is far enough in the past that all 40 idle calls run in
    the synth catch-up phase (~0.05 s effective timeout each), keeping
    the test at ~2 s of wall clock — well past the ~1 s staleness
    threshold the positive test reconnects under.
    """
    base_ts = (int(time.time()) - 200) * 1000
    updates = [_make_ohlcv(base_ts, is_closed=True, close=100.0)]
    provider = _SilentFeedProvider(updates, max_idle_calls=40)
    provider.feed_timeout_bars = None

    from pynecore.core import live_runner as _live_runner_mod
    _orig_floor = _live_runner_mod._FEED_STALE_FLOOR_S
    _live_runner_mod._FEED_STALE_FLOOR_S = 0.2
    try:
        _, bars = _drain(provider, "TEST", "1S")
    finally:
        _live_runner_mod._FEED_STALE_FLOOR_S = _orig_floor

    assert provider.connect_calls == 1, (
        "watchdog disabled: no reconnect may happen on a silent feed"
    )
    # Idle synthesis must keep working without the watchdog interfering.
    assert any(b.volume == 0.0 for b in bars)


def __test_feed_staleness_fires_when_slot_pinned_in_closed_window__():
    """A feed that dies across a session close trips the watchdog after reopen.

    Regression test for the pinned-slot blind spot: when the feed dies
    near a session close, ``last_closed_bar`` stops advancing, so the
    pending synth slot stays calendar-closed forever and the closed-window
    branch runs on every iteration — even after the session has reopened.
    That branch used to rebase the staleness clock unconditionally, which
    disarmed the liveness watchdog for good (frozen strategy on an open
    market); it must instead trip the watchdog once the session is open
    again.

    Calendar: one interval covering "now" (session open) but NOT the
    pinned synth slot ~139 s in the past (slot closed). With the staleness
    floor shrunk and ``feed_timeout_bars=1`` on a 1-second timeframe the
    threshold is ~1 s, so the forced reconnect must arrive within the
    test's few-second budget.
    """
    from pynecore.core.syminfo import SymInfoInterval
    from datetime import datetime as ddatetime, time as dtime, timedelta, UTC

    now_dt = ddatetime.now(tz=UTC)
    open_start = now_dt - timedelta(seconds=60)
    if open_start.date() != now_dt.date():
        # Just after midnight: clamp the window to today so the single
        # same-day interval still covers "now".
        open_start = now_dt.replace(hour=0, minute=0, second=0)
    open_end = now_dt + timedelta(minutes=6)
    start_time = dtime(open_start.hour, open_start.minute, open_start.second)
    if open_end.date() != now_dt.date():
        # Just before midnight: split the window at the day boundary —
        # clamping the end to 23:59:59 would close the synthetic session
        # again seconds after the test starts, before the ~1 s staleness
        # trip can fire, and the run would never terminate. The post-
        # midnight segment starts at 00:00, so it cannot reach back to
        # the pinned slot ~139 s in the past (previous day).
        intervals = [
            SymInfoInterval(day=d, start=start_time, end=dtime(23, 59, 59))
            for d in range(7)
        ] + [
            SymInfoInterval(
                day=d, start=dtime(0, 0, 0),
                end=dtime(open_end.hour, open_end.minute, open_end.second),
            )
            for d in range(7)
        ]
    else:
        intervals = [
            SymInfoInterval(
                day=d, start=start_time,
                end=dtime(open_end.hour, open_end.minute, open_end.second),
            )
            for d in range(7)
        ]
    syminfo = _make_syminfo(intervals, timezone="UTC")

    # The synth slot (base_ts + 1s) lies ~79 s before the session window
    # opens -> calendar-closed, while wall-clock "now" is in-session.
    base_ts = (int(time.time()) - 140) * 1000
    updates = [_make_ohlcv(base_ts, is_closed=True, close=100.0)]
    provider = _SilentFeedProvider(updates, stop_after_connects=2)
    provider.feed_timeout_bars = 1

    from pynecore.core import live_runner as _live_runner_mod
    _orig_floor = _live_runner_mod._FEED_STALE_FLOOR_S
    _orig_sleep = _live_runner_mod._CLOSED_WINDOW_SLEEP_S
    _live_runner_mod._FEED_STALE_FLOOR_S = 0.2
    _live_runner_mod._CLOSED_WINDOW_SLEEP_S = 0.05
    try:
        _drain(provider, "TEST", "1S", syminfo=syminfo)
    finally:
        _live_runner_mod._FEED_STALE_FLOOR_S = _orig_floor
        _live_runner_mod._CLOSED_WINDOW_SLEEP_S = _orig_sleep

    assert provider.connect_calls >= 2, (
        "staleness watchdog must fire when the pinned synth slot is "
        "calendar-closed but the session is open now"
    )


# --- Forming-bar finalisation tests ---
#
# Providers that close a bar only when the NEXT bar's timestamp arrives
# (cTrader) never emit a close event for the last bar before a session
# boundary or a feed gap — that close simply never comes. The boundary
# watchdog must finalise the real forming bar it already received with
# its accumulated OHLCV instead of discarding it and fabricating a frozen
# V=0 synth. The no-forming-bar V=0 fallback (the watchdog's behaviour
# when no forming bar was tracked for the slot) is covered by
# ``__test_live_generator_synthesises_idle_bars_at_tf_boundary__``.


def __test_idle_watchdog_finalises_forming_bar_with_real_data__():
    """A forming bar for the boundary slot is closed with its real OHLCV.

    The provider delivers a closed bar then a forming (is_closed=False)
    bar for the next slot carrying real accumulated volume, then goes
    silent — no close event ever follows. The watchdog must emit a CLOSED
    bar at the forming slot with the forming bar's own OHLCV/volume, NOT
    a frozen V=0 filler at the previous close.
    """
    base_ts = (int(time.time()) - 200) * 1000
    forming = OHLCV(timestamp=base_ts + 60_000, open=100.0, high=106.0,
                    low=99.0, close=105.0, volume=500.0, is_closed=False)
    updates = [_make_ohlcv(base_ts, is_closed=True, close=100.0), forming]
    provider = _IdleAfterFirstBar(updates)

    bars: list[OHLCV] = []
    seen_transition = False
    for item in live_ohlcv_generator(provider, "BTC/USDT", "1"):
        if item is LIVE_TRANSITION:
            seen_transition = True
            continue
        if not seen_transition:
            continue
        bars.append(item)
        if any(b.timestamp == base_ts + 60_000 and b.is_closed for b in bars):
            break
        if len(bars) >= 8:
            break

    finalised = [b for b in bars if b.timestamp == base_ts + 60_000 and b.is_closed]
    assert len(finalised) == 1, (
        f"expected one finalised closed bar at the forming slot, "
        f"got {len(finalised)}"
    )
    assert finalised[0].close == 105.0  # real close, not the previous 100.0
    assert finalised[0].high == 106.0
    assert finalised[0].low == 99.0
    assert finalised[0].volume == 500.0  # real volume, not a V=0 synth


class _FormingThenLateClose(MockLiveProvider):
    """closed -> forming(next slot) -> stall (watchdog finalises) -> late
    real close for the same slot (conflicting values) -> exhausted.

    Models a provider whose own delayed close for a slot lands only after
    the watchdog already finalised that slot from the forming bar (e.g.
    the close event arrives after a session reopens).
    """

    def __init__(self, bar_updates: list[OHLCV], stall_seconds: float = 0.3):
        super().__init__(bar_updates)
        self._stall_seconds = stall_seconds
        self._stalled = False

    async def watch_ohlcv(self, symbol: str, timeframe: str) -> OHLCV:
        # Stall once between the forming bar (index 2) and the late close
        # so the watchdog finalises the forming slot before it is served.
        if self._index == 2 and not self._stalled:
            self._stalled = True
            await asyncio.sleep(self._stall_seconds)
        return await super().watch_ohlcv(symbol, timeframe)


def __test_late_real_close_dropped_after_forming_finalisation__():
    """A provider's late close for an already-finalised slot is dropped.

    After the watchdog finalises the forming slot, the provider finally
    emits its own CLOSED bar for the same timestamp with conflicting
    values. The existing same-/older-timestamp dedup must drop it so the
    consumer keeps exactly one closed bar for the slot — the real forming
    data, not the late conflicting close.
    """
    base_ts = (int(time.time()) - 200) * 1000
    forming = OHLCV(timestamp=base_ts + 60_000, open=100.0, high=106.0,
                    low=99.0, close=105.0, volume=500.0, is_closed=False)
    late_close = OHLCV(timestamp=base_ts + 60_000, open=100.0, high=200.0,
                       low=50.0, close=999.0, volume=777.0, is_closed=True)
    updates = [_make_ohlcv(base_ts, is_closed=True, close=100.0),
               forming, late_close]
    provider = _FormingThenLateClose(updates, stall_seconds=0.3)

    bars: list[OHLCV] = []
    seen_transition = False
    for item in live_ohlcv_generator(provider, "BTC/USDT", "1"):
        if item is LIVE_TRANSITION:
            seen_transition = True
            continue
        if not seen_transition:
            continue
        bars.append(item)
        if len(bars) >= 8:
            break

    closed_at_slot = [b for b in bars
                      if b.timestamp == base_ts + 60_000 and b.is_closed]
    assert len(closed_at_slot) == 1, (
        f"late real close must be dropped; got {len(closed_at_slot)} "
        f"closed bars at the slot"
    )
    assert closed_at_slot[0].close == 105.0  # forming data wins
    assert closed_at_slot[0].volume == 500.0


def __test_forming_bar_finalised_even_when_soft_cap_drops_queue_updates__():
    """Forming tracking is independent of the intra-bar queue soft-cap.

    With the soft cap forced to zero every forming (is_closed=False)
    update is dropped from the consumer queue, so the consumer sees no
    intra-bar updates at all. The watchdog must still finalise the slot
    with the forming bar's real OHLCV, because finalisation state is
    tracked BEFORE the cap, not via queue admission.
    """
    base_ts = (int(time.time()) - 200) * 1000
    forming = OHLCV(timestamp=base_ts + 60_000, open=100.0, high=106.0,
                    low=99.0, close=105.0, volume=500.0, is_closed=False)
    updates = [_make_ohlcv(base_ts, is_closed=True, close=100.0), forming]
    provider = _IdleAfterFirstBar(updates)

    from pynecore.core import live_runner as _live_runner_mod
    _orig_cap = _live_runner_mod._INTRA_BAR_SOFT_CAP
    _live_runner_mod._INTRA_BAR_SOFT_CAP = 0
    try:
        bars: list[OHLCV] = []
        seen_transition = False
        for item in live_ohlcv_generator(provider, "BTC/USDT", "1"):
            if item is LIVE_TRANSITION:
                seen_transition = True
                continue
            if not seen_transition:
                continue
            bars.append(item)
            if any(b.timestamp == base_ts + 60_000 and b.is_closed for b in bars):
                break
            if len(bars) >= 8:
                break
    finally:
        _live_runner_mod._INTRA_BAR_SOFT_CAP = _orig_cap

    # The soft cap (0) dropped every forming update from the queue.
    assert all(b.is_closed for b in bars), (
        "soft cap=0 must drop all intra-bar (forming) updates from the queue"
    )
    # ...but the watchdog still finalised the slot with real data.
    finalised = [b for b in bars if b.timestamp == base_ts + 60_000 and b.is_closed]
    assert len(finalised) == 1
    assert finalised[0].close == 105.0
    assert finalised[0].volume == 500.0


def __test_forming_finalised_at_session_end_then_next_slot_skipped__():
    """Session-boundary case: last in-session slot finalises, next is skipped.

    Models the cTrader Friday-close bug: the last bar of the session is
    delivered as a forming bar (no close event ever follows, because the
    next bar only arrives after the weekend). The watchdog must finalise
    that slot with its real OHLCV (the session's true close), while the
    slot AFTER the session end is gated out — neither finalised nor
    frozen-synth.
    """
    from pynecore.core.syminfo import SymInfoInterval
    from datetime import datetime as ddatetime, time as dtime, UTC

    base_ts = (int(time.time()) - 260) * 1000
    synth_ts = base_ts + 60_000  # last in-session slot start
    # Session ends exactly at the slot boundary after ``synth_ts`` so
    # [synth_ts, synth_ts+60s) is in-session and [synth_ts+60s, +120s) is not.
    start_dt = ddatetime.fromtimestamp((synth_ts - 1_800_000) / 1000, tz=UTC)
    end_dt = ddatetime.fromtimestamp((synth_ts + 60_000) / 1000, tz=UTC)
    start_t = dtime(start_dt.hour, start_dt.minute, start_dt.second)
    end_t = dtime(end_dt.hour, end_dt.minute, end_dt.second)
    if start_dt.date() == end_dt.date():
        intervals = [SymInfoInterval(day=d, start=start_t, end=end_t)
                     for d in range(7)]
    else:
        # Window straddles UTC midnight: split at the day boundary so the
        # pre/post-midnight halves stay contiguous and the post-end slot
        # remains closed.
        intervals = [
            SymInfoInterval(day=d, start=start_t, end=dtime(23, 59, 59))
            for d in range(7)
        ] + [
            SymInfoInterval(day=d, start=dtime(0, 0, 0), end=end_t)
            for d in range(7)
        ]
    syminfo = _make_syminfo(intervals, timezone="UTC")

    forming = OHLCV(timestamp=synth_ts, open=100.0, high=106.0,
                    low=99.0, close=105.0, volume=500.0, is_closed=False)
    updates = [_make_ohlcv(base_ts, is_closed=True, close=100.0), forming]
    provider = _IdleThenCancelProvider(updates, max_idle_calls=20)

    from pynecore.core import live_runner as _live_runner_mod
    _orig_sleep = _live_runner_mod._CLOSED_WINDOW_SLEEP_S
    _live_runner_mod._CLOSED_WINDOW_SLEEP_S = 0.05
    try:
        _, bars = _drain(provider, "TEST", "1", syminfo=syminfo)
    finally:
        _live_runner_mod._CLOSED_WINDOW_SLEEP_S = _orig_sleep

    # The last in-session slot was finalised once with its real OHLCV.
    finalised = [b for b in bars if b.timestamp == synth_ts and b.is_closed]
    assert len(finalised) == 1, (
        f"last in-session slot must be finalised once, got {len(finalised)}"
    )
    assert finalised[0].close == 105.0
    assert finalised[0].volume == 500.0
    # The slot past the session end must not be emitted at all.
    assert all(b.timestamp != synth_ts + 60_000 for b in bars), (
        "the out-of-session slot must be neither finalised nor synthesised"
    )
    # No frozen V=0 synth was produced — the only closed-bar fill was the
    # real-data finalisation.
    assert all(b.volume > 0.0 for b in bars if b.is_closed), (
        "no frozen V=0 synth expected; only the real-data finalisation"
    )


def _drain_streamer(bars) -> LiveBarStreamer:
    """Drive a LiveBarStreamer's drain loop synchronously over a fixed bar list.

    Injects ``bars`` as the generator and calls ``_drain`` directly (no thread),
    so the queue and developing slot reflect the full sequence deterministically.
    The provider is never used here (``_gen`` is overridden), so an idle mock
    satisfies the constructor's type.
    """
    streamer = LiveBarStreamer(provider=MockLiveProvider([]), symbol="X", timeframe="3")
    streamer._gen = (_b for _b in bars)
    streamer._drain()
    return streamer


def __test_streamer_exposes_developing_bar__():
    """Forming bars feed the developing slot; closed bars go to the queue."""
    bars = [
        _make_ohlcv(0, close=100.0, is_closed=False),    # forming intrabar 0
        _make_ohlcv(0, close=101.0, is_closed=False),    # forming update
        _make_ohlcv(0, close=101.0, is_closed=True),     # intrabar 0 closes
        _make_ohlcv(180, close=102.0, is_closed=False),  # forming intrabar 1
    ]
    streamer = _drain_streamer(bars)

    closed = streamer.pop_new_closed_bars()
    assert len(closed) == 1
    assert closed[0].timestamp == 0 and closed[0].is_closed

    dev = streamer.peek_developing_bar()
    assert dev is not None
    assert dev.timestamp == 180 and not dev.is_closed
    assert dev.close == 102.0


def __test_streamer_clears_developing_on_close__():
    """A close supersedes the forming slot — peek returns None afterwards."""
    bars = [
        _make_ohlcv(0, close=100.0, is_closed=False),
        _make_ohlcv(0, close=100.5, is_closed=False),
        _make_ohlcv(0, close=100.5, is_closed=True),
    ]
    streamer = _drain_streamer(bars)

    assert streamer.peek_developing_bar() is None
    assert len(streamer.pop_new_closed_bars()) == 1


def __test_streamer_developing_peek_does_not_consume__():
    """peek_developing_bar is idempotent — repeated reads return the same bar."""
    bars = [_make_ohlcv(60, close=50.0, is_closed=False)]
    streamer = _drain_streamer(bars)

    first = streamer.peek_developing_bar()
    second = streamer.peek_developing_bar()
    assert first is not None and second is not None
    assert first.timestamp == second.timestamp == 60
    assert streamer.pop_new_closed_bars() == []


# --- Shutdown-while-reconnecting regression --------------------------------

class _ReconnectHangProvider(MockLiveProvider):
    """Connects once, then wedges the reconnect ``connect()`` forever.

    Reproduces the live shape where a feed drop puts the runner into
    ``_handle_connection_error`` and the reconnect handshake stalls (a broker
    edge that accepts TCP but never finishes the app handshake). A shutdown
    requested in that window must abandon the in-flight ``connect()`` at once —
    not wait out the connect timeout / the ``shutdown_timeout + 5`` join.
    """

    def __init__(self):
        super().__init__([])
        self.reconnect_entered = threading.Event()
        self._connect_calls = 0

    async def connect(self):
        self._connect_calls += 1
        if self._connect_calls == 1:
            self._connected = True
            return
        # Reconnect attempt: never completes until cancelled by the shutdown.
        self.reconnect_entered.set()
        await asyncio.Event().wait()

    async def watch_ohlcv(self, symbol: str, timeframe: str) -> OHLCV:
        # First live pull fails -> drives the reconnect path.
        self._connected = False
        raise ConnectionError("feed dropped")


def __test_shutdown_during_reconnect_is_prompt__():
    """Closing the live generator while a reconnect is wedged must not block.

    Regression for the cTrader ``adopted-cancel`` shutdown hang: the reconnect
    ``await provider.connect()`` ran on the broker loop without observing the
    stop signal, so teardown stalled for the whole connect timeout (SIGINT
    produced no shutdown output for ~30 s, exit 137). The fix mirrors
    ``stop_event`` onto a loop-side asyncio Event so the handshake is cancelled
    immediately.
    """
    provider = _ReconnectHangProvider()
    gen = live_ohlcv_generator(
        provider, "BTC/USDT", "1D", shutdown_timeout=30.0,
    )
    it = iter(gen)
    next(it)  # LIVE_TRANSITION — connect() succeeded, feed is live

    assert provider.reconnect_entered.wait(timeout=5.0), \
        "runner never reached the wedged reconnect"

    start = time.monotonic()
    gen.close()
    elapsed = time.monotonic() - start
    # Bounded teardown: well under the connect timeout (30 s) and the
    # shutdown_timeout + 5 producer join. A few seconds of slack absorbs the
    # loop teardown; the pre-fix behaviour blocked ~35 s.
    assert elapsed < 10.0, f"shutdown blocked for {elapsed:.1f}s during reconnect"


class _CancelResistantReconnectProvider(MockLiveProvider):
    """Connects once, then swallows the shutdown's cancel on the reconnect.

    Cancellation is a request, not a guarantee: a provider hook that catches its
    ``CancelledError`` and keeps working (the "adopted cancel" shape seen on
    real broker SDKs) goes on running long after teardown asked it to stop.
    """

    def __init__(self):
        super().__init__([])
        self.reconnect_entered = threading.Event()
        self.disconnect_times: list[float] = []
        self._connect_calls = 0

    async def connect(self):
        self._connect_calls += 1
        if self._connect_calls == 1:
            self._connected = True
            return
        self.reconnect_entered.set()
        # Reconnect attempt: keeps running for well over the grace window no
        # matter how often it is cancelled.
        deadline = time.monotonic() + 2.0
        while time.monotonic() < deadline:
            try:
                await asyncio.sleep(2.0)
            except asyncio.CancelledError:
                continue

    async def disconnect(self):
        self.disconnect_times.append(time.monotonic())
        self._connected = False

    async def watch_ohlcv(self, symbol: str, timeframe: str) -> OHLCV:
        # First live pull fails -> drives the reconnect path.
        self._connected = False
        raise ConnectionError("feed dropped")


def __test_shutdown_detaches_a_cancel_resistant_reconnect_hook__():
    """Teardown must not be pinned by a hook that ignores its cancellation.

    ``_await_or_stop`` cancels the in-flight hook and then waits for it, but the
    cancel is only a request: a ``connect()`` / ``on_reconnect()`` that swallows
    it kept ``_async_loop`` parked on that wait, so ``_graceful_shutdown`` never
    ran — the provider was never disconnected and no sentinel reached the
    consumer. With ``shutdown_timeout=0`` ("wait forever") the caller's join has
    no bound either, so the whole shutdown hung on the provider's goodwill. The
    wait is now bounded: the hook is detached, and teardown proceeds.
    """
    from pynecore.core import live_runner as _live_runner_mod

    provider = _CancelResistantReconnectProvider()
    _orig_hook_grace = _live_runner_mod._HOOK_CANCEL_GRACE_S
    _orig_late_grace = _live_runner_mod._LATE_CONNECT_GRACE_S
    # Both windows shorter than the hook's 2 s of cancel-resistance, so the
    # test measures the bound rather than the hook.
    _live_runner_mod._HOOK_CANCEL_GRACE_S = 0.05
    _live_runner_mod._LATE_CONNECT_GRACE_S = 0.05
    try:
        gen = live_ohlcv_generator(
            provider, "BTC/USDT", "1D", shutdown_timeout=1.0,
        )
        it = iter(gen)
        next(it)  # LIVE_TRANSITION — connect() succeeded, feed is live

        assert provider.reconnect_entered.wait(timeout=5.0), \
            "runner never reached the cancel-resistant reconnect"

        start = time.monotonic()
        gen.close()

        # The reconnect path already disconnected once before its attempt, so
        # only the closes that follow the shutdown signal are teardown's. The
        # first of them is ``_graceful_shutdown``'s — the one that used to be
        # unreachable until the hook felt like returning. (A later one belongs
        # to the detached hook closing what it opened, hence "first", not
        # "last".)
        after_shutdown = [t - start for t in provider.disconnect_times if t >= start]
        assert after_shutdown, "graceful shutdown never disconnected the provider"
        assert after_shutdown[0] < 1.0, (
            "teardown waited out the cancel-resistant hook before disconnecting "
            f"({after_shutdown[0]:.1f}s)"
        )
    finally:
        _live_runner_mod._HOOK_CANCEL_GRACE_S = _orig_hook_grace
        _live_runner_mod._LATE_CONNECT_GRACE_S = _orig_late_grace


class _BackfillProvider(MockLiveProvider):
    """Provider that reports the bars which closed while it was subscribing."""

    def __init__(self, bar_updates: list[OHLCV], recovered: list[OHLCV],
                 failure: Exception | None = None):
        super().__init__(bar_updates)
        self._recovered = recovered
        self._failure = failure
        self.backfill_calls: list[tuple[str, str, int]] = []

    async def backfill_closed_bars(self, symbol: str, timeframe: str,
                                   since_ms: int) -> list[OHLCV]:
        self.backfill_calls.append((symbol, timeframe, since_ms))
        if self._failure is not None:
            raise self._failure
        return self._recovered


def __test_startup_gap_bars_are_spliced_before_the_live_stream__():
    """Bars that closed during subscribe reach the script, in order, once.

    The warmup download ends at ``last_historical_timestamp`` and the stream
    starts from whenever the subscription came up; without this recovery the
    bars in between are lost to both.
    """
    recovered = [_make_ohlcv(2000, close=200.0), _make_ohlcv(3000, close=300.0)]
    provider = _BackfillProvider([_make_ohlcv(4000, close=400.0)], recovered)

    catchup, live = _drain(provider, "BTC/USDT", "1D",
                           last_historical_timestamp=1000)

    assert [bar.timestamp for bar in catchup + live] == [2000, 3000, 4000]
    assert provider.backfill_calls == [("BTC/USDT", "1D", 1000)]


def __test_startup_gap_drops_stale_and_unclosed_recovered_bars__():
    """A provider may over-answer; only genuinely new closed bars are accepted."""
    recovered = [
        _make_ohlcv(500, close=50.0),                    # older than the warmup
        _make_ohlcv(1000, close=100.0),                  # the warmup's own bar
        _make_ohlcv(2000, close=200.0, is_closed=False),  # still forming
        _make_ohlcv(3000, close=300.0),                  # the only real gap bar
    ]
    provider = _BackfillProvider([_make_ohlcv(4000, close=400.0)], recovered)

    catchup, live = _drain(provider, "BTC/USDT", "1D",
                           last_historical_timestamp=1000)

    assert [bar.timestamp for bar in catchup + live] == [3000, 4000]


def __test_startup_gap_failure_does_not_stop_the_run__():
    """A failed history query logs and continues — it must not strand the bot."""
    provider = _BackfillProvider(
        [_make_ohlcv(4000, close=400.0)], [], failure=RuntimeError("history down"),
    )

    catchup, live = _drain(provider, "BTC/USDT", "1D",
                           last_historical_timestamp=1000)

    assert [bar.timestamp for bar in catchup + live] == [4000]


def __test_startup_gap_skipped_when_no_full_bar_could_have_closed__():
    """No query is made when the warmup already reaches the current bar."""
    now_ms = int(time.time() * 1000)
    provider = _BackfillProvider([_make_ohlcv(now_ms + 60_000, close=400.0)], [])

    _drain(provider, "BTC/USDT", "1D", last_historical_timestamp=now_ms)

    assert provider.backfill_calls == []
