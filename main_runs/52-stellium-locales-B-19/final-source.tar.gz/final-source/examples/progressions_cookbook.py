#!/usr/bin/env python3
"""
Secondary Progressions Cookbook - Internal Development & Symbolic Timing

This cookbook demonstrates how to calculate and analyze secondary progressions
in Stellium. Progressions use the symbolic equation "1 day = 1 year" to show
internal psychological development and unfolding potential.

The "predictive trinity" in astrology:
- Transits: External events happening TO you
- Returns: Annual/periodic themes
- Progressions: Internal development - you BECOMING who you're meant to be

Key progressed events to watch:
- Progressed Moon changing signs (~2.5 years): emotional tone shifts
- Progressed Sun changing signs (~30 years): identity evolution
- Progressed planets aspecting natal: developmental milestones

Run this script to generate example progressions in examples/progressions/

Usage:
    source ~/.zshrc && pyenv activate starlight
    python examples/progressions_cookbook.py

For full documentation, see docs/CHART_TYPES.md
"""

import os
from datetime import datetime
from pathlib import Path

from stellium import ChartBuilder, MultiChartBuilder

# Output directory for generated files
SCRIPT_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = SCRIPT_DIR / "progressions"
os.makedirs(OUTPUT_DIR, exist_ok=True)


def section_header(title: str) -> None:
    """Print a formatted section header."""
    print(f"\n{'=' * 60}")
    print(f"  {title}")
    print(f"{'=' * 60}\n")


# =============================================================================
# PART 1: BASIC PROGRESSIONS BY AGE
# =============================================================================


def example_1_simple_progression_by_age():
    """
    Example 1: Simple Progression by Age

    The easiest way to get progressions - just specify the age!
    """
    section_header("Example 1: Simple Progression by Age")

    # Create natal chart
    natal = ChartBuilder.from_notable("Albert Einstein").with_aspects().calculate()

    print(
        f"Natal Sun: {natal.get_object('Sun').longitude:.2f}° {natal.get_object('Sun').sign}"
    )
    print(
        f"Natal Moon: {natal.get_object('Moon').longitude:.2f}° {natal.get_object('Moon').sign}"
    )
    print(
        f"Natal ASC: {natal.get_object('ASC').longitude:.2f}° {natal.get_object('ASC').sign}"
    )

    # Calculate progressions for age 26 (when Einstein published special relativity!)
    prog = MultiChartBuilder.progression(natal, age=26).calculate()

    print("\nProgressions at Age 26 (1905 - 'Miracle Year'):")
    print(
        f"  Progressed Sun: {prog.chart2.get_object('Sun').longitude:.2f}° {prog.chart2.get_object('Sun').sign}"
    )
    print(
        f"  Progressed Moon: {prog.chart2.get_object('Moon').longitude:.2f}° {prog.chart2.get_object('Moon').sign}"
    )
    print(
        f"  Progressed ASC: {prog.chart2.get_object('ASC').longitude:.2f}° {prog.chart2.get_object('ASC').sign}"
    )

    # Show cross-aspects between progressed and natal
    cross = prog.get_all_cross_aspects()
    print(f"\nProgressed-to-Natal Aspects: {len(cross)}")
    for asp in sorted(cross, key=lambda a: a.orb)[:5]:
        print(
            f"  P.{asp.object2.name} {asp.aspect_name} N.{asp.object1.name} (orb: {asp.orb:.2f}°)"
        )


def example_2_progressed_sun_motion():
    """
    Example 2: Track Progressed Sun Motion Over Time

    The progressed Sun moves ~1° per year. Watch it change signs!
    """
    section_header("Example 2: Progressed Sun Motion (~1°/year)")

    natal = (
        ChartBuilder.from_details(
            "1994-01-06 11:47",
            (37.4419, -122.1430),  # Palo Alto coordinates
            name="Kate",
        )
        .with_aspects()
        .calculate()
    )

    print(
        f"Natal Sun: {natal.get_object('Sun').longitude:.2f}° {natal.get_object('Sun').sign}"
    )

    # Track Sun motion at different ages
    ages = [0, 10, 20, 30, 40]

    print("\nProgressed Sun at different ages:")
    print("-" * 50)

    prev_sun = natal.get_object("Sun").longitude
    for age in ages:
        if age == 0:
            sun = natal.get_object("Sun")
            motion = 0
        else:
            prog = MultiChartBuilder.progression(natal, age=age).calculate()
            sun = prog.chart2.get_object("Sun")
            motion = sun.longitude - prev_sun
            if motion < 0:
                motion += 360

        print(
            f"  Age {age:2d}: {sun.longitude:6.2f}° {sun.sign:12s} (moved {motion:.1f}° from prev)"
        )
        prev_sun = sun.longitude


def example_3_progressed_moon_cycle():
    """
    Example 3: The Progressed Moon Cycle (~27 year cycle)

    The progressed Moon moves ~12-13° per year, completing the zodiac
    in about 27-28 years. Each sign change marks an emotional shift.
    """
    section_header("Example 3: Progressed Moon Cycle (~12°/year)")

    natal = (
        ChartBuilder.from_details("1994-01-06 11:47", (37.4419, -122.1430), name="Kate")
        .with_aspects()
        .calculate()
    )

    print(
        f"Natal Moon: {natal.get_object('Moon').longitude:.2f}° {natal.get_object('Moon').sign}"
    )

    # Track Moon through approximate sign changes (~2.5 years per sign)
    print("\nProgressed Moon sign changes (approximate):")
    print("-" * 50)

    current_sign = natal.get_object("Moon").sign

    for age in range(0, 31, 3):
        if age == 0:
            moon = natal.get_object("Moon")
        else:
            prog = MultiChartBuilder.progression(natal, age=age).calculate()
            moon = prog.chart2.get_object("Moon")

        sign_change = "← SIGN CHANGE" if moon.sign != current_sign else ""
        print(f"  Age {age:2d}: {moon.longitude:6.2f}° {moon.sign:12s} {sign_change}")
        current_sign = moon.sign


# =============================================================================
# PART 2: PROGRESSIONS BY TARGET DATE
# =============================================================================


def example_4_progression_by_target_date():
    """
    Example 4: Progression to a Specific Target Date

    Calculate progressions for a specific date instead of age.
    Useful for analyzing specific life events.
    """
    section_header("Example 4: Progression by Target Date")

    natal = ChartBuilder.from_notable("Albert Einstein").with_aspects().calculate()

    # Progressions for when Einstein received the Nobel Prize (1921)
    prog = MultiChartBuilder.progression(
        natal,
        target_date="1921-11-09",  # Nobel Prize announcement
    ).calculate()

    print("Progressions for November 9, 1921 (Nobel Prize)")
    print(f"  Progressed Sun: {prog.chart2.get_object('Sun').longitude:.2f}°")
    print(f"  Progressed Moon: {prog.chart2.get_object('Moon').longitude:.2f}°")
    print(f"  Progressed Mercury: {prog.chart2.get_object('Mercury').longitude:.2f}°")

    # Calculate how old he was
    birth_year = 1879
    event_year = 1921
    print(f"\n  (Einstein was {event_year - birth_year} years old)")


def example_5_current_progressions():
    """
    Example 5: Current Progressions (No Date = Now)

    If you don't specify age or target_date, progressions
    default to the current moment.
    """
    section_header("Example 5: Current Progressions")

    natal = (
        ChartBuilder.from_details("1994-01-06 11:47", (37.4419, -122.1430), name="Kate")
        .with_aspects()
        .calculate()
    )

    # Progressions for NOW
    prog = MultiChartBuilder.progression(natal).calculate()

    # Calculate current age
    birth_dt = natal.datetime.local_datetime or natal.datetime.utc_datetime
    now = datetime.now()
    current_age = (now - birth_dt).days / 365.25

    print(f"Current progressions (age ~{current_age:.1f}):")
    print(
        f"  Progressed Sun: {prog.chart2.get_object('Sun').longitude:.2f}° {prog.chart2.get_object('Sun').sign}"
    )
    print(
        f"  Progressed Moon: {prog.chart2.get_object('Moon').longitude:.2f}° {prog.chart2.get_object('Moon').sign}"
    )
    print(
        f"  Progressed Venus: {prog.chart2.get_object('Venus').longitude:.2f}° {prog.chart2.get_object('Venus').sign}"
    )


# =============================================================================
# PART 3: ANGLE PROGRESSION METHODS
#
# In secondary progressions, planetary positions are unambiguous: cast a chart
# for the progressed datetime (natal + N days for N years of life) and read
# the planets. But ANGLES (ASC, MC) are a different story.
#
# The problem: the Ascendant rotates through the full 360° zodiac every ~24
# hours (tied to Earth's rotation). In secondary progressions, 1 year of life
# = 1 progressed day. This means the progressed ASC naturally cycles the ENTIRE
# zodiac every year — which makes it hyper-sensitive to the fractional-day
# component of the progressed datetime.
#
# Concretely: if your target date is your birthday, the progressed time lands
# at an integer number of days (same time-of-day as birth). But if your target
# is 6 months after your birthday, the progressed time shifts by ~12 hours,
# and the ASC moves ~180°. This is mathematically correct but interpretively
# useless for general progressed chart reading.
#
# Three solutions exist:
#
# SOLAR ARC (default) — "Move angles at the Sun's rate"
#   Calculation: Natal ASC/MC + (Progressed Sun longitude - Natal Sun longitude)
#   Rate: ~1°/year (varies slightly, since the Sun moves faster in Jan than Jul)
#   Use case: Standard progressed chart interpretation. The most common method
#   in professional software (Solar Fire, Astro.com default to this).
#   Meaning: The angles unfold at the same pace as your core identity (Sun).
#
# NAIBOD — "Move angles at the Sun's MEAN rate"
#   Calculation: Natal ASC/MC + (years × 59'08"/year)
#   Rate: Exactly 0.9856°/year, constant regardless of birth date.
#   Use case: When you want perfectly uniform angle progression. Popular in
#   Uranian/cosmobiology traditions. Gives very similar results to Solar Arc
#   (within ~1° over a lifetime) but with zero seasonal variation.
#   Meaning: A standardized symbolic clock — pure time-as-meaning.
#
# QUOTIDIAN — "Use the raw chart-cast angles"
#   Calculation: Cast a chart for the progressed datetime, use those angles.
#   Rate: ~360°/year (full zodiac rotation per progressed day).
#   Use case: ADVANCED TIMING TECHNIQUE. Not for general chart reading!
#   Astrologers use quotidian progressions to time events WITHIN a year:
#   "When does my progressed ASC cross my natal Mars?" — that gives a specific
#   week or month. The ~1° per real-time day sensitivity is the feature, not
#   a bug, for this application.
#   Meaning: A fast-moving timer for pinpointing developmental moments.
#
# WHY SOLAR ARC IS THE DEFAULT:
#   - Matches professional software behavior
#   - Gives interpretively meaningful results (~30° of ASC motion over 30 years)
#   - Stable across all target dates (no birthday-sensitivity)
#   - The "expected" behavior for users comparing against other tools
# =============================================================================


def example_6_quotidian_angles():
    """
    Example 6: Quotidian Angle Progression (Advanced Timing Technique)

    Quotidian uses the actual angles from the progressed chart cast.
    The ASC/MC cycle through the full zodiac every progressed day (= every
    year of life), making this a precision timing tool rather than a general
    progression method.

    Use case: "When exactly does my progressed ASC conjoin natal Mars?"
    The answer might be "age 30.27" — i.e., about April of your 30th year.

    Note: Results vary dramatically with target date. This is intentional —
    the sensitivity IS the feature for timing work. For general progressed
    chart interpretation, use solar_arc (the default).
    """
    section_header("Example 6: Quotidian Angles (Advanced Timing)")

    natal = (
        ChartBuilder.from_details("1994-01-06 11:47", (37.4419, -122.1430), name="Kate")
        .with_aspects()
        .calculate()
    )

    # Quotidian must be explicitly requested (solar_arc is the default)
    prog = MultiChartBuilder.progression(
        natal,
        age=30,
        angle_method="quotidian",
    ).calculate()

    print("Quotidian Angles (actual ephemeris motion):")
    print(
        f"  Natal ASC: {natal.get_object('ASC').longitude:.2f}° {natal.get_object('ASC').sign}"
    )
    print(
        f"  Progressed ASC: {prog.chart2.get_object('ASC').longitude:.2f}° {prog.chart2.get_object('ASC').sign}"
    )
    print(
        f"  Natal MC: {natal.get_object('MC').longitude:.2f}° {natal.get_object('MC').sign}"
    )
    print(
        f"  Progressed MC: {prog.chart2.get_object('MC').longitude:.2f}° {prog.chart2.get_object('MC').sign}"
    )


def example_7_solar_arc_angles():
    """
    Example 7: Solar Arc Angle Progression (Default)

    In Solar Arc, ALL angles progress at the same rate as the
    progressed Sun. If the Sun moved 30°, so do ASC and MC.

    This is the default method because:
    - It produces stable, predictable results (~1°/year)
    - It matches professional software defaults (Solar Fire, Astro.com)
    - The rate is symbolically meaningful (angles unfold at the Sun's pace)
    - Results don't vary wildly based on target date vs birthday

    The Sun's actual rate varies slightly by season (~0.95°-1.02°/year)
    because Earth's orbit is elliptical (faster in January near perihelion).
    """
    section_header("Example 7: Solar Arc Angles (Default)")

    natal = (
        ChartBuilder.from_details("1994-01-06 11:47", (37.4419, -122.1430), name="Kate")
        .with_aspects()
        .calculate()
    )

    prog = MultiChartBuilder.progression(
        natal, age=30, angle_method="solar_arc"
    ).calculate()

    # Calculate the solar arc
    natal_sun = natal.get_object("Sun").longitude
    prog_sun = prog.chart2.get_object("Sun").longitude
    solar_arc = prog_sun - natal_sun
    if solar_arc < 0:
        solar_arc += 360

    print("Solar Arc Method:")
    print(f"  Solar Arc: {solar_arc:.2f}° (Sun's motion in 30 years)")
    print(f"\n  Natal ASC: {natal.get_object('ASC').longitude:.2f}°")
    print(
        f"  Progressed ASC: {prog.chart2.get_object('ASC').longitude:.2f}° (natal + {solar_arc:.2f}°)"
    )
    print(f"\n  Natal MC: {natal.get_object('MC').longitude:.2f}°")
    print(
        f"  Progressed MC: {prog.chart2.get_object('MC').longitude:.2f}° (natal + {solar_arc:.2f}°)"
    )

    # Note: quotidian method doesn't store angle_method/angle_arc in metadata
    print(f"\n  Metadata: angle_method = {prog.chart2.metadata.get('angle_method')}")
    print(f"  Metadata: angle_arc = {prog.chart2.metadata.get('angle_arc', 0):.2f}°")


def example_8_naibod_angles():
    """
    Example 8: Naibod Angle Progression

    Naibod uses the Sun's MEAN daily motion (59'08" per year = 0.9856°/year)
    rather than its actual motion. This gives a perfectly consistent rate
    regardless of birth date or season.

    Naibod rate: exactly 59'08" per year = 0.9856°/year
    At age 30: 29.57° of arc
    At age 60: 59.13° of arc

    Compared to Solar Arc, Naibod differs by at most ~1° over a lifetime
    (since the Sun's actual daily motion ranges from ~0.95° to ~1.02°).
    Popular in Uranian astrology and cosmobiology traditions.
    """
    section_header("Example 8: Naibod Angles")

    natal = (
        ChartBuilder.from_details("1994-01-06 11:47", (37.4419, -122.1430), name="Kate")
        .with_aspects()
        .calculate()
    )

    prog = MultiChartBuilder.progression(
        natal, age=30, angle_method="naibod"
    ).calculate()

    # Calculate expected Naibod arc
    naibod_rate = 59.1333 / 60  # degrees per year
    expected_arc = 30 * naibod_rate

    print("Naibod Method (mean Sun rate: 59'08\"/year):")
    print(f"  Expected arc for 30 years: {expected_arc:.2f}°")
    print(f"\n  Natal ASC: {natal.get_object('ASC').longitude:.2f}°")
    print(
        f"  Progressed ASC: {prog.chart2.get_object('ASC').longitude:.2f}° (natal + {expected_arc:.2f}°)"
    )

    # Verify the metadata
    actual_arc = prog.chart2.metadata.get("angle_arc", 0)
    print(f"\n  Metadata: angle_arc = {actual_arc:.2f}°")


def example_9_compare_angle_methods():
    """
    Example 9: Compare All Three Angle Methods

    See how the different methods produce different angle positions.

    Expected results at age 30:
    - Solar Arc: natal ASC + ~30° (Sun's actual motion)
    - Naibod:    natal ASC + ~29.57° (Sun's mean motion)
    - Quotidian: natal ASC + ??? (depends on fractional day — could be anything!)

    Solar Arc and Naibod will always be within ~1° of each other.
    Quotidian will appear to give a "random" angle unless the target
    is exactly on a birthday (integer years).
    """
    section_header("Example 9: Compare Angle Methods")

    natal = (
        ChartBuilder.from_details("1994-01-06 11:47", (37.4419, -122.1430), name="Kate")
        .with_aspects()
        .calculate()
    )

    natal_asc = natal.get_object("ASC").longitude

    print(f"Natal ASC: {natal_asc:.2f}°\n")
    print(f"{'Method':<12} {'Progressed ASC':>15} {'Difference':>12}")
    print("-" * 42)

    for method in ["quotidian", "solar_arc", "naibod"]:
        prog = MultiChartBuilder.progression(
            natal, age=30, angle_method=method
        ).calculate()

        prog_asc = prog.chart2.get_object("ASC").longitude
        diff = prog_asc - natal_asc
        if diff < 0:
            diff += 360

        print(f"{method:<12} {prog_asc:>15.2f}° {diff:>11.2f}°")


# =============================================================================
# PART 4: ANALYZING PROGRESSIONS
# =============================================================================


def example_10_progressed_aspects_to_natal():
    """
    Example 10: Find Progressed Aspects to Natal

    The most common use of progressions - finding when progressed
    planets aspect natal positions.
    """
    section_header("Example 10: Progressed-to-Natal Aspects")

    natal = ChartBuilder.from_notable("Albert Einstein").with_aspects().calculate()

    prog = MultiChartBuilder.progression(natal, age=26).calculate()

    print("Progressed-to-Natal Aspects at Age 26:")
    print("-" * 50)

    cross = prog.get_all_cross_aspects()
    if cross:
        for asp in sorted(cross, key=lambda a: a.orb):
            # In progressions, object2 is progressed, object1 is natal
            print(
                f"  P.{asp.object2.name:<8} {asp.aspect_name:<12} "
                f"N.{asp.object1.name:<8} (orb: {asp.orb:.3f}°)"
            )
    else:
        print("  No aspects within 1° orb (progressions use tight orbs!)")


def example_11_house_overlays():
    """
    Example 11: Progressed Planets in Natal Houses

    See which natal houses your progressed planets fall in.
    """
    section_header("Example 11: Progressed Planets in Natal Houses")

    natal = (
        ChartBuilder.from_details("1994-01-06 11:47", (37.4419, -122.1430), name="Kate")
        .with_aspects()
        .calculate()
    )

    prog = MultiChartBuilder.progression(natal, age=30).calculate()

    print("Progressed Planets in Natal Houses:")
    print("-" * 50)

    # House overlays show where each chart's planets fall in the other's houses
    # Filter for progressed planets in natal houses (planet_owner="chart2")
    prog_in_natal = [
        h for h in prog.get_all_house_overlays() if h.planet_owner == "chart2"
    ]

    for overlay in prog_in_natal[:10]:  # Show first 10
        print(f"  P.{overlay.planet_name:<8} in Natal House {overlay.falls_in_house}")


# =============================================================================
# PART 5: BACKWARDS COMPATIBILITY
# =============================================================================


def example_12_legacy_explicit_chart():
    """
    Example 12: Legacy API with Explicit Progressed Chart

    The old way still works - pass a pre-calculated progressed chart.
    """
    section_header("Example 12: Legacy API (Explicit Chart)")

    from datetime import timedelta

    # Create natal chart
    natal = (
        ChartBuilder.from_details("1994-01-06 11:47", (37.4419, -122.1430), name="Kate")
        .with_aspects()
        .calculate()
    )

    # Manually calculate progressed datetime (30 days = 30 years)
    natal_dt = natal.datetime.local_datetime
    progressed_dt = natal_dt + timedelta(days=30)

    # Manually create progressed chart
    progressed = ChartBuilder.from_details(
        progressed_dt, natal.location, name="Kate - Progressed (manual)"
    ).calculate()

    # Legacy API: pass both charts explicitly
    prog = MultiChartBuilder.progression(natal, progressed).calculate()

    print("Legacy API works!")
    print(f"  Relationship: {prog.get_relationship(0, 1)}")
    print(f"  Cross aspects: {len(prog.get_all_cross_aspects())}")


def example_13_tuple_format():
    """
    Example 13: Using Tuple Format (datetime, location)

    Both natal and progressed can be specified as tuples.
    """
    section_header("Example 13: Tuple Format")

    # Both charts as tuples
    prog = MultiChartBuilder.progression(
        ("1994-01-06 11:47", "Palo Alto, CA"),
        ("1994-02-05 11:47", "Palo Alto, CA"),  # 30 days later = age 30
    ).calculate()

    print("Tuple format works!")
    print(f"  Relationship: {prog.get_relationship(0, 1)}")
    print(
        f"  Days between: {prog.chart2.datetime.julian_day - prog.chart1.datetime.julian_day:.1f}"
    )


# =============================================================================
# PART 6: VISUALIZATION
# =============================================================================


def example_14_draw_progression_biwheel():
    """
    Example 14: Draw Progression Bi-Wheel

    Create a bi-wheel chart with natal (inner) and progressed (outer).
    """
    section_header("Example 14: Progression Bi-Wheel Chart")

    natal = (
        ChartBuilder.from_details("1994-01-06 11:47", (37.4419, -122.1430), name="Kate")
        .with_aspects()
        .calculate()
    )

    prog = MultiChartBuilder.progression(
        natal, age=30, natal_label="Natal", progressed_label="Progressed Age 30"
    ).calculate()

    # Draw the bi-wheel
    output = OUTPUT_DIR / "14_progression_biwheel.svg"
    prog.draw(str(output)).save()

    print(f"Created progression bi-wheel: {output}")
    print("  Inner ring: Natal chart")
    print("  Outer ring: Progressed (age 30)")


def example_15_progression_with_solar_arc_biwheel():
    """
    Example 15: Solar Arc Progression Bi-Wheel

    Draw a bi-wheel using solar arc angles.
    """
    section_header("Example 15: Solar Arc Progression Bi-Wheel")

    natal = ChartBuilder.from_notable("Albert Einstein").with_aspects().calculate()

    prog = MultiChartBuilder.progression(
        natal,
        age=26,
        angle_method="solar_arc",
        natal_label="Einstein Natal",
        progressed_label="Progressed 1905",
    ).calculate()

    output = OUTPUT_DIR / "15_einstein_1905_solar_arc.svg"
    prog.draw(str(output)).save()

    print(f"Created: {output}")
    print("  Solar arc used for angle progression")


# =============================================================================
# PART 7: TERTIARY AND MINOR PROGRESSIONS
# =============================================================================


def example_16_tertiary_progressions():
    """
    Example 16: Tertiary Progressions (Day-for-a-Lunar-Month)

    Tertiary progressions use the time key: 1 day of planetary motion
    = 1 lunar month (~27.3 days) of life. This makes them move ~13x
    faster than secondary progressions, useful for timing within a year.
    """
    section_header("Example 16: Tertiary Progressions")

    natal = (
        ChartBuilder.from_details("1994-01-06 11:47", (37.4419, -122.1430), name="Kate")
        .with_aspects()
        .calculate()
    )

    prog = MultiChartBuilder.progression(
        natal, age=30, progression_type="tertiary"
    ).calculate()

    natal_sun = natal.get_object("Sun")
    prog_sun = prog.chart2.get_object("Sun")

    print(f"Natal Sun: {natal_sun.longitude:.2f}° {natal_sun.sign}")
    print(
        f"Tertiary Progressed Sun (age 30): {prog_sun.longitude:.2f}° {prog_sun.sign}"
    )
    print(f"  Sun movement: {(prog_sun.longitude - natal_sun.longitude) % 360:.2f}°")
    print(
        f"  (~{(30 * 365.25 / 27.32):.0f} progressed days = ~{(30 * 365.25 / 27.32) / 365.25:.1f} years of solar motion)"
    )

    # Tertiary Moon moves much further than secondary
    natal_moon = natal.get_object("Moon")
    prog_moon = prog.chart2.get_object("Moon")
    print(f"\nNatal Moon: {natal_moon.longitude:.2f}° {natal_moon.sign}")
    print(f"Tertiary Progressed Moon: {prog_moon.longitude:.2f}° {prog_moon.sign}")

    # Works with angle methods too
    prog_sa = MultiChartBuilder.progression(
        natal, age=30, progression_type="tertiary", angle_method="solar_arc"
    ).calculate()
    print("\nTertiary + Solar Arc angle method: ✓")
    print(f"  Chart name: {prog_sa.chart2.metadata.get('name')}")


def example_17_minor_progressions():
    """
    Example 17: Minor Progressions (Lunar-Month-for-a-Year)

    Minor progressions use the time key: 1 lunar month (~27.3 days)
    of planetary motion = 1 year of life. This gives ~27x more motion
    than secondary progressions — intermediate between secondary and
    tertiary rates.
    """
    section_header("Example 17: Minor Progressions")

    natal = (
        ChartBuilder.from_details("1994-01-06 11:47", (37.4419, -122.1430), name="Kate")
        .with_aspects()
        .calculate()
    )

    prog = MultiChartBuilder.progression(
        natal, age=30, progression_type="minor"
    ).calculate()

    natal_sun = natal.get_object("Sun")
    prog_sun = prog.chart2.get_object("Sun")

    print(f"Natal Sun: {natal_sun.longitude:.2f}° {natal_sun.sign}")
    print(f"Minor Progressed Sun (age 30): {prog_sun.longitude:.2f}° {prog_sun.sign}")
    print(f"  Sun movement: {(prog_sun.longitude - natal_sun.longitude) % 360:.2f}°")
    print(
        f"  (~{30 * 27.32:.0f} progressed days = ~{30 * 27.32 / 365.25:.1f} years of solar motion)"
    )


def example_18_compare_progression_types():
    """
    Example 18: Compare All Three Progression Types

    Side-by-side comparison of secondary, tertiary, and minor progressions
    for the same natal chart and age.
    """
    section_header("Example 18: Compare Progression Types")

    natal = (
        ChartBuilder.from_details("1994-01-06 11:47", (37.4419, -122.1430), name="Kate")
        .with_aspects()
        .calculate()
    )

    natal_sun = natal.get_object("Sun")

    print(f"Natal Sun: {natal_sun.longitude:.2f}° {natal_sun.sign}")
    print("\nProgressed Sun at age 30:")
    print(f"  {'Type':<12} {'Position':<20} {'Movement':<12} {'Rate'}")
    print(f"  {'-' * 65}")

    for ptype in ["secondary", "tertiary", "minor"]:
        prog = MultiChartBuilder.progression(
            natal, age=30, progression_type=ptype
        ).calculate()
        prog_sun = prog.chart2.get_object("Sun")
        delta = (prog_sun.longitude - natal_sun.longitude) % 360
        rate = delta / 30  # degrees per year of life
        print(
            f"  {ptype:<12} {prog_sun.longitude:>7.2f}° {prog_sun.sign:<10} {delta:>7.2f}°    ~{rate:.2f}°/year"
        )

    print("\n  Secondary: 1 day = 1 year (slowest, most traditional)")
    print("  Tertiary:  1 day = 1 lunar month (~13x faster)")
    print("  Minor:     1 lunar month = 1 year (~27x faster)")

    # Cross-aspects work with all types
    print("\n  Cross-aspects per type:")
    for ptype in ["secondary", "tertiary", "minor"]:
        prog = MultiChartBuilder.progression(
            natal, age=30, progression_type=ptype
        ).calculate()
        cross = prog.get_all_cross_aspects()
        print(f"    {ptype:<12}: {len(cross)} progressed-to-natal aspects")


def example_19_triwheel_with_tertiary():
    """
    Example 19: Tri-Wheel with Tertiary Progression

    Combine natal, secondary, and tertiary progressions in one chart.
    """
    section_header("Example 19: Tri-Wheel (Natal + Secondary + Tertiary)")

    natal = (
        ChartBuilder.from_details("1994-01-06 11:47", (37.4419, -122.1430), name="Kate")
        .with_aspects()
        .calculate()
    )

    mc = (
        MultiChartBuilder.from_chart(natal, "Natal")
        .add_progression(age=30, progression_type="secondary", label="2° Progressed")
        .add_progression(age=30, progression_type="tertiary", label="3° Progressed")
        .calculate()
    )

    print(f"Charts: {mc.labels}")
    print(f"  Natal Sun: {mc.chart1.get_object('Sun').longitude:.2f}°")
    print(f"  Secondary Sun: {mc.chart2.get_object('Sun').longitude:.2f}°")
    print(f"  Tertiary Sun: {mc.chart3.get_object('Sun').longitude:.2f}°")

    output = OUTPUT_DIR / "19_triwheel_secondary_tertiary.svg"
    mc.draw(str(output)).save()
    print(f"\nSaved: {output}")


# =============================================================================
# RUN ALL EXAMPLES
# =============================================================================


def main():
    """Run all progression cookbook examples."""
    print("\n" + "=" * 60)
    print("  PROGRESSIONS COOKBOOK")
    print("  Secondary, Tertiary, and Minor Progressions")
    print("  Stellium - Computational Astrology Library")
    print("=" * 60)

    # Part 1: Basic Progressions by Age
    example_1_simple_progression_by_age()
    example_2_progressed_sun_motion()
    example_3_progressed_moon_cycle()

    # Part 2: Progressions by Target Date
    example_4_progression_by_target_date()
    example_5_current_progressions()

    # Part 3: Angle Progression Methods
    example_6_quotidian_angles()
    example_7_solar_arc_angles()
    example_8_naibod_angles()
    example_9_compare_angle_methods()

    # Part 4: Analyzing Progressions
    example_10_progressed_aspects_to_natal()
    example_11_house_overlays()

    # Part 5: Backwards Compatibility
    example_12_legacy_explicit_chart()
    example_13_tuple_format()

    # Part 6: Visualization
    example_14_draw_progression_biwheel()
    example_15_progression_with_solar_arc_biwheel()

    # Part 7: Tertiary and Minor Progressions
    example_16_tertiary_progressions()
    example_17_minor_progressions()
    example_18_compare_progression_types()
    example_19_triwheel_with_tertiary()

    print("\n" + "=" * 60)
    print("  All examples complete!")
    print(f"  Output directory: {OUTPUT_DIR}")
    print("=" * 60 + "\n")


if __name__ == "__main__":
    main()
