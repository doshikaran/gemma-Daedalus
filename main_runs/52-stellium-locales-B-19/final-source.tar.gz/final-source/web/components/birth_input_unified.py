"""
Stellium Web - Unified Birth Input Component

A birth input that can toggle between:
1. Manual entry (name, date, time, location)
2. Notable selection (search famous charts)

Features:
- Date input with validation and calendar picker
- Location input with Place/Coords toggle
- Time input with AM/PM and validation
"""

from components.date_input import create_date_input
from components.location_input import create_location_input_with_coords
from components.notable_selector import create_notable_autocomplete
from components.time_input import (
    create_time_input,
    parse_24h_to_components,
    parse_time_to_24h,
)
from config import COLORS
from i18n import wt
from nicegui import ui
from state import ChartState


def create_unified_birth_input(
    state: ChartState,
    on_change=None,
    on_notable_select=None,
    label: str = "BIRTH DETAILS",
    show_notable_toggle: bool = True,
):
    """
    Create a unified birth input with manual/notable toggle.

    Args:
        state: ChartState instance to bind to
        on_change: Callback when any field changes
        on_notable_select: Callback when a notable is selected (receives Notable object)
        label: Section label
        show_notable_toggle: Whether to show the toggle (disable for explore page)

    Returns:
        Reference to the container element.
    """
    _ = wt()

    # Local state for input mode
    mode_state = {"mode": "manual"}  # "manual" or "notable"

    # UI references for refreshing
    refs = {
        "form_container": None,
    }

    def update_field(field: str, value):
        setattr(state, field, value)
        if on_change:
            on_change()

    def on_time_change(hour: str, minute: str, period: str):
        """Convert time components to 24h format and update state."""
        time_24h = parse_time_to_24h(hour, minute, period)
        update_field("time", time_24h)

    def on_location_change(value: str):
        """Update location in state."""
        update_field("location", value)

    def on_coords_change(lat: float | None, lon: float | None):
        """Update coordinates in state."""
        if lat is not None and lon is not None:
            # Store as coordinate string for the location field
            state.location = f"{lat}, {lon}"
            state.latitude = lat
            state.longitude = lon
            if on_change:
                on_change()

    def on_date_change(date_str: str):
        """Update date in state."""
        update_field("date", date_str)

    def on_notable_selected(notable):
        """Handle notable selection - fill in all fields from notable."""
        # Fill state from notable
        state.name = notable.name
        state.location = notable.location.name

        # Format date
        dt = notable.datetime.local_datetime
        state.date = dt.strftime("%Y-%m-%d")
        state.time = dt.strftime("%H:%M")
        state.time_unknown = False

        if on_change:
            on_change()

        if on_notable_select:
            on_notable_select(notable)

        # Refresh the form to show filled values
        refresh_form()

        ui.notify(_("Loaded: ") + notable.name, type="positive")

    def on_mode_change(e):
        """Handle mode toggle change."""
        mode_state["mode"] = e.value
        refresh_form()

    def refresh_form():
        """Refresh the form based on current mode."""
        if refs["form_container"]:
            refs["form_container"].clear()
            with refs["form_container"]:
                create_form_content()

    def create_form_content():
        """Create the form content based on mode."""
        # Parse existing time to components
        hour, minute, period = parse_24h_to_components(state.time)

        if mode_state["mode"] == "notable":
            # Notable search mode
            with ui.column().classes("gap-4 w-full"):
                ui.label(_("Search famous charts:")).classes("text-sm").style(
                    f"color: {COLORS['text_muted']}"
                )
                create_notable_autocomplete(
                    on_select=on_notable_selected,
                    placeholder=_("Type a name..."),
                )

                # Show current selection if any
                if state.name:
                    with (
                        ui.element("div")
                        .classes("p-3 rounded mt-2")
                        .style(
                            f"background-color: {COLORS['cream']}; border: 1px solid {COLORS['border']};"
                        )
                    ):
                        ui.label(_("Selected:")).classes("text-xs").style(
                            f"color: {COLORS['text_muted']}"
                        )
                        ui.label(state.name).classes("font-medium").style(
                            f"color: {COLORS['text']}"
                        )
                        if state.date:
                            ui.label(f"{state.date} {state.time}").classes(
                                "text-sm"
                            ).style(f"color: {COLORS['text_muted']}")
                        if state.location:
                            ui.label(state.location).classes("text-sm").style(
                                f"color: {COLORS['accent']}"
                            )

        else:
            # Manual entry mode
            with ui.column().classes("gap-6 w-full"):
                # Name field
                with ui.row().classes("items-center gap-4 w-full"):
                    ui.label(_("Name:")).classes("w-28 flex-shrink-0 text-base").style(
                        f"color: {COLORS['text']}"
                    )
                    ui.input(
                        value=state.name,
                        placeholder=_("(optional)"),
                        on_change=lambda e: update_field("name", e.value),
                    ).classes("minimal-input flex-grow").props("borderless dense")

                # Location field with Place/Coords toggle
                with ui.row().classes("items-start gap-4 w-full"):
                    ui.label(_("Birth place:")).classes(
                        "w-28 flex-shrink-0 text-base mt-2"
                    ).style(f"color: {COLORS['text']}")
                    with ui.element("div").classes("flex-grow"):
                        # Check if state has coordinates already
                        initial_lat = getattr(state, "latitude", None)
                        initial_lon = getattr(state, "longitude", None)
                        create_location_input_with_coords(
                            value=state.location,
                            latitude=initial_lat,
                            longitude=initial_lon,
                            placeholder=_("City, State, Country"),
                            on_change=on_location_change,
                            on_coords_change=on_coords_change,
                        )

                # Date field with validation and picker
                with ui.row().classes("items-center gap-4 w-full"):
                    ui.label(_("Birth date:")).classes(
                        "w-28 flex-shrink-0 text-base"
                    ).style(f"color: {COLORS['text']}")
                    with ui.element("div").classes("flex-grow"):
                        create_date_input(
                            value=state.date,
                            placeholder="YYYY-MM-DD",
                            on_change=on_date_change,
                        )

                # Time field with hour/minute/AM-PM
                with ui.row().classes("items-center gap-4 w-full"):
                    ui.label(_("Birth time:")).classes(
                        "w-28 flex-shrink-0 text-base"
                    ).style(f"color: {COLORS['text']}")
                    with ui.element("div").classes("flex-grow"):
                        create_time_input(
                            hour_value=hour,
                            minute_value=minute,
                            period_value=period,
                            on_change=on_time_change,
                            disabled=state.time_unknown,
                        )

                # Unknown time checkbox
                ui.checkbox(
                    _("I don't know my birth time"),
                    value=state.time_unknown,
                    on_change=lambda e: update_field("time_unknown", e.value),
                ).classes("mt-2").style(f"color: {COLORS['text_muted']}")

    # Build the UI
    with ui.element("div").classes("w-full") as container:
        # Section label with optional toggle
        with ui.row().classes("items-center justify-between w-full mb-4"):
            ui.label(f"☆  {label}").classes(
                "font-display text-xs tracking-[0.2em]"
            ).style(f"color: {COLORS['primary']}")

            if show_notable_toggle:
                ui.toggle(
                    {"manual": _("Enter"), "notable": _("Famous")},
                    value=mode_state["mode"],
                    on_change=on_mode_change,
                ).props("dense no-caps")

        # Form container
        refs["form_container"] = ui.element("div").classes("w-full")
        with refs["form_container"]:
            create_form_content()

    return container
